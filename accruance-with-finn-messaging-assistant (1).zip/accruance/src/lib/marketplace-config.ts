// Marketplace Feature Flags and Configuration
export const MARKETPLACE_CONFIG = {
  // Feature flags (controlled by environment variables)
  ENABLED: process.env.MARKETPLACE_ENABLED === 'true',
  BOOKINGS_ENABLED: process.env.MARKETPLACE_BOOKINGS_ENABLED === 'true',
  PAYMENTS_ENABLED: process.env.MARKETPLACE_PAYMENTS_ENABLED === 'true',
  REVIEWS_ENABLED: process.env.MARKETPLACE_REVIEWS_ENABLED === 'true',
  
  // Configuration values
  COMMISSION_RATE: parseFloat(process.env.MARKETPLACE_COMMISSION_RATE || '0.08'),
  MIN_SERVICE_PRICE: parseFloat(process.env.MARKETPLACE_MIN_SERVICE_PRICE || '50'),
  FEATURED_LISTING_PRICE: parseFloat(process.env.MARKETPLACE_FEATURED_LISTING_PRICE || '99'),
  
  // Stripe Connect configuration
  STRIPE_CONNECT_CLIENT_ID: process.env.STRIPE_CONNECT_CLIENT_ID,
  
  // User thresholds for marketplace activation
  ACTIVATION_THRESHOLDS: {
    TOTAL_USERS: 1000,
    VERIFIED_PROFESSIONALS: 100,
    MONTHLY_CONNECTIONS: 500,
    MONTHLY_TRANSACTION_VOLUME: 50000
  }
}

// Service categories configuration
export const SERVICE_CATEGORIES = [
  {
    id: 'tax-preparation',
    name: 'Tax Preparation',
    description: 'Individual and business tax filing services',
    icon: 'calculator',
    popular: true
  },
  {
    id: 'bookkeeping',
    name: 'Bookkeeping & Accounting',
    description: 'Monthly bookkeeping and financial statement preparation',
    icon: 'book-open',
    popular: true
  },
  {
    id: 'financial-planning',
    name: 'Financial Planning',
    description: 'Personal and business financial planning services',
    icon: 'trending-up',
    popular: true
  },
  {
    id: 'business-consulting',
    name: 'Business Consulting',
    description: 'Strategic business and financial consulting',
    icon: 'briefcase',
    popular: false
  },
  {
    id: 'audit-compliance',
    name: 'Audit & Compliance',
    description: 'Financial audits and regulatory compliance',
    icon: 'shield-check',
    popular: false
  },
  {
    id: 'payroll',
    name: 'Payroll Services',
    description: 'Payroll processing and management',
    icon: 'users',
    popular: false
  },
  {
    id: 'cfo-services',
    name: 'CFO Services',
    description: 'Part-time and fractional CFO services',
    icon: 'user-tie',
    popular: false
  },
  {
    id: 'business-formation',
    name: 'Business Formation',
    description: 'Entity formation and business setup',
    icon: 'building',
    popular: false
  }
]

// Service types configuration
export const SERVICE_TYPES = [
  {
    id: 'hourly',
    name: 'Hourly Consulting',
    description: 'Pay by the hour for consulting services',
    icon: 'clock'
  },
  {
    id: 'fixed',
    name: 'Fixed Price Project',
    description: 'One-time project with fixed pricing',
    icon: 'tag'
  },
  {
    id: 'package',
    name: 'Service Package',
    description: 'Bundled services with comprehensive offerings',
    icon: 'package'
  },
  {
    id: 'retainer',
    name: 'Monthly Retainer',
    description: 'Ongoing monthly services',
    icon: 'calendar'
  }
]

// Professional tier configuration
export const PROFESSIONAL_TIERS = [
  {
    id: 'basic',
    name: 'Basic',
    price: 0,
    commission: 0.12,
    features: [
      'Basic profile listing',
      'Up to 5 services',
      'Standard support',
      'Basic analytics'
    ]
  },
  {
    id: 'standard',
    name: 'Standard',
    price: 29,
    commission: 0.08,
    features: [
      'Enhanced profile with portfolio',
      'Unlimited services',
      'Priority support',
      'Advanced analytics',
      'Featured in search results'
    ]
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 99,
    commission: 0.05,
    features: [
      'Premium profile with verification badge',
      'Unlimited services and packages',
      'Dedicated account manager',
      'Advanced analytics and insights',
      'Top placement in search results',
      'Custom service packages',
      'Priority customer matching'
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 199,
    commission: 0.03,
    features: [
      'White-label marketplace access',
      'Custom branding options',
      'API access for integrations',
      'Advanced team management',
      'Custom reporting and analytics',
      'Dedicated success manager',
      'Priority placement and matching'
    ]
  }
]

// Marketplace status checks
export const checkMarketplaceStatus = () => {
  return {
    isEnabled: MARKETPLACE_CONFIG.ENABLED,
    canBook: MARKETPLACE_CONFIG.ENABLED && MARKETPLACE_CONFIG.BOOKINGS_ENABLED,
    canPay: MARKETPLACE_CONFIG.ENABLED && MARKETPLACE_CONFIG.PAYMENTS_ENABLED,
    canReview: MARKETPLACE_CONFIG.ENABLED && MARKETPLACE_CONFIG.REVIEWS_ENABLED
  }
}

// Helper function to get commission rate by tier
export const getCommissionRate = (tier: string = 'basic'): number => {
  const tierConfig = PROFESSIONAL_TIERS.find(t => t.id === tier)
  return tierConfig?.commission || MARKETPLACE_CONFIG.COMMISSION_RATE
}

// Helper function to calculate marketplace fees
export const calculateMarketplaceFees = (amount: number, tier: string = 'basic') => {
  const commissionRate = getCommissionRate(tier)
  const platformFee = amount * commissionRate
  const professionalAmount = amount - platformFee
  
  return {
    totalAmount: amount,
    platformFee: Math.round(platformFee * 100) / 100,
    professionalAmount: Math.round(professionalAmount * 100) / 100,
    commissionRate
  }
}

// Marketplace activation check
export const shouldActivateMarketplace = async (metrics: {
  totalUsers: number
  verifiedProfessionals: number
  monthlyConnections: number
  monthlyTransactionVolume: number
}) => {
  const thresholds = MARKETPLACE_CONFIG.ACTIVATION_THRESHOLDS
  
  return (
    metrics.totalUsers >= thresholds.TOTAL_USERS &&
    metrics.verifiedProfessionals >= thresholds.VERIFIED_PROFESSIONALS &&
    metrics.monthlyConnections >= thresholds.MONTHLY_CONNECTIONS &&
    metrics.monthlyTransactionVolume >= thresholds.MONTHLY_TRANSACTION_VOLUME
  )
}

// Default marketplace settings for database
export const DEFAULT_MARKETPLACE_SETTINGS = [
  {
    key: 'marketplace_enabled',
    value: 'false',
    type: 'boolean',
    description: 'Enable/disable marketplace functionality',
    public: true
  },
  {
    key: 'marketplace_bookings_enabled',
    value: 'false',
    type: 'boolean',
    description: 'Enable/disable service bookings',
    public: true
  },
  {
    key: 'marketplace_payments_enabled',
    value: 'false',
    type: 'boolean',
    description: 'Enable/disable marketplace payments',
    public: false
  },
  {
    key: 'commission_rate',
    value: '0.08',
    type: 'number',
    description: 'Platform commission rate (8%)',
    public: false
  },
  {
    key: 'minimum_service_price',
    value: '50',
    type: 'number',
    description: 'Minimum service price in USD',
    public: true
  },
  {
    key: 'featured_listing_price',
    value: '99',
    type: 'number',
    description: 'Monthly price for featured listings',
    public: false
  },
  {
    key: 'auto_approval_enabled',
    value: 'false',
    type: 'boolean',
    description: 'Auto-approve new services',
    public: false
  },
  {
    key: 'dispute_resolution_days',
    value: '7',
    type: 'number',
    description: 'Days to resolve disputes',
    public: true
  }
]

