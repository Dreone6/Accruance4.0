import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

export interface InvoiceItem {
  id: string
  description: string
  quantity: number
  unit_price: number
  total: number
}

export interface InvoiceData {
  id: string
  invoice_number: string
  organization_id: string
  client_id: string
  client_name: string
  client_email: string
  client_address: string
  issue_date: string
  due_date: string
  items: InvoiceItem[]
  subtotal: number
  tax_rate: number
  tax_amount: number
  total_amount: number
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled'
  notes?: string
  payment_terms?: string
  created_at: string
  updated_at: string
  paid_at?: string
  payment_method?: string
  stripe_payment_intent_id?: string
}

export interface Client {
  id: string
  organization_id: string
  name: string
  email: string
  phone?: string
  address: string
  city: string
  state: string
  zip_code: string
  country: string
  created_at: string
  updated_at: string
}

export class InvoiceManager {
  // Generate invoice number
  static generateInvoiceNumber(organizationId: string): string {
    const timestamp = Date.now()
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0')
    return `INV-${timestamp}-${random}`
  }

  // Create new invoice
  static async createInvoice(invoiceData: Omit<InvoiceData, 'id' | 'created_at' | 'updated_at'>): Promise<InvoiceData> {
    const invoice: InvoiceData = {
      ...invoiceData,
      id: `invoice_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }

    // In a real implementation, this would save to Supabase
    console.log('Creating invoice:', invoice)
    return invoice
  }

  // Get invoices for organization
  static async getInvoices(organizationId: string, filters?: {
    status?: InvoiceData['status']
    client_id?: string
    date_from?: string
    date_to?: string
  }): Promise<{ invoices: InvoiceData[], total: number }> {
    // Mock data for demonstration
    const mockInvoices: InvoiceData[] = [
      {
        id: 'inv_1',
        invoice_number: 'INV-2024-001',
        organization_id: organizationId,
        client_id: 'client_1',
        client_name: 'Acme Corporation',
        client_email: 'billing@acme.com',
        client_address: '123 Business St, Suite 100\nNew York, NY 10001',
        issue_date: '2024-01-15',
        due_date: '2024-02-14',
        items: [
          {
            id: 'item_1',
            description: 'Web Development Services',
            quantity: 40,
            unit_price: 125.00,
            total: 5000.00
          },
          {
            id: 'item_2',
            description: 'UI/UX Design',
            quantity: 20,
            unit_price: 100.00,
            total: 2000.00
          }
        ],
        subtotal: 7000.00,
        tax_rate: 0.08,
        tax_amount: 560.00,
        total_amount: 7560.00,
        status: 'sent',
        payment_terms: 'Net 30',
        notes: 'Thank you for your business!',
        created_at: '2024-01-15T10:00:00Z',
        updated_at: '2024-01-15T10:00:00Z'
      },
      {
        id: 'inv_2',
        invoice_number: 'INV-2024-002',
        organization_id: organizationId,
        client_id: 'client_2',
        client_name: 'TechStart Inc.',
        client_email: 'finance@techstart.com',
        client_address: '456 Innovation Ave\nSan Francisco, CA 94105',
        issue_date: '2024-01-20',
        due_date: '2024-02-19',
        items: [
          {
            id: 'item_3',
            description: 'Monthly Consulting',
            quantity: 1,
            unit_price: 3500.00,
            total: 3500.00
          }
        ],
        subtotal: 3500.00,
        tax_rate: 0.0875,
        tax_amount: 306.25,
        total_amount: 3806.25,
        status: 'paid',
        payment_terms: 'Net 15',
        created_at: '2024-01-20T14:30:00Z',
        updated_at: '2024-01-25T09:15:00Z',
        paid_at: '2024-01-25T09:15:00Z',
        payment_method: 'Credit Card'
      },
      {
        id: 'inv_3',
        invoice_number: 'INV-2024-003',
        organization_id: organizationId,
        client_id: 'client_3',
        client_name: 'Global Solutions LLC',
        client_email: 'accounts@globalsolutions.com',
        client_address: '789 Enterprise Blvd\nChicago, IL 60601',
        issue_date: '2024-01-10',
        due_date: '2024-01-25',
        items: [
          {
            id: 'item_4',
            description: 'Software License',
            quantity: 5,
            unit_price: 299.00,
            total: 1495.00
          },
          {
            id: 'item_5',
            description: 'Setup & Training',
            quantity: 8,
            unit_price: 150.00,
            total: 1200.00
          }
        ],
        subtotal: 2695.00,
        tax_rate: 0.10,
        tax_amount: 269.50,
        total_amount: 2964.50,
        status: 'overdue',
        payment_terms: 'Net 15',
        notes: 'Please remit payment as soon as possible.',
        created_at: '2024-01-10T11:00:00Z',
        updated_at: '2024-01-10T11:00:00Z'
      }
    ]

    // Apply filters
    let filteredInvoices = mockInvoices
    if (filters?.status) {
      filteredInvoices = filteredInvoices.filter(inv => inv.status === filters.status)
    }
    if (filters?.client_id) {
      filteredInvoices = filteredInvoices.filter(inv => inv.client_id === filters.client_id)
    }

    return {
      invoices: filteredInvoices,
      total: filteredInvoices.length
    }
  }

  // Update invoice
  static async updateInvoice(invoiceId: string, updates: Partial<InvoiceData>): Promise<InvoiceData> {
    // In a real implementation, this would update in Supabase
    console.log('Updating invoice:', invoiceId, updates)
    
    // Mock updated invoice
    const updatedInvoice: InvoiceData = {
      id: invoiceId,
      invoice_number: 'INV-2024-001',
      organization_id: 'org_1',
      client_id: 'client_1',
      client_name: 'Acme Corporation',
      client_email: 'billing@acme.com',
      client_address: '123 Business St, Suite 100\nNew York, NY 10001',
      issue_date: '2024-01-15',
      due_date: '2024-02-14',
      items: [],
      subtotal: 0,
      tax_rate: 0,
      tax_amount: 0,
      total_amount: 0,
      status: 'draft',
      created_at: '2024-01-15T10:00:00Z',
      updated_at: new Date().toISOString(),
      ...updates
    }

    return updatedInvoice
  }

  // Delete invoice
  static async deleteInvoice(invoiceId: string): Promise<void> {
    // In a real implementation, this would delete from Supabase
    console.log('Deleting invoice:', invoiceId)
  }

  // Generate PDF from HTML element
  static async generatePDF(invoiceData: InvoiceData, elementId: string): Promise<Blob> {
    const element = document.getElementById(elementId)
    if (!element) {
      throw new Error('Invoice element not found')
    }

    try {
      // Capture the element as canvas
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff'
      })

      // Create PDF
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      })

      const imgData = canvas.toDataURL('image/png')
      const imgWidth = 210 // A4 width in mm
      const pageHeight = 295 // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width
      let heightLeft = imgHeight

      let position = 0

      // Add first page
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight

      // Add additional pages if needed
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight
        pdf.addPage()
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
        heightLeft -= pageHeight
      }

      return pdf.output('blob')
    } catch (error) {
      console.error('Error generating PDF:', error)
      throw new Error('Failed to generate PDF')
    }
  }

  // Send invoice via email
  static async sendInvoice(invoiceId: string, recipientEmail: string): Promise<void> {
    // In a real implementation, this would send via email service
    console.log('Sending invoice:', invoiceId, 'to:', recipientEmail)
    
    // Mock email sending
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    // Update invoice status to 'sent'
    await this.updateInvoice(invoiceId, { 
      status: 'sent',
      updated_at: new Date().toISOString()
    })
  }

  // Mark invoice as paid
  static async markAsPaid(invoiceId: string, paymentMethod: string, paymentIntentId?: string): Promise<InvoiceData> {
    const updates: Partial<InvoiceData> = {
      status: 'paid',
      paid_at: new Date().toISOString(),
      payment_method: paymentMethod,
      updated_at: new Date().toISOString()
    }

    if (paymentIntentId) {
      updates.stripe_payment_intent_id = paymentIntentId
    }

    return await this.updateInvoice(invoiceId, updates)
  }

  // Get invoice statistics
  static async getInvoiceStats(organizationId: string): Promise<{
    total_invoices: number
    total_amount: number
    paid_amount: number
    pending_amount: number
    overdue_amount: number
    draft_count: number
    sent_count: number
    paid_count: number
    overdue_count: number
  }> {
    const { invoices } = await this.getInvoices(organizationId)

    const stats = {
      total_invoices: invoices.length,
      total_amount: 0,
      paid_amount: 0,
      pending_amount: 0,
      overdue_amount: 0,
      draft_count: 0,
      sent_count: 0,
      paid_count: 0,
      overdue_count: 0
    }

    invoices.forEach(invoice => {
      stats.total_amount += invoice.total_amount

      switch (invoice.status) {
        case 'draft':
          stats.draft_count++
          break
        case 'sent':
          stats.sent_count++
          stats.pending_amount += invoice.total_amount
          break
        case 'paid':
          stats.paid_count++
          stats.paid_amount += invoice.total_amount
          break
        case 'overdue':
          stats.overdue_count++
          stats.overdue_amount += invoice.total_amount
          break
      }
    })

    return stats
  }

  // Client management
  static async getClients(organizationId: string): Promise<{ clients: Client[], total: number }> {
    // Mock client data
    const mockClients: Client[] = [
      {
        id: 'client_1',
        organization_id: organizationId,
        name: 'Acme Corporation',
        email: 'billing@acme.com',
        phone: '+1 (555) 123-4567',
        address: '123 Business St, Suite 100',
        city: 'New York',
        state: 'NY',
        zip_code: '10001',
        country: 'United States',
        created_at: '2024-01-01T00:00:00Z',
        updated_at: '2024-01-01T00:00:00Z'
      },
      {
        id: 'client_2',
        organization_id: organizationId,
        name: 'TechStart Inc.',
        email: 'finance@techstart.com',
        phone: '+1 (555) 987-6543',
        address: '456 Innovation Ave',
        city: 'San Francisco',
        state: 'CA',
        zip_code: '94105',
        country: 'United States',
        created_at: '2024-01-05T00:00:00Z',
        updated_at: '2024-01-05T00:00:00Z'
      },
      {
        id: 'client_3',
        organization_id: organizationId,
        name: 'Global Solutions LLC',
        email: 'accounts@globalsolutions.com',
        phone: '+1 (555) 456-7890',
        address: '789 Enterprise Blvd',
        city: 'Chicago',
        state: 'IL',
        zip_code: '60601',
        country: 'United States',
        created_at: '2024-01-10T00:00:00Z',
        updated_at: '2024-01-10T00:00:00Z'
      }
    ]

    return {
      clients: mockClients,
      total: mockClients.length
    }
  }

  static async createClient(clientData: Omit<Client, 'id' | 'created_at' | 'updated_at'>): Promise<Client> {
    const client: Client = {
      ...clientData,
      id: `client_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }

    // In a real implementation, this would save to Supabase
    console.log('Creating client:', client)
    return client
  }

  // Format currency
  static formatCurrency(amount: number, currency: string = 'USD'): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount)
  }

  // Format date
  static formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  // Calculate due date
  static calculateDueDate(issueDate: string, paymentTerms: string): string {
    const issue = new Date(issueDate)
    let daysToAdd = 30 // Default to 30 days

    // Parse payment terms
    if (paymentTerms.includes('Net 15')) {
      daysToAdd = 15
    } else if (paymentTerms.includes('Net 30')) {
      daysToAdd = 30
    } else if (paymentTerms.includes('Net 60')) {
      daysToAdd = 60
    } else if (paymentTerms.includes('Due on receipt')) {
      daysToAdd = 0
    }

    const dueDate = new Date(issue)
    dueDate.setDate(dueDate.getDate() + daysToAdd)
    return dueDate.toISOString().split('T')[0]
  }

  // Get status color for UI
  static getStatusColor(status: InvoiceData['status']): string {
    switch (status) {
      case 'draft':
        return 'text-gray-600 bg-gray-100'
      case 'sent':
        return 'text-blue-600 bg-blue-100'
      case 'paid':
        return 'text-green-600 bg-green-100'
      case 'overdue':
        return 'text-red-600 bg-red-100'
      case 'cancelled':
        return 'text-gray-600 bg-gray-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }
}

