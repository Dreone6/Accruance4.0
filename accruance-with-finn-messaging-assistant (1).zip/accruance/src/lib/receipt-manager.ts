import Tesseract from 'tesseract.js'
import { BookkeepingEngine } from './bookkeeping'

export interface ReceiptData {
  id: string
  organization_id: string
  file_name: string
  file_size: number
  file_type: string
  file_url: string
  upload_date: string
  processed_date?: string
  status: 'uploading' | 'processing' | 'completed' | 'failed'
  extracted_data?: {
    merchant_name?: string
    date?: string
    total_amount?: number
    tax_amount?: number
    items?: Array<{
      description: string
      quantity?: number
      unit_price?: number
      total?: number
    }>
    payment_method?: string
    receipt_number?: string
  }
  confidence_score?: number
  transaction_id?: string
  created_by: string
  notes?: string
}

export interface OCRResult {
  text: string
  confidence: number
  extracted_data: ReceiptData['extracted_data']
}

export class ReceiptManager {
  // Upload receipt file and create initial record
  static async uploadReceipt(
    organizationId: string, 
    file: File, 
    userId: string
  ): Promise<ReceiptData> {
    const receiptId = `receipt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    
    // Create receipt record
    const receipt: ReceiptData = {
      id: receiptId,
      organization_id: organizationId,
      file_name: file.name,
      file_size: file.size,
      file_type: file.type,
      file_url: URL.createObjectURL(file), // In production, this would be a cloud storage URL
      upload_date: new Date().toISOString(),
      status: 'uploading',
      created_by: userId
    }

    // Simulate upload delay
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    receipt.status = 'processing'
    
    // Process OCR
    try {
      const ocrResult = await this.processOCR(file)
      receipt.extracted_data = ocrResult.extracted_data
      receipt.confidence_score = ocrResult.confidence
      receipt.processed_date = new Date().toISOString()
      receipt.status = 'completed'
      
      // Auto-create transaction if confidence is high enough
      if (ocrResult.confidence > 0.7 && receipt.extracted_data?.total_amount) {
        const transaction = await this.createTransactionFromReceipt(receipt)
        receipt.transaction_id = transaction.id
      }
    } catch (error) {
      console.error('OCR processing failed:', error)
      receipt.status = 'failed'
    }

    return receipt
  }

  // Process OCR on receipt image
  static async processOCR(file: File): Promise<OCRResult> {
    try {
      const { data: { text, confidence } } = await Tesseract.recognize(file, 'eng', {
        logger: m => console.log(m)
      })

      const extractedData = this.parseReceiptText(text)
      
      return {
        text,
        confidence: confidence / 100, // Convert to 0-1 scale
        extracted_data: extractedData
      }
    } catch (error) {
      throw new Error(`OCR processing failed: ${error}`)
    }
  }

  // Parse OCR text to extract structured data
  static parseReceiptText(text: string): ReceiptData['extracted_data'] {
    const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0)
    
    const extractedData: ReceiptData['extracted_data'] = {
      items: []
    }

    // Extract merchant name (usually first few lines)
    const merchantPatterns = [
      /^([A-Z][A-Z\s&]+[A-Z])$/,
      /^([A-Z][a-zA-Z\s&]+)$/
    ]
    
    for (let i = 0; i < Math.min(3, lines.length); i++) {
      for (const pattern of merchantPatterns) {
        const match = lines[i].match(pattern)
        if (match && match[1].length > 2) {
          extractedData.merchant_name = match[1].trim()
          break
        }
      }
      if (extractedData.merchant_name) break
    }

    // Extract total amount
    const totalPatterns = [
      /(?:total|amount|sum)[\s:]*\$?(\d+\.?\d*)/i,
      /\$(\d+\.\d{2})\s*(?:total|amount)?/i,
      /(\d+\.\d{2})\s*(?:total|amount|sum)/i
    ]

    for (const line of lines) {
      for (const pattern of totalPatterns) {
        const match = line.match(pattern)
        if (match) {
          const amount = parseFloat(match[1])
          if (amount > 0 && amount < 10000) { // Reasonable range
            extractedData.total_amount = amount
            break
          }
        }
      }
      if (extractedData.total_amount) break
    }

    // Extract date
    const datePatterns = [
      /(\d{1,2}\/\d{1,2}\/\d{2,4})/,
      /(\d{1,2}-\d{1,2}-\d{2,4})/,
      /(\d{4}-\d{1,2}-\d{1,2})/
    ]

    for (const line of lines) {
      for (const pattern of datePatterns) {
        const match = line.match(pattern)
        if (match) {
          try {
            const date = new Date(match[1])
            if (!isNaN(date.getTime())) {
              extractedData.date = date.toISOString().split('T')[0]
              break
            }
          } catch (e) {
            // Invalid date, continue
          }
        }
      }
      if (extractedData.date) break
    }

    // Extract tax amount
    const taxPatterns = [
      /(?:tax|hst|gst|vat)[\s:]*\$?(\d+\.?\d*)/i,
      /\$(\d+\.\d{2})\s*(?:tax|hst|gst|vat)/i
    ]

    for (const line of lines) {
      for (const pattern of taxPatterns) {
        const match = line.match(pattern)
        if (match) {
          const tax = parseFloat(match[1])
          if (tax > 0 && tax < (extractedData.total_amount || 1000)) {
            extractedData.tax_amount = tax
            break
          }
        }
      }
      if (extractedData.tax_amount) break
    }

    // Extract receipt number
    const receiptNumberPatterns = [
      /(?:receipt|ref|order)[\s#:]*([A-Z0-9]+)/i,
      /#([A-Z0-9]+)/
    ]

    for (const line of lines) {
      for (const pattern of receiptNumberPatterns) {
        const match = line.match(pattern)
        if (match && match[1].length >= 3) {
          extractedData.receipt_number = match[1]
          break
        }
      }
      if (extractedData.receipt_number) break
    }

    // Extract line items (simplified)
    const itemPatterns = [
      /^(.+?)\s+\$?(\d+\.\d{2})$/,
      /^(.+?)\s+(\d+)\s*x\s*\$?(\d+\.\d{2})\s*=?\s*\$?(\d+\.\d{2})$/
    ]

    for (const line of lines) {
      for (const pattern of itemPatterns) {
        const match = line.match(pattern)
        if (match) {
          if (pattern === itemPatterns[0]) {
            // Simple item with price
            const description = match[1].trim()
            const price = parseFloat(match[2])
            if (description.length > 2 && price > 0 && price < 1000) {
              extractedData.items?.push({
                description,
                unit_price: price,
                total: price,
                quantity: 1
              })
            }
          } else {
            // Item with quantity
            const description = match[1].trim()
            const quantity = parseInt(match[2])
            const unitPrice = parseFloat(match[3])
            const total = parseFloat(match[4])
            if (description.length > 2 && quantity > 0 && unitPrice > 0) {
              extractedData.items?.push({
                description,
                quantity,
                unit_price: unitPrice,
                total
              })
            }
          }
        }
      }
    }

    return extractedData
  }

  // Create transaction from receipt data
  static async createTransactionFromReceipt(receipt: ReceiptData) {
    if (!receipt.extracted_data?.total_amount) {
      throw new Error('No amount found in receipt')
    }

    const transactionData = {
      date: receipt.extracted_data.date || new Date().toISOString().split('T')[0],
      description: receipt.extracted_data.merchant_name || `Receipt ${receipt.file_name}`,
      amount: -Math.abs(receipt.extracted_data.total_amount), // Negative for expense
      type: 'expense' as const,
      category_id: await this.suggestCategory(receipt.extracted_data),
      account_id: 'acc_default', // Default account
      reference: receipt.extracted_data.receipt_number || receipt.id,
      notes: `Auto-created from receipt: ${receipt.file_name}`
    }

    return await BookkeepingEngine.createTransaction(receipt.organization_id, transactionData)
  }

  // Suggest category based on merchant and items
  static async suggestCategory(data: ReceiptData['extracted_data']): Promise<string> {
    const merchantName = data?.merchant_name?.toLowerCase() || ''
    const items = data?.items || []
    
    // Simple category mapping based on merchant patterns
    const categoryMappings = [
      { pattern: /(?:starbucks|coffee|cafe|tim hortons)/i, category: 'cat_meals' },
      { pattern: /(?:shell|exxon|chevron|bp|gas|fuel)/i, category: 'cat_fuel' },
      { pattern: /(?:staples|office depot|amazon|supplies)/i, category: 'cat_office_supplies' },
      { pattern: /(?:restaurant|food|pizza|burger|dining)/i, category: 'cat_meals' },
      { pattern: /(?:uber|lyft|taxi|transport)/i, category: 'cat_travel' },
      { pattern: /(?:hotel|motel|accommodation)/i, category: 'cat_travel' },
      { pattern: /(?:software|subscription|saas)/i, category: 'cat_software' }
    ]

    for (const mapping of categoryMappings) {
      if (mapping.pattern.test(merchantName)) {
        return mapping.category
      }
    }

    // Check items for category hints
    const itemText = items.map(item => item.description).join(' ').toLowerCase()
    for (const mapping of categoryMappings) {
      if (mapping.pattern.test(itemText)) {
        return mapping.category
      }
    }

    return 'cat_uncategorized'
  }

  // Get receipts for organization
  static async getReceipts(organizationId: string, filters?: {
    status?: string
    dateFrom?: string
    dateTo?: string
    search?: string
  }): Promise<{ receipts: ReceiptData[], total: number }> {
    // Mock data for demonstration
    const mockReceipts: ReceiptData[] = [
      {
        id: 'receipt_001',
        organization_id: organizationId,
        file_name: 'starbucks_receipt.jpg',
        file_size: 245760,
        file_type: 'image/jpeg',
        file_url: '/mock/starbucks_receipt.jpg',
        upload_date: '2024-12-10T09:30:00Z',
        processed_date: '2024-12-10T09:31:00Z',
        status: 'completed',
        extracted_data: {
          merchant_name: 'STARBUCKS',
          date: '2024-12-10',
          total_amount: 12.45,
          tax_amount: 1.62,
          receipt_number: 'SB123456',
          items: [
            { description: 'Grande Latte', quantity: 1, unit_price: 5.95, total: 5.95 },
            { description: 'Blueberry Muffin', quantity: 1, unit_price: 4.88, total: 4.88 }
          ]
        },
        confidence_score: 0.92,
        transaction_id: 'txn_001',
        created_by: 'user_123'
      },
      {
        id: 'receipt_002',
        organization_id: organizationId,
        file_name: 'office_supplies.pdf',
        file_size: 156432,
        file_type: 'application/pdf',
        file_url: '/mock/office_supplies.pdf',
        upload_date: '2024-12-09T14:15:00Z',
        processed_date: '2024-12-09T14:16:30Z',
        status: 'completed',
        extracted_data: {
          merchant_name: 'STAPLES',
          date: '2024-12-09',
          total_amount: 89.99,
          tax_amount: 11.70,
          receipt_number: 'ST789012',
          items: [
            { description: 'Copy Paper 500 sheets', quantity: 2, unit_price: 12.99, total: 25.98 },
            { description: 'Blue Pens Pack', quantity: 3, unit_price: 8.99, total: 26.97 },
            { description: 'Desk Organizer', quantity: 1, unit_price: 25.34, total: 25.34 }
          ]
        },
        confidence_score: 0.88,
        transaction_id: 'txn_002',
        created_by: 'user_123'
      },
      {
        id: 'receipt_003',
        organization_id: organizationId,
        file_name: 'gas_station.jpg',
        file_size: 198765,
        file_type: 'image/jpeg',
        file_url: '/mock/gas_station.jpg',
        upload_date: '2024-12-08T16:45:00Z',
        status: 'processing',
        created_by: 'user_123'
      }
    ]

    // Apply filters
    let filteredReceipts = mockReceipts

    if (filters?.status && filters.status !== 'all') {
      filteredReceipts = filteredReceipts.filter(r => r.status === filters.status)
    }

    if (filters?.search) {
      const search = filters.search.toLowerCase()
      filteredReceipts = filteredReceipts.filter(r => 
        r.file_name.toLowerCase().includes(search) ||
        r.extracted_data?.merchant_name?.toLowerCase().includes(search) ||
        r.extracted_data?.receipt_number?.toLowerCase().includes(search)
      )
    }

    if (filters?.dateFrom) {
      filteredReceipts = filteredReceipts.filter(r => r.upload_date >= filters.dateFrom!)
    }

    if (filters?.dateTo) {
      filteredReceipts = filteredReceipts.filter(r => r.upload_date <= filters.dateTo!)
    }

    return {
      receipts: filteredReceipts,
      total: filteredReceipts.length
    }
  }

  // Delete receipt
  static async deleteReceipt(receiptId: string): Promise<void> {
    // In production, this would delete from database and cloud storage
    console.log(`Deleting receipt: ${receiptId}`)
  }

  // Update receipt notes
  static async updateReceiptNotes(receiptId: string, notes: string): Promise<void> {
    // In production, this would update the database
    console.log(`Updating receipt ${receiptId} notes: ${notes}`)
  }

  // Reprocess receipt OCR
  static async reprocessReceipt(receiptId: string, file: File): Promise<ReceiptData> {
    // In production, this would fetch the file from storage and reprocess
    const ocrResult = await this.processOCR(file)
    
    // Update receipt with new data
    const updatedReceipt: Partial<ReceiptData> = {
      extracted_data: ocrResult.extracted_data,
      confidence_score: ocrResult.confidence,
      processed_date: new Date().toISOString(),
      status: 'completed'
    }

    console.log(`Reprocessed receipt ${receiptId}:`, updatedReceipt)
    return updatedReceipt as ReceiptData
  }

  // Format file size for display
  static formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  // Get status color for UI
  static getStatusColor(status: ReceiptData['status']): string {
    switch (status) {
      case 'uploading':
        return 'text-blue-600 bg-blue-100'
      case 'processing':
        return 'text-yellow-600 bg-yellow-100'
      case 'completed':
        return 'text-green-600 bg-green-100'
      case 'failed':
        return 'text-red-600 bg-red-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  // Get confidence color for UI
  static getConfidenceColor(confidence: number): string {
    if (confidence >= 0.9) return 'text-green-600'
    if (confidence >= 0.7) return 'text-yellow-600'
    return 'text-red-600'
  }
}

