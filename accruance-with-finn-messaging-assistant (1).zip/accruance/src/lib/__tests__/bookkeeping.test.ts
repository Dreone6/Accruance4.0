import { BookkeepingService } from '@/lib/bookkeeping'

describe('BookkeepingService', () => {
  describe('categorizeTransaction', () => {
    test('categorizes office supplies correctly', async () => {
      const result = await BookkeepingService.categorizeTransaction(
        'Staples office supplies purchase',
        125.50,
        'expense'
      )

      expect(result).toMatchObject({
        category: 'Office Supplies',
        confidence: expect.any(Number),
        reasoning: expect.any(String),
      })
      expect(result.confidence).toBeGreaterThan(0.9)
    })

    test('categorizes fuel expenses correctly', async () => {
      const result = await BookkeepingService.categorizeTransaction(
        'Shell gas station fuel',
        45.75,
        'expense'
      )

      expect(result).toMatchObject({
        category: 'Fuel & Gas',
        confidence: expect.any(Number),
        reasoning: expect.any(String),
      })
      expect(result.confidence).toBeGreaterThan(0.85)
    })

    test('categorizes software subscriptions correctly', async () => {
      const result = await BookkeepingService.categorizeTransaction(
        'Adobe Creative Cloud subscription',
        52.99,
        'expense'
      )

      expect(result).toMatchObject({
        category: 'Software & Subscriptions',
        confidence: expect.any(Number),
        reasoning: expect.any(String),
      })
      expect(result.confidence).toBeGreaterThan(0.9)
    })

    test('categorizes revenue transactions correctly', async () => {
      const result = await BookkeepingService.categorizeTransaction(
        'Client payment for consulting services',
        2500.00,
        'income'
      )

      expect(result).toMatchObject({
        category: 'Sales Revenue',
        confidence: expect.any(Number),
        reasoning: expect.any(String),
      })
      expect(result.confidence).toBeGreaterThan(0.9)
    })

    test('handles unknown transactions with lower confidence', async () => {
      const result = await BookkeepingService.categorizeTransaction(
        'Random unknown transaction',
        100.00,
        'expense'
      )

      expect(result.confidence).toBeLessThan(0.7)
      expect(result.category).toBe('Other')
    })
  })

  describe('validateTransaction', () => {
    test('validates correct transaction data', () => {
      const transaction = {
        description: 'Test transaction',
        amount: 100.00,
        date: '2024-01-15',
        type: 'expense' as const,
        category: 'Office Supplies',
      }

      const result = BookkeepingService.validateTransaction(transaction)
      expect(result.isValid).toBe(true)
      expect(result.errors).toHaveLength(0)
    })

    test('validates required fields', () => {
      const transaction = {
        description: '',
        amount: 0,
        date: '',
        type: 'expense' as const,
        category: '',
      }

      const result = BookkeepingService.validateTransaction(transaction)
      expect(result.isValid).toBe(false)
      expect(result.errors).toContain('Description is required')
      expect(result.errors).toContain('Amount must be greater than 0')
      expect(result.errors).toContain('Date is required')
    })

    test('validates amount limits', () => {
      const transaction = {
        description: 'Large transaction',
        amount: 1000000,
        date: '2024-01-15',
        type: 'expense' as const,
        category: 'Other',
      }

      const result = BookkeepingService.validateTransaction(transaction)
      expect(result.isValid).toBe(false)
      expect(result.errors).toContain('Amount cannot exceed $999,999.99')
    })

    test('validates date format', () => {
      const transaction = {
        description: 'Test transaction',
        amount: 100.00,
        date: 'invalid-date',
        type: 'expense' as const,
        category: 'Office Supplies',
      }

      const result = BookkeepingService.validateTransaction(transaction)
      expect(result.isValid).toBe(false)
      expect(result.errors).toContain('Invalid date format')
    })
  })

  describe('formatCurrency', () => {
    test('formats positive amounts correctly', () => {
      expect(BookkeepingService.formatCurrency(1234.56)).toBe('$1,234.56')
      expect(BookkeepingService.formatCurrency(0.99)).toBe('$0.99')
      expect(BookkeepingService.formatCurrency(1000000)).toBe('$1,000,000.00')
    })

    test('formats negative amounts correctly', () => {
      expect(BookkeepingService.formatCurrency(-1234.56)).toBe('-$1,234.56')
      expect(BookkeepingService.formatCurrency(-0.99)).toBe('-$0.99')
    })

    test('handles zero correctly', () => {
      expect(BookkeepingService.formatCurrency(0)).toBe('$0.00')
    })
  })

  describe('calculateTotals', () => {
    test('calculates transaction totals correctly', () => {
      const transactions = [
        { amount: 100, type: 'income' as const },
        { amount: 50, type: 'expense' as const },
        { amount: 200, type: 'income' as const },
        { amount: 75, type: 'expense' as const },
      ]

      const totals = BookkeepingService.calculateTotals(transactions)
      
      expect(totals.totalIncome).toBe(300)
      expect(totals.totalExpenses).toBe(125)
      expect(totals.netAmount).toBe(175)
    })

    test('handles empty transaction list', () => {
      const totals = BookkeepingService.calculateTotals([])
      
      expect(totals.totalIncome).toBe(0)
      expect(totals.totalExpenses).toBe(0)
      expect(totals.netAmount).toBe(0)
    })
  })
})

