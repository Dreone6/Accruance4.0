import { ReceiptManager } from '@/lib/receipt-manager'

describe('ReceiptManager', () => {
  describe('extractReceiptData', () => {
    test('extracts merchant name correctly', () => {
      const ocrText = `
        STAPLES
        123 Main Street
        Total: $25.99
        Date: 01/15/2024
      `

      const result = ReceiptManager.extractReceiptData(ocrText)
      expect(result.merchant).toBe('STAPLES')
    })

    test('extracts total amount correctly', () => {
      const ocrText = `
        Store Name
        Item 1: $10.99
        Item 2: $15.00
        Total: $25.99
        Tax: $2.08
      `

      const result = ReceiptManager.extractReceiptData(ocrText)
      expect(result.total).toBe(25.99)
    })

    test('extracts date correctly', () => {
      const ocrText = `
        Store Name
        Date: 01/15/2024
        Total: $25.99
      `

      const result = ReceiptManager.extractReceiptData(ocrText)
      expect(result.date).toBe('2024-01-15')
    })

    test('extracts tax amount correctly', () => {
      const ocrText = `
        Store Name
        Subtotal: $23.91
        HST: $2.08
        Total: $25.99
      `

      const result = ReceiptManager.extractReceiptData(ocrText)
      expect(result.tax).toBe(2.08)
    })

    test('extracts line items correctly', () => {
      const ocrText = `
        Store Name
        Paper Clips 1 @ $5.99
        Stapler 1 @ $19.99
        Total: $25.98
      `

      const result = ReceiptManager.extractReceiptData(ocrText)
      expect(result.line_items).toHaveLength(2)
      expect(result.line_items[0]).toMatchObject({
        description: 'Paper Clips',
        quantity: 1,
        price: 5.99,
      })
    })

    test('handles missing information gracefully', () => {
      const ocrText = 'Incomplete receipt text'

      const result = ReceiptManager.extractReceiptData(ocrText)
      expect(result.merchant).toBe('Unknown')
      expect(result.total).toBe(0)
      expect(result.date).toBe('')
      expect(result.line_items).toHaveLength(0)
    })
  })

  describe('categorizeReceipt', () => {
    test('categorizes office supply receipts correctly', () => {
      const receiptData = {
        merchant: 'STAPLES',
        total: 25.99,
        line_items: [
          { description: 'Paper', quantity: 1, price: 10.99 },
          { description: 'Pens', quantity: 1, price: 15.00 },
        ],
      }

      const result = ReceiptManager.categorizeReceipt(receiptData)
      expect(result.category).toBe('Office Supplies')
      expect(result.confidence).toBeGreaterThan(0.9)
    })

    test('categorizes restaurant receipts correctly', () => {
      const receiptData = {
        merchant: 'MCDONALDS',
        total: 12.50,
        line_items: [
          { description: 'Big Mac', quantity: 1, price: 8.50 },
          { description: 'Fries', quantity: 1, price: 4.00 },
        ],
      }

      const result = ReceiptManager.categorizeReceipt(receiptData)
      expect(result.category).toBe('Meals & Entertainment')
      expect(result.confidence).toBeGreaterThan(0.85)
    })

    test('categorizes gas station receipts correctly', () => {
      const receiptData = {
        merchant: 'SHELL',
        total: 45.75,
        line_items: [
          { description: 'Regular Gas', quantity: 12.5, price: 3.66 },
        ],
      }

      const result = ReceiptManager.categorizeReceipt(receiptData)
      expect(result.category).toBe('Fuel & Gas')
      expect(result.confidence).toBeGreaterThan(0.9)
    })

    test('handles unknown merchants with lower confidence', () => {
      const receiptData = {
        merchant: 'UNKNOWN STORE',
        total: 100.00,
        line_items: [],
      }

      const result = ReceiptManager.categorizeReceipt(receiptData)
      expect(result.confidence).toBeLessThan(0.7)
    })
  })

  describe('validateReceiptData', () => {
    test('validates complete receipt data', () => {
      const receiptData = {
        merchant: 'Test Store',
        date: '2024-01-15',
        total: 25.99,
        tax: 2.08,
        line_items: [
          { description: 'Item 1', quantity: 1, price: 23.91 },
        ],
      }

      const result = ReceiptManager.validateReceiptData(receiptData)
      expect(result.isValid).toBe(true)
      expect(result.errors).toHaveLength(0)
    })

    test('validates required fields', () => {
      const receiptData = {
        merchant: '',
        date: '',
        total: 0,
        tax: 0,
        line_items: [],
      }

      const result = ReceiptManager.validateReceiptData(receiptData)
      expect(result.isValid).toBe(false)
      expect(result.errors).toContain('Merchant name is required')
      expect(result.errors).toContain('Total amount must be greater than 0')
    })

    test('validates date format', () => {
      const receiptData = {
        merchant: 'Test Store',
        date: 'invalid-date',
        total: 25.99,
        tax: 0,
        line_items: [],
      }

      const result = ReceiptManager.validateReceiptData(receiptData)
      expect(result.isValid).toBe(false)
      expect(result.errors).toContain('Invalid date format')
    })

    test('validates reasonable amounts', () => {
      const receiptData = {
        merchant: 'Test Store',
        date: '2024-01-15',
        total: 1000000,
        tax: 0,
        line_items: [],
      }

      const result = ReceiptManager.validateReceiptData(receiptData)
      expect(result.isValid).toBe(false)
      expect(result.errors).toContain('Total amount seems unreasonably high')
    })
  })

  describe('calculateConfidence', () => {
    test('calculates high confidence for complete data', () => {
      const receiptData = {
        merchant: 'STAPLES',
        date: '2024-01-15',
        total: 25.99,
        tax: 2.08,
        receipt_number: 'R123456',
        line_items: [
          { description: 'Paper', quantity: 1, price: 10.99 },
          { description: 'Pens', quantity: 1, price: 15.00 },
        ],
      }

      const confidence = ReceiptManager.calculateConfidence(receiptData)
      expect(confidence).toBeGreaterThan(0.9)
    })

    test('calculates lower confidence for incomplete data', () => {
      const receiptData = {
        merchant: 'Unknown',
        date: '',
        total: 0,
        tax: 0,
        receipt_number: '',
        line_items: [],
      }

      const confidence = ReceiptManager.calculateConfidence(receiptData)
      expect(confidence).toBeLessThan(0.5)
    })
  })
})

