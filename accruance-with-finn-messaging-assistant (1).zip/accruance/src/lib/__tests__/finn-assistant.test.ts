import { FINNAssistant } from '@/lib/finn-assistant'

describe('FINNAssistant Service', () => {
  let finnAssistant: FINNAssistant

  beforeEach(() => {
    finnAssistant = new FINNAssistant()
  })

  describe('processQuery', () => {
    test('processes financial queries', async () => {
      const result = await finnAssistant.processQuery(
        'What is my cash flow?',
        'test-user',
        'test-org',
        { cashFlow: 50000 }
      )

      expect(result).toMatchObject({
        user_id: 'test-user',
        organization_id: 'test-org',
        query: 'What is my cash flow?',
        response: expect.any(String),
        confidence_score: expect.any(Number),
        response_time_ms: expect.any(Number),
      })
    })

    test('handles revenue queries', async () => {
      const result = await finnAssistant.processQuery(
        'How is my revenue trending?',
        'test-user',
        'test-org'
      )

      expect(result.response).toContain('revenue')
      expect(result.confidence_score).toBeGreaterThan(0.8)
    })

    test('handles expense queries', async () => {
      const result = await finnAssistant.processQuery(
        'What are my biggest expenses?',
        'test-user',
        'test-org'
      )

      expect(result.response).toContain('expense')
      expect(result.confidence_score).toBeGreaterThan(0.8)
    })

    test('handles tax queries', async () => {
      const result = await finnAssistant.processQuery(
        'When are my taxes due?',
        'test-user',
        'test-org'
      )

      expect(result.response).toContain('tax')
      expect(result.confidence_score).toBeGreaterThan(0.8)
    })
  })

  describe('generateInsights', () => {
    test('generates cash flow insights', async () => {
      const insights = await finnAssistant.generateInsights('test-org', {
        cashFlow: 5000, // Below threshold
        expenseGrowth: 0.1,
        revenueGrowth: 0.05,
        overdueInvoices: 0,
      })

      const cashFlowInsight = insights.find(i => i.type === 'cash_flow')
      expect(cashFlowInsight).toBeDefined()
      expect(cashFlowInsight?.priority).toBe('high')
    })

    test('generates expense trend insights', async () => {
      const insights = await finnAssistant.generateInsights('test-org', {
        cashFlow: 50000,
        expenseGrowth: 0.2, // Above threshold
        revenueGrowth: 0.05,
        overdueInvoices: 0,
      })

      const expenseInsight = insights.find(i => i.type === 'expense_trend')
      expect(expenseInsight).toBeDefined()
      expect(expenseInsight?.priority).toBe('medium')
    })

    test('generates tax reminders', async () => {
      const insights = await finnAssistant.generateInsights('test-org', {
        cashFlow: 50000,
        expenseGrowth: 0.1,
        revenueGrowth: 0.05,
        overdueInvoices: 0,
      })

      const taxInsight = insights.find(i => i.type === 'tax_reminder')
      expect(taxInsight).toBeDefined()
      expect(taxInsight?.action_required).toBe(true)
    })

    test('generates payment reminders for overdue invoices', async () => {
      const insights = await finnAssistant.generateInsights('test-org', {
        cashFlow: 50000,
        expenseGrowth: 0.1,
        revenueGrowth: 0.05,
        overdueInvoices: 3,
      })

      const paymentInsight = insights.find(i => i.type === 'payment_reminder')
      expect(paymentInsight).toBeDefined()
      expect(paymentInsight?.priority).toBe('high')
    })
  })

  describe('generateMonthlySummary', () => {
    test('generates comprehensive monthly summary', async () => {
      const summary = await finnAssistant.generateMonthlySummary('test-org', 'January', '2024')

      expect(summary).toMatchObject({
        period: 'January 2024',
        total_revenue: expect.any(Number),
        total_expenses: expect.any(Number),
        net_profit: expect.any(Number),
        cash_flow: expect.any(Number),
        key_insights: expect.any(Array),
        recommendations: expect.any(Array),
        tax_obligations: expect.objectContaining({
          estimated_quarterly: expect.any(Number),
          due_date: expect.any(String),
          preparation_tips: expect.any(Array),
        }),
        expense_breakdown: expect.any(Array),
      })
    })

    test('includes proper expense breakdown', async () => {
      const summary = await finnAssistant.generateMonthlySummary('test-org', 'January', '2024')

      expect(summary.expense_breakdown).toHaveLength(8)
      summary.expense_breakdown.forEach(expense => {
        expect(expense).toMatchObject({
          category: expect.any(String),
          amount: expect.any(Number),
          percentage: expect.any(Number),
          trend: expect.stringMatching(/^(up|down|stable)$/),
        })
      })
    })
  })

  describe('utility methods', () => {
    test('formats currency correctly', () => {
      expect(FINNAssistant.formatCurrency(1234.56)).toBe('$1,234.56')
      expect(FINNAssistant.formatCurrency(0)).toBe('$0.00')
      expect(FINNAssistant.formatCurrency(-500)).toBe('-$500.00')
    })

    test('formats percentage correctly', () => {
      expect(FINNAssistant.formatPercentage(0.1234)).toBe('12.3%')
      expect(FINNAssistant.formatPercentage(0)).toBe('0.0%')
      expect(FINNAssistant.formatPercentage(1)).toBe('100.0%')
    })

    test('gets correct priority colors', () => {
      expect(FINNAssistant.getPriorityColor('urgent')).toContain('red')
      expect(FINNAssistant.getPriorityColor('high')).toContain('orange')
      expect(FINNAssistant.getPriorityColor('medium')).toContain('yellow')
      expect(FINNAssistant.getPriorityColor('low')).toContain('blue')
    })

    test('gets correct insight icons', () => {
      expect(FINNAssistant.getInsightIcon('cash_flow')).toBe('💰')
      expect(FINNAssistant.getInsightIcon('expense_trend')).toBe('📈')
      expect(FINNAssistant.getInsightIcon('revenue_opportunity')).toBe('🚀')
      expect(FINNAssistant.getInsightIcon('tax_reminder')).toBe('📋')
    })
  })
})

