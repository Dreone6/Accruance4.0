import { format, subDays, startOfMonth, endOfMonth, subMonths } from 'date-fns'

export interface DashboardMetrics {
  totalRevenue: number
  totalExpenses: number
  netProfit: number
  cashFlow: number
  revenueChange: number
  expensesChange: number
  profitChange: number
  cashFlowChange: number
}

export interface ChartDataPoint {
  date: string
  revenue: number
  expenses: number
  profit: number
  cashFlow: number
}

export interface TransactionSummary {
  id: string
  date: string
  description: string
  amount: number
  type: 'income' | 'expense'
  category: string
  account: string
  status: 'pending' | 'cleared' | 'reconciled'
}

export interface CategoryBreakdown {
  category: string
  amount: number
  percentage: number
  change: number
  color: string
}

export class DashboardService {
  // Generate mock data for demonstration
  static generateMockMetrics(): DashboardMetrics {
    return {
      totalRevenue: 125000,
      totalExpenses: 87500,
      netProfit: 37500,
      cashFlow: 42000,
      revenueChange: 12.5,
      expensesChange: -8.2,
      profitChange: 18.7,
      cashFlowChange: 15.3
    }
  }

  static generateMockChartData(days: number = 30): ChartDataPoint[] {
    const data: ChartDataPoint[] = []
    const today = new Date()

    for (let i = days - 1; i >= 0; i--) {
      const date = subDays(today, i)
      const baseRevenue = 3000 + Math.random() * 2000
      const baseExpenses = 2000 + Math.random() * 1500
      
      data.push({
        date: format(date, 'MMM dd'),
        revenue: Math.round(baseRevenue),
        expenses: Math.round(baseExpenses),
        profit: Math.round(baseRevenue - baseExpenses),
        cashFlow: Math.round((baseRevenue - baseExpenses) * 1.1)
      })
    }

    return data
  }

  static generateMockTransactions(count: number = 10): TransactionSummary[] {
    const transactions: TransactionSummary[] = []
    const categories = [
      'Office Supplies', 'Marketing', 'Software', 'Travel', 'Meals',
      'Professional Services', 'Utilities', 'Rent', 'Insurance', 'Sales'
    ]
    const accounts = ['Business Checking', 'Business Savings', 'Credit Card']
    const descriptions = [
      'Office supplies purchase', 'Google Ads campaign', 'Software subscription',
      'Business travel', 'Client dinner', 'Legal consultation', 'Internet bill',
      'Office rent', 'Business insurance', 'Product sales'
    ]

    for (let i = 0; i < count; i++) {
      const isIncome = Math.random() > 0.7
      const amount = isIncome 
        ? Math.round((Math.random() * 5000 + 1000) * 100) / 100
        : Math.round((Math.random() * 1000 + 50) * 100) / 100

      transactions.push({
        id: `txn_${Math.random().toString(36).substr(2, 9)}`,
        date: format(subDays(new Date(), Math.floor(Math.random() * 30)), 'MMM dd, yyyy'),
        description: descriptions[Math.floor(Math.random() * descriptions.length)],
        amount: isIncome ? amount : -amount,
        type: isIncome ? 'income' : 'expense',
        category: categories[Math.floor(Math.random() * categories.length)],
        account: accounts[Math.floor(Math.random() * accounts.length)],
        status: ['pending', 'cleared', 'reconciled'][Math.floor(Math.random() * 3)] as any
      })
    }

    return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  }

  static generateMockCategoryBreakdown(): CategoryBreakdown[] {
    const categories = [
      { name: 'Office Supplies', color: '#3B82F6' },
      { name: 'Marketing', color: '#10B981' },
      { name: 'Software', color: '#F59E0B' },
      { name: 'Travel', color: '#EF4444' },
      { name: 'Professional Services', color: '#8B5CF6' },
      { name: 'Utilities', color: '#06B6D4' },
      { name: 'Rent', color: '#84CC16' },
      { name: 'Insurance', color: '#F97316' }
    ]

    const total = 87500
    let remaining = total

    return categories.map((cat, index) => {
      const isLast = index === categories.length - 1
      const amount = isLast ? remaining : Math.round((Math.random() * 0.2 + 0.05) * total)
      remaining -= amount

      return {
        category: cat.name,
        amount,
        percentage: Math.round((amount / total) * 100),
        change: Math.round((Math.random() - 0.5) * 40 * 100) / 100,
        color: cat.color
      }
    }).filter(cat => cat.amount > 0)
  }

  static async getRealtimeMetrics(organizationId: string): Promise<DashboardMetrics> {
    // In a real implementation, this would query the database
    // For now, return mock data
    return this.generateMockMetrics()
  }

  static async getChartData(organizationId: string, period: 'week' | 'month' | 'quarter' = 'month'): Promise<ChartDataPoint[]> {
    const days = period === 'week' ? 7 : period === 'month' ? 30 : 90
    return this.generateMockChartData(days)
  }

  static async getRecentTransactions(organizationId: string, limit: number = 10): Promise<TransactionSummary[]> {
    return this.generateMockTransactions(limit)
  }

  static async getCategoryBreakdown(organizationId: string): Promise<CategoryBreakdown[]> {
    return this.generateMockCategoryBreakdown()
  }

  static formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount)
  }

  static formatPercentage(value: number): string {
    const sign = value >= 0 ? '+' : ''
    return `${sign}${value.toFixed(1)}%`
  }

  static getChangeColor(value: number): string {
    if (value > 0) return 'text-green-600'
    if (value < 0) return 'text-red-600'
    return 'text-gray-600'
  }

  static getChangeIcon(value: number): string {
    if (value > 0) return '↗'
    if (value < 0) return '↘'
    return '→'
  }
}

