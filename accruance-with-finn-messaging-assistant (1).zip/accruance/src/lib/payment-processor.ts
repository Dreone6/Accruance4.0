import { loadStripe, Stripe } from '@stripe/stripe-js'

export interface PaymentIntentData {
  amount: number
  currency: string
  invoice_id: string
  client_email: string
  description: string
}

export interface PaymentResult {
  success: boolean
  payment_intent_id?: string
  error?: string
}

export class PaymentProcessor {
  private static stripePromise: Promise<Stripe | null> | null = null

  // Initialize Stripe
  static getStripe(): Promise<Stripe | null> {
    if (!this.stripePromise) {
      // In production, this would use the actual Stripe publishable key
      const publishableKey = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || 'pk_test_placeholder'
      this.stripePromise = loadStripe(publishableKey)
    }
    return this.stripePromise
  }

  // Create payment intent
  static async createPaymentIntent(data: PaymentIntentData): Promise<{
    client_secret: string
    payment_intent_id: string
  }> {
    try {
      // In a real implementation, this would call your backend API
      // which would create a payment intent with Stripe
      const response = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        throw new Error('Failed to create payment intent')
      }

      const result = await response.json()
      return result
    } catch (error) {
      console.error('Error creating payment intent:', error)
      
      // Mock response for demonstration
      return {
        client_secret: `pi_mock_${Date.now()}_secret_mock`,
        payment_intent_id: `pi_mock_${Date.now()}`
      }
    }
  }

  // Process payment
  static async processPayment(
    clientSecret: string,
    paymentMethodId: string
  ): Promise<PaymentResult> {
    try {
      const stripe = await this.getStripe()
      if (!stripe) {
        throw new Error('Stripe not initialized')
      }

      const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
        payment_method: paymentMethodId
      })

      if (error) {
        return {
          success: false,
          error: error.message
        }
      }

      if (paymentIntent?.status === 'succeeded') {
        return {
          success: true,
          payment_intent_id: paymentIntent.id
        }
      }

      return {
        success: false,
        error: 'Payment failed'
      }
    } catch (error) {
      console.error('Error processing payment:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Payment processing failed'
      }
    }
  }

  // Create payment method
  static async createPaymentMethod(
    cardElement: any,
    billingDetails: {
      name: string
      email: string
      address?: {
        line1: string
        city: string
        state: string
        postal_code: string
        country: string
      }
    }
  ): Promise<{ paymentMethod?: any, error?: any }> {
    try {
      const stripe = await this.getStripe()
      if (!stripe) {
        throw new Error('Stripe not initialized')
      }

      const { error, paymentMethod } = await stripe.createPaymentMethod({
        type: 'card',
        card: cardElement,
        billing_details: billingDetails,
      })

      return { paymentMethod, error }
    } catch (error) {
      console.error('Error creating payment method:', error)
      return { error }
    }
  }

  // Get payment methods for customer
  static async getPaymentMethods(customerId: string): Promise<any[]> {
    try {
      // In a real implementation, this would call your backend API
      const response = await fetch(`/api/payment-methods/${customerId}`)
      
      if (!response.ok) {
        throw new Error('Failed to fetch payment methods')
      }

      const data = await response.json()
      return data.payment_methods || []
    } catch (error) {
      console.error('Error fetching payment methods:', error)
      return []
    }
  }

  // Format amount for Stripe (convert to cents)
  static formatAmountForStripe(amount: number): number {
    return Math.round(amount * 100)
  }

  // Format amount from Stripe (convert from cents)
  static formatAmountFromStripe(amount: number): number {
    return amount / 100
  }

  // Validate card number
  static validateCardNumber(cardNumber: string): boolean {
    // Remove spaces and non-digits
    const cleaned = cardNumber.replace(/\D/g, '')
    
    // Check length
    if (cleaned.length < 13 || cleaned.length > 19) {
      return false
    }

    // Luhn algorithm
    let sum = 0
    let isEven = false

    for (let i = cleaned.length - 1; i >= 0; i--) {
      let digit = parseInt(cleaned[i])

      if (isEven) {
        digit *= 2
        if (digit > 9) {
          digit -= 9
        }
      }

      sum += digit
      isEven = !isEven
    }

    return sum % 10 === 0
  }

  // Get card type from number
  static getCardType(cardNumber: string): string {
    const cleaned = cardNumber.replace(/\D/g, '')
    
    if (/^4/.test(cleaned)) {
      return 'visa'
    } else if (/^5[1-5]/.test(cleaned) || /^2[2-7]/.test(cleaned)) {
      return 'mastercard'
    } else if (/^3[47]/.test(cleaned)) {
      return 'amex'
    } else if (/^6(?:011|5)/.test(cleaned)) {
      return 'discover'
    }
    
    return 'unknown'
  }

  // Format card number for display
  static formatCardNumber(cardNumber: string): string {
    const cleaned = cardNumber.replace(/\D/g, '')
    const groups = cleaned.match(/.{1,4}/g) || []
    return groups.join(' ').substr(0, 19) // Limit to 19 characters
  }

  // Format expiry date
  static formatExpiryDate(expiry: string): string {
    const cleaned = expiry.replace(/\D/g, '')
    if (cleaned.length >= 2) {
      return cleaned.substr(0, 2) + (cleaned.length > 2 ? '/' + cleaned.substr(2, 2) : '')
    }
    return cleaned
  }

  // Validate expiry date
  static validateExpiryDate(expiry: string): boolean {
    const cleaned = expiry.replace(/\D/g, '')
    if (cleaned.length !== 4) {
      return false
    }

    const month = parseInt(cleaned.substr(0, 2))
    const year = parseInt('20' + cleaned.substr(2, 2))
    
    if (month < 1 || month > 12) {
      return false
    }

    const now = new Date()
    const currentYear = now.getFullYear()
    const currentMonth = now.getMonth() + 1

    if (year < currentYear || (year === currentYear && month < currentMonth)) {
      return false
    }

    return true
  }

  // Validate CVV
  static validateCVV(cvv: string, cardType: string = 'unknown'): boolean {
    const cleaned = cvv.replace(/\D/g, '')
    
    if (cardType === 'amex') {
      return cleaned.length === 4
    } else {
      return cleaned.length === 3
    }
  }

  // Get supported payment methods
  static getSupportedPaymentMethods(): string[] {
    return ['card', 'apple_pay', 'google_pay']
  }

  // Check if payment method is supported
  static isPaymentMethodSupported(method: string): boolean {
    return this.getSupportedPaymentMethods().includes(method)
  }

  // Calculate processing fee
  static calculateProcessingFee(amount: number, paymentMethod: string = 'card'): number {
    // Standard Stripe fees (as of 2024)
    const cardFeeRate = 0.029 // 2.9%
    const cardFeeFixed = 0.30 // $0.30
    
    switch (paymentMethod) {
      case 'card':
        return (amount * cardFeeRate) + cardFeeFixed
      case 'apple_pay':
      case 'google_pay':
        return (amount * cardFeeRate) + cardFeeFixed
      default:
        return (amount * cardFeeRate) + cardFeeFixed
    }
  }

  // Format currency for display
  static formatCurrency(amount: number, currency: string = 'USD'): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount)
  }

  // Get currency symbol
  static getCurrencySymbol(currency: string): string {
    const symbols: { [key: string]: string } = {
      'USD': '$',
      'EUR': '€',
      'GBP': '£',
      'CAD': 'C$',
      'AUD': 'A$',
      'JPY': '¥'
    }
    return symbols[currency] || currency
  }

  // Convert currency (mock implementation)
  static async convertCurrency(
    amount: number,
    fromCurrency: string,
    toCurrency: string
  ): Promise<number> {
    if (fromCurrency === toCurrency) {
      return amount
    }

    // Mock conversion rates (in production, use a real currency API)
    const rates: { [key: string]: number } = {
      'USD_EUR': 0.85,
      'USD_GBP': 0.73,
      'USD_CAD': 1.25,
      'USD_AUD': 1.35,
      'EUR_USD': 1.18,
      'GBP_USD': 1.37,
      'CAD_USD': 0.80,
      'AUD_USD': 0.74
    }

    const rateKey = `${fromCurrency}_${toCurrency}`
    const rate = rates[rateKey] || 1

    return amount * rate
  }
}

