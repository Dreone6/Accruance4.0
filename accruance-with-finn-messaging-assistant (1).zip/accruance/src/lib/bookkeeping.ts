import { format, parseISO } from 'date-fns'
import type { Transaction, Account, Category } from './supabase'

export interface TransactionFormData {
  date: string
  description: string
  amount: number
  type: 'income' | 'expense'
  category_id: string
  account_id: string
  reference?: string
  notes?: string
}

export interface TransactionFilters {
  dateFrom?: string
  dateTo?: string
  type?: 'income' | 'expense' | 'all'
  category?: string
  account?: string
  status?: 'pending' | 'cleared' | 'reconciled' | 'all'
  search?: string
  minAmount?: number
  maxAmount?: number
}

export interface BulkAction {
  type: 'categorize' | 'delete' | 'reconcile' | 'export'
  categoryId?: string
  status?: string
}

export interface AICategorizationRule {
  id: string
  pattern: string
  category_id: string
  confidence: number
  description_keywords: string[]
  amount_range?: { min?: number; max?: number }
  merchant_patterns?: string[]
}

export interface CategorizationSuggestion {
  category_id: string
  category_name: string
  confidence: number
  reason: string
  rule_id?: string
}

export class BookkeepingEngine {
  // AI Categorization Rules (Mock implementation)
  private static aiRules: AICategorizationRule[] = [
    {
      id: 'rule_1',
      pattern: 'office supplies|staples|office depot|amazon.*office',
      category_id: 'cat_office_supplies',
      confidence: 0.95,
      description_keywords: ['office', 'supplies', 'paper', 'pens', 'desk'],
      amount_range: { min: 5, max: 500 }
    },
    {
      id: 'rule_2',
      pattern: 'gas|fuel|shell|exxon|chevron|bp',
      category_id: 'cat_fuel',
      confidence: 0.90,
      description_keywords: ['gas', 'fuel', 'gasoline', 'station'],
      amount_range: { min: 10, max: 200 }
    },
    {
      id: 'rule_3',
      pattern: 'restaurant|food|dining|uber eats|doordash|grubhub',
      category_id: 'cat_meals',
      confidence: 0.85,
      description_keywords: ['restaurant', 'food', 'dining', 'meal', 'lunch', 'dinner'],
      amount_range: { min: 5, max: 300 }
    },
    {
      id: 'rule_4',
      pattern: 'software|saas|subscription|adobe|microsoft|google workspace',
      category_id: 'cat_software',
      confidence: 0.92,
      description_keywords: ['software', 'subscription', 'saas', 'license'],
      amount_range: { min: 5, max: 1000 }
    },
    {
      id: 'rule_5',
      pattern: 'rent|lease|property|real estate',
      category_id: 'cat_rent',
      confidence: 0.98,
      description_keywords: ['rent', 'lease', 'property', 'office space'],
      amount_range: { min: 500, max: 10000 }
    },
    {
      id: 'rule_6',
      pattern: 'marketing|advertising|facebook ads|google ads|linkedin',
      category_id: 'cat_marketing',
      confidence: 0.88,
      description_keywords: ['marketing', 'advertising', 'ads', 'promotion'],
      amount_range: { min: 10, max: 5000 }
    },
    {
      id: 'rule_7',
      pattern: 'client payment|invoice|payment received|sales',
      category_id: 'cat_sales_revenue',
      confidence: 0.95,
      description_keywords: ['payment', 'invoice', 'sales', 'revenue', 'client'],
      amount_range: { min: 100, max: 50000 }
    }
  ]

  // Mock categories for demonstration
  private static mockCategories = [
    { id: 'cat_office_supplies', name: 'Office Supplies', type: 'expense' },
    { id: 'cat_fuel', name: 'Fuel & Gas', type: 'expense' },
    { id: 'cat_meals', name: 'Meals & Entertainment', type: 'expense' },
    { id: 'cat_software', name: 'Software & Subscriptions', type: 'expense' },
    { id: 'cat_rent', name: 'Rent & Lease', type: 'expense' },
    { id: 'cat_marketing', name: 'Marketing & Advertising', type: 'expense' },
    { id: 'cat_sales_revenue', name: 'Sales Revenue', type: 'income' },
    { id: 'cat_consulting_revenue', name: 'Consulting Revenue', type: 'income' },
    { id: 'cat_utilities', name: 'Utilities', type: 'expense' },
    { id: 'cat_insurance', name: 'Insurance', type: 'expense' }
  ]

  static async categorizeTransaction(
    description: string, 
    amount: number, 
    merchantName?: string
  ): Promise<CategorizationSuggestion[]> {
    const suggestions: CategorizationSuggestion[] = []
    const searchText = `${description} ${merchantName || ''}`.toLowerCase()

    // Apply AI rules
    for (const rule of this.aiRules) {
      const regex = new RegExp(rule.pattern, 'i')
      let confidence = 0

      // Check pattern match
      if (regex.test(searchText)) {
        confidence += 0.6
      }

      // Check keyword matches
      const keywordMatches = rule.description_keywords.filter(keyword => 
        searchText.includes(keyword.toLowerCase())
      ).length
      confidence += (keywordMatches / rule.description_keywords.length) * 0.3

      // Check amount range
      if (rule.amount_range) {
        const { min = 0, max = Infinity } = rule.amount_range
        if (amount >= min && amount <= max) {
          confidence += 0.1
        }
      }

      // If confidence is above threshold, add suggestion
      if (confidence >= 0.5) {
        const category = this.mockCategories.find(c => c.id === rule.category_id)
        if (category) {
          suggestions.push({
            category_id: rule.category_id,
            category_name: category.name,
            confidence: Math.min(confidence * rule.confidence, 0.99),
            reason: this.generateReason(rule, keywordMatches, confidence),
            rule_id: rule.id
          })
        }
      }
    }

    // Sort by confidence and return top 3
    return suggestions
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 3)
  }

  private static generateReason(
    rule: AICategorizationRule, 
    keywordMatches: number, 
    confidence: number
  ): string {
    const reasons = []
    
    if (confidence >= 0.8) {
      reasons.push('Strong pattern match')
    } else if (confidence >= 0.6) {
      reasons.push('Good pattern match')
    }

    if (keywordMatches > 0) {
      reasons.push(`${keywordMatches} keyword${keywordMatches > 1 ? 's' : ''} matched`)
    }

    if (rule.amount_range) {
      reasons.push('Amount within expected range')
    }

    return reasons.join(', ') || 'Pattern recognition'
  }

  static async createTransaction(
    organizationId: string, 
    data: TransactionFormData
  ): Promise<Transaction> {
    // In a real implementation, this would save to the database
    const transaction: Transaction = {
      id: `txn_${Math.random().toString(36).substr(2, 9)}`,
      organization_id: organizationId,
      date: data.date,
      description: data.description,
      amount: data.type === 'expense' ? -Math.abs(data.amount) : Math.abs(data.amount),
      category_id: data.category_id,
      account_id: data.account_id,
      reference: data.reference,
      notes: data.notes,
      status: 'pending',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }

    return transaction
  }

  static async updateTransaction(
    transactionId: string, 
    updates: Partial<TransactionFormData>
  ): Promise<Transaction> {
    // In a real implementation, this would update the database
    // For now, return a mock updated transaction
    return {
      id: transactionId,
      organization_id: 'org_123',
      date: updates.date || new Date().toISOString().split('T')[0],
      description: updates.description || 'Updated transaction',
      amount: updates.amount || 0,
      category_id: updates.category_id || 'cat_office_supplies',
      account_id: updates.account_id || 'acc_123',
      reference: updates.reference,
      notes: updates.notes,
      status: 'pending',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }
  }

  static async deleteTransaction(transactionId: string): Promise<boolean> {
    // In a real implementation, this would delete from the database
    return true
  }

  static async bulkUpdateTransactions(
    transactionIds: string[], 
    action: BulkAction
  ): Promise<boolean> {
    // In a real implementation, this would perform bulk operations
    console.log(`Bulk ${action.type} on ${transactionIds.length} transactions`)
    return true
  }

  static async getTransactions(
    organizationId: string,
    filters: TransactionFilters = {},
    page: number = 1,
    limit: number = 50
  ): Promise<{ transactions: Transaction[]; total: number; pages: number }> {
    // Mock transaction data
    const mockTransactions: Transaction[] = [
      {
        id: 'txn_001',
        organization_id: organizationId,
        date: '2024-12-10',
        description: 'Office supplies from Staples',
        amount: -89.99,
        category_id: 'cat_office_supplies',
        account_id: 'acc_checking',
        status: 'cleared',
        created_at: '2024-12-10T10:00:00Z',
        updated_at: '2024-12-10T10:00:00Z'
      },
      {
        id: 'txn_002',
        organization_id: organizationId,
        date: '2024-12-09',
        description: 'Client payment - Project Alpha',
        amount: 2500.00,
        category_id: 'cat_consulting_revenue',
        account_id: 'acc_checking',
        status: 'cleared',
        created_at: '2024-12-09T14:30:00Z',
        updated_at: '2024-12-09T14:30:00Z'
      },
      {
        id: 'txn_003',
        organization_id: organizationId,
        date: '2024-12-08',
        description: 'Google Workspace subscription',
        amount: -12.00,
        category_id: 'cat_software',
        account_id: 'acc_credit_card',
        status: 'pending',
        created_at: '2024-12-08T09:15:00Z',
        updated_at: '2024-12-08T09:15:00Z'
      },
      {
        id: 'txn_004',
        organization_id: organizationId,
        date: '2024-12-07',
        description: 'Fuel - Shell Station',
        amount: -45.67,
        category_id: 'cat_fuel',
        account_id: 'acc_credit_card',
        status: 'cleared',
        created_at: '2024-12-07T16:45:00Z',
        updated_at: '2024-12-07T16:45:00Z'
      },
      {
        id: 'txn_005',
        organization_id: organizationId,
        date: '2024-12-06',
        description: 'Marketing campaign - Facebook Ads',
        amount: -150.00,
        category_id: 'cat_marketing',
        account_id: 'acc_credit_card',
        status: 'reconciled',
        created_at: '2024-12-06T11:20:00Z',
        updated_at: '2024-12-06T11:20:00Z'
      }
    ]

    // Apply filters (simplified for demo)
    let filteredTransactions = mockTransactions

    if (filters.type && filters.type !== 'all') {
      filteredTransactions = filteredTransactions.filter(t => 
        filters.type === 'income' ? t.amount > 0 : t.amount < 0
      )
    }

    if (filters.search) {
      filteredTransactions = filteredTransactions.filter(t =>
        t.description.toLowerCase().includes(filters.search!.toLowerCase())
      )
    }

    if (filters.status && filters.status !== 'all') {
      filteredTransactions = filteredTransactions.filter(t => t.status === filters.status)
    }

    const total = filteredTransactions.length
    const pages = Math.ceil(total / limit)
    const startIndex = (page - 1) * limit
    const paginatedTransactions = filteredTransactions.slice(startIndex, startIndex + limit)

    return {
      transactions: paginatedTransactions,
      total,
      pages
    }
  }

  static formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount)
  }

  static formatDate(date: string): string {
    return format(parseISO(date), 'MMM dd, yyyy')
  }

  static getTransactionType(amount: number): 'income' | 'expense' {
    return amount >= 0 ? 'income' : 'expense'
  }

  static getStatusColor(status: string): string {
    switch (status) {
      case 'cleared':
        return 'text-green-600 bg-green-100'
      case 'pending':
        return 'text-yellow-600 bg-yellow-100'
      case 'reconciled':
        return 'text-blue-600 bg-blue-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  static getAmountColor(amount: number): string {
    return amount >= 0 ? 'text-green-600' : 'text-red-600'
  }

  // Audit trail functionality
  static async createAuditEntry(
    transactionId: string,
    action: string,
    oldValues?: any,
    newValues?: any,
    userId?: string
  ): Promise<void> {
    // In a real implementation, this would save to audit_logs table
    console.log('Audit entry created:', {
      transactionId,
      action,
      oldValues,
      newValues,
      userId,
      timestamp: new Date().toISOString()
    })
  }

  // Keyboard shortcuts mapping
  static getKeyboardShortcuts() {
    return {
      'ctrl+n': 'Create new transaction',
      'ctrl+e': 'Edit selected transaction',
      'ctrl+d': 'Delete selected transaction',
      'ctrl+a': 'Select all transactions',
      'ctrl+f': 'Focus search',
      'escape': 'Clear selection',
      'enter': 'Open transaction details',
      'ctrl+shift+c': 'Categorize selected transactions',
      'ctrl+shift+r': 'Mark as reconciled',
      'ctrl+shift+e': 'Export selected transactions'
    }
  }
}

