// Enhanced Marketplace Configuration with Expanded Categories
export const ENHANCED_MARKETPLACE_CONFIG = {
  // Feature flags (controlled by environment variables)
  ENABLED: process.env.MARKETPLACE_ENABLED === 'true',
  BOOKINGS_ENABLED: process.env.MARKETPLACE_BOOKINGS_ENABLED === 'true',
  PAYMENTS_ENABLED: process.env.MARKETPLACE_PAYMENTS_ENABLED === 'true',
  REVIEWS_ENABLED: process.env.MARKETPLACE_REVIEWS_ENABLED === 'true',
  
  // Configuration values
  COMMISSION_RATE: parseFloat(process.env.MARKETPLACE_COMMISSION_RATE || '0.08'),
  MIN_SERVICE_PRICE: parseFloat(process.env.MARKETPLACE_MIN_SERVICE_PRICE || '50'),
  FEATURED_LISTING_PRICE: parseFloat(process.env.MARKETPLACE_FEATURED_LISTING_PRICE || '99'),
  
  // User thresholds for marketplace activation
  ACTIVATION_THRESHOLDS: {
    TOTAL_USERS: 1000,
    VERIFIED_PROFESSIONALS: 100,
    MONTHLY_CONNECTIONS: 500,
    MONTHLY_TRANSACTION_VOLUME: 50000
  }
}

// Expanded Equipment Categories
export const EQUIPMENT_CATEGORIES = [
  {
    id: 'computer_hardware',
    name: 'Computer Hardware',
    description: 'Desktops, laptops, servers, and computer components',
    icon: 'monitor',
    subcategories: ['desktop', 'laptop', 'server', 'workstation', 'tablet', 'components']
  },
  {
    id: 'software_licenses',
    name: 'Software Licenses',
    description: 'Business software licenses and subscriptions',
    icon: 'code',
    subcategories: ['accounting', 'crm', 'project_management', 'design', 'development', 'productivity']
  },
  {
    id: 'office_furniture',
    name: 'Office Furniture',
    description: 'Desks, chairs, tables, and office furnishings',
    icon: 'chair',
    subcategories: ['desk', 'chair', 'table', 'cabinet', 'bookshelf', 'reception_desk']
  },
  {
    id: 'real_estate_offices',
    name: 'Office Real Estate',
    description: 'Office spaces, coworking, and commercial real estate',
    icon: 'building',
    subcategories: ['office_space', 'coworking', 'executive_suite', 'warehouse', 'retail_space']
  },
  {
    id: 'networking_equipment',
    name: 'Networking Equipment',
    description: 'Routers, switches, firewalls, and network infrastructure',
    icon: 'wifi',
    subcategories: ['router', 'switch', 'firewall', 'access_point', 'cables']
  },
  {
    id: 'financial_tools',
    name: 'Financial Tools',
    description: 'POS systems, payment terminals, and financial hardware',
    icon: 'credit-card',
    subcategories: ['pos_system', 'payment_terminal', 'cash_register', 'card_reader']
  },
  {
    id: 'security_systems',
    name: 'Security Systems',
    description: 'Surveillance cameras, access control, and security equipment',
    icon: 'shield',
    subcategories: ['camera', 'access_control', 'alarm_system', 'monitoring']
  },
  {
    id: 'communication_tools',
    name: 'Communication Tools',
    description: 'Phone systems, video conferencing, and communication equipment',
    icon: 'phone',
    subcategories: ['phone_system', 'video_conference', 'headsets', 'microphones']
  }
]

// Executive Service Categories
export const EXECUTIVE_SERVICE_CATEGORIES = [
  {
    id: 'c_suite_executives',
    name: 'C-Suite Executives',
    description: 'Fractional and interim C-level executives',
    icon: 'user-tie',
    roles: [
      { id: 'ceo', name: 'Chief Executive Officer (CEO)', description: 'Strategic leadership and overall company direction' },
      { id: 'cfo', name: 'Chief Financial Officer (CFO)', description: 'Financial strategy, planning, and risk management' },
      { id: 'cto', name: 'Chief Technology Officer (CTO)', description: 'Technology strategy and innovation leadership' },
      { id: 'coo', name: 'Chief Operating Officer (COO)', description: 'Operations management and process optimization' },
      { id: 'cmo', name: 'Chief Marketing Officer (CMO)', description: 'Marketing strategy and brand management' },
      { id: 'chro', name: 'Chief Human Resources Officer (CHRO)', description: 'HR strategy and organizational development' }
    ]
  },
  {
    id: 'management_services',
    name: 'Management Services',
    description: 'Project management and operational leadership',
    icon: 'clipboard-list',
    roles: [
      { id: 'project_manager', name: 'Project Manager', description: 'Project planning, execution, and delivery' },
      { id: 'program_manager', name: 'Program Manager', description: 'Large-scale program coordination and management' },
      { id: 'general_manager', name: 'General Manager', description: 'Business unit leadership and P&L responsibility' }
    ]
  },
  {
    id: 'specialized_consulting',
    name: 'Specialized Consulting',
    description: 'Expert consulting in specific business areas',
    icon: 'lightbulb',
    roles: [
      { id: 'strategy_consultant', name: 'Strategy Consultant', description: 'Business strategy and strategic planning' },
      { id: 'operations_consultant', name: 'Operations Consultant', description: 'Process improvement and operational efficiency' },
      { id: 'digital_transformation', name: 'Digital Transformation', description: 'Technology adoption and digital strategy' },
      { id: 'change_management', name: 'Change Management', description: 'Organizational change and transformation' }
    ]
  }
]

// Professional Service Categories (Expanded)
export const PROFESSIONAL_SERVICE_CATEGORIES = [
  {
    id: 'financial_services',
    name: 'Financial Services',
    description: 'Accounting, tax, and financial advisory services',
    icon: 'calculator',
    services: [
      'tax_preparation', 'bookkeeping', 'financial_planning', 'audit_compliance',
      'payroll_services', 'cfo_services', 'business_formation', 'investment_advisory'
    ]
  },
  {
    id: 'legal_services',
    name: 'Legal Services',
    description: 'Business legal services and compliance',
    icon: 'scale',
    services: [
      'corporate_law', 'contract_management', 'intellectual_property', 'compliance_consulting',
      'employment_law', 'real_estate_law', 'tax_law', 'litigation_support'
    ]
  },
  {
    id: 'technology_services',
    name: 'Technology Services',
    description: 'Software development and IT consulting',
    icon: 'code',
    services: [
      'software_development', 'web_development', 'mobile_development', 'cloud_consulting',
      'cybersecurity', 'data_analytics', 'it_support', 'system_integration'
    ]
  },
  {
    id: 'marketing_services',
    name: 'Marketing Services',
    description: 'Marketing strategy and digital marketing',
    icon: 'megaphone',
    services: [
      'marketing_strategy', 'digital_marketing', 'content_marketing', 'social_media',
      'seo_services', 'brand_consulting', 'advertising', 'public_relations'
    ]
  },
  {
    id: 'hr_services',
    name: 'HR Services',
    description: 'Human resources and organizational development',
    icon: 'users',
    services: [
      'hr_consulting', 'talent_acquisition', 'organizational_development', 'compensation_consulting',
      'training_development', 'performance_management', 'employee_relations', 'benefits_administration'
    ]
  },
  {
    id: 'business_services',
    name: 'Business Services',
    description: 'General business consulting and support',
    icon: 'briefcase',
    services: [
      'business_consulting', 'market_research', 'business_planning', 'process_improvement',
      'quality_assurance', 'risk_management', 'vendor_management', 'facilities_management'
    ]
  }
]

// Real Estate Property Types
export const REAL_ESTATE_PROPERTY_TYPES = [
  {
    id: 'office_space',
    name: 'Traditional Office Space',
    description: 'Private offices and office suites',
    features: ['private_offices', 'conference_rooms', 'reception_area', 'parking']
  },
  {
    id: 'coworking',
    name: 'Coworking Space',
    description: 'Shared workspace and hot desks',
    features: ['hot_desks', 'dedicated_desks', 'meeting_rooms', 'networking']
  },
  {
    id: 'executive_suite',
    name: 'Executive Suite',
    description: 'Furnished executive offices with services',
    features: ['furnished', 'receptionist', 'mail_handling', 'phone_service']
  },
  {
    id: 'warehouse',
    name: 'Warehouse Space',
    description: 'Storage and distribution facilities',
    features: ['loading_docks', 'high_ceilings', 'storage_racks', 'security']
  },
  {
    id: 'retail_space',
    name: 'Retail Space',
    description: 'Commercial retail and storefront locations',
    features: ['storefront', 'foot_traffic', 'display_windows', 'customer_parking']
  },
  {
    id: 'mixed_use',
    name: 'Mixed Use',
    description: 'Combined office, retail, and other uses',
    features: ['flexible_use', 'multiple_zones', 'varied_access', 'diverse_tenants']
  }
]

// Software License Types
export const SOFTWARE_LICENSE_TYPES = [
  {
    id: 'perpetual',
    name: 'Perpetual License',
    description: 'One-time purchase with permanent usage rights',
    transferable: true
  },
  {
    id: 'subscription',
    name: 'Subscription License',
    description: 'Monthly or annual subscription model',
    transferable: false
  },
  {
    id: 'volume',
    name: 'Volume License',
    description: 'Multi-user license for organizations',
    transferable: true
  },
  {
    id: 'educational',
    name: 'Educational License',
    description: 'Discounted license for educational institutions',
    transferable: false
  },
  {
    id: 'trial',
    name: 'Trial License',
    description: 'Limited-time trial or demo license',
    transferable: false
  }
]

// Engagement Types for Executive Services
export const ENGAGEMENT_TYPES = [
  {
    id: 'fractional',
    name: 'Fractional Executive',
    description: 'Part-time ongoing executive role',
    typical_duration: '6-24 months',
    commitment: '10-40 hours/week'
  },
  {
    id: 'interim',
    name: 'Interim Executive',
    description: 'Temporary full-time executive role',
    typical_duration: '3-12 months',
    commitment: 'Full-time'
  },
  {
    id: 'project_based',
    name: 'Project-Based',
    description: 'Specific project or initiative leadership',
    typical_duration: '1-6 months',
    commitment: 'Variable'
  },
  {
    id: 'advisory',
    name: 'Advisory Role',
    description: 'Strategic advice and guidance',
    typical_duration: '6-36 months',
    commitment: '2-10 hours/week'
  },
  {
    id: 'board_member',
    name: 'Board Member',
    description: 'Board of directors participation',
    typical_duration: '12-60 months',
    commitment: '5-15 hours/month'
  }
]

// Industry Categories
export const INDUSTRY_CATEGORIES = [
  'Technology', 'Healthcare', 'Finance', 'Manufacturing', 'Retail',
  'Real Estate', 'Education', 'Non-Profit', 'Government', 'Consulting',
  'Energy', 'Transportation', 'Media', 'Hospitality', 'Agriculture',
  'Construction', 'Telecommunications', 'Pharmaceuticals', 'Automotive', 'Aerospace'
]

// Company Size Categories
export const COMPANY_SIZE_CATEGORIES = [
  { id: 'startup', name: 'Startup', description: '1-10 employees', range: '1-10' },
  { id: 'small_business', name: 'Small Business', description: '11-50 employees', range: '11-50' },
  { id: 'mid_market', name: 'Mid-Market', description: '51-500 employees', range: '51-500' },
  { id: 'enterprise', name: 'Enterprise', description: '501-5000 employees', range: '501-5000' },
  { id: 'fortune_500', name: 'Fortune 500', description: '5000+ employees', range: '5000+' }
]

// Helper functions
export const getEquipmentSubcategories = (categoryId: string) => {
  const category = EQUIPMENT_CATEGORIES.find(cat => cat.id === categoryId)
  return category?.subcategories || []
}

export const getExecutiveRoles = (categoryId: string) => {
  const category = EXECUTIVE_SERVICE_CATEGORIES.find(cat => cat.id === categoryId)
  return category?.roles || []
}

export const getProfessionalServices = (categoryId: string) => {
  const category = PROFESSIONAL_SERVICE_CATEGORIES.find(cat => cat.id === categoryId)
  return category?.services || []
}

export const getRealEstateFeatures = (propertyType: string) => {
  const type = REAL_ESTATE_PROPERTY_TYPES.find(type => type.id === propertyType)
  return type?.features || []
}

// Search configuration
export const SEARCH_CONFIG = {
  DEFAULT_RADIUS: 50,
  MAX_RADIUS: 500,
  MIN_RADIUS: 5,
  DEFAULT_LIMIT: 20,
  MAX_LIMIT: 100,
  SORT_OPTIONS: {
    services: ['relevance', 'price_low', 'price_high', 'distance', 'rating', 'newest'],
    equipment: ['relevance', 'price_low', 'price_high', 'distance', 'condition', 'newest'],
    executives: ['relevance', 'hourly_rate_low', 'hourly_rate_high', 'experience', 'distance', 'rating'],
    real_estate: ['relevance', 'price_low', 'price_high', 'distance', 'square_footage', 'newest']
  }
}

export default ENHANCED_MARKETPLACE_CONFIG

