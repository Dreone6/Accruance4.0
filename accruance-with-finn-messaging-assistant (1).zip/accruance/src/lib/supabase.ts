import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export type BusinessType = 'sole_prop' | 'llc' | 'corp' | 's_corp'
export type AccountingMethod = 'cash' | 'accrual'
export type UserRole = 'owner' | 'admin' | 'accountant' | 'read_only'
export type TransactionType = 'income' | 'expense' | 'transfer'
export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled'
export type AccountType = 'asset' | 'liability' | 'equity' | 'income' | 'expense'

export interface Organization {
  id: string
  name: string
  business_type: BusinessType
  accounting_method: AccountingMethod
  industry?: string
  monthly_revenue?: number
  fiscal_year_end?: string
  tax_id?: string
  w9_document_url?: string
  created_at: string
  updated_at: string
}

export interface User {
  id: string
  organization_id?: string
  role: UserRole
  first_name?: string
  last_name?: string
  email: string
  avatar_url?: string
  onboarding_completed: boolean
  created_at: string
  updated_at: string
}

export interface Account {
  id: string
  organization_id: string
  account_number?: string
  name: string
  account_type: AccountType
  parent_account_id?: string
  description?: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface Transaction {
  id: string
  organization_id: string
  account_id: string
  bank_connection_id?: string
  plaid_transaction_id?: string
  amount: number
  transaction_type: TransactionType
  description?: string
  category?: string
  subcategory?: string
  merchant_name?: string
  transaction_date: string
  is_categorized: boolean
  ai_confidence_score?: number
  is_reconciled: boolean
  notes?: string
  created_at: string
  updated_at: string
}

export interface Invoice {
  id: string
  organization_id: string
  invoice_number: string
  customer_name: string
  customer_email?: string
  customer_address?: string
  issue_date: string
  due_date: string
  subtotal: number
  tax_amount: number
  total_amount: number
  status: InvoiceStatus
  payment_terms?: string
  notes?: string
  stripe_payment_intent_id?: string
  paid_at?: string
  created_at: string
  updated_at: string
}

export interface InvoiceLineItem {
  id: string
  invoice_id: string
  description: string
  quantity: number
  unit_price: number
  line_total: number
  created_at: string
}

export interface Receipt {
  id: string
  organization_id: string
  transaction_id?: string
  file_url: string
  file_name?: string
  file_size?: number
  merchant_name?: string
  amount?: number
  receipt_date?: string
  category?: string
  ocr_text?: string
  ocr_confidence_score?: number
  is_matched: boolean
  created_at: string
  updated_at: string
}

export interface BankConnection {
  id: string
  organization_id: string
  plaid_item_id: string
  plaid_access_token: string
  bank_name?: string
  account_name?: string
  account_type?: string
  account_subtype?: string
  mask?: string
  is_active: boolean
  last_sync_at?: string
  created_at: string
  updated_at: string
}

export interface AICategorization {
  id: string
  organization_id: string
  merchant_pattern?: string
  description_pattern?: string
  category: string
  subcategory?: string
  confidence_threshold: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface ReportsCache {
  id: string
  organization_id: string
  report_type: string
  report_period: string
  report_data: any
  generated_at: string
  expires_at: string
}

