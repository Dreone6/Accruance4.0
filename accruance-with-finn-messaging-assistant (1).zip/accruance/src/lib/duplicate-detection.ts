import { ReceiptManager } from './receipt-manager'
import type { ReceiptData } from './receipt-manager'

export interface DuplicateDetectionResult {
  isDuplicate: boolean
  confidence: number
  duplicateReceipts: ReceiptData[]
  reasons: string[]
}

export interface DuplicateGroup {
  id: string
  receipts: ReceiptData[]
  confidence: number
  reasons: string[]
  suggestedAction: 'keep_first' | 'keep_highest_quality' | 'manual_review'
}

export class DuplicateDetectionService {
  // Main duplicate detection function
  static async detectDuplicates(
    newReceipt: ReceiptData, 
    existingReceipts: ReceiptData[]
  ): Promise<DuplicateDetectionResult> {
    const duplicates: ReceiptData[] = []
    let maxConfidence = 0
    const allReasons: string[] = []

    for (const existing of existingReceipts) {
      const comparison = this.compareReceipts(newReceipt, existing)
      if (comparison.confidence > 0.7) { // 70% threshold for duplicates
        duplicates.push(existing)
        maxConfidence = Math.max(maxConfidence, comparison.confidence)
        allReasons.push(...comparison.reasons)
      }
    }

    return {
      isDuplicate: duplicates.length > 0,
      confidence: maxConfidence,
      duplicateReceipts: duplicates,
      reasons: [...new Set(allReasons)] // Remove duplicate reasons
    }
  }

  // Compare two receipts for similarity
  static compareReceipts(receipt1: ReceiptData, receipt2: ReceiptData): {
    confidence: number
    reasons: string[]
  } {
    let confidence = 0
    const reasons: string[] = []

    // Skip comparison if either receipt lacks extracted data
    if (!receipt1.extracted_data || !receipt2.extracted_data) {
      return { confidence: 0, reasons: [] }
    }

    const data1 = receipt1.extracted_data
    const data2 = receipt2.extracted_data

    // 1. Exact amount matching (highest weight)
    if (data1.total_amount && data2.total_amount) {
      const amountDiff = Math.abs(data1.total_amount - data2.total_amount)
      if (amountDiff === 0) {
        confidence += 0.4
        reasons.push('Exact amount match')
      } else if (amountDiff <= 0.01) {
        confidence += 0.35
        reasons.push('Very close amount match')
      } else if (amountDiff <= 1.00) {
        confidence += 0.2
        reasons.push('Close amount match')
      }
    }

    // 2. Date matching
    if (data1.date && data2.date) {
      const date1 = new Date(data1.date)
      const date2 = new Date(data2.date)
      const daysDiff = Math.abs((date1.getTime() - date2.getTime()) / (1000 * 60 * 60 * 24))
      
      if (daysDiff === 0) {
        confidence += 0.25
        reasons.push('Same date')
      } else if (daysDiff <= 1) {
        confidence += 0.15
        reasons.push('Within 1 day')
      } else if (daysDiff <= 3) {
        confidence += 0.05
        reasons.push('Within 3 days')
      }
    }

    // 3. Merchant name matching
    if (data1.merchant_name && data2.merchant_name) {
      const merchant1 = data1.merchant_name.toLowerCase().trim()
      const merchant2 = data2.merchant_name.toLowerCase().trim()
      
      if (merchant1 === merchant2) {
        confidence += 0.2
        reasons.push('Exact merchant match')
      } else if (this.calculateStringSimilarity(merchant1, merchant2) > 0.8) {
        confidence += 0.15
        reasons.push('Similar merchant name')
      }
    }

    // 4. Receipt number matching (if available)
    if (data1.receipt_number && data2.receipt_number) {
      if (data1.receipt_number === data2.receipt_number) {
        confidence += 0.3
        reasons.push('Same receipt number')
      }
    }

    // 5. Tax amount matching
    if (data1.tax_amount && data2.tax_amount) {
      const taxDiff = Math.abs(data1.tax_amount - data2.tax_amount)
      if (taxDiff === 0) {
        confidence += 0.1
        reasons.push('Same tax amount')
      } else if (taxDiff <= 0.01) {
        confidence += 0.05
        reasons.push('Similar tax amount')
      }
    }

    // 6. File similarity (name, size, type)
    if (receipt1.file_name === receipt2.file_name) {
      confidence += 0.15
      reasons.push('Same filename')
    } else if (this.calculateStringSimilarity(receipt1.file_name, receipt2.file_name) > 0.7) {
      confidence += 0.05
      reasons.push('Similar filename')
    }

    if (receipt1.file_size === receipt2.file_size) {
      confidence += 0.1
      reasons.push('Same file size')
    }

    if (receipt1.file_type === receipt2.file_type) {
      confidence += 0.05
      reasons.push('Same file type')
    }

    // 7. Line items comparison (if available)
    if (data1.items && data2.items && data1.items.length > 0 && data2.items.length > 0) {
      const itemSimilarity = this.compareLineItems(data1.items, data2.items)
      confidence += itemSimilarity * 0.15
      if (itemSimilarity > 0.8) {
        reasons.push('Very similar line items')
      } else if (itemSimilarity > 0.5) {
        reasons.push('Similar line items')
      }
    }

    return {
      confidence: Math.min(confidence, 1.0), // Cap at 100%
      reasons
    }
  }

  // Find all duplicate groups in a set of receipts
  static async findDuplicateGroups(receipts: ReceiptData[]): Promise<DuplicateGroup[]> {
    const groups: DuplicateGroup[] = []
    const processed = new Set<string>()

    for (let i = 0; i < receipts.length; i++) {
      if (processed.has(receipts[i].id)) continue

      const currentReceipt = receipts[i]
      const duplicates = [currentReceipt]
      let maxConfidence = 0
      const allReasons: string[] = []

      for (let j = i + 1; j < receipts.length; j++) {
        if (processed.has(receipts[j].id)) continue

        const comparison = this.compareReceipts(currentReceipt, receipts[j])
        if (comparison.confidence > 0.7) {
          duplicates.push(receipts[j])
          maxConfidence = Math.max(maxConfidence, comparison.confidence)
          allReasons.push(...comparison.reasons)
          processed.add(receipts[j].id)
        }
      }

      if (duplicates.length > 1) {
        groups.push({
          id: `group_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          receipts: duplicates,
          confidence: maxConfidence,
          reasons: [...new Set(allReasons)],
          suggestedAction: this.getSuggestedAction(duplicates)
        })
      }

      processed.add(currentReceipt.id)
    }

    return groups.sort((a, b) => b.confidence - a.confidence)
  }

  // Calculate string similarity using Levenshtein distance
  static calculateStringSimilarity(str1: string, str2: string): number {
    const len1 = str1.length
    const len2 = str2.length
    
    if (len1 === 0) return len2 === 0 ? 1 : 0
    if (len2 === 0) return 0

    const matrix = Array(len2 + 1).fill(null).map(() => Array(len1 + 1).fill(null))

    for (let i = 0; i <= len1; i++) matrix[0][i] = i
    for (let j = 0; j <= len2; j++) matrix[j][0] = j

    for (let j = 1; j <= len2; j++) {
      for (let i = 1; i <= len1; i++) {
        const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,     // deletion
          matrix[j - 1][i] + 1,     // insertion
          matrix[j - 1][i - 1] + indicator // substitution
        )
      }
    }

    const maxLen = Math.max(len1, len2)
    return (maxLen - matrix[len2][len1]) / maxLen
  }

  // Compare line items between two receipts
  static compareLineItems(items1: any[], items2: any[]): number {
    if (items1.length === 0 && items2.length === 0) return 1
    if (items1.length === 0 || items2.length === 0) return 0

    let totalSimilarity = 0
    let comparisons = 0

    for (const item1 of items1) {
      let bestMatch = 0
      for (const item2 of items2) {
        let itemSimilarity = 0

        // Compare descriptions
        if (item1.description && item2.description) {
          itemSimilarity += this.calculateStringSimilarity(
            item1.description.toLowerCase(),
            item2.description.toLowerCase()
          ) * 0.5
        }

        // Compare prices
        if (item1.unit_price && item2.unit_price) {
          const priceDiff = Math.abs(item1.unit_price - item2.unit_price)
          if (priceDiff === 0) {
            itemSimilarity += 0.3
          } else if (priceDiff <= 0.01) {
            itemSimilarity += 0.25
          } else if (priceDiff <= 1.00) {
            itemSimilarity += 0.1
          }
        }

        // Compare quantities
        if (item1.quantity && item2.quantity) {
          if (item1.quantity === item2.quantity) {
            itemSimilarity += 0.2
          }
        }

        bestMatch = Math.max(bestMatch, itemSimilarity)
      }
      totalSimilarity += bestMatch
      comparisons++
    }

    return comparisons > 0 ? totalSimilarity / comparisons : 0
  }

  // Get suggested action for duplicate group
  static getSuggestedAction(receipts: ReceiptData[]): DuplicateGroup['suggestedAction'] {
    // If all receipts have the same confidence score, keep the first one
    const confidenceScores = receipts.map(r => r.confidence_score || 0)
    const maxConfidence = Math.max(...confidenceScores)
    const highConfidenceCount = confidenceScores.filter(c => c === maxConfidence).length

    if (highConfidenceCount === 1) {
      return 'keep_highest_quality'
    }

    // If receipts have very different file sizes, might be different quality scans
    const fileSizes = receipts.map(r => r.file_size)
    const maxSize = Math.max(...fileSizes)
    const minSize = Math.min(...fileSizes)
    
    if (maxSize / minSize > 2) {
      return 'keep_highest_quality'
    }

    // If upload dates are very close, likely accidental duplicates
    const uploadDates = receipts.map(r => new Date(r.upload_date).getTime())
    const dateRange = Math.max(...uploadDates) - Math.min(...uploadDates)
    const oneHour = 60 * 60 * 1000

    if (dateRange < oneHour) {
      return 'keep_first'
    }

    return 'manual_review'
  }

  // Resolve duplicate group by keeping specified receipt and removing others
  static async resolveDuplicateGroup(
    groupId: string, 
    keepReceiptId: string, 
    removeReceiptIds: string[]
  ): Promise<void> {
    try {
      // Remove duplicate receipts
      for (const receiptId of removeReceiptIds) {
        await ReceiptManager.deleteReceipt(receiptId)
      }

      // Add note to kept receipt about duplicate resolution
      await ReceiptManager.updateReceiptNotes(
        keepReceiptId, 
        `Duplicate resolution: Kept this receipt, removed ${removeReceiptIds.length} duplicates`
      )

      console.log(`Resolved duplicate group ${groupId}: kept ${keepReceiptId}, removed ${removeReceiptIds.length} duplicates`)
    } catch (error) {
      console.error('Error resolving duplicate group:', error)
      throw error
    }
  }

  // Get duplicate detection statistics
  static async getDuplicateStats(organizationId: string): Promise<{
    totalReceipts: number
    duplicateGroups: number
    potentialDuplicates: number
    storageWasted: number
  }> {
    try {
      const { receipts } = await ReceiptManager.getReceipts(organizationId)
      const duplicateGroups = await this.findDuplicateGroups(receipts)
      
      let potentialDuplicates = 0
      let storageWasted = 0

      for (const group of duplicateGroups) {
        potentialDuplicates += group.receipts.length - 1 // All but one are duplicates
        
        // Calculate wasted storage (sum of all but the largest file)
        const fileSizes = group.receipts.map(r => r.file_size).sort((a, b) => b - a)
        storageWasted += fileSizes.slice(1).reduce((sum, size) => sum + size, 0)
      }

      return {
        totalReceipts: receipts.length,
        duplicateGroups: duplicateGroups.length,
        potentialDuplicates,
        storageWasted
      }
    } catch (error) {
      console.error('Error getting duplicate stats:', error)
      return {
        totalReceipts: 0,
        duplicateGroups: 0,
        potentialDuplicates: 0,
        storageWasted: 0
      }
    }
  }

  // Format file size for display
  static formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  // Get confidence color for UI
  static getConfidenceColor(confidence: number): string {
    if (confidence >= 0.9) return 'text-red-600 bg-red-100'
    if (confidence >= 0.8) return 'text-orange-600 bg-orange-100'
    if (confidence >= 0.7) return 'text-yellow-600 bg-yellow-100'
    return 'text-gray-600 bg-gray-100'
  }
}

