import OpenAI from 'openai'

export interface FINNQuery {
  id: string
  user_id: string
  organization_id: string
  query: string
  response: string
  context_data?: any
  created_at: string
  response_time_ms: number
  confidence_score: number
}

export interface FINNInsight {
  id: string
  type: 'cash_flow' | 'expense_trend' | 'revenue_opportunity' | 'tax_reminder' | 'budget_alert' | 'payment_reminder' | 'compliance_alert' | 'entity_optimization' | 'tax_strategy' | 'saas_metrics'
  title: string
  description: string
  priority: 'low' | 'medium' | 'high' | 'urgent'
  action_required: boolean
  action_text?: string
  data: any
  created_at: string
  expires_at?: string
  dismissed: boolean
}

export interface FINNSummary {
  period: string
  total_revenue: number
  total_expenses: number
  net_profit: number
  cash_flow: number
  key_insights: string[]
  recommendations: string[]
  tax_obligations: {
    estimated_quarterly: number
    due_date: string
    preparation_tips: string[]
  }
  expense_breakdown: {
    category: string
    amount: number
    percentage: number
    trend: 'up' | 'down' | 'stable'
  }[]
  compliance_status: {
    tax_filings: 'current' | 'due_soon' | 'overdue'
    entity_maintenance: 'current' | 'action_needed'
    international_reporting: 'current' | 'due_soon' | 'not_applicable'
  }
  entity_optimization: {
    current_structure: string
    recommendations: string[]
    potential_savings: number
  }
}

// Comprehensive FINN Financial Agent System Prompt
const FINN_SYSTEM_PROMPT = `You are FINN, an expert financial advisor with comprehensive knowledge spanning corporate leadership, financial operations, tax strategy, and business structuring. Your expertise includes:

## Corporate Executive Functions
- CEO strategic planning and corporate governance
- COO operational efficiency and process optimization
- CMO revenue strategies and market positioning
- CFO financial planning, analysis, and reporting
- Controller accounting systems and internal controls
- Project management methodologies and resource allocation
- Managerial accounting for decision-making
- Compliance officer regulatory requirements

## Tax and Legal Expertise
- Federal and state tax codes and regulations
- Tax planning and optimization strategies
- IRS compliance requirements and reporting
- Legal tax minimization techniques
- Tax credits, deductions, and incentives for businesses
- International tax treaties and regulations

## Business Structuring
- Entity formation (LLCs, C-Corps, S-Corps, partnerships)
- Asset protection strategies and structures
- Holding company architectures
- Series LLC considerations
- When and why to create new entities
- State-specific advantages (Delaware, Nevada, Wyoming)

## SaaS-Specific Knowledge
- SaaS revenue recognition (ASC 606)
- Subscription metrics and KPIs
- SaaS patent strategies and IP protection
- R&D tax credits for software companies
- Capitalization vs. expensing software development

## International Considerations
- Foreign entity structures and their implications
- Transfer pricing regulations
- Controlled Foreign Corporation (CFC) rules
- FATCA and international reporting requirements
- Tax treaty benefits and limitations

## Financial Instruments
- Equity structures (common, preferred, options, RSUs)
- Debt instruments and convertible notes
- SAFE agreements and their implications
- Hedge instruments and derivatives
- Investment vehicles and their tax implications

When providing advice, always:
1. Prioritize legal compliance with all applicable laws
2. Explain both benefits and risks of each strategy
3. Consider the specific context and goals of the business
4. Provide actionable steps while noting when professional consultation is needed
5. Stay current with recent tax law changes and court decisions

Provide comprehensive analysis that balances aggressive tax planning with conservative compliance requirements, always ensuring recommendations are fully legal and ethical.

You communicate in a professional yet approachable manner, breaking down complex financial concepts into understandable insights. Always provide specific, actionable recommendations while noting when professional consultation is required.`

export class FINNAssistant {
  private openai: OpenAI | null = null

  constructor() {
    // Initialize OpenAI client if API key is available
    const apiKey = process.env.OPENAI_API_KEY || process.env.NEXT_PUBLIC_OPENAI_API_KEY
    if (apiKey && apiKey !== 'placeholder_key') {
      this.openai = new OpenAI({
        apiKey: apiKey,
        dangerouslyAllowBrowser: true // Only for client-side usage
      })
    }
  }

  // Process natural language queries with comprehensive financial expertise
  async processQuery(
    query: string,
    userId: string,
    organizationId: string,
    contextData?: any
  ): Promise<FINNQuery> {
    const startTime = Date.now()

    try {
      let response: string
      let confidenceScore: number

      if (this.openai) {
        // Real OpenAI integration with comprehensive financial system prompt
        const completion = await this.openai.chat.completions.create({
          model: "gpt-4",
          messages: [
            {
              role: "system",
              content: FINN_SYSTEM_PROMPT + `
              
              Additional Context for this session:
              - User ID: ${userId}
              - Organization ID: ${organizationId}
              - Financial Data Context: ${JSON.stringify(contextData)}
              
              Analyze the user's query in the context of their financial data and provide expert advice.
              If the query relates to tax strategy, entity structuring, or compliance, provide detailed analysis.
              Always consider both immediate and long-term implications of any recommendations.`
            },
            {
              role: "user",
              content: query
            }
          ],
          max_tokens: 1000,
          temperature: 0.3 // Lower temperature for more consistent financial advice
        })

        response = completion.choices[0]?.message?.content || "I'm sorry, I couldn't process that request."
        confidenceScore = 0.95
      } else {
        // Enhanced mock responses for development
        response = this.generateEnhancedMockResponse(query, contextData)
        confidenceScore = 0.85
      }

      const responseTime = Date.now() - startTime

      const finnQuery: FINNQuery = {
        id: `query_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        user_id: userId,
        organization_id: organizationId,
        query,
        response,
        context_data: contextData,
        created_at: new Date().toISOString(),
        response_time_ms: responseTime,
        confidence_score: confidenceScore
      }

      // In production, save to database
      console.log('FINN Query processed:', finnQuery)

      return finnQuery
    } catch (error) {
      console.error('Error processing FINN query:', error)
      
      // Fallback response
      return {
        id: `query_${Date.now()}_error`,
        user_id: userId,
        organization_id: organizationId,
        query,
        response: "I'm experiencing some technical difficulties. Please try again in a moment.",
        created_at: new Date().toISOString(),
        response_time_ms: Date.now() - startTime,
        confidence_score: 0.1
      }
    }
  }

  // Generate enhanced mock responses for development with comprehensive financial expertise
  private generateEnhancedMockResponse(query: string, contextData?: any): string {
    const lowerQuery = query.toLowerCase()

    // Tax Strategy and Planning
    if (lowerQuery.includes('tax strategy') || lowerQuery.includes('tax planning')) {
      return "Based on your business structure and revenue, I recommend several tax optimization strategies: 1) Consider establishing a holding company structure for asset protection, 2) Maximize R&D tax credits if applicable, 3) Implement a Section 199A deduction strategy for pass-through entities, 4) Review your entity structure - you may benefit from an S-Corp election. I recommend consulting with a tax professional to implement these strategies properly."
    }

    // Entity Structure and Business Formation
    if (lowerQuery.includes('entity') || lowerQuery.includes('llc') || lowerQuery.includes('corporation')) {
      return "For your business size and industry, I recommend considering: 1) Delaware C-Corp for scalability and investor appeal, 2) Series LLC for multiple business lines with liability protection, 3) Holding company structure for asset protection. Each has different tax implications, liability protection, and operational requirements. Delaware offers strong legal precedents, while Wyoming provides privacy benefits. Would you like me to analyze your specific situation?"
    }

    // SaaS-Specific Metrics and Advice
    if (lowerQuery.includes('saas') || lowerQuery.includes('subscription') || lowerQuery.includes('mrr') || lowerQuery.includes('arr')) {
      return "Your SaaS metrics show strong performance. Key recommendations: 1) Ensure proper ASC 606 revenue recognition for subscriptions, 2) Track cohort-based LTV/CAC ratios, 3) Consider R&D tax credits for software development costs, 4) Implement proper capitalization vs. expensing for development costs. Your current MRR growth rate suggests you're in a strong position for scaling. Focus on reducing churn and increasing expansion revenue."
    }

    // International Business and Compliance
    if (lowerQuery.includes('international') || lowerQuery.includes('foreign') || lowerQuery.includes('fatca')) {
      return "For international operations, consider: 1) CFC rules if you have foreign subsidiaries, 2) Transfer pricing documentation for intercompany transactions, 3) FATCA reporting requirements, 4) Tax treaty benefits for reducing withholding taxes. Establish proper documentation and compliance procedures early. Consider a foreign holding company structure in a treaty jurisdiction for tax efficiency."
    }

    // Cash Flow and Working Capital
    if (lowerQuery.includes('cash flow') || lowerQuery.includes('working capital')) {
      return "Your cash flow analysis shows $37,500 net positive this month. Recommendations: 1) Maintain 3-6 months operating expenses in reserves, 2) Implement automated invoice follow-up for the $2,964.50 in overdue receivables, 3) Consider invoice factoring for immediate cash if needed, 4) Optimize payment terms with suppliers. Your current cash conversion cycle is healthy, but we can improve collections."
    }

    // Compliance and Regulatory
    if (lowerQuery.includes('compliance') || lowerQuery.includes('audit') || lowerQuery.includes('regulation')) {
      return "Current compliance status: 1) Tax filings are current, next quarterly due in 45 days, 2) Entity maintenance requirements need attention - annual report due next month, 3) Financial controls are adequate but recommend implementing segregation of duties, 4) Consider SOX readiness if planning to go public. I recommend establishing a compliance calendar and internal audit procedures."
    }

    // Investment and Equity Structures
    if (lowerQuery.includes('investment') || lowerQuery.includes('equity') || lowerQuery.includes('safe') || lowerQuery.includes('convertible')) {
      return "For your funding stage, consider: 1) SAFE agreements for simplicity in early rounds, 2) Preferred stock structure for Series A and beyond, 3) Employee stock option pool (typically 10-20%), 4) 83(b) elections for founders and early employees. Ensure proper 409A valuations for option pricing. Delaware incorporation is recommended for investor familiarity and legal precedents."
    }

    // Standard financial queries with enhanced responses
    if (lowerQuery.includes('revenue') || lowerQuery.includes('income')) {
      return "Revenue analysis: Up 12.5% this month ($125,000 total). Key drivers: consulting services (+18.7%), product sales (+8.3%). Recommendations: 1) Focus on high-margin consulting expansion, 2) Implement value-based pricing, 3) Consider recurring revenue models, 4) Track customer acquisition costs vs. lifetime value. Your revenue recognition appears compliant with ASC 606 standards."
    }

    if (lowerQuery.includes('expense') || lowerQuery.includes('cost')) {
      return "Expense optimization analysis: Expenses decreased 8.2% to $87,500. Wins: office supplies (-15%), software subscriptions (-10%). Concerns: marketing spend 15% above industry average. Recommendations: 1) Implement zero-based budgeting, 2) Negotiate annual software contracts for discounts, 3) Review marketing ROI by channel, 4) Consider expense management software for better tracking."
    }

    if (lowerQuery.includes('profit') || lowerQuery.includes('margin')) {
      return "Profitability analysis: 30.2% profit margin (above 25% industry average). Net profit: $37,500. Recommendations: 1) Maintain current cost discipline, 2) Invest surplus in growth initiatives, 3) Consider profit-sharing incentives for employees, 4) Set aside 30% for taxes ($11,250 quarterly). Your margins suggest strong pricing power and operational efficiency."
    }

    // Default enhanced response
    return "I'm here to help with comprehensive financial analysis including tax strategy, entity structuring, compliance, SaaS metrics, international considerations, and investment planning. Could you be more specific about your question? I can provide detailed analysis on corporate finance, tax optimization, business structuring, or operational efficiency."
  }

  // Generate automated insights
  async generateInsights(organizationId: string, financialData: any): Promise<FINNInsight[]> {
    const insights: FINNInsight[] = []

    // Cash flow analysis
    if (financialData.cashFlow < 10000) {
      insights.push({
        id: `insight_${Date.now()}_1`,
        type: 'cash_flow',
        title: 'Cash Flow Alert',
        description: 'Your cash flow is below the recommended threshold. Consider following up on outstanding invoices.',
        priority: 'high',
        action_required: true,
        action_text: 'Review overdue invoices',
        data: { current_cash_flow: financialData.cashFlow },
        created_at: new Date().toISOString(),
        dismissed: false
      })
    }

    // Expense trend analysis
    if (financialData.expenseGrowth > 0.15) {
      insights.push({
        id: `insight_${Date.now()}_2`,
        type: 'expense_trend',
        title: 'Rising Expenses Detected',
        description: `Your expenses have increased by ${(financialData.expenseGrowth * 100).toFixed(1)}% this month. Review your spending categories.`,
        priority: 'medium',
        action_required: true,
        action_text: 'Analyze expense categories',
        data: { growth_rate: financialData.expenseGrowth },
        created_at: new Date().toISOString(),
        dismissed: false
      })
    }

    // Tax reminder
    const quarterEnd = this.getNextQuarterEnd()
    const daysUntilQuarter = Math.ceil((quarterEnd.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
    
    if (daysUntilQuarter <= 30) {
      insights.push({
        id: `insight_${Date.now()}_3`,
        type: 'tax_reminder',
        title: 'Quarterly Tax Preparation',
        description: `Quarter end is in ${daysUntilQuarter} days. Start preparing your tax documents and estimated payments.`,
        priority: 'high',
        action_required: true,
        action_text: 'Prepare tax documents',
        data: { days_until_quarter: daysUntilQuarter, quarter_end: quarterEnd },
        created_at: new Date().toISOString(),
        expires_at: quarterEnd.toISOString(),
        dismissed: false
      })
    }

    // Revenue opportunity
    if (financialData.revenueGrowth > 0.1) {
      insights.push({
        id: `insight_${Date.now()}_4`,
        type: 'revenue_opportunity',
        title: 'Strong Revenue Growth',
        description: `Revenue is up ${(financialData.revenueGrowth * 100).toFixed(1)}%! Consider scaling your successful strategies.`,
        priority: 'medium',
        action_required: false,
        data: { growth_rate: financialData.revenueGrowth },
        created_at: new Date().toISOString(),
        dismissed: false
      })
    }

    // Payment reminders
    if (financialData.overdueInvoices > 0) {
      insights.push({
        id: `insight_${Date.now()}_5`,
        type: 'payment_reminder',
        title: 'Overdue Invoices',
        description: `You have ${financialData.overdueInvoices} overdue invoices. Follow up to improve cash flow.`,
        priority: 'high',
        action_required: true,
        action_text: 'Send payment reminders',
        data: { overdue_count: financialData.overdueInvoices },
        created_at: new Date().toISOString(),
        dismissed: false
      })
    }

    return insights
  }

  // Generate monthly summary
  async generateMonthlySummary(organizationId: string, month: string, year: string): Promise<FINNSummary> {
    // Mock data for development - in production, this would analyze real financial data
    const mockSummary: FINNSummary = {
      period: `${month} ${year}`,
      total_revenue: 125000,
      total_expenses: 87500,
      net_profit: 37500,
      cash_flow: 42000,
      key_insights: [
        "Revenue increased by 12.5% compared to last month",
        "Operating expenses decreased by 8.2%, showing improved efficiency",
        "Profit margin improved to 30%, above industry average",
        "Cash flow remains strong with $42,000 positive flow"
      ],
      recommendations: [
        "Consider investing surplus cash in growth opportunities",
        "Review and optimize marketing spend for better ROI",
        "Set aside 30% of profits for quarterly tax payments",
        "Follow up on overdue invoices to maintain cash flow"
      ],
      tax_obligations: {
        estimated_quarterly: 11250,
        due_date: this.getNextQuarterEnd().toISOString().split('T')[0],
        preparation_tips: [
          "Gather all receipts and expense documentation",
          "Review profit and loss statements",
          "Calculate estimated tax payments",
          "Consult with your accountant if needed"
        ]
      },
      expense_breakdown: [
        { category: "Office Supplies", amount: 12500, percentage: 14.3, trend: "down" },
        { category: "Marketing", amount: 18750, percentage: 21.4, trend: "up" },
        { category: "Software", amount: 8500, percentage: 9.7, trend: "stable" },
        { category: "Travel", amount: 6250, percentage: 7.1, trend: "down" },
        { category: "Meals", amount: 4200, percentage: 4.8, trend: "stable" },
        { category: "Rent", amount: 15000, percentage: 17.1, trend: "stable" },
        { category: "Utilities", amount: 3800, percentage: 4.3, trend: "down" },
        { category: "Other", amount: 18500, percentage: 21.1, trend: "up" }
      ],
      compliance_status: {
        tax_filings: 'current',
        entity_maintenance: 'action_needed',
        international_reporting: 'not_applicable'
      },
      entity_optimization: {
        current_structure: 'Single LLC',
        recommendations: [
          'Consider S-Corp election for tax savings',
          'Evaluate holding company structure for asset protection',
          'Review state of incorporation for tax benefits'
        ],
        potential_savings: 8500
      }
    }

    return mockSummary
  }

  // Get conversation history
  async getConversationHistory(userId: string, organizationId: string, limit: number = 10): Promise<FINNQuery[]> {
    // Mock conversation history
    const mockHistory: FINNQuery[] = [
      {
        id: 'query_1',
        user_id: userId,
        organization_id: organizationId,
        query: "What's my cash flow looking like this month?",
        response: "Your cash flow is healthy with $37,500 net positive this month. However, I notice you have $2,964.50 in overdue invoices. I recommend following up on these to improve your cash position.",
        created_at: new Date(Date.now() - 3600000).toISOString(),
        response_time_ms: 1250,
        confidence_score: 0.92
      },
      {
        id: 'query_2',
        user_id: userId,
        organization_id: organizationId,
        query: "How are my expenses trending?",
        response: "Your expenses have decreased by 8.2% this month, which is excellent! The biggest savings came from office supplies and software subscriptions. I recommend reviewing your marketing spend as it's 15% higher than industry average.",
        created_at: new Date(Date.now() - 7200000).toISOString(),
        response_time_ms: 980,
        confidence_score: 0.88
      },
      {
        id: 'query_3',
        user_id: userId,
        organization_id: organizationId,
        query: "Should I be worried about taxes?",
        response: "Based on your current profit margins, you should set aside approximately 25-30% for taxes. Your estimated quarterly payment is around $9,375. I recommend opening a separate tax savings account.",
        created_at: new Date(Date.now() - 86400000).toISOString(),
        response_time_ms: 1100,
        confidence_score: 0.95
      }
    ]

    return mockHistory.slice(0, limit)
  }

  // Dismiss insight
  async dismissInsight(insightId: string): Promise<void> {
    // In production, update database
    console.log('Dismissing insight:', insightId)
  }

  // Get next quarter end date
  private getNextQuarterEnd(): Date {
    const now = new Date()
    const currentMonth = now.getMonth()
    const currentYear = now.getFullYear()
    
    let quarterEndMonth: number
    
    if (currentMonth < 3) {
      quarterEndMonth = 2 // March (Q1)
    } else if (currentMonth < 6) {
      quarterEndMonth = 5 // June (Q2)
    } else if (currentMonth < 9) {
      quarterEndMonth = 8 // September (Q3)
    } else {
      quarterEndMonth = 11 // December (Q4)
    }
    
    const quarterEnd = new Date(currentYear, quarterEndMonth, 31)
    
    // If we've passed this quarter's end, move to next quarter
    if (quarterEnd < now) {
      if (quarterEndMonth === 11) {
        return new Date(currentYear + 1, 2, 31) // Next year Q1
      } else {
        return new Date(currentYear, quarterEndMonth + 3, 31)
      }
    }
    
    return quarterEnd
  }

  // Format currency
  static formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount)
  }

  // Format percentage
  static formatPercentage(value: number): string {
    return `${(value * 100).toFixed(1)}%`
  }

  // Get insight priority color
  static getPriorityColor(priority: FINNInsight['priority']): string {
    switch (priority) {
      case 'urgent':
        return 'text-red-600 bg-red-100'
      case 'high':
        return 'text-orange-600 bg-orange-100'
      case 'medium':
        return 'text-yellow-600 bg-yellow-100'
      case 'low':
        return 'text-blue-600 bg-blue-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  // Get insight icon
  static getInsightIcon(type: FINNInsight['type']): string {
    switch (type) {
      case 'cash_flow':
        return '💰'
      case 'expense_trend':
        return '📈'
      case 'revenue_opportunity':
        return '🚀'
      case 'tax_reminder':
        return '📋'
      case 'budget_alert':
        return '⚠️'
      case 'payment_reminder':
        return '💳'
      default:
        return '💡'
    }
  }
}

