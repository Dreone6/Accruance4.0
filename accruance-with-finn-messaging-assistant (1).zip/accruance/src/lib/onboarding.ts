import { DatabaseService } from './database'
import type { BusinessType } from './supabase'

export interface PlaidLinkConfig {
  clientName: string
  env: 'sandbox' | 'development' | 'production'
  product: string[]
  countryCodes: string[]
  language: string
}

export interface BankAccount {
  id: string
  name: string
  type: string
  subtype: string
  mask: string
  institutionName: string
  balance?: number
}

export class PlaidService {
  private static config: PlaidLinkConfig = {
    clientName: 'Accruance',
    env: 'sandbox', // Change to 'production' for live environment
    product: ['transactions', 'auth', 'identity'],
    countryCodes: ['US'],
    language: 'en'
  }

  static async createLinkToken(userId: string): Promise<string> {
    // In a real implementation, this would call your backend API
    // which would then call Plaid's /link/token/create endpoint
    
    // For demo purposes, return a mock token
    return 'link-sandbox-mock-token-' + userId
  }

  static async exchangePublicToken(publicToken: string, organizationId: string): Promise<BankAccount[]> {
    // In a real implementation, this would:
    // 1. Call your backend API with the public token
    // 2. Backend exchanges public token for access token via Plaid
    // 3. Backend stores access token securely
    // 4. Backend fetches account info and returns to frontend
    
    // For demo purposes, return mock bank accounts
    const mockAccounts: BankAccount[] = [
      {
        id: 'acc_' + Math.random().toString(36).substr(2, 9),
        name: 'Business Checking',
        type: 'depository',
        subtype: 'checking',
        mask: '0000',
        institutionName: 'Chase Bank',
        balance: 25000.00
      },
      {
        id: 'acc_' + Math.random().toString(36).substr(2, 9),
        name: 'Business Savings',
        type: 'depository',
        subtype: 'savings',
        mask: '1111',
        institutionName: 'Chase Bank',
        balance: 50000.00
      }
    ]

    // Store bank connection in database
    try {
      await DatabaseService.createBankConnection({
        organization_id: organizationId,
        institution_name: mockAccounts[0].institutionName,
        account_name: mockAccounts[0].name,
        account_type: mockAccounts[0].type,
        account_subtype: mockAccounts[0].subtype,
        mask: mockAccounts[0].mask,
        is_active: true
      })
    } catch (error) {
      console.error('Error storing bank connection:', error)
    }

    return mockAccounts
  }

  static async getTransactions(accountId: string, startDate: Date, endDate: Date) {
    // In a real implementation, this would call Plaid's /transactions/get endpoint
    // For demo purposes, return empty array
    return []
  }

  static getConfig(): PlaidLinkConfig {
    return this.config
  }
}

export interface ChartOfAccountsTemplate {
  name: string
  type: 'asset' | 'liability' | 'equity' | 'revenue' | 'expense'
  code: string
  description: string
  isDefault: boolean
}

export class OnboardingService {
  static getChartOfAccountsTemplate(businessType: BusinessType, industry: string): ChartOfAccountsTemplate[] {
    const baseAccounts: ChartOfAccountsTemplate[] = [
      // Assets
      { name: 'Cash and Cash Equivalents', type: 'asset', code: '1000', description: 'Checking and savings accounts', isDefault: true },
      { name: 'Accounts Receivable', type: 'asset', code: '1200', description: 'Money owed by customers', isDefault: true },
      { name: 'Inventory', type: 'asset', code: '1300', description: 'Products for sale', isDefault: false },
      { name: 'Equipment', type: 'asset', code: '1500', description: 'Business equipment and machinery', isDefault: true },
      { name: 'Accumulated Depreciation', type: 'asset', code: '1510', description: 'Depreciation of equipment', isDefault: true },

      // Liabilities
      { name: 'Accounts Payable', type: 'liability', code: '2000', description: 'Money owed to suppliers', isDefault: true },
      { name: 'Credit Card Payable', type: 'liability', code: '2100', description: 'Business credit card balances', isDefault: true },
      { name: 'Loans Payable', type: 'liability', code: '2200', description: 'Business loans and lines of credit', isDefault: true },
      { name: 'Payroll Liabilities', type: 'liability', code: '2300', description: 'Wages and payroll taxes owed', isDefault: true },

      // Equity
      { name: 'Owner\'s Equity', type: 'equity', code: '3000', description: 'Owner\'s investment in the business', isDefault: true },
      { name: 'Retained Earnings', type: 'equity', code: '3200', description: 'Accumulated profits', isDefault: true },

      // Revenue
      { name: 'Sales Revenue', type: 'revenue', code: '4000', description: 'Income from sales', isDefault: true },
      { name: 'Service Revenue', type: 'revenue', code: '4100', description: 'Income from services', isDefault: true },
      { name: 'Other Income', type: 'revenue', code: '4900', description: 'Miscellaneous income', isDefault: true },

      // Expenses
      { name: 'Cost of Goods Sold', type: 'expense', code: '5000', description: 'Direct costs of products sold', isDefault: false },
      { name: 'Rent Expense', type: 'expense', code: '6000', description: 'Office and facility rent', isDefault: true },
      { name: 'Utilities Expense', type: 'expense', code: '6100', description: 'Electricity, water, internet', isDefault: true },
      { name: 'Marketing Expense', type: 'expense', code: '6200', description: 'Advertising and marketing costs', isDefault: true },
      { name: 'Professional Services', type: 'expense', code: '6300', description: 'Legal, accounting, consulting', isDefault: true },
      { name: 'Office Supplies', type: 'expense', code: '6400', description: 'Office materials and supplies', isDefault: true },
      { name: 'Travel Expense', type: 'expense', code: '6500', description: 'Business travel costs', isDefault: true },
      { name: 'Insurance Expense', type: 'expense', code: '6600', description: 'Business insurance premiums', isDefault: true },
      { name: 'Depreciation Expense', type: 'expense', code: '6700', description: 'Equipment depreciation', isDefault: true },
    ]

    // Industry-specific customizations
    const industryAccounts: Record<string, ChartOfAccountsTemplate[]> = {
      retail: [
        { name: 'Inventory - Finished Goods', type: 'asset', code: '1310', description: 'Retail inventory', isDefault: true },
        { name: 'Sales Tax Payable', type: 'liability', code: '2150', description: 'Sales tax collected', isDefault: true },
        { name: 'Returns and Allowances', type: 'revenue', code: '4050', description: 'Product returns', isDefault: true },
      ],
      restaurant: [
        { name: 'Food Inventory', type: 'asset', code: '1320', description: 'Food and beverage inventory', isDefault: true },
        { name: 'Tips Payable', type: 'liability', code: '2350', description: 'Tips owed to employees', isDefault: true },
        { name: 'Food Sales', type: 'revenue', code: '4010', description: 'Food revenue', isDefault: true },
        { name: 'Beverage Sales', type: 'revenue', code: '4020', description: 'Beverage revenue', isDefault: true },
      ],
      consulting: [
        { name: 'Unbilled Receivables', type: 'asset', code: '1250', description: 'Work completed but not yet billed', isDefault: true },
        { name: 'Deferred Revenue', type: 'liability', code: '2400', description: 'Payments received in advance', isDefault: true },
        { name: 'Consulting Revenue', type: 'revenue', code: '4110', description: 'Consulting fees', isDefault: true },
      ],
      ecommerce: [
        { name: 'Digital Inventory', type: 'asset', code: '1330', description: 'Digital products and licenses', isDefault: true },
        { name: 'Payment Processing Fees', type: 'expense', code: '6250', description: 'Credit card and payment fees', isDefault: true },
        { name: 'Shipping Expense', type: 'expense', code: '6260', description: 'Shipping and fulfillment costs', isDefault: true },
      ],
      technology: [
        { name: 'Software Licenses', type: 'asset', code: '1400', description: 'Software and technology licenses', isDefault: true },
        { name: 'Research and Development', type: 'expense', code: '6800', description: 'R&D expenses', isDefault: true },
        { name: 'Software Subscriptions', type: 'expense', code: '6450', description: 'SaaS and software costs', isDefault: true },
      ]
    }

    // Combine base accounts with industry-specific accounts
    let accounts = [...baseAccounts]
    if (industryAccounts[industry]) {
      accounts = accounts.concat(industryAccounts[industry])
    }

    // Business type specific adjustments
    if (businessType === 'sole_prop') {
      accounts = accounts.filter(acc => acc.name !== 'Owner\'s Equity')
      accounts.push({ 
        name: 'Owner\'s Capital', 
        type: 'equity', 
        code: '3100', 
        description: 'Sole proprietor\'s capital account', 
        isDefault: true 
      })
    } else if (businessType === 'corp' || businessType === 's_corp') {
      accounts = accounts.filter(acc => acc.name !== 'Owner\'s Equity')
      accounts.push(
        { name: 'Common Stock', type: 'equity', code: '3100', description: 'Issued common stock', isDefault: true },
        { name: 'Additional Paid-in Capital', type: 'equity', code: '3150', description: 'Capital in excess of par value', isDefault: true }
      )
    }

    return accounts.sort((a, b) => a.code.localeCompare(b.code))
  }

  static calculateOnboardingProgress(user: any, organization: any, bankConnections: any[]): {
    percentage: number
    completedSteps: string[]
    pendingSteps: string[]
  } {
    const steps = [
      { id: 'organization', name: 'Organization Created', completed: !!organization },
      { id: 'chart_of_accounts', name: 'Chart of Accounts', completed: !!organization },
      { id: 'bank_connection', name: 'Bank Connection', completed: bankConnections.length > 0 },
      { id: 'first_transaction', name: 'First Transaction', completed: false }, // TODO: Check for transactions
      { id: 'team_members', name: 'Team Members', completed: false }, // TODO: Check for team members
    ]

    const completedSteps = steps.filter(step => step.completed).map(step => step.name)
    const pendingSteps = steps.filter(step => !step.completed).map(step => step.name)
    const percentage = Math.round((completedSteps.length / steps.length) * 100)

    return {
      percentage,
      completedSteps,
      pendingSteps
    }
  }
}

