import { supabase } from './supabase'
import type { Organization, User, Account, BusinessType } from './supabase'

export class DatabaseService {
  // Organization methods
  static async createOrganization(data: Partial<Organization>): Promise<Organization | null> {
    const { data: organization, error } = await supabase
      .from('organizations')
      .insert(data)
      .select()
      .single()

    if (error) {
      console.error('Error creating organization:', error)
      return null
    }

    return organization
  }

  static async getOrganization(id: string): Promise<Organization | null> {
    const { data: organization, error } = await supabase
      .from('organizations')
      .select('*')
      .eq('id', id)
      .single()

    if (error) {
      console.error('Error fetching organization:', error)
      return null
    }

    return organization
  }

  static async updateOrganization(id: string, data: Partial<Organization>): Promise<Organization | null> {
    const { data: organization, error } = await supabase
      .from('organizations')
      .update(data)
      .eq('id', id)
      .select()
      .single()

    if (error) {
      console.error('Error updating organization:', error)
      return null
    }

    return organization
  }

  // User methods
  static async createUser(data: Partial<User>): Promise<User | null> {
    const { data: user, error } = await supabase
      .from('users')
      .insert(data)
      .select()
      .single()

    if (error) {
      console.error('Error creating user:', error)
      return null
    }

    return user
  }

  static async getUser(id: string): Promise<User | null> {
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .single()

    if (error) {
      console.error('Error fetching user:', error)
      return null
    }

    return user
  }

  static async updateUser(id: string, data: Partial<User>): Promise<User | null> {
    const { data: user, error } = await supabase
      .from('users')
      .update(data)
      .eq('id', id)
      .select()
      .single()

    if (error) {
      console.error('Error updating user:', error)
      return null
    }

    return user
  }

  static async getUsersByOrganization(organizationId: string): Promise<User[]> {
    const { data: users, error } = await supabase
      .from('users')
      .select('*')
      .eq('organization_id', organizationId)

    if (error) {
      console.error('Error fetching users:', error)
      return []
    }

    return users || []
  }

  // Account methods
  static async createDefaultChartOfAccounts(
    organizationId: string, 
    businessType: BusinessType, 
    industry: string = 'general'
  ): Promise<boolean> {
    const { error } = await supabase.rpc('create_default_chart_of_accounts', {
      org_id: organizationId,
      business_type_param: businessType,
      industry_param: industry
    })

    if (error) {
      console.error('Error creating default chart of accounts:', error)
      return false
    }

    return true
  }

  static async getAccounts(organizationId: string): Promise<Account[]> {
    const { data: accounts, error } = await supabase
      .from('accounts')
      .select('*')
      .eq('organization_id', organizationId)
      .eq('is_active', true)
      .order('account_number')

    if (error) {
      console.error('Error fetching accounts:', error)
      return []
    }

    return accounts || []
  }

  static async createAccount(data: Partial<Account>): Promise<Account | null> {
    const { data: account, error } = await supabase
      .from('accounts')
      .insert(data)
      .select()
      .single()

    if (error) {
      console.error('Error creating account:', error)
      return null
    }

    return account
  }

  // Industry categories
  static async getIndustryCategories(industry: string): Promise<Array<{category: string, subcategory: string}>> {
    const { data: categories, error } = await supabase.rpc('get_industry_categories', {
      industry_param: industry
    })

    if (error) {
      console.error('Error fetching industry categories:', error)
      return []
    }

    return categories || []
  }

  // Health check
  static async healthCheck(): Promise<boolean> {
    try {
      const { error } = await supabase.from('organizations').select('id').limit(1)
      return !error
    } catch (error) {
      console.error('Database health check failed:', error)
      return false
    }
  }
}

