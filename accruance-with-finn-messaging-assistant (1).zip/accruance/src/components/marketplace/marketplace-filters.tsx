'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'

interface MarketplaceFiltersProps {
  searchType: 'services' | 'equipment' | 'wanted_ads'
  onFiltersChange: (filters: any) => void
  onSortChange: (sort: string) => void
  currentSort: string
}

export default function MarketplaceFilters({ 
  searchType, 
  onFiltersChange, 
  onSortChange, 
  currentSort 
}: MarketplaceFiltersProps) {
  const [filters, setFilters] = useState<any>({
    category: '',
    subcategory: '',
    minPrice: '',
    maxPrice: '',
    // Service-specific
    serviceType: '',
    locationType: '',
    minRating: '',
    verified: false,
    responseTime: '',
    // Equipment-specific
    condition: '',
    listingType: '',
    brand: '',
    yearMin: '',
    yearMax: '',
    hasWarranty: false,
    pickupLocation: '',
    // Wanted ads specific
    adType: '',
    urgency: '',
    locationPreference: ''
  })

  const [activeFilters, setActiveFilters] = useState<string[]>([])

  // Update filters when they change
  useEffect(() => {
    onFiltersChange(filters)
    
    // Track active filters for display
    const active = Object.entries(filters)
      .filter(([key, value]) => {
        if (typeof value === 'boolean') return value
        return value && value !== ''
      })
      .map(([key]) => key)
    
    setActiveFilters(active)
  }, [filters, onFiltersChange])

  // Handle filter change
  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }))
  }

  // Clear all filters
  const clearAllFilters = () => {
    setFilters({
      category: '',
      subcategory: '',
      minPrice: '',
      maxPrice: '',
      serviceType: '',
      locationType: '',
      minRating: '',
      verified: false,
      responseTime: '',
      condition: '',
      listingType: '',
      brand: '',
      yearMin: '',
      yearMax: '',
      hasWarranty: false,
      pickupLocation: '',
      adType: '',
      urgency: '',
      locationPreference: ''
    })
  }

  // Remove specific filter
  const removeFilter = (key: string) => {
    if (typeof filters[key] === 'boolean') {
      handleFilterChange(key, false)
    } else {
      handleFilterChange(key, '')
    }
  }

  // Sort options based on search type
  const getSortOptions = () => {
    const commonOptions = [
      { value: 'relevance', label: 'Most Relevant' },
      { value: 'newest', label: 'Newest First' },
      { value: 'price_low', label: 'Price: Low to High' },
      { value: 'price_high', label: 'Price: High to Low' }
    ]

    if (searchType === 'services') {
      return [
        ...commonOptions,
        { value: 'rating', label: 'Highest Rated' },
        { value: 'distance', label: 'Nearest First' }
      ]
    }

    if (searchType === 'equipment') {
      return [
        ...commonOptions,
        { value: 'condition', label: 'Best Condition' },
        { value: 'distance', label: 'Nearest First' }
      ]
    }

    return commonOptions
  }

  // Category options based on search type
  const getCategoryOptions = () => {
    if (searchType === 'services') {
      return [
        // Financial Services
        { value: 'tax-preparation', label: 'Tax Preparation' },
        { value: 'bookkeeping', label: 'Bookkeeping & Accounting' },
        { value: 'financial-planning', label: 'Financial Planning' },
        { value: 'business-consulting', label: 'Business Consulting' },
        { value: 'audit-compliance', label: 'Audit & Compliance' },
        { value: 'payroll', label: 'Payroll Services' },
        { value: 'cfo-services', label: 'CFO Services' },
        { value: 'business-formation', label: 'Business Formation' },
        
        // Executive Services
        { value: 'fractional-ceo', label: 'Fractional CEO' },
        { value: 'fractional-cfo', label: 'Fractional CFO' },
        { value: 'fractional-cto', label: 'Fractional CTO' },
        { value: 'fractional-coo', label: 'Fractional COO' },
        { value: 'fractional-cmo', label: 'Fractional CMO' },
        { value: 'fractional-chro', label: 'Fractional CHRO' },
        { value: 'project-management', label: 'Project Management' },
        { value: 'interim-management', label: 'Interim Management' },
        
        // Professional Services
        { value: 'legal-services', label: 'Legal Services' },
        { value: 'marketing-services', label: 'Marketing Services' },
        { value: 'hr-services', label: 'HR Services' },
        { value: 'technology-services', label: 'Technology Services' },
        { value: 'business-strategy', label: 'Business Strategy' },
        { value: 'operations-consulting', label: 'Operations Consulting' }
      ]
    }

    if (searchType === 'equipment') {
      return [
        { value: 'computer_hardware', label: 'Computer Hardware' },
        { value: 'software_licenses', label: 'Software Licenses' },
        { value: 'office_furniture', label: 'Office Furniture' },
        { value: 'real_estate_offices', label: 'Office Real Estate' },
        { value: 'networking_equipment', label: 'Networking Equipment' },
        { value: 'financial_tools', label: 'Financial Tools' },
        { value: 'security_systems', label: 'Security Systems' },
        { value: 'communication_tools', label: 'Communication Tools' },
        { value: 'business_assets', label: 'Business Assets' },
        { value: 'vehicles', label: 'Vehicles' },
        { value: 'machinery', label: 'Machinery' }
      ]
    }

    return []
  }

  return (
    <div className="space-y-6">
      {/* Sort Options */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Sort Results</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2">
            {getSortOptions().map((option) => (
              <Button
                key={option.value}
                variant={currentSort === option.value ? "default" : "outline"}
                size="sm"
                onClick={() => onSortChange(option.value)}
                className="justify-start"
              >
                {option.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Active Filters */}
      {activeFilters.length > 0 && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Active Filters</CardTitle>
              <Button variant="outline" size="sm" onClick={clearAllFilters}>
                Clear All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {activeFilters.map((filterKey) => (
                <Badge
                  key={filterKey}
                  variant="secondary"
                  className="cursor-pointer hover:bg-red-100"
                  onClick={() => removeFilter(filterKey)}
                >
                  {filterKey.replace(/([A-Z])/g, ' $1').toLowerCase()}
                  <span className="ml-1">×</span>
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Category Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Category</CardTitle>
        </CardHeader>
        <CardContent>
          <select
            value={filters.category}
            onChange={(e) => handleFilterChange('category', e.target.value)}
            className="w-full p-2 border rounded-md"
          >
            <option value="">All Categories</option>
            {getCategoryOptions().map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </CardContent>
      </Card>

      {/* Price Range */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Price Range</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="min-price">Min Price</Label>
              <Input
                id="min-price"
                type="number"
                placeholder="$0"
                value={filters.minPrice}
                onChange={(e) => handleFilterChange('minPrice', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="max-price">Max Price</Label>
              <Input
                id="max-price"
                type="number"
                placeholder="No limit"
                value={filters.maxPrice}
                onChange={(e) => handleFilterChange('maxPrice', e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Service-specific filters */}
      {searchType === 'services' && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Service Type</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={filters.serviceType}
                onChange={(e) => handleFilterChange('serviceType', e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="">All Types</option>
                <option value="hourly">Hourly Consulting</option>
                <option value="fixed">Fixed Price Project</option>
                <option value="package">Service Package</option>
                <option value="retainer">Monthly Retainer</option>
              </select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Location Type</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={filters.locationType}
                onChange={(e) => handleFilterChange('locationType', e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="">All Locations</option>
                <option value="remote">Remote Only</option>
                <option value="on_site">On-Site Only</option>
                <option value="hybrid">Hybrid</option>
                <option value="client_location">At Client Location</option>
              </select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Professional Quality</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="min-rating">Minimum Rating</Label>
                <select
                  id="min-rating"
                  value={filters.minRating}
                  onChange={(e) => handleFilterChange('minRating', e.target.value)}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="">Any Rating</option>
                  <option value="4">4+ Stars</option>
                  <option value="4.5">4.5+ Stars</option>
                  <option value="4.8">4.8+ Stars</option>
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="verified"
                  checked={filters.verified}
                  onChange={(e) => handleFilterChange('verified', e.target.checked)}
                />
                <Label htmlFor="verified">Verified Professionals Only</Label>
              </div>

              <div>
                <Label htmlFor="response-time">Max Response Time</Label>
                <select
                  id="response-time"
                  value={filters.responseTime}
                  onChange={(e) => handleFilterChange('responseTime', e.target.value)}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="">Any Response Time</option>
                  <option value="1">Within 1 hour</option>
                  <option value="4">Within 4 hours</option>
                  <option value="24">Within 24 hours</option>
                </select>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* Equipment-specific filters */}
      {searchType === 'equipment' && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Condition</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={filters.condition}
                onChange={(e) => handleFilterChange('condition', e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="">Any Condition</option>
                <option value="new">New</option>
                <option value="like_new">Like New</option>
                <option value="good">Good</option>
                <option value="fair">Fair</option>
                <option value="poor">Poor</option>
              </select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Listing Type</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={filters.listingType}
                onChange={(e) => handleFilterChange('listingType', e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="">All Types</option>
                <option value="sale">For Sale</option>
                <option value="lease">For Lease</option>
                <option value="rent">For Rent</option>
              </select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Equipment Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="brand">Brand</Label>
                <Input
                  id="brand"
                  placeholder="e.g., Dell, HP, Canon"
                  value={filters.brand}
                  onChange={(e) => handleFilterChange('brand', e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label htmlFor="year-min">Min Year</Label>
                  <Input
                    id="year-min"
                    type="number"
                    placeholder="2020"
                    value={filters.yearMin}
                    onChange={(e) => handleFilterChange('yearMin', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="year-max">Max Year</Label>
                  <Input
                    id="year-max"
                    type="number"
                    placeholder="2024"
                    value={filters.yearMax}
                    onChange={(e) => handleFilterChange('yearMax', e.target.value)}
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="has-warranty"
                  checked={filters.hasWarranty}
                  onChange={(e) => handleFilterChange('hasWarranty', e.target.checked)}
                />
                <Label htmlFor="has-warranty">Has Warranty</Label>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Pickup/Delivery</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={filters.pickupLocation}
                onChange={(e) => handleFilterChange('pickupLocation', e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="">Any Pickup Option</option>
                <option value="pickup_only">Pickup Only</option>
                <option value="delivery_available">Delivery Available</option>
                <option value="shipping_available">Shipping Available</option>
                <option value="digital_delivery">Digital Delivery</option>
              </select>
            </CardContent>
          </Card>
        </>
      )}

      {/* Wanted ads specific filters */}
      {searchType === 'wanted_ads' && (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Ad Type</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={filters.adType}
                onChange={(e) => handleFilterChange('adType', e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="">All Types</option>
                <option value="service_wanted">Service Wanted</option>
                <option value="equipment_wanted">Equipment Wanted</option>
                <option value="partnership">Partnership</option>
                <option value="collaboration">Collaboration</option>
              </select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Urgency</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={filters.urgency}
                onChange={(e) => handleFilterChange('urgency', e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="">Any Urgency</option>
                <option value="urgent">Urgent</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Location Preference</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={filters.locationPreference}
                onChange={(e) => handleFilterChange('locationPreference', e.target.value)}
                className="w-full p-2 border rounded-md"
              >
                <option value="">Any Location</option>
                <option value="remote">Remote</option>
                <option value="local">Local</option>
                <option value="regional">Regional</option>
                <option value="national">National</option>
                <option value="international">International</option>
              </select>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}

