'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'

interface LocationSearchProps {
  onLocationChange: (location: LocationData) => void
  defaultRadius?: number
}

interface LocationData {
  latitude: number | null
  longitude: number | null
  address: string
  city: string
  state: string
  radius: number
}

export default function LocationSearch({ onLocationChange, defaultRadius = 50 }: LocationSearchProps) {
  const [location, setLocation] = useState<LocationData>({
    latitude: null,
    longitude: null,
    address: '',
    city: '',
    state: '',
    radius: defaultRadius
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [useCurrentLocation, setUseCurrentLocation] = useState(false)

  // Get user's current location
  const getCurrentLocation = () => {
    setIsLoading(true)
    setError('')

    if (!navigator.geolocation) {
      setError('Geolocation is not supported by this browser')
      setIsLoading(false)
      return
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords
        
        try {
          // Reverse geocode to get address
          const response = await fetch(
            `https://api.mapbox.com/geocoding/v5/mapbox.places/${longitude},${latitude}.json?access_token=${process.env.NEXT_PUBLIC_MAPBOX_TOKEN}&types=address,place`
          )
          
          if (response.ok) {
            const data = await response.json()
            const place = data.features[0]
            
            if (place) {
              const newLocation = {
                latitude,
                longitude,
                address: place.place_name || '',
                city: place.context?.find((c: any) => c.id.includes('place'))?.text || '',
                state: place.context?.find((c: any) => c.id.includes('region'))?.text || '',
                radius: location.radius
              }
              
              setLocation(newLocation)
              setUseCurrentLocation(true)
              onLocationChange(newLocation)
            }
          }
        } catch (err) {
          console.error('Reverse geocoding error:', err)
          // Still use coordinates even if reverse geocoding fails
          const newLocation = {
            latitude,
            longitude,
            address: `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`,
            city: '',
            state: '',
            radius: location.radius
          }
          
          setLocation(newLocation)
          setUseCurrentLocation(true)
          onLocationChange(newLocation)
        }
        
        setIsLoading(false)
      },
      (error) => {
        setError('Unable to retrieve your location')
        setIsLoading(false)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      }
    )
  }

  // Search for address
  const searchAddress = async (address: string) => {
    if (!address.trim()) return

    setIsLoading(true)
    setError('')

    try {
      const response = await fetch(
        `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json?access_token=${process.env.NEXT_PUBLIC_MAPBOX_TOKEN}&country=US&types=address,place`
      )
      
      if (response.ok) {
        const data = await response.json()
        const place = data.features[0]
        
        if (place) {
          const [longitude, latitude] = place.center
          const newLocation = {
            latitude,
            longitude,
            address: place.place_name || address,
            city: place.context?.find((c: any) => c.id.includes('place'))?.text || '',
            state: place.context?.find((c: any) => c.id.includes('region'))?.text || '',
            radius: location.radius
          }
          
          setLocation(newLocation)
          setUseCurrentLocation(false)
          onLocationChange(newLocation)
        } else {
          setError('Address not found')
        }
      } else {
        setError('Failed to search address')
      }
    } catch (err) {
      setError('Error searching address')
    }
    
    setIsLoading(false)
  }

  // Handle radius change
  const handleRadiusChange = (newRadius: number) => {
    const updatedLocation = { ...location, radius: newRadius }
    setLocation(updatedLocation)
    onLocationChange(updatedLocation)
  }

  // Clear location
  const clearLocation = () => {
    const clearedLocation = {
      latitude: null,
      longitude: null,
      address: '',
      city: '',
      state: '',
      radius: defaultRadius
    }
    setLocation(clearedLocation)
    setUseCurrentLocation(false)
    onLocationChange(clearedLocation)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Location & Radius</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current Location Button */}
        <div className="flex gap-2">
          <Button
            onClick={getCurrentLocation}
            disabled={isLoading}
            variant={useCurrentLocation ? "default" : "outline"}
            className="flex-1"
          >
            {isLoading ? 'Getting Location...' : 'Use Current Location'}
          </Button>
          {(location.latitude || location.address) && (
            <Button onClick={clearLocation} variant="outline">
              Clear
            </Button>
          )}
        </div>

        {/* Address Search */}
        <div className="space-y-2">
          <Label htmlFor="address-search">Search by Address</Label>
          <div className="flex gap-2">
            <Input
              id="address-search"
              placeholder="Enter city, state, or address"
              value={location.address}
              onChange={(e) => setLocation({ ...location, address: e.target.value })}
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  searchAddress(location.address)
                }
              }}
            />
            <Button 
              onClick={() => searchAddress(location.address)}
              disabled={isLoading || !location.address.trim()}
            >
              Search
            </Button>
          </div>
        </div>

        {/* Location Display */}
        {(location.latitude && location.longitude) && (
          <div className="p-3 bg-green-50 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-green-800">Location Set</p>
                <p className="text-sm text-green-600">
                  {location.city && location.state 
                    ? `${location.city}, ${location.state}`
                    : `${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}`
                  }
                </p>
              </div>
              {useCurrentLocation && (
                <Badge variant="secondary">Current Location</Badge>
              )}
            </div>
          </div>
        )}

        {/* Radius Selector */}
        <div className="space-y-2">
          <Label htmlFor="radius">Search Radius: {location.radius} miles</Label>
          <input
            id="radius"
            type="range"
            min="5"
            max="500"
            step="5"
            value={location.radius}
            onChange={(e) => handleRadiusChange(parseInt(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-xs text-gray-500">
            <span>5 mi</span>
            <span>100 mi</span>
            <span>500 mi</span>
          </div>
        </div>

        {/* Quick Radius Options */}
        <div className="flex flex-wrap gap-2">
          {[10, 25, 50, 100, 250].map((radius) => (
            <Button
              key={radius}
              variant={location.radius === radius ? "default" : "outline"}
              size="sm"
              onClick={() => handleRadiusChange(radius)}
            >
              {radius} mi
            </Button>
          ))}
        </div>

        {/* Error Display */}
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        {/* Location Info */}
        <div className="text-xs text-gray-500 space-y-1">
          <p>• Use current location for most accurate results</p>
          <p>• Search includes remote services regardless of location</p>
          <p>• Larger radius may show more results but less relevance</p>
        </div>
      </CardContent>
    </Card>
  )
}

