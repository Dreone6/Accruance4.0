'use client'

import { useState } from 'react'
import { useHotkeys } from 'react-hotkeys-hook'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { BookkeepingEngine } from '@/lib/bookkeeping'
import type { Transaction, BulkAction } from '@/lib/bookkeeping'
import { 
  Zap,
  Tag,
  CheckCircle,
  Trash2,
  Download,
  FileSpreadsheet,
  RotateCcw,
  AlertTriangle,
  Users,
  Clock,
  Target,
  Keyboard
} from 'lucide-react'

interface BulkActionsInterfaceProps {
  selectedTransactions: Transaction[]
  onBulkAction: (action: BulkAction) => Promise<void>
  onClearSelection: () => void
}

export function BulkActionsInterface({ selectedTransactions, onBulkAction, onClearSelection }: BulkActionsInterfaceProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [selectedAction, setSelectedAction] = useState<string>('')
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('')
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [pendingAction, setPendingAction] = useState<BulkAction | null>(null)

  // Mock categories
  const categories = [
    { id: 'cat_office_supplies', name: 'Office Supplies' },
    { id: 'cat_fuel', name: 'Fuel & Gas' },
    { id: 'cat_meals', name: 'Meals & Entertainment' },
    { id: 'cat_software', name: 'Software & Subscriptions' },
    { id: 'cat_marketing', name: 'Marketing & Advertising' },
    { id: 'cat_utilities', name: 'Utilities' },
    { id: 'cat_insurance', name: 'Insurance' }
  ]

  // Keyboard shortcuts for bulk actions
  useHotkeys('ctrl+shift+c', () => {
    if (selectedTransactions.length > 0) {
      setSelectedAction('categorize')
    }
  })

  useHotkeys('ctrl+shift+r', () => {
    if (selectedTransactions.length > 0) {
      handleBulkAction({ type: 'reconcile' })
    }
  })

  useHotkeys('ctrl+shift+e', () => {
    if (selectedTransactions.length > 0) {
      handleBulkAction({ type: 'export' })
    }
  })

  useHotkeys('ctrl+shift+d', () => {
    if (selectedTransactions.length > 0) {
      setSelectedAction('delete')
      setShowConfirmation(true)
      setPendingAction({ type: 'delete' })
    }
  })

  const handleBulkAction = async (action: BulkAction) => {
    if (action.type === 'delete') {
      setShowConfirmation(true)
      setPendingAction(action)
      return
    }

    setIsProcessing(true)
    try {
      await onBulkAction(action)
      setSelectedAction('')
      setSelectedCategoryId('')
    } catch (error) {
      console.error('Bulk action failed:', error)
    } finally {
      setIsProcessing(false)
    }
  }

  const confirmAction = async () => {
    if (!pendingAction) return

    setIsProcessing(true)
    try {
      await onBulkAction(pendingAction)
      setShowConfirmation(false)
      setPendingAction(null)
      setSelectedAction('')
    } catch (error) {
      console.error('Bulk action failed:', error)
    } finally {
      setIsProcessing(false)
    }
  }

  const cancelAction = () => {
    setShowConfirmation(false)
    setPendingAction(null)
    setSelectedAction('')
  }

  const getActionStats = () => {
    const totalAmount = selectedTransactions.reduce((sum, t) => sum + Math.abs(t.amount), 0)
    const incomeCount = selectedTransactions.filter(t => t.amount > 0).length
    const expenseCount = selectedTransactions.filter(t => t.amount < 0).length
    const statusCounts = selectedTransactions.reduce((acc, t) => {
      acc[t.status] = (acc[t.status] || 0) + 1
      return acc
    }, {} as Record<string, number>)

    return { totalAmount, incomeCount, expenseCount, statusCounts }
  }

  const stats = getActionStats()

  if (selectedTransactions.length === 0) {
    return null
  }

  return (
    <>
      <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center text-blue-900">
                <Zap className="w-5 h-5 mr-2" />
                Bulk Actions
              </CardTitle>
              <CardDescription className="text-blue-700">
                {selectedTransactions.length} transaction{selectedTransactions.length > 1 ? 's' : ''} selected
              </CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={onClearSelection}>
              Clear Selection
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Selection Statistics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-900">
                {BookkeepingEngine.formatCurrency(stats.totalAmount)}
              </div>
              <div className="text-xs text-blue-600">Total Amount</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{stats.incomeCount}</div>
              <div className="text-xs text-blue-600">Income</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{stats.expenseCount}</div>
              <div className="text-xs text-blue-600">Expenses</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-900">
                {Object.keys(stats.statusCounts).length}
              </div>
              <div className="text-xs text-blue-600">Status Types</div>
            </div>
          </div>

          {/* Status Breakdown */}
          <div className="flex flex-wrap gap-2">
            {Object.entries(stats.statusCounts).map(([status, count]) => (
              <Badge key={status} className={BookkeepingEngine.getStatusColor(status)}>
                {status}: {count}
              </Badge>
            ))}
          </div>

          {/* Action Selection */}
          <div className="space-y-4">
            <h3 className="font-medium text-blue-900">Select Action</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button
                variant={selectedAction === 'categorize' ? 'default' : 'outline'}
                className="h-auto p-4 flex flex-col items-center space-y-2"
                onClick={() => setSelectedAction('categorize')}
              >
                <Tag className="w-6 h-6" />
                <span className="text-sm">Categorize</span>
                <kbd className="text-xs bg-gray-200 px-1 rounded">Ctrl+Shift+C</kbd>
              </Button>

              <Button
                variant={selectedAction === 'reconcile' ? 'default' : 'outline'}
                className="h-auto p-4 flex flex-col items-center space-y-2"
                onClick={() => handleBulkAction({ type: 'reconcile' })}
                disabled={isProcessing}
              >
                <CheckCircle className="w-6 h-6" />
                <span className="text-sm">Reconcile</span>
                <kbd className="text-xs bg-gray-200 px-1 rounded">Ctrl+Shift+R</kbd>
              </Button>

              <Button
                variant={selectedAction === 'export' ? 'default' : 'outline'}
                className="h-auto p-4 flex flex-col items-center space-y-2"
                onClick={() => handleBulkAction({ type: 'export' })}
                disabled={isProcessing}
              >
                <Download className="w-6 h-6" />
                <span className="text-sm">Export</span>
                <kbd className="text-xs bg-gray-200 px-1 rounded">Ctrl+Shift+E</kbd>
              </Button>

              <Button
                variant={selectedAction === 'delete' ? 'destructive' : 'outline'}
                className="h-auto p-4 flex flex-col items-center space-y-2"
                onClick={() => {
                  setSelectedAction('delete')
                  setShowConfirmation(true)
                  setPendingAction({ type: 'delete' })
                }}
                disabled={isProcessing}
              >
                <Trash2 className="w-6 h-6" />
                <span className="text-sm">Delete</span>
                <kbd className="text-xs bg-gray-200 px-1 rounded">Ctrl+Shift+D</kbd>
              </Button>
            </div>
          </div>

          {/* Category Selection for Categorize Action */}
          {selectedAction === 'categorize' && (
            <div className="space-y-4">
              <h3 className="font-medium text-blue-900">Select Category</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {categories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategoryId === category.id ? 'default' : 'outline'}
                    className="justify-start"
                    onClick={() => setSelectedCategoryId(category.id)}
                  >
                    <Tag className="w-4 h-4 mr-2" />
                    {category.name}
                  </Button>
                ))}
              </div>
              
              {selectedCategoryId && (
                <div className="flex justify-end">
                  <Button
                    onClick={() => handleBulkAction({ type: 'categorize', categoryId: selectedCategoryId })}
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <RotateCcw className="w-4 h-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Tag className="w-4 h-4 mr-2" />
                        Apply Category
                      </>
                    )}
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Keyboard Shortcuts Help */}
          <div className="bg-white/50 rounded-lg p-4">
            <h4 className="font-medium text-blue-900 mb-3 flex items-center">
              <Keyboard className="w-4 h-4 mr-2" />
              Keyboard Shortcuts
            </h4>
            <div className="grid grid-cols-2 gap-2 text-sm text-blue-700">
              <div><kbd className="bg-gray-200 px-1 rounded text-xs">Ctrl+Shift+C</kbd> Categorize</div>
              <div><kbd className="bg-gray-200 px-1 rounded text-xs">Ctrl+Shift+R</kbd> Reconcile</div>
              <div><kbd className="bg-gray-200 px-1 rounded text-xs">Ctrl+Shift+E</kbd> Export</div>
              <div><kbd className="bg-gray-200 px-1 rounded text-xs">Ctrl+Shift+D</kbd> Delete</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="flex items-center text-red-600">
                <AlertTriangle className="w-5 h-5 mr-2" />
                Confirm Bulk Action
              </CardTitle>
              <CardDescription>
                This action cannot be undone. Please confirm you want to proceed.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h4 className="font-medium text-red-900 mb-2">
                  {pendingAction?.type === 'delete' ? 'Delete Transactions' : 'Bulk Action'}
                </h4>
                <p className="text-sm text-red-700">
                  You are about to {pendingAction?.type} {selectedTransactions.length} transaction{selectedTransactions.length > 1 ? 's' : ''}.
                  {pendingAction?.type === 'delete' && ' This will permanently remove the selected transactions from your records.'}
                </p>
              </div>

              <div className="flex justify-end space-x-3">
                <Button variant="outline" onClick={cancelAction} disabled={isProcessing}>
                  Cancel
                </Button>
                <Button 
                  variant="destructive" 
                  onClick={confirmAction}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <RotateCcw className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Confirm
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  )
}

