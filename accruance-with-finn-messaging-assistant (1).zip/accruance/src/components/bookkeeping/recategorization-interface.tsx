'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { BookkeepingEngine } from '@/lib/bookkeeping'
import type { Transaction, CategorizationSuggestion } from '@/lib/bookkeeping'
import { 
  Wand2,
  Save,
  X,
  AlertCircle,
  CheckCircle,
  Sparkles,
  ArrowRight,
  History,
  Tag,
  TrendingUp,
  Brain
} from 'lucide-react'

interface RecategorizationInterfaceProps {
  transaction: Transaction
  onSave: (categoryId: string, confidence?: number) => void
  onCancel: () => void
}

export function RecategorizationInterface({ transaction, onSave, onCancel }: RecategorizationInterfaceProps) {
  const [suggestions, setSuggestions] = useState<CategorizationSuggestion[]>([])
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>(transaction.category_id || '')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [manualOverride, setManualOverride] = useState(false)

  // Mock categories
  const categories = [
    { id: 'cat_office_supplies', name: 'Office Supplies', type: 'expense' },
    { id: 'cat_fuel', name: 'Fuel & Gas', type: 'expense' },
    { id: 'cat_meals', name: 'Meals & Entertainment', type: 'expense' },
    { id: 'cat_software', name: 'Software & Subscriptions', type: 'expense' },
    { id: 'cat_rent', name: 'Rent & Lease', type: 'expense' },
    { id: 'cat_marketing', name: 'Marketing & Advertising', type: 'expense' },
    { id: 'cat_utilities', name: 'Utilities', type: 'expense' },
    { id: 'cat_insurance', name: 'Insurance', type: 'expense' },
    { id: 'cat_sales_revenue', name: 'Sales Revenue', type: 'income' },
    { id: 'cat_consulting_revenue', name: 'Consulting Revenue', type: 'income' },
    { id: 'cat_uncategorized', name: 'Uncategorized', type: 'both' }
  ]

  const transactionType = transaction.amount >= 0 ? 'income' : 'expense'
  const filteredCategories = categories.filter(cat => cat.type === transactionType || cat.type === 'both')

  // Get AI suggestions on component mount
  useEffect(() => {
    analyzeTransaction()
  }, [])

  const analyzeTransaction = async () => {
    setIsAnalyzing(true)
    try {
      const aiSuggestions = await BookkeepingEngine.categorizeTransaction(
        transaction.description,
        Math.abs(transaction.amount)
      )
      setSuggestions(aiSuggestions)
    } catch (error) {
      console.error('Error analyzing transaction:', error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  const handleCategorySelect = (categoryId: string, isAISuggestion = false, confidence?: number) => {
    setSelectedCategoryId(categoryId)
    if (!isAISuggestion) {
      setManualOverride(true)
    }
  }

  const handleSave = () => {
    const selectedSuggestion = suggestions.find(s => s.category_id === selectedCategoryId)
    onSave(selectedCategoryId, selectedSuggestion?.confidence)
  }

  const getCurrentCategoryName = () => {
    const category = categories.find(c => c.id === (transaction.category_id || ''))
    return category?.name || 'Uncategorized'
  }

  const getSelectedCategoryName = () => {
    const category = categories.find(c => c.id === selectedCategoryId)
    return category?.name || 'Uncategorized'
  }

  return (
    <Card className="w-full max-w-4xl">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Tag className="w-5 h-5 mr-2" />
          Recategorize Transaction
        </CardTitle>
        <CardDescription>
          Review and update the category for this transaction using AI suggestions or manual selection.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Transaction Details */}
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700">Date</label>
              <p className="text-sm text-gray-900">{BookkeepingEngine.formatDate(transaction.date)}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">Description</label>
              <p className="text-sm text-gray-900 font-medium">{transaction.description}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700">Amount</label>
              <p className={`text-sm font-medium ${BookkeepingEngine.getAmountColor(transaction.amount)}`}>
                {BookkeepingEngine.formatCurrency(transaction.amount)}
              </p>
            </div>
          </div>
        </div>

        {/* Current vs New Category */}
        <div className="flex items-center justify-center space-x-4 py-4">
          <div className="text-center">
            <label className="text-sm font-medium text-gray-700">Current Category</label>
            <div className="mt-2">
              <Badge variant="outline" className="text-sm">
                {getCurrentCategoryName()}
              </Badge>
            </div>
          </div>
          
          <ArrowRight className="w-6 h-6 text-gray-400" />
          
          <div className="text-center">
            <label className="text-sm font-medium text-gray-700">New Category</label>
            <div className="mt-2">
              <Badge variant="default" className="text-sm">
                {getSelectedCategoryName()}
              </Badge>
              {manualOverride && (
                <div className="text-xs text-orange-600 mt-1">Manual Override</div>
              )}
            </div>
          </div>
        </div>

        {/* AI Suggestions */}
        {suggestions.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium flex items-center">
                <Brain className="w-5 h-5 mr-2 text-purple-600" />
                AI Suggestions
              </h3>
              <Button
                variant="outline"
                size="sm"
                onClick={analyzeTransaction}
                disabled={isAnalyzing}
              >
                <Wand2 className={`w-4 h-4 mr-2 ${isAnalyzing ? 'animate-spin' : ''}`} />
                Re-analyze
              </Button>
            </div>

            <div className="grid gap-3">
              {suggestions.map((suggestion, index) => (
                <div
                  key={index}
                  className={`p-4 border rounded-lg cursor-pointer transition-all ${
                    selectedCategoryId === suggestion.category_id
                      ? 'border-purple-500 bg-purple-50 ring-2 ring-purple-200'
                      : 'border-gray-200 hover:border-purple-300 hover:bg-purple-25'
                  }`}
                  onClick={() => handleCategorySelect(suggestion.category_id, true, suggestion.confidence)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-2">
                          <Sparkles className="w-4 h-4 text-purple-600" />
                          <span className="font-medium text-gray-900">{suggestion.category_name}</span>
                        </div>
                        <Badge 
                          variant={suggestion.confidence >= 0.9 ? 'default' : suggestion.confidence >= 0.7 ? 'secondary' : 'outline'}
                          className="text-xs"
                        >
                          {Math.round(suggestion.confidence * 100)}% confident
                        </Badge>
                        {index === 0 && (
                          <Badge variant="success" className="text-xs">
                            Top Choice
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{suggestion.reason}</p>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      {selectedCategoryId === suggestion.category_id && (
                        <CheckCircle className="w-5 h-5 text-purple-600" />
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleCategorySelect(suggestion.category_id, true, suggestion.confidence)
                        }}
                      >
                        Select
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Manual Category Selection */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium flex items-center">
            <Tag className="w-5 h-5 mr-2 text-gray-600" />
            Manual Category Selection
          </h3>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {filteredCategories.map((category) => (
              <div
                key={category.id}
                className={`p-3 border rounded-lg cursor-pointer transition-all ${
                  selectedCategoryId === category.id
                    ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200'
                    : 'border-gray-200 hover:border-blue-300 hover:bg-blue-25'
                }`}
                onClick={() => handleCategorySelect(category.id, false)}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900">{category.name}</span>
                  {selectedCategoryId === category.id && (
                    <CheckCircle className="w-4 h-4 text-blue-600" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Learning Feedback */}
        {manualOverride && (
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <TrendingUp className="w-5 h-5 text-orange-600 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-orange-900">Learning Opportunity</h4>
                <p className="text-sm text-orange-700 mt-1">
                  Your manual categorization will help improve our AI suggestions for similar transactions in the future.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex justify-end space-x-3 pt-4 border-t">
          <Button variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button 
            onClick={handleSave}
            disabled={!selectedCategoryId || selectedCategoryId === transaction.category_id}
          >
            <Save className="w-4 h-4 mr-2" />
            Save Category
          </Button>
        </div>

        {/* Help Text */}
        <div className="text-xs text-gray-500 pt-2 border-t">
          <p>
            <strong>Tip:</strong> AI suggestions are based on transaction description, amount, and historical patterns. 
            Manual selections help train the system for better future suggestions.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

