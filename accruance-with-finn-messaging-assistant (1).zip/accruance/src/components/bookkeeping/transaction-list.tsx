'use client'

import { useState, useEffect } from 'react'
import { useHotkeys } from 'react-hotkeys-hook'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { BookkeepingEngine } from '@/lib/bookkeeping'
import type { Transaction, TransactionFilters, BulkAction } from '@/lib/bookkeeping'
import { 
  Search,
  Filter,
  Download,
  Edit,
  Trash2,
  MoreHorizontal,
  CheckSquare,
  Square,
  ArrowUpDown,
  Plus,
  RefreshCw,
  Eye,
  Tag,
  Calendar,
  DollarSign,
  History,
  RotateCcw
} from 'lucide-react'

interface TransactionListProps {
  organizationId: string
  onEditTransaction: (transaction: Transaction) => void
  onCreateTransaction: () => void
  onRecategorizeTransaction?: (transaction: Transaction) => void
  onViewAuditTrail?: (transaction: Transaction) => void
  selectedTransactions?: Transaction[]
  onSelectionChange?: (transactions: Transaction[]) => void
}

export function TransactionList({ 
  organizationId, 
  onEditTransaction, 
  onCreateTransaction,
  onRecategorizeTransaction,
  onViewAuditTrail,
  selectedTransactions = [],
  onSelectionChange
}: TransactionListProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [filters, setFilters] = useState<TransactionFilters>({
    type: 'all',
    status: 'all',
    search: ''
  })
  const [sortField, setSortField] = useState<'date' | 'amount' | 'description'>('date')
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc')
  const [showFilters, setShowFilters] = useState(false)

  // Mock categories for bulk actions
  const categories = [
    { id: 'cat_office_supplies', name: 'Office Supplies' },
    { id: 'cat_fuel', name: 'Fuel & Gas' },
    { id: 'cat_meals', name: 'Meals & Entertainment' },
    { id: 'cat_software', name: 'Software & Subscriptions' },
    { id: 'cat_marketing', name: 'Marketing & Advertising' }
  ]

  const loadTransactions = async () => {
    setLoading(true)
    try {
      const result = await BookkeepingEngine.getTransactions(organizationId, filters)
      setTransactions(result.transactions)
    } catch (error) {
      console.error('Error loading transactions:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadTransactions()
  }, [organizationId, filters])

  // Update parent component when selection changes
  useEffect(() => {
    const selected = transactions.filter(t => selectedIds.has(t.id))
    onSelectionChange?.(selected)
  }, [selectedIds, transactions, onSelectionChange])

  // Keyboard shortcuts
  useHotkeys('ctrl+n', (e) => {
    e.preventDefault()
    onCreateTransaction()
  })

  useHotkeys('ctrl+a', (e) => {
    e.preventDefault()
    if (selectedIds.size === transactions.length) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(transactions.map(t => t.id)))
    }
  })

  useHotkeys('ctrl+f', (e) => {
    e.preventDefault()
    document.getElementById('search-input')?.focus()
  })

  useHotkeys('escape', () => {
    setSelectedIds(new Set())
  })

  useHotkeys('delete', () => {
    if (selectedIds.size > 0) {
      handleBulkDelete()
    }
  })

  const handleSort = (field: 'date' | 'amount' | 'description') => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('desc')
    }
  }

  const handleSelectTransaction = (id: string) => {
    const newSelected = new Set(selectedIds)
    if (newSelected.has(id)) {
      newSelected.delete(id)
    } else {
      newSelected.add(id)
    }
    setSelectedIds(newSelected)
  }

  const handleSelectAll = () => {
    if (selectedIds.size === transactions.length) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(transactions.map(t => t.id)))
    }
  }

  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return

    try {
      await BookkeepingEngine.bulkUpdateTransactions(Array.from(selectedIds), { type: 'delete' })
      setSelectedIds(new Set())
      loadTransactions()
    } catch (error) {
      console.error('Error performing bulk delete:', error)
    }
  }

  const handleDeleteTransaction = async (id: string) => {
    try {
      await BookkeepingEngine.deleteTransaction(id)
      loadTransactions()
    } catch (error) {
      console.error('Error deleting transaction:', error)
    }
  }

  const sortedTransactions = [...transactions].sort((a, b) => {
    let aValue: any, bValue: any

    switch (sortField) {
      case 'date':
        aValue = new Date(a.date)
        bValue = new Date(b.date)
        break
      case 'amount':
        aValue = Math.abs(a.amount)
        bValue = Math.abs(b.amount)
        break
      case 'description':
        aValue = a.description.toLowerCase()
        bValue = b.description.toLowerCase()
        break
      default:
        return 0
    }

    if (sortDirection === 'asc') {
      return aValue < bValue ? -1 : aValue > bValue ? 1 : 0
    } else {
      return aValue > bValue ? -1 : aValue < bValue ? 1 : 0
    }
  })

  const getStatusBadge = (status: string) => {
    const colors = BookkeepingEngine.getStatusColor(status)
    return (
      <Badge className={`text-xs ${colors}`}>
        {status}
      </Badge>
    )
  }

  const getAmountDisplay = (amount: number) => {
    const color = BookkeepingEngine.getAmountColor(amount)
    return (
      <span className={`font-medium ${color}`}>
        {BookkeepingEngine.formatCurrency(amount)}
      </span>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Transactions</h2>
          <p className="text-gray-600">Manage your financial transactions</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
          <Button variant="outline" onClick={loadTransactions}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={onCreateTransaction}>
            <Plus className="w-4 h-4 mr-2" />
            Add Transaction
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                id="search-input"
                placeholder="Search transactions..."
                value={filters.search}
                onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                className="pl-10"
              />
            </div>
            
            <select
              className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={filters.type}
              onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value as any }))}
            >
              <option value="all">All Types</option>
              <option value="income">Income</option>
              <option value="expense">Expense</option>
            </select>

            <select
              className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={filters.status}
              onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value as any }))}
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="cleared">Cleared</option>
              <option value="reconciled">Reconciled</option>
            </select>
          </div>

          {showFilters && (
            <div className="mt-4 pt-4 border-t grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Date From</label>
                <Input
                  type="date"
                  value={filters.dateFrom || ''}
                  onChange={(e) => setFilters(prev => ({ ...prev, dateFrom: e.target.value }))}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Date To</label>
                <Input
                  type="date"
                  value={filters.dateTo || ''}
                  onChange={(e) => setFilters(prev => ({ ...prev, dateTo: e.target.value }))}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Min Amount</label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={filters.minAmount || ''}
                  onChange={(e) => setFilters(prev => ({ ...prev, minAmount: parseFloat(e.target.value) || undefined }))}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Max Amount</label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={filters.maxAmount || ''}
                  onChange={(e) => setFilters(prev => ({ ...prev, maxAmount: parseFloat(e.target.value) || undefined }))}
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transactions Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Transaction History</CardTitle>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-8 text-center">
              <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-gray-600">Loading transactions...</p>
            </div>
          ) : sortedTransactions.length === 0 ? (
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No transactions found</h3>
              <p className="text-gray-500 mb-4">
                {filters.search || filters.type !== 'all' || filters.status !== 'all'
                  ? 'Try adjusting your filters or search terms.'
                  : 'Get started by adding your first transaction.'
                }
              </p>
              <Button onClick={onCreateTransaction}>
                <Plus className="w-4 h-4 mr-2" />
                Add Transaction
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="w-12 p-4">
                      <button
                        onClick={handleSelectAll}
                        className="flex items-center justify-center"
                      >
                        {selectedIds.size === transactions.length ? (
                          <CheckSquare className="w-4 h-4 text-blue-600" />
                        ) : (
                          <Square className="w-4 h-4 text-gray-400" />
                        )}
                      </button>
                    </th>
                    <th className="text-left p-4">
                      <button
                        onClick={() => handleSort('date')}
                        className="flex items-center space-x-1 font-medium text-gray-900 hover:text-blue-600"
                      >
                        <span>Date</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </button>
                    </th>
                    <th className="text-left p-4">
                      <button
                        onClick={() => handleSort('description')}
                        className="flex items-center space-x-1 font-medium text-gray-900 hover:text-blue-600"
                      >
                        <span>Description</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </button>
                    </th>
                    <th className="text-left p-4">Category</th>
                    <th className="text-right p-4">
                      <button
                        onClick={() => handleSort('amount')}
                        className="flex items-center space-x-1 font-medium text-gray-900 hover:text-blue-600 ml-auto"
                      >
                        <span>Amount</span>
                        <ArrowUpDown className="w-3 h-3" />
                      </button>
                    </th>
                    <th className="text-center p-4">Status</th>
                    <th className="w-32 p-4">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {sortedTransactions.map((transaction) => (
                    <tr
                      key={transaction.id}
                      className={`hover:bg-gray-50 ${selectedIds.has(transaction.id) ? 'bg-blue-50' : ''}`}
                    >
                      <td className="p-4">
                        <button
                          onClick={() => handleSelectTransaction(transaction.id)}
                          className="flex items-center justify-center"
                        >
                          {selectedIds.has(transaction.id) ? (
                            <CheckSquare className="w-4 h-4 text-blue-600" />
                          ) : (
                            <Square className="w-4 h-4 text-gray-400" />
                          )}
                        </button>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-900">
                            {BookkeepingEngine.formatDate(transaction.date)}
                          </span>
                        </div>
                      </td>
                      <td className="p-4">
                        <div>
                          <p className="font-medium text-gray-900">{transaction.description}</p>
                          {transaction.reference && (
                            <p className="text-sm text-gray-500">Ref: {transaction.reference}</p>
                          )}
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center space-x-2">
                          <Tag className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-600">
                            {categories.find(c => c.id === transaction.category_id)?.name || 'Uncategorized'}
                          </span>
                        </div>
                      </td>
                      <td className="p-4 text-right">
                        {getAmountDisplay(transaction.amount)}
                      </td>
                      <td className="p-4 text-center">
                        {getStatusBadge(transaction.status)}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center space-x-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onEditTransaction(transaction)}
                            title="Edit Transaction"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          {onRecategorizeTransaction && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onRecategorizeTransaction(transaction)}
                              title="Recategorize"
                            >
                              <RotateCcw className="w-4 h-4" />
                            </Button>
                          )}
                          {onViewAuditTrail && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => onViewAuditTrail(transaction)}
                              title="View Audit Trail"
                            >
                              <History className="w-4 h-4" />
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteTransaction(transaction.id)}
                            title="Delete Transaction"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Keyboard Shortcuts Help */}
      <Card className="bg-gray-50">
        <CardContent className="p-4">
          <div className="text-sm text-gray-600">
            <p className="font-medium mb-2">Keyboard Shortcuts:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <span><kbd className="px-1 py-0.5 bg-gray-200 rounded text-xs">Ctrl+N</kbd> New</span>
              <span><kbd className="px-1 py-0.5 bg-gray-200 rounded text-xs">Ctrl+A</kbd> Select All</span>
              <span><kbd className="px-1 py-0.5 bg-gray-200 rounded text-xs">Ctrl+F</kbd> Search</span>
              <span><kbd className="px-1 py-0.5 bg-gray-200 rounded text-xs">Del</kbd> Delete</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

