'use client'

import { useState, useEffect } from 'react'
import { useHotkeys } from 'react-hotkeys-hook'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { BookkeepingEngine } from '@/lib/bookkeeping'
import type { TransactionFormData, CategorizationSuggestion } from '@/lib/bookkeeping'
import { 
  Plus,
  Wand2,
  Save,
  X,
  AlertCircle,
  CheckCircle,
  Sparkles
} from 'lucide-react'

interface TransactionFormProps {
  onSubmit: (data: TransactionFormData) => void
  onCancel: () => void
  initialData?: Partial<TransactionFormData>
  organizationId: string
}

export function TransactionForm({ onSubmit, onCancel, initialData, organizationId }: TransactionFormProps) {
  const [formData, setFormData] = useState<TransactionFormData>({
    date: new Date().toISOString().split('T')[0],
    description: '',
    amount: 0,
    type: 'expense',
    category_id: '',
    account_id: 'acc_checking',
    reference: '',
    notes: '',
    ...initialData
  })

  const [suggestions, setSuggestions] = useState<CategorizationSuggestion[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Mock accounts and categories
  const accounts = [
    { id: 'acc_checking', name: 'Business Checking' },
    { id: 'acc_savings', name: 'Business Savings' },
    { id: 'acc_credit_card', name: 'Business Credit Card' }
  ]

  const categories = [
    { id: 'cat_office_supplies', name: 'Office Supplies', type: 'expense' },
    { id: 'cat_fuel', name: 'Fuel & Gas', type: 'expense' },
    { id: 'cat_meals', name: 'Meals & Entertainment', type: 'expense' },
    { id: 'cat_software', name: 'Software & Subscriptions', type: 'expense' },
    { id: 'cat_rent', name: 'Rent & Lease', type: 'expense' },
    { id: 'cat_marketing', name: 'Marketing & Advertising', type: 'expense' },
    { id: 'cat_utilities', name: 'Utilities', type: 'expense' },
    { id: 'cat_insurance', name: 'Insurance', type: 'expense' },
    { id: 'cat_sales_revenue', name: 'Sales Revenue', type: 'income' },
    { id: 'cat_consulting_revenue', name: 'Consulting Revenue', type: 'income' }
  ]

  const filteredCategories = categories.filter(cat => cat.type === formData.type)

  // AI Categorization
  const analyzeTransaction = async () => {
    if (!formData.description || formData.amount === 0) return

    setIsAnalyzing(true)
    try {
      const suggestions = await BookkeepingEngine.categorizeTransaction(
        formData.description,
        Math.abs(formData.amount)
      )
      setSuggestions(suggestions)
    } catch (error) {
      console.error('Error analyzing transaction:', error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  // Auto-analyze when description or amount changes
  useEffect(() => {
    const timer = setTimeout(() => {
      if (formData.description && formData.amount > 0) {
        analyzeTransaction()
      }
    }, 1000)

    return () => clearTimeout(timer)
  }, [formData.description, formData.amount])

  const handleInputChange = (field: keyof TransactionFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }))
    }
  }

  const applySuggestion = (suggestion: CategorizationSuggestion) => {
    setFormData(prev => ({ ...prev, category_id: suggestion.category_id }))
    setSuggestions([])
  }

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required'
    }

    if (formData.amount === 0) {
      newErrors.amount = 'Amount must be greater than 0'
    }

    if (!formData.category_id) {
      newErrors.category_id = 'Category is required'
    }

    if (!formData.account_id) {
      newErrors.account_id = 'Account is required'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (validateForm()) {
      onSubmit(formData)
    }
  }

  // Keyboard shortcuts
  useHotkeys('ctrl+s', (e) => {
    e.preventDefault()
    handleSubmit(e as any)
  })

  useHotkeys('escape', () => {
    onCancel()
  })

  useHotkeys('ctrl+shift+a', () => {
    analyzeTransaction()
  })

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Plus className="w-5 h-5 mr-2" />
          {initialData ? 'Edit Transaction' : 'Add New Transaction'}
        </CardTitle>
        <CardDescription>
          Enter transaction details. AI will suggest categories automatically.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Date and Type */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => handleInputChange('date', e.target.value)}
                className={errors.date ? 'border-red-500' : ''}
              />
              {errors.date && <p className="text-sm text-red-600">{errors.date}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Type *</Label>
              <select
                id="type"
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                value={formData.type}
                onChange={(e) => handleInputChange('type', e.target.value as 'income' | 'expense')}
              >
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </select>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Input
              id="description"
              placeholder="Enter transaction description..."
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              className={errors.description ? 'border-red-500' : ''}
            />
            {errors.description && <p className="text-sm text-red-600">{errors.description}</p>}
          </div>

          {/* Amount */}
          <div className="space-y-2">
            <Label htmlFor="amount">Amount *</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={formData.amount || ''}
                onChange={(e) => handleInputChange('amount', parseFloat(e.target.value) || 0)}
                className={`pl-8 ${errors.amount ? 'border-red-500' : ''}`}
              />
            </div>
            {errors.amount && <p className="text-sm text-red-600">{errors.amount}</p>}
          </div>

          {/* AI Suggestions */}
          {suggestions.length > 0 && (
            <div className="space-y-2">
              <Label className="flex items-center">
                <Sparkles className="w-4 h-4 mr-2 text-purple-600" />
                AI Category Suggestions
              </Label>
              <div className="space-y-2">
                {suggestions.map((suggestion, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 border border-purple-200 rounded-lg bg-purple-50 cursor-pointer hover:bg-purple-100 transition-colors"
                    onClick={() => applySuggestion(suggestion)}
                  >
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium text-purple-900">{suggestion.category_name}</span>
                        <Badge variant="outline" className="text-xs">
                          {Math.round(suggestion.confidence * 100)}% confident
                        </Badge>
                      </div>
                      <p className="text-sm text-purple-700">{suggestion.reason}</p>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => applySuggestion(suggestion)}
                    >
                      Apply
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Manual Analyze Button */}
          <div className="flex justify-center">
            <Button
              type="button"
              variant="outline"
              onClick={analyzeTransaction}
              disabled={isAnalyzing || !formData.description || formData.amount === 0}
              className="flex items-center"
            >
              <Wand2 className={`w-4 h-4 mr-2 ${isAnalyzing ? 'animate-spin' : ''}`} />
              {isAnalyzing ? 'Analyzing...' : 'Analyze with AI'}
            </Button>
          </div>

          {/* Category and Account */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Category *</Label>
              <select
                id="category"
                className={`flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${errors.category_id ? 'border-red-500' : ''}`}
                value={formData.category_id}
                onChange={(e) => handleInputChange('category_id', e.target.value)}
              >
                <option value="">Select category...</option>
                {filteredCategories.map(category => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
              {errors.category_id && <p className="text-sm text-red-600">{errors.category_id}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="account">Account *</Label>
              <select
                id="account"
                className={`flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${errors.account_id ? 'border-red-500' : ''}`}
                value={formData.account_id}
                onChange={(e) => handleInputChange('account_id', e.target.value)}
              >
                {accounts.map(account => (
                  <option key={account.id} value={account.id}>
                    {account.name}
                  </option>
                ))}
              </select>
              {errors.account_id && <p className="text-sm text-red-600">{errors.account_id}</p>}
            </div>
          </div>

          {/* Reference and Notes */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="reference">Reference (Optional)</Label>
              <Input
                id="reference"
                placeholder="Check #, Invoice #, etc."
                value={formData.reference}
                onChange={(e) => handleInputChange('reference', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Input
                id="notes"
                placeholder="Additional notes..."
                value={formData.notes}
                onChange={(e) => handleInputChange('notes', e.target.value)}
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button type="submit">
              <Save className="w-4 h-4 mr-2" />
              {initialData ? 'Update Transaction' : 'Create Transaction'}
            </Button>
          </div>

          {/* Keyboard Shortcuts Help */}
          <div className="text-xs text-gray-500 pt-2 border-t">
            <p><strong>Shortcuts:</strong> Ctrl+S to save, Esc to cancel, Ctrl+Shift+A to analyze</p>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

