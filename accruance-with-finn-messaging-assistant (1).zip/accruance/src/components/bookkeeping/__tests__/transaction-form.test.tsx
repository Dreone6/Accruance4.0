import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { TransactionForm } from '@/components/bookkeeping/transaction-form'

// Mock the bookkeeping service
jest.mock('@/lib/bookkeeping', () => ({
  BookkeepingService: {
    categorizeTransaction: jest.fn().mockResolvedValue({
      category: 'Office Supplies',
      confidence: 0.92,
      reasoning: 'Pattern matches office supply vendors',
    }),
    createTransaction: jest.fn().mockResolvedValue({
      id: 'test-transaction-1',
      description: 'Test transaction',
      amount: 100.00,
      category: 'Office Supplies',
    }),
  },
}))

describe('TransactionForm Component', () => {
  const defaultProps = {
    onSubmit: jest.fn(),
    onCancel: jest.fn(),
  }

  beforeEach(() => {
    jest.clearAllMocks()
  })

  test('renders transaction form', () => {
    render(<TransactionForm {...defaultProps} />)
    
    expect(screen.getByLabelText(/description/i)).toBeInTheDocument()
    expect(screen.getByLabelText(/amount/i)).toBeInTheDocument()
    expect(screen.getByLabelText(/date/i)).toBeInTheDocument()
    expect(screen.getByLabelText(/type/i)).toBeInTheDocument()
  })

  test('validates required fields', async () => {
    const user = userEvent.setup()
    render(<TransactionForm {...defaultProps} />)
    
    const submitButton = screen.getByRole('button', { name: /create transaction/i })
    await user.click(submitButton)

    await waitFor(() => {
      expect(screen.getByText(/description is required/i)).toBeInTheDocument()
      expect(screen.getByText(/amount is required/i)).toBeInTheDocument()
    })
  })

  test('provides AI categorization suggestions', async () => {
    const user = userEvent.setup()
    render(<TransactionForm {...defaultProps} />)
    
    const descriptionInput = screen.getByLabelText(/description/i)
    await user.type(descriptionInput, 'Staples office supplies')

    await waitFor(() => {
      expect(screen.getByText(/AI Suggestion/i)).toBeInTheDocument()
      expect(screen.getByText('Office Supplies')).toBeInTheDocument()
      expect(screen.getByText('92%')).toBeInTheDocument()
    })
  })

  test('submits form with valid data', async () => {
    const user = userEvent.setup()
    const mockOnSubmit = jest.fn()
    render(<TransactionForm {...defaultProps} onSubmit={mockOnSubmit} />)
    
    await user.type(screen.getByLabelText(/description/i), 'Test transaction')
    await user.type(screen.getByLabelText(/amount/i), '100.00')
    
    const submitButton = screen.getByRole('button', { name: /create transaction/i })
    await user.click(submitButton)

    await waitFor(() => {
      expect(mockOnSubmit).toHaveBeenCalledWith(
        expect.objectContaining({
          description: 'Test transaction',
          amount: 100.00,
        })
      )
    })
  })

  test('handles amount formatting', async () => {
    const user = userEvent.setup()
    render(<TransactionForm {...defaultProps} />)
    
    const amountInput = screen.getByLabelText(/amount/i)
    await user.type(amountInput, '1234.56')

    expect(amountInput).toHaveValue('1234.56')
  })

  test('applies AI categorization suggestion', async () => {
    const user = userEvent.setup()
    render(<TransactionForm {...defaultProps} />)
    
    const descriptionInput = screen.getByLabelText(/description/i)
    await user.type(descriptionInput, 'Staples office supplies')

    await waitFor(() => {
      expect(screen.getByText('Office Supplies')).toBeInTheDocument()
    })

    const applyButton = screen.getByRole('button', { name: /apply/i })
    await user.click(applyButton)

    const categorySelect = screen.getByDisplayValue('Office Supplies')
    expect(categorySelect).toBeInTheDocument()
  })
})

