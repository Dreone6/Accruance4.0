'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { FINNAssistant } from '@/lib/finn-assistant'
import type { FINNInsight } from '@/lib/finn-assistant'
import { 
  X,
  AlertTriangle,
  TrendingUp,
  DollarSign,
  Calendar,
  Target,
  CreditCard,
  ChevronRight,
  Lightbulb,
  CheckCircle
} from 'lucide-react'

interface FINNInsightsProps {
  organizationId: string
  financialData: any
  onInsightAction?: (insight: FINNInsight) => void
}

export function FINNInsights({ organizationId, financialData, onInsightAction }: FINNInsightsProps) {
  const [insights, setInsights] = useState<FINNInsight[]>([])
  const [loading, setLoading] = useState(true)
  const finnAssistant = new FINNAssistant()

  useEffect(() => {
    const loadInsights = async () => {
      setLoading(true)
      try {
        const generatedInsights = await finnAssistant.generateInsights(organizationId, financialData)
        setInsights(generatedInsights.filter(insight => !insight.dismissed))
      } catch (error) {
        console.error('Error loading insights:', error)
      } finally {
        setLoading(false)
      }
    }

    loadInsights()
  }, [organizationId, financialData])

  const handleDismissInsight = async (insightId: string) => {
    try {
      await finnAssistant.dismissInsight(insightId)
      setInsights(prev => prev.filter(insight => insight.id !== insightId))
    } catch (error) {
      console.error('Error dismissing insight:', error)
    }
  }

  const handleInsightAction = (insight: FINNInsight) => {
    onInsightAction?.(insight)
  }

  const getInsightIcon = (type: FINNInsight['type']) => {
    switch (type) {
      case 'cash_flow':
        return <DollarSign className="w-5 h-5" />
      case 'expense_trend':
        return <TrendingUp className="w-5 h-5" />
      case 'revenue_opportunity':
        return <Target className="w-5 h-5" />
      case 'tax_reminder':
        return <Calendar className="w-5 h-5" />
      case 'budget_alert':
        return <AlertTriangle className="w-5 h-5" />
      case 'payment_reminder':
        return <CreditCard className="w-5 h-5" />
      default:
        return <Lightbulb className="w-5 h-5" />
    }
  }

  const getPriorityIcon = (priority: FINNInsight['priority']) => {
    switch (priority) {
      case 'urgent':
        return '🚨'
      case 'high':
        return '⚠️'
      case 'medium':
        return '💡'
      case 'low':
        return 'ℹ️'
      default:
        return '💡'
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Lightbulb className="w-5 h-5 mr-2" />
            FINN Insights
          </CardTitle>
          <CardDescription>AI-powered financial insights and recommendations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Lightbulb className="w-5 h-5 mr-2" />
              FINN Insights
            </CardTitle>
            <CardDescription>AI-powered financial insights and recommendations</CardDescription>
          </div>
          {insights.length > 0 && (
            <Badge variant="outline" className="text-blue-600 border-blue-600">
              {insights.length} active
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {insights.length === 0 ? (
          <div className="text-center py-8">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">All caught up!</h3>
            <p className="text-gray-600">
              No urgent insights at the moment. FINN is monitoring your finances and will alert you to any important changes.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {insights.map((insight) => (
              <div
                key={insight.id}
                className={`border rounded-lg p-4 ${
                  insight.priority === 'urgent' ? 'border-red-200 bg-red-50' :
                  insight.priority === 'high' ? 'border-orange-200 bg-orange-50' :
                  insight.priority === 'medium' ? 'border-yellow-200 bg-yellow-50' :
                  'border-blue-200 bg-blue-50'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    <div className={`p-2 rounded-lg ${
                      insight.priority === 'urgent' ? 'bg-red-100 text-red-600' :
                      insight.priority === 'high' ? 'bg-orange-100 text-orange-600' :
                      insight.priority === 'medium' ? 'bg-yellow-100 text-yellow-600' :
                      'bg-blue-100 text-blue-600'
                    }`}>
                      {getInsightIcon(insight.type)}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="font-medium text-gray-900">{insight.title}</h4>
                        <span className="text-sm">{getPriorityIcon(insight.priority)}</span>
                        <Badge 
                          className={FINNAssistant.getPriorityColor(insight.priority)}
                          variant="secondary"
                        >
                          {insight.priority}
                        </Badge>
                      </div>
                      
                      <p className="text-sm text-gray-700 mb-3">{insight.description}</p>
                      
                      {insight.action_required && insight.action_text && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleInsightAction(insight)}
                          className="mr-2"
                        >
                          {insight.action_text}
                          <ChevronRight className="w-4 h-4 ml-1" />
                        </Button>
                      )}
                      
                      <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-200">
                        <span className="text-xs text-gray-500">
                          {new Date(insight.created_at).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                        
                        {insight.expires_at && (
                          <span className="text-xs text-gray-500">
                            Expires {new Date(insight.expires_at).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDismissInsight(insight.id)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

