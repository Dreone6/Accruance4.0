import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { FINNChat } from '@/components/finn/finn-chat'

// Mock the FINN Assistant
jest.mock('@/lib/finn-assistant', () => ({
  FINNAssistant: jest.fn().mockImplementation(() => ({
    processQuery: jest.fn().mockResolvedValue({
      id: 'test-query-1',
      user_id: 'test-user',
      organization_id: 'test-org',
      query: 'Test query',
      response: 'Test response from FINN',
      created_at: new Date().toISOString(),
      response_time_ms: 1000,
      confidence_score: 0.95,
    }),
    getConversationHistory: jest.fn().mockResolvedValue([]),
  })),
}))

describe('FINNChat Component', () => {
  const defaultProps = {
    userId: 'test-user',
    organizationId: 'test-org',
    contextData: { revenue: 100000, expenses: 75000 },
  }

  beforeEach(() => {
    jest.clearAllMocks()
  })

  test('renders FINN chat interface', async () => {
    render(<FINNChat {...defaultProps} />)
    
    await waitFor(() => {
      expect(screen.getByText('FINN AI Assistant')).toBeInTheDocument()
      expect(screen.getByText('Your AI-powered CFO assistant')).toBeInTheDocument()
      expect(screen.getByPlaceholderText('Ask FINN about your finances...')).toBeInTheDocument()
    })
  })

  test('displays welcome message for new users', async () => {
    render(<FINNChat {...defaultProps} />)
    
    await waitFor(() => {
      expect(screen.getByText("Hi! I'm FINN, your AI CFO assistant")).toBeInTheDocument()
      expect(screen.getByText(/I can help you understand your financial data/)).toBeInTheDocument()
    })
  })

  test('sends message and displays response', async () => {
    const user = userEvent.setup()
    render(<FINNChat {...defaultProps} />)
    
    await waitFor(() => {
      expect(screen.getByPlaceholderText('Ask FINN about your finances...')).toBeInTheDocument()
    })

    const input = screen.getByPlaceholderText('Ask FINN about your finances...')
    const sendButton = screen.getByRole('button', { name: /send/i })

    await user.type(input, 'What is my cash flow?')
    await user.click(sendButton)

    await waitFor(() => {
      expect(screen.getByText('What is my cash flow?')).toBeInTheDocument()
      expect(screen.getByText('Test response from FINN')).toBeInTheDocument()
    })
  })

  test('handles keyboard shortcuts', async () => {
    const user = userEvent.setup()
    render(<FINNChat {...defaultProps} />)
    
    await waitFor(() => {
      expect(screen.getByPlaceholderText('Ask FINN about your finances...')).toBeInTheDocument()
    })

    const input = screen.getByPlaceholderText('Ask FINN about your finances...')
    
    await user.type(input, 'Test message')
    await user.keyboard('{Enter}')

    await waitFor(() => {
      expect(screen.getByText('Test message')).toBeInTheDocument()
    })
  })

  test('displays confidence scores', async () => {
    const user = userEvent.setup()
    render(<FINNChat {...defaultProps} />)
    
    await waitFor(() => {
      expect(screen.getByPlaceholderText('Ask FINN about your finances...')).toBeInTheDocument()
    })

    const input = screen.getByPlaceholderText('Ask FINN about your finances...')
    const sendButton = screen.getByRole('button', { name: /send/i })

    await user.type(input, 'Test query')
    await user.click(sendButton)

    await waitFor(() => {
      expect(screen.getByText('95%')).toBeInTheDocument()
    })
  })

  test('shows loading state during message processing', async () => {
    const user = userEvent.setup()
    render(<FINNChat {...defaultProps} />)
    
    await waitFor(() => {
      expect(screen.getByPlaceholderText('Ask FINN about your finances...')).toBeInTheDocument()
    })

    const input = screen.getByPlaceholderText('Ask FINN about your finances...')
    const sendButton = screen.getByRole('button', { name: /send/i })

    await user.type(input, 'Test query')
    await user.click(sendButton)

    // Check for loading state
    expect(screen.getByText('FINN is thinking...')).toBeInTheDocument()
  })

  test('handles suggested questions', async () => {
    const user = userEvent.setup()
    render(<FINNChat {...defaultProps} />)
    
    await waitFor(() => {
      expect(screen.getByText("What's my cash flow looking like this month?")).toBeInTheDocument()
    })

    const suggestedQuestion = screen.getByText("What's my cash flow looking like this month?")
    await user.click(suggestedQuestion)

    const input = screen.getByPlaceholderText('Ask FINN about your finances...')
    expect(input).toHaveValue("What's my cash flow looking like this month?")
  })
})

