'use client'

import React from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Sparkles, 
  Crown, 
  Zap, 
  ArrowRight,
  MessageCircle,
  Bot,
  Star,
  CheckCircle
} from 'lucide-react'

interface FinnUpgradePromptProps {
  currentPlan: string
  currentUsage: number
  usageLimit: number
  isVisible: boolean
  onClose: () => void
  onUpgrade: (plan: string) => void
  upgradeReason: 'limit_reached' | 'feature_locked' | 'no_subscription'
}

const FinnUpgradePrompt: React.FC<FinnUpgradePromptProps> = ({
  currentPlan,
  currentUsage,
  usageLimit,
  isVisible,
  onClose,
  onUpgrade,
  upgradeReason
}) => {
  if (!isVisible) return null

  const planFeatures = {
    essentials: {
      name: 'Essentials',
      price: '$24.99',
      finnAssists: 50,
      features: [
        'Basic message analysis',
        'Tone suggestions',
        'Grammar checking',
        'Professional polish'
      ],
      icon: <MessageCircle className="w-5 h-5" />,
      color: 'bg-blue-500'
    },
    professional: {
      name: 'Professional',
      price: '$49.99',
      finnAssists: 200,
      features: [
        'Advanced message rewriting',
        'Context-aware suggestions',
        'Multiple tone options',
        'Response templates',
        'Conversation insights'
      ],
      icon: <Sparkles className="w-5 h-5" />,
      color: 'bg-purple-500'
    },
    enterprise: {
      name: 'Enterprise',
      price: '$99.99',
      finnAssists: 1000,
      features: [
        'Unlimited message assistance',
        'Custom communication styles',
        'Team collaboration features',
        'Advanced analytics',
        'Priority support'
      ],
      icon: <Crown className="w-5 h-5" />,
      color: 'bg-gold-500'
    }
  }

  const getUpgradeMessage = () => {
    switch (upgradeReason) {
      case 'limit_reached':
        return {
          title: "You've reached your FINN assist limit",
          description: `You've used all ${usageLimit} FINN assists for this month. Upgrade to continue getting AI-powered message assistance.`,
          urgency: 'high'
        }
      case 'feature_locked':
        return {
          title: "Unlock FINN Messaging Assistant",
          description: "Get AI-powered help to craft perfect professional messages with tone analysis, rewriting, and smart suggestions.",
          urgency: 'medium'
        }
      case 'no_subscription':
        return {
          title: "FINN Messaging Assistant",
          description: "Transform your business communication with AI-powered message assistance. Perfect every message before you send it.",
          urgency: 'low'
        }
    }
  }

  const message = getUpgradeMessage()
  const recommendedPlan = currentPlan === 'free' ? 'essentials' : 
                         currentPlan === 'essentials' ? 'professional' : 'enterprise'

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="text-center pb-4">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
              <Bot className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">
            {message.title}
          </CardTitle>
          <CardDescription className="text-lg text-gray-600 mt-2">
            {message.description}
          </CardDescription>
          
          {upgradeReason === 'limit_reached' && (
            <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <div className="flex items-center justify-center space-x-2 text-amber-800">
                <Zap className="w-5 h-5" />
                <span className="font-medium">
                  {currentUsage} / {usageLimit} assists used this month
                </span>
              </div>
            </div>
          )}
        </CardHeader>

        <CardContent>
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {Object.entries(planFeatures).map(([planKey, plan]) => {
              const isRecommended = planKey === recommendedPlan
              const isCurrent = planKey === currentPlan
              
              return (
                <div
                  key={planKey}
                  className={`relative border-2 rounded-xl p-6 transition-all duration-200 ${
                    isRecommended 
                      ? 'border-purple-500 shadow-lg scale-105' 
                      : isCurrent
                      ? 'border-blue-300 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {isRecommended && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-purple-500 text-white px-3 py-1">
                        <Star className="w-3 h-3 mr-1" />
                        Recommended
                      </Badge>
                    </div>
                  )}
                  
                  {isCurrent && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-blue-500 text-white px-3 py-1">
                        Current Plan
                      </Badge>
                    </div>
                  )}

                  <div className="text-center mb-4">
                    <div className={`w-12 h-12 ${plan.color} rounded-full flex items-center justify-center text-white mx-auto mb-3`}>
                      {plan.icon}
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">{plan.name}</h3>
                    <div className="text-3xl font-bold text-gray-900 mt-2">
                      {plan.price}
                      <span className="text-sm font-normal text-gray-600">/month</span>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {plan.finnAssists === 1000 ? 'Unlimited' : plan.finnAssists} FINN assists/month
                    </div>
                  </div>

                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    onClick={() => onUpgrade(planKey)}
                    disabled={isCurrent}
                    className={`w-full ${
                      isRecommended 
                        ? 'bg-purple-600 hover:bg-purple-700' 
                        : isCurrent
                        ? 'bg-gray-300 cursor-not-allowed'
                        : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {isCurrent ? 'Current Plan' : `Upgrade to ${plan.name}`}
                    {!isCurrent && <ArrowRight className="w-4 h-4 ml-2" />}
                  </Button>
                </div>
              )
            })}
          </div>

          <div className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-xl p-6 mb-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <Sparkles className="w-5 h-5 text-purple-600 mr-2" />
              Why FINN Messaging Assistant?
            </h4>
            <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-700">
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span>Perfect professional tone every time</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span>Context-aware suggestions for each recipient</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span>Save time with instant message improvements</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span>Build stronger professional relationships</span>
              </div>
            </div>
          </div>

          <div className="flex justify-center space-x-4">
            <Button variant="outline" onClick={onClose}>
              Maybe Later
            </Button>
            <Button 
              onClick={() => onUpgrade(recommendedPlan)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              <Crown className="w-4 h-4 mr-2" />
              Upgrade to {planFeatures[recommendedPlan as keyof typeof planFeatures].name}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default FinnUpgradePrompt

