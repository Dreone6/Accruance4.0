'use client'

import React, { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Sparkles, 
  MessageSquare, 
  CheckCircle, 
  AlertTriangle, 
  Lightbulb, 
  Wand2, 
  RotateCcw,
  TrendingUp,
  Clock,
  Star,
  Zap,
  X,
  Minimize2,
  Maximize2
} from 'lucide-react'

// FINN's logo as base64
const FINN_LOGO = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABVEAAAbiCAYAAAAkVrKVAAAACXBIWXMAAAsSAAALEgHS3X78AAAAAXNSR0IArs4c6QAAIABJREFUeF7svWuvbUuSHTTXvtVV3W3LFnQjGWSD8SfjMgJsCYHAdv9w3M0bCfN2Nx/wF4TACBthYbpNd9W9Z8HMjIgcMeKRudY599Zt6VzVqb33mnNmRkaMGBEz8rEeV/Hf8/l8XNel/+67nnQr/1019fXzrxr4PjRwY/Prfz9uDdw2qnjiq/1+3Lb7Kt2X18DXmPnldfq1xa8a+KqBrxr4qoE/fRr4mgP+6bPZV4l/PBr46j8/Hltkkrxin9N3g1fa/CG1cyq/ynR6/5cY75fo625D/12Px8PaLAV8Pp8fUkS9f+oD/DMz0qnAP6SBPxfgv2pZv/efa+BLONhX3X4/GlDbZHzw1W7fj86/tvrj18Cflvj449fkVwm/auCrBr5q4KsG/jRq4GsO+MNb7avOf3idf989frXp963h99t/xTan7wWvtPm+5K8/eSr/6X0oweeM+Uv0p8XTTyLUMy2iPp/Pb67r+on8++l1Xb8B/6Sg+ktZmfprd1u0UvW+9msi8C+v9bvq4v4s+2+09X3/9zlG+IKyDf3Bf0djfwcEX1DmH3NTA3M/ZgE/Qzb2l5fH+SVx847/dEVU5Y939fM5YxO5Kj66RXpZ19k4PkfGN/Ry6gvduF/mpjfk/JU/8g6Wvw9bfh9t/sqV+8MJgLG09NevOv7hDPK1p68aeFcDFSd/9d93Nfrjfu6dGPzjHtGfHum+lO6/+uav3uZky5Pc/ou82/zqR/5FJUC9fVH97HyNfCirm+lAT9/vvqhi3m3slBv0vk5POx1WMrIMJ3/jIlEsnP7JdV347xfXdf3i8XgM4JiAz+fzZ1A0/bPXdf3Wd9f1W/fP6/ruJ99c39yF1LvQev/7uK5P31zXh65WfVzXJ2nr43ldd8FWf97d4O/fyaDvZsY1+Xk/r7+/a7s1nk0L7xrmBcG0aI1jfOHx/a2HQHVyHD6z7fxUf+/2V7SPY2G9Mn743mpMiLnQ/qn834M+urFu7XPfcCr7rrHTsWE72TMozzttYvufMzbpu8PHZ/PQF9J/JmMp26FOX/GLlpNPbQByfe+cyFg+1MnOBT77eqErjZOn7f/g+gPBKtw4/iR9n/rRDzUu7GfonnKQUzuM+w7x/zaPv4HdtzmNxlLZI/DBoQ5e0usPeXPBTV8sZ/sB9fM2ztDHv0QO/gPaj/lT30FUhFP+cSK/YrPmXpTlLTlIj1/Cvj+gaWZXyGGsqzd875Xc5XisnYzHjXzhG1/B4GnXb8STtunvQ8bTsfxY79vp5EvbYMMRmZpSLtq9r31f+t4ttPm++t3ktV+Cr3e1KIxd/DsO+1SWLPa99P74pXS984HqeobBd/2lKphikRRzeCyY3kq7i5Ty87vvruub//u6rvvfP5V//891XX/4eDz+yAW55/P5Z67r+nPy7y6e/sVP1/WXrvnvpx/Xp7tEf/+T1aqPn1zXQwqqtvX/jptPeb9IRC4SgVtP9/mrpb5eUeTu3t31LwUkesfibsd5s/BfKta7YEze78wm0uc6z+HFAb+rv91YVIw326/w03XbdRXyvVcc/0SlB/pocs6THsJL/me194pdXrn3bCTxrcios/ZYHvn7XWwci3xg47St5Dn9qOKRLYdCR9x8xslaLNma8jOU2HL+sZI3N3YD2A7uvFC2FbfQ0/2xcvNOnM+hoNHPVshFGQFn8mxX7FQMbuNaIgeO7URObaKMo42+72d5HK/0aeJTH24MJ76/63R3faNHvtw2B/J2OAs+e8LDJ+M40VeF35P2D579rPhYtb8b1+76gc9ubznQj/LDD8LJncAq66FemD+P8uqdwrTvQxl4MgVlOFD9Tpr99e+xk9O4UQqJsp3qcz/iMH+VFayP1fI9yeiG8cbYFdsH6tjfcqyMfVNV/HvhSX/rqW7eHcNp+28PgB78nETtM2Swd4RmvMpNpsqdTl/R3asBNOv7lf5QV6/0/W4fJ3HrRfth/BqPkmzH1ES6tFw8GevO5MdDqF4SLDk/bmndyG0eCBtMn+WkHNPvv/Wf6v0unN7/vpWf9yrTb6/r0/3zH13Xx/9xXdc/ln//53Vd97+7sHo95Auk7t//ueu6fvu6rn/hu+v6l765rr/yuK5/9bqu/+a6nj+VvdNSSL2LqKOg+nFdo4iqJXMRziWoooD6fD7lQFYLzlY8fV7XY2qs0hsneFU8DSeSnD8358EwgOJEinOBkJAw4AE0+oAJFf+efT6v5/UYL/D7/+7GyCOsI88+HmZnMmYcta3ed6+e1xN6y+QrOZMUuhOh43HVTcfPjuQ2xmRdd7JxUVt1cI6XqU1qDC+1RxMc3YtWwPtg8wOEJQPrZGcfqHE8sYscwP5f2VcD0Ym/BY6R4th+5MkdINCObe6xBC4tglvDFfeXCIa86v7gbp70BQdqe9/lkVS+YVx0WNh7XYfMV9jC4pYTX9L4esaTvaSaC70UysU+7mVus8MCde7uXtH1RJumGYPWHS3mf73W8OqpflWisx5W/Onw1tlN0hM3mlclZZnNCw+4LnBFlgCfWKm650WcuGZQN3hBRYx6Os4jlEdcE7v4dKIHbbDO654p/AuatC7fxQTLHOLLht93Y3a8StY7c7rGF+knCXc+an+pcWfHYXgwWUSR8WXW5ufgvWqvyr+cT0jHnct/TlE6sfMAcm/fNJsJadmpbdaDXRP5tQ5Hmc5UmRnH2MuhCL6er7G7w3G38OJLxHuH7zQJzhho5uxzfMKt0JD58qkBi/t23HfS/I67T9p4Vc+7d3uv8zlB/UP9t+Orz+ECHlc6psOx2nuNYiy8a0+fOnnv0Ty103Mo3IL2qpOd7nIb7nOPk/Yrtc3YwwsU3yte8Wbzni/TfK945Zn"

interface FinnMessagingAssistantProps {
  messageText: string
  onMessageChange: (text: string) => void
  recipientContext?: any
  conversationContext?: any
  isVisible: boolean
  onToggleVisibility: () => void
  onSendMessage: () => void
  className?: string
}

interface AssistantSuggestion {
  type: string
  description: string
  example_before?: string
  example_after?: string
  confidence: number
}

interface UsageStats {
  messaging_assistant_available: boolean
  current_usage: number
  usage_limit: number
  remaining_uses: number
  subscription_plan: string
}

export default function FinnMessagingAssistant({
  messageText,
  onMessageChange,
  recipientContext,
  conversationContext,
  isVisible,
  onToggleVisibility,
  onSendMessage,
  className = ""
}: FinnMessagingAssistantProps) {
  const [isMinimized, setIsMinimized] = useState(false)
  const [activeTab, setActiveTab] = useState('suggestions')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [suggestions, setSuggestions] = useState<AssistantSuggestion[]>([])
  const [toneAnalysis, setToneAnalysis] = useState<any>(null)
  const [rewrittenVersions, setRewrittenVersions] = useState<any[]>([])
  const [responseOptions, setResponseOptions] = useState<any[]>([])
  const [usageStats, setUsageStats] = useState<UsageStats | null>(null)
  const [selectedTone, setSelectedTone] = useState('professional')
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false)
  const [lastAnalyzedText, setLastAnalyzedText] = useState('')
  
  const debounceTimer = useRef<NodeJS.Timeout>()

  // Fetch usage stats on component mount
  useEffect(() => {
    fetchUsageStats()
  }, [])

  // Auto-analyze message when text changes (debounced)
  useEffect(() => {
    if (messageText && messageText !== lastAnalyzedText && messageText.length > 10) {
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current)
      }
      
      debounceTimer.current = setTimeout(() => {
        analyzeMessage()
      }, 1000) // 1 second debounce
    }

    return () => {
      if (debounceTimer.current) {
        clearTimeout(debounceTimer.current)
      }
    }
  }, [messageText])

  const fetchUsageStats = async () => {
    try {
      const response = await fetch('/api/finn/messaging-assistant')
      if (response.ok) {
        const stats = await response.json()
        setUsageStats(stats)
      }
    } catch (error) {
      console.error('Error fetching usage stats:', error)
    }
  }

  const callFinnAPI = async (action: string, additionalData: any = {}) => {
    if (!usageStats?.messaging_assistant_available) {
      setShowUpgradePrompt(true)
      return null
    }

    if (usageStats.remaining_uses <= 0) {
      setShowUpgradePrompt(true)
      return null
    }

    try {
      const response = await fetch('/api/finn/messaging-assistant', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action,
          message_text: messageText,
          recipient_context: recipientContext,
          conversation_context: conversationContext,
          tone_preference: selectedTone,
          ...additionalData
        })
      })

      if (response.status === 403) {
        setShowUpgradePrompt(true)
        return null
      }

      if (response.ok) {
        const result = await response.json()
        // Update usage stats
        await fetchUsageStats()
        return result
      }
    } catch (error) {
      console.error('Error calling FINN API:', error)
    }
    return null
  }

  const analyzeMessage = async () => {
    if (!messageText.trim()) return
    
    setIsAnalyzing(true)
    setLastAnalyzedText(messageText)
    
    try {
      // Get suggestions and tone analysis in parallel
      const [suggestionsResult, toneResult] = await Promise.all([
        callFinnAPI('suggest_improvements'),
        callFinnAPI('check_tone')
      ])

      if (suggestionsResult) {
        setSuggestions(suggestionsResult.suggestions || [])
      }

      if (toneResult) {
        setToneAnalysis(toneResult.tone_analysis)
      }
    } finally {
      setIsAnalyzing(false)
    }
  }

  const rewriteMessage = async () => {
    const result = await callFinnAPI('rewrite_message')
    if (result) {
      setRewrittenVersions(result.rewritten_versions || [])
      setActiveTab('rewrite')
    }
  }

  const suggestResponses = async () => {
    const result = await callFinnAPI('suggest_responses')
    if (result) {
      setResponseOptions(result.response_options || [])
      setActiveTab('responses')
    }
  }

  const professionalPolish = async () => {
    const result = await callFinnAPI('professional_polish')
    if (result && result.polished_message) {
      onMessageChange(result.polished_message)
    }
  }

  const grammarCheck = async () => {
    const result = await callFinnAPI('grammar_check')
    if (result && result.improved_version) {
      onMessageChange(result.improved_version)
    }
  }

  const applyRewrite = (rewrittenText: string) => {
    onMessageChange(rewrittenText)
    setActiveTab('suggestions')
  }

  const applyResponse = (responseText: string) => {
    onMessageChange(responseText)
    setActiveTab('suggestions')
  }

  if (!isVisible) {
    return (
      <Button
        onClick={onToggleVisibility}
        className="fixed bottom-4 right-4 rounded-full w-14 h-14 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 shadow-lg z-50"
        size="sm"
      >
        <img src={FINN_LOGO} alt="FINN" className="w-8 h-8" />
      </Button>
    )
  }

  return (
    <Card className={`fixed bottom-4 right-4 w-96 max-h-[600px] shadow-2xl border-2 border-blue-200 bg-white z-50 ${className}`}>
      <CardHeader className="pb-2 bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <img src={FINN_LOGO} alt="FINN" className="w-8 h-8" />
            <div>
              <CardTitle className="text-lg font-bold text-gray-800">FINN Assistant</CardTitle>
              <CardDescription className="text-sm text-gray-600">
                Perfect your professional messages
              </CardDescription>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMinimized(!isMinimized)}
              className="h-8 w-8 p-0"
            >
              {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleVisibility}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Usage Stats */}
        {usageStats && (
          <div className="flex items-center justify-between text-xs text-gray-600 mt-2">
            <span>Plan: {usageStats.subscription_plan}</span>
            <span>{usageStats.remaining_uses}/{usageStats.usage_limit} assists left</span>
          </div>
        )}
      </CardHeader>

      {!isMinimized && (
        <CardContent className="p-4 max-h-[500px] overflow-y-auto">
          {showUpgradePrompt ? (
            <Alert className="mb-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                FINN Messaging Assistant requires an Essentials+ subscription. 
                <Button variant="link" className="p-0 h-auto font-semibold text-blue-600">
                  Upgrade now
                </Button>
              </AlertDescription>
            </Alert>
          ) : (
            <>
              {/* Quick Actions */}
              <div className="flex flex-wrap gap-2 mb-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={analyzeMessage}
                  disabled={!messageText.trim() || isAnalyzing}
                  className="flex items-center space-x-1"
                >
                  <Sparkles className="h-3 w-3" />
                  <span>Analyze</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={rewriteMessage}
                  disabled={!messageText.trim()}
                  className="flex items-center space-x-1"
                >
                  <Wand2 className="h-3 w-3" />
                  <span>Rewrite</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={professionalPolish}
                  disabled={!messageText.trim()}
                  className="flex items-center space-x-1"
                >
                  <Star className="h-3 w-3" />
                  <span>Polish</span>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={grammarCheck}
                  disabled={!messageText.trim()}
                  className="flex items-center space-x-1"
                >
                  <CheckCircle className="h-3 w-3" />
                  <span>Grammar</span>
                </Button>
              </div>

              {/* Tone Selector */}
              <div className="mb-4">
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Desired Tone:
                </label>
                <Select value={selectedTone} onValueChange={setSelectedTone}>
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="friendly">Friendly</SelectItem>
                    <SelectItem value="formal">Formal</SelectItem>
                    <SelectItem value="casual">Casual</SelectItem>
                    <SelectItem value="direct">Direct</SelectItem>
                    <SelectItem value="consultative">Consultative</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Tone Analysis */}
              {toneAnalysis && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <TrendingUp className="h-4 w-4 text-blue-600" />
                    <span className="font-medium text-blue-800">Tone Analysis</span>
                  </div>
                  <div className="text-sm text-gray-700">
                    <p><strong>Current:</strong> {toneAnalysis.current_tone}</p>
                    <p><strong>Score:</strong> {toneAnalysis.tone_score}/10</p>
                    {toneAnalysis.adjustments_needed && (
                      <p><strong>Suggestion:</strong> {toneAnalysis.adjustments_needed}</p>
                    )}
                  </div>
                </div>
              )}

              {/* Main Content Tabs */}
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
                  <TabsTrigger value="rewrite">Rewrite</TabsTrigger>
                  <TabsTrigger value="responses">Responses</TabsTrigger>
                </TabsList>

                <TabsContent value="suggestions" className="mt-4">
                  {isAnalyzing ? (
                    <div className="flex items-center justify-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                      <span className="ml-2 text-gray-600">Analyzing...</span>
                    </div>
                  ) : suggestions.length > 0 ? (
                    <div className="space-y-3">
                      {suggestions.map((suggestion, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-start space-x-2">
                            <Lightbulb className="h-4 w-4 text-yellow-500 mt-0.5" />
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-800">
                                {suggestion.type}
                              </p>
                              <p className="text-sm text-gray-600 mt-1">
                                {suggestion.description}
                              </p>
                              {suggestion.example_after && (
                                <div className="mt-2 p-2 bg-green-50 rounded text-xs">
                                  <strong>Try:</strong> "{suggestion.example_after}"
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <MessageSquare className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>Start typing to get suggestions</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="rewrite" className="mt-4">
                  {rewrittenVersions.length > 0 ? (
                    <div className="space-y-3">
                      {rewrittenVersions.map((version, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-800 mb-2">
                                Version {index + 1}
                              </p>
                              <p className="text-sm text-gray-700 mb-3">
                                "{version.message || version}"
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => applyRewrite(version.message || version)}
                            className="w-full"
                          >
                            Use This Version
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <RotateCcw className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>Click "Rewrite" to see alternative versions</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="responses" className="mt-4">
                  {responseOptions.length > 0 ? (
                    <div className="space-y-3">
                      {responseOptions.map((response, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <Badge variant="secondary" className="text-xs">
                                  {response.type}
                                </Badge>
                                <span className="text-xs text-gray-500">
                                  {response.tone}
                                </span>
                              </div>
                              <p className="text-sm text-gray-700 mb-2">
                                "{response.message}"
                              </p>
                              {response.rationale && (
                                <p className="text-xs text-gray-500">
                                  {response.rationale}
                                </p>
                              )}
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => applyResponse(response.message)}
                            className="w-full mt-2"
                          >
                            Use This Response
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <MessageSquare className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>Get response suggestions for received messages</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </>
          )}
        </CardContent>
      )}
    </Card>
  )
}

