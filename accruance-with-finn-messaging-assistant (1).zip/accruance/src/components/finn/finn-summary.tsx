'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { FINNAssistant } from '@/lib/finn-assistant'
import type { FINNSummary } from '@/lib/finn-assistant'
import { 
  Calendar,
  TrendingUp,
  TrendingDown,
  Minus,
  DollarSign,
  PieChart,
  FileText,
  Download,
  Mail,
  AlertCircle,
  CheckCircle,
  Target,
  Lightbulb
} from 'lucide-react'

interface FINNSummaryProps {
  organizationId: string
  month?: string
  year?: string
  onExport?: (summary: FINNSummary) => void
  onEmail?: (summary: FINNSummary) => void
}

export function FINNSummaryComponent({ 
  organizationId, 
  month = new Date().toLocaleString('default', { month: 'long' }),
  year = new Date().getFullYear().toString(),
  onExport,
  onEmail
}: FINNSummaryProps) {
  const [summary, setSummary] = useState<FINNSummary | null>(null)
  const [loading, setLoading] = useState(true)
  const finnAssistant = new FINNAssistant()

  useEffect(() => {
    const loadSummary = async () => {
      setLoading(true)
      try {
        const monthlySummary = await finnAssistant.generateMonthlySummary(organizationId, month, year)
        setSummary(monthlySummary)
      } catch (error) {
        console.error('Error loading monthly summary:', error)
      } finally {
        setLoading(false)
      }
    }

    loadSummary()
  }, [organizationId, month, year])

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="w-4 h-4 text-green-600" />
      case 'down':
        return <TrendingDown className="w-4 h-4 text-red-600" />
      case 'stable':
        return <Minus className="w-4 h-4 text-gray-600" />
    }
  }

  const getTrendColor = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up':
        return 'text-green-600'
      case 'down':
        return 'text-red-600'
      case 'stable':
        return 'text-gray-600'
    }
  }

  const handleExport = () => {
    if (summary && onExport) {
      onExport(summary)
    }
  }

  const handleEmail = () => {
    if (summary && onEmail) {
      onEmail(summary)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="w-5 h-5 mr-2" />
            Monthly Summary
          </CardTitle>
          <CardDescription>AI-generated financial summary and insights</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!summary) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="w-5 h-5 mr-2" />
            Monthly Summary
          </CardTitle>
          <CardDescription>AI-generated financial summary and insights</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Unable to generate summary</h3>
            <p className="text-gray-600">Please try again later.</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2" />
                Monthly Summary - {summary.period}
              </CardTitle>
              <CardDescription>AI-generated financial summary and insights</CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={handleEmail}>
                <Mail className="w-4 h-4 mr-2" />
                Email
              </Button>
              <Button variant="outline" size="sm" onClick={handleExport}>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Financial Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <DollarSign className="w-5 h-5 mr-2" />
            Financial Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <h3 className="text-sm font-medium text-gray-600 mb-1">Total Revenue</h3>
              <p className="text-2xl font-bold text-green-600">
                {FINNAssistant.formatCurrency(summary.total_revenue)}
              </p>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <h3 className="text-sm font-medium text-gray-600 mb-1">Total Expenses</h3>
              <p className="text-2xl font-bold text-red-600">
                {FINNAssistant.formatCurrency(summary.total_expenses)}
              </p>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <h3 className="text-sm font-medium text-gray-600 mb-1">Net Profit</h3>
              <p className="text-2xl font-bold text-blue-600">
                {FINNAssistant.formatCurrency(summary.net_profit)}
              </p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <h3 className="text-sm font-medium text-gray-600 mb-1">Cash Flow</h3>
              <p className="text-2xl font-bold text-purple-600">
                {FINNAssistant.formatCurrency(summary.cash_flow)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Lightbulb className="w-5 h-5 mr-2" />
            Key Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {summary.key_insights.map((insight, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-gray-700">{insight}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Target className="w-5 h-5 mr-2" />
            Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {summary.recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg">
                <Target className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-gray-700">{recommendation}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Expense Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <PieChart className="w-5 h-5 mr-2" />
            Expense Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {summary.expense_breakdown.map((expense, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2">
                    <span className="font-medium text-gray-900">{expense.category}</span>
                    {getTrendIcon(expense.trend)}
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {expense.percentage.toFixed(1)}%
                  </Badge>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">
                    {FINNAssistant.formatCurrency(expense.amount)}
                  </p>
                  <p className={`text-xs ${getTrendColor(expense.trend)}`}>
                    {expense.trend === 'stable' ? 'No change' : 
                     expense.trend === 'up' ? 'Increased' : 'Decreased'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Tax Obligations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            Tax Obligations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-orange-50 rounded-lg">
              <div>
                <h3 className="font-medium text-gray-900">Estimated Quarterly Payment</h3>
                <p className="text-sm text-gray-600">
                  Due: {new Date(summary.tax_obligations.due_date).toLocaleDateString()}
                </p>
              </div>
              <div className="text-right">
                <p className="text-xl font-bold text-orange-600">
                  {FINNAssistant.formatCurrency(summary.tax_obligations.estimated_quarterly)}
                </p>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-gray-900 mb-3">Preparation Tips</h4>
              <div className="space-y-2">
                {summary.tax_obligations.preparation_tips.map((tip, index) => (
                  <div key={index} className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-gray-700">{tip}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

