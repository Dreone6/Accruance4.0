'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { DashboardService } from '@/lib/dashboard'
import type { DashboardMetrics } from '@/lib/dashboard'
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Minus
} from 'lucide-react'

interface MetricsCardsProps {
  metrics: DashboardMetrics
}

export function MetricsCards({ metrics }: MetricsCardsProps) {
  const cards = [
    {
      title: 'Total Revenue',
      value: metrics.totalRevenue,
      change: metrics.revenueChange,
      icon: DollarSign,
      description: 'Total income this month'
    },
    {
      title: 'Total Expenses',
      value: metrics.totalExpenses,
      change: metrics.expensesChange,
      icon: TrendingDown,
      description: 'Total spending this month'
    },
    {
      title: 'Net Profit',
      value: metrics.netProfit,
      change: metrics.profitChange,
      icon: BarChart3,
      description: 'Revenue minus expenses'
    },
    {
      title: 'Cash Flow',
      value: metrics.cashFlow,
      change: metrics.cashFlowChange,
      icon: TrendingUp,
      description: 'Money in minus money out'
    }
  ]

  const getChangeIcon = (change: number) => {
    if (change > 0) return ArrowUpRight
    if (change < 0) return ArrowDownRight
    return Minus
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, index) => {
        const Icon = card.icon
        const ChangeIcon = getChangeIcon(card.change)
        const changeColor = DashboardService.getChangeColor(card.change)
        
        return (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {card.title}
              </CardTitle>
              <Icon className="h-4 w-4 text-gray-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900 mb-1">
                {DashboardService.formatCurrency(card.value)}
              </div>
              <div className="flex items-center text-xs">
                <ChangeIcon className={`w-3 h-3 mr-1 ${changeColor}`} />
                <span className={changeColor}>
                  {DashboardService.formatPercentage(card.change)}
                </span>
                <span className="text-gray-500 ml-1">from last month</span>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {card.description}
              </p>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

