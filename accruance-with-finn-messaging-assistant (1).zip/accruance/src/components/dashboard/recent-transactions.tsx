'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { DashboardService } from '@/lib/dashboard'
import type { TransactionSummary } from '@/lib/dashboard'
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  MoreHorizontal,
  Filter,
  Download
} from 'lucide-react'

interface RecentTransactionsProps {
  transactions: TransactionSummary[]
}

export function RecentTransactions({ transactions }: RecentTransactionsProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'cleared':
        return 'success'
      case 'pending':
        return 'warning'
      case 'reconciled':
        return 'default'
      default:
        return 'outline'
    }
  }

  const getAmountColor = (amount: number) => {
    return amount >= 0 ? 'text-green-600' : 'text-red-600'
  }

  const getAmountIcon = (amount: number) => {
    return amount >= 0 ? ArrowUpRight : ArrowDownRight
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Recent Transactions</CardTitle>
            <CardDescription>
              Your latest financial activity
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {transactions.length === 0 ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <ArrowUpRight className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No transactions yet</h3>
              <p className="text-gray-500 mb-4">
                Connect your bank account or add your first transaction to get started.
              </p>
              <Button>Add Transaction</Button>
            </div>
          ) : (
            <>
              {transactions.map((transaction) => {
                const AmountIcon = getAmountIcon(transaction.amount)
                const amountColor = getAmountColor(transaction.amount)
                
                return (
                  <div key={transaction.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        transaction.amount >= 0 ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        <AmountIcon className={`w-5 h-5 ${amountColor}`} />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {transaction.description}
                          </p>
                          <Badge variant={getStatusColor(transaction.status)} className="text-xs">
                            {transaction.status}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <span>{transaction.date}</span>
                          <span>•</span>
                          <span>{transaction.category}</span>
                          <span>•</span>
                          <span>{transaction.account}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="text-right">
                        <p className={`text-sm font-semibold ${amountColor}`}>
                          {DashboardService.formatCurrency(Math.abs(transaction.amount))}
                        </p>
                        <p className="text-xs text-gray-500 capitalize">
                          {transaction.type}
                        </p>
                      </div>
                      
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )
              })}
              
              <div className="pt-4 border-t">
                <Button variant="outline" className="w-full">
                  View All Transactions
                </Button>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

