'use client'

import { useState, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { InvoiceManager } from '@/lib/invoice-manager'
import type { InvoiceData } from '@/lib/invoice-manager'
import { 
  Download,
  Send,
  Edit,
  X,
  Mail,
  FileText,
  Calendar,
  DollarSign,
  User,
  Building,
  Phone,
  MapPin,
  CreditCard,
  Clock
} from 'lucide-react'

interface InvoiceViewerProps {
  invoice: InvoiceData
  onClose: () => void
  onEdit: (invoice: InvoiceData) => void
  onUpdate?: (invoice: InvoiceData) => void
}

export function InvoiceViewer({ invoice, onClose, onEdit, onUpdate }: InvoiceViewerProps) {
  const [loading, setLoading] = useState(false)
  const invoiceRef = useRef<HTMLDivElement>(null)

  const handleDownloadPDF = async () => {
    if (!invoiceRef.current) return

    setLoading(true)
    try {
      const blob = await InvoiceManager.generatePDF(invoice, 'invoice-content')
      
      // Create download link
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `${invoice.invoice_number}.pdf`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    } catch (error) {
      console.error('Error downloading PDF:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSendInvoice = async () => {
    setLoading(true)
    try {
      await InvoiceManager.sendInvoice(invoice.id, invoice.client_email)
      const updatedInvoice = await InvoiceManager.updateInvoice(invoice.id, { status: 'sent' })
      onUpdate?.(updatedInvoice)
    } catch (error) {
      console.error('Error sending invoice:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  const isOverdue = () => {
    const dueDate = new Date(invoice.due_date)
    const today = new Date()
    return invoice.status !== 'paid' && dueDate < today
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              Invoice {invoice.invoice_number}
            </h2>
            <p className="text-sm text-gray-500">
              {invoice.client_name} • {formatDate(invoice.issue_date)}
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            <Badge className={InvoiceManager.getStatusColor(invoice.status)}>
              {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
            </Badge>
            
            {isOverdue() && (
              <Badge className="text-red-600 bg-red-100">
                Overdue
              </Badge>
            )}

            <div className="flex items-center space-x-2">
              {invoice.status === 'draft' && (
                <Button variant="outline" size="sm" onClick={() => onEdit(invoice)}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              )}
              
              {(invoice.status === 'draft' || invoice.status === 'sent') && (
                <Button variant="outline" size="sm" onClick={handleSendInvoice} disabled={loading}>
                  <Send className="w-4 h-4 mr-2" />
                  {invoice.status === 'draft' ? 'Send' : 'Resend'}
                </Button>
              )}
              
              <Button variant="outline" size="sm" onClick={handleDownloadPDF} disabled={loading}>
                <Download className="w-4 h-4 mr-2" />
                {loading ? 'Generating...' : 'Download PDF'}
              </Button>
              
              <Button variant="outline" size="sm" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Invoice Content */}
        <div className="overflow-y-auto max-h-[calc(90vh-120px)]">
          <div id="invoice-content" ref={invoiceRef} className="p-8 bg-white">
            {/* Invoice Header */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">INVOICE</h1>
                <div className="text-gray-600">
                  <p className="font-medium">Invoice Number: {invoice.invoice_number}</p>
                  <p>Issue Date: {formatDate(invoice.issue_date)}</p>
                  <p>Due Date: {formatDate(invoice.due_date)}</p>
                </div>
              </div>
              
              <div className="text-right">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center mb-4">
                  <span className="text-white font-bold text-xl">A</span>
                </div>
                <h2 className="text-xl font-bold text-gray-900">Accruance</h2>
                <p className="text-gray-600">AI-Powered Financial Dashboard</p>
              </div>
            </div>

            {/* Bill To Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Bill To:</h3>
                <div className="text-gray-700">
                  <p className="font-medium text-lg">{invoice.client_name}</p>
                  <p className="text-gray-600">{invoice.client_email}</p>
                  <div className="mt-2 whitespace-pre-line">
                    {invoice.client_address}
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Payment Terms:</h3>
                <div className="text-gray-700">
                  <p>{invoice.payment_terms}</p>
                  <p className="text-sm text-gray-600 mt-1">
                    Payment is due by {formatDate(invoice.due_date)}
                  </p>
                </div>
              </div>
            </div>

            {/* Line Items */}
            <div className="mb-8">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b-2 border-gray-200">
                      <th className="text-left py-3 px-2 font-semibold text-gray-900">Description</th>
                      <th className="text-right py-3 px-2 font-semibold text-gray-900">Qty</th>
                      <th className="text-right py-3 px-2 font-semibold text-gray-900">Unit Price</th>
                      <th className="text-right py-3 px-2 font-semibold text-gray-900">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoice.items.map((item, index) => (
                      <tr key={item.id} className="border-b border-gray-100">
                        <td className="py-3 px-2 text-gray-700">{item.description}</td>
                        <td className="py-3 px-2 text-right text-gray-700">{item.quantity}</td>
                        <td className="py-3 px-2 text-right text-gray-700">
                          {InvoiceManager.formatCurrency(item.unit_price)}
                        </td>
                        <td className="py-3 px-2 text-right font-medium text-gray-900">
                          {InvoiceManager.formatCurrency(item.total)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Totals */}
            <div className="flex justify-end mb-8">
              <div className="w-full max-w-sm">
                <div className="space-y-2">
                  <div className="flex justify-between py-2">
                    <span className="text-gray-700">Subtotal:</span>
                    <span className="font-medium text-gray-900">
                      {InvoiceManager.formatCurrency(invoice.subtotal)}
                    </span>
                  </div>
                  
                  {invoice.tax_amount > 0 && (
                    <div className="flex justify-between py-2">
                      <span className="text-gray-700">
                        Tax ({(invoice.tax_rate * 100).toFixed(1)}%):
                      </span>
                      <span className="font-medium text-gray-900">
                        {InvoiceManager.formatCurrency(invoice.tax_amount)}
                      </span>
                    </div>
                  )}
                  
                  <div className="flex justify-between py-3 border-t-2 border-gray-200">
                    <span className="text-lg font-semibold text-gray-900">Total:</span>
                    <span className="text-lg font-bold text-gray-900">
                      {InvoiceManager.formatCurrency(invoice.total_amount)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Notes */}
            {invoice.notes && (
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Notes:</h3>
                <p className="text-gray-700 whitespace-pre-line">{invoice.notes}</p>
              </div>
            )}

            {/* Payment Information */}
            <div className="border-t pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Payment Information</h3>
              <div className="text-gray-700 space-y-1">
                <p>Please make payment by {formatDate(invoice.due_date)}</p>
                <p>For questions about this invoice, please contact us.</p>
                {invoice.status === 'paid' && invoice.paid_at && (
                  <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center">
                      <CreditCard className="w-5 h-5 text-green-600 mr-2" />
                      <span className="font-medium text-green-900">
                        Paid on {formatDate(invoice.paid_at)}
                      </span>
                      {invoice.payment_method && (
                        <span className="text-green-700 ml-2">
                          via {invoice.payment_method}
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="mt-8 pt-6 border-t text-center text-gray-500 text-sm">
              <p>Thank you for your business!</p>
              <p className="mt-1">Generated by Accruance - AI-Powered Financial Dashboard</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

