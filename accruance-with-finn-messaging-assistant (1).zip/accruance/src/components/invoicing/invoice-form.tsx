'use client'

import { useState, useEffect } from 'react'
import { useForm, useFieldArray } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { InvoiceManager } from '@/lib/invoice-manager'
import type { InvoiceData, InvoiceItem, Client } from '@/lib/invoice-manager'
import { 
  Plus,
  Trash2,
  Save,
  Send,
  Eye,
  Calculator,
  User,
  Calendar,
  DollarSign,
  FileText,
  Building
} from 'lucide-react'

const invoiceItemSchema = z.object({
  description: z.string().min(1, 'Description is required'),
  quantity: z.number().min(0.01, 'Quantity must be greater than 0'),
  unit_price: z.number().min(0.01, 'Unit price must be greater than 0')
})

const invoiceSchema = z.object({
  client_id: z.string().min(1, 'Client is required'),
  client_name: z.string().min(1, 'Client name is required'),
  client_email: z.string().email('Valid email is required'),
  client_address: z.string().min(1, 'Client address is required'),
  issue_date: z.string().min(1, 'Issue date is required'),
  due_date: z.string().min(1, 'Due date is required'),
  payment_terms: z.string().min(1, 'Payment terms are required'),
  tax_rate: z.number().min(0).max(1, 'Tax rate must be between 0 and 100%'),
  notes: z.string().optional(),
  items: z.array(invoiceItemSchema).min(1, 'At least one item is required')
})

type InvoiceFormData = z.infer<typeof invoiceSchema>

interface InvoiceFormProps {
  organizationId: string
  invoice?: InvoiceData
  onSave: (invoice: InvoiceData) => void
  onCancel: () => void
}

export function InvoiceForm({ organizationId, invoice, onSave, onCancel }: InvoiceFormProps) {
  const [clients, setClients] = useState<Client[]>([])
  const [loading, setLoading] = useState(false)
  const [showClientForm, setShowClientForm] = useState(false)

  const {
    register,
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors }
  } = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceSchema),
    defaultValues: {
      client_id: invoice?.client_id || '',
      client_name: invoice?.client_name || '',
      client_email: invoice?.client_email || '',
      client_address: invoice?.client_address || '',
      issue_date: invoice?.issue_date || new Date().toISOString().split('T')[0],
      due_date: invoice?.due_date || InvoiceManager.calculateDueDate(
        new Date().toISOString().split('T')[0], 
        'Net 30'
      ),
      payment_terms: invoice?.payment_terms || 'Net 30',
      tax_rate: invoice?.tax_rate || 0.08,
      notes: invoice?.notes || '',
      items: invoice?.items || [
        { description: '', quantity: 1, unit_price: 0 }
      ]
    }
  })

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'items'
  })

  const watchedItems = watch('items')
  const watchedTaxRate = watch('tax_rate')
  const watchedPaymentTerms = watch('payment_terms')
  const watchedIssueDate = watch('issue_date')

  // Load clients
  useEffect(() => {
    const loadClients = async () => {
      try {
        const { clients } = await InvoiceManager.getClients(organizationId)
        setClients(clients)
      } catch (error) {
        console.error('Error loading clients:', error)
      }
    }
    loadClients()
  }, [organizationId])

  // Update due date when issue date or payment terms change
  useEffect(() => {
    if (watchedIssueDate && watchedPaymentTerms) {
      const dueDate = InvoiceManager.calculateDueDate(watchedIssueDate, watchedPaymentTerms)
      setValue('due_date', dueDate)
    }
  }, [watchedIssueDate, watchedPaymentTerms, setValue])

  // Calculate totals
  const subtotal = watchedItems.reduce((sum, item) => {
    const quantity = Number(item.quantity) || 0
    const unitPrice = Number(item.unit_price) || 0
    return sum + (quantity * unitPrice)
  }, 0)

  const taxAmount = subtotal * (watchedTaxRate || 0)
  const total = subtotal + taxAmount

  const handleClientSelect = (clientId: string) => {
    const client = clients.find(c => c.id === clientId)
    if (client) {
      setValue('client_id', client.id)
      setValue('client_name', client.name)
      setValue('client_email', client.email)
      setValue('client_address', `${client.address}\n${client.city}, ${client.state} ${client.zip_code}`)
    }
  }

  const addItem = () => {
    append({ description: '', quantity: 1, unit_price: 0 })
  }

  const removeItem = (index: number) => {
    if (fields.length > 1) {
      remove(index)
    }
  }

  const onSubmit = async (data: InvoiceFormData) => {
    setLoading(true)
    try {
      const invoiceItems: InvoiceItem[] = data.items.map((item, index) => ({
        id: `item_${index + 1}`,
        description: item.description,
        quantity: Number(item.quantity),
        unit_price: Number(item.unit_price),
        total: Number(item.quantity) * Number(item.unit_price)
      }))

      const invoiceData: Omit<InvoiceData, 'id' | 'created_at' | 'updated_at'> = {
        invoice_number: invoice?.invoice_number || InvoiceManager.generateInvoiceNumber(organizationId),
        organization_id: organizationId,
        client_id: data.client_id,
        client_name: data.client_name,
        client_email: data.client_email,
        client_address: data.client_address,
        issue_date: data.issue_date,
        due_date: data.due_date,
        items: invoiceItems,
        subtotal,
        tax_rate: Number(data.tax_rate),
        tax_amount: taxAmount,
        total_amount: total,
        status: invoice?.status || 'draft',
        payment_terms: data.payment_terms,
        notes: data.notes
      }

      const savedInvoice = invoice?.id 
        ? await InvoiceManager.updateInvoice(invoice.id, invoiceData)
        : await InvoiceManager.createInvoice(invoiceData)

      onSave(savedInvoice)
    } catch (error) {
      console.error('Error saving invoice:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="w-5 h-5 mr-2" />
            {invoice ? 'Edit Invoice' : 'Create New Invoice'}
          </CardTitle>
          <CardDescription>
            {invoice 
              ? `Editing invoice ${invoice.invoice_number}`
              : 'Create a professional invoice for your client'
            }
          </CardDescription>
        </CardHeader>
      </Card>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Client Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <User className="w-5 h-5 mr-2" />
              Client Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Client Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="client_select">Select Existing Client</Label>
                <select
                  id="client_select"
                  className="w-full p-2 border border-gray-300 rounded-lg"
                  onChange={(e) => handleClientSelect(e.target.value)}
                  defaultValue=""
                >
                  <option value="">Choose a client...</option>
                  {clients.map((client) => (
                    <option key={client.id} value={client.id}>
                      {client.name} ({client.email})
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowClientForm(!showClientForm)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  New Client
                </Button>
              </div>
            </div>

            {/* Client Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="client_name">Client Name *</Label>
                <Input
                  id="client_name"
                  {...register('client_name')}
                  placeholder="Enter client name"
                />
                {errors.client_name && (
                  <p className="text-sm text-red-600 mt-1">{errors.client_name.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="client_email">Client Email *</Label>
                <Input
                  id="client_email"
                  type="email"
                  {...register('client_email')}
                  placeholder="client@example.com"
                />
                {errors.client_email && (
                  <p className="text-sm text-red-600 mt-1">{errors.client_email.message}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="client_address">Client Address *</Label>
              <Textarea
                id="client_address"
                {...register('client_address')}
                placeholder="Enter client address"
                rows={3}
              />
              {errors.client_address && (
                <p className="text-sm text-red-600 mt-1">{errors.client_address.message}</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Invoice Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="w-5 h-5 mr-2" />
              Invoice Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="issue_date">Issue Date *</Label>
                <Input
                  id="issue_date"
                  type="date"
                  {...register('issue_date')}
                />
                {errors.issue_date && (
                  <p className="text-sm text-red-600 mt-1">{errors.issue_date.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="payment_terms">Payment Terms *</Label>
                <select
                  id="payment_terms"
                  {...register('payment_terms')}
                  className="w-full p-2 border border-gray-300 rounded-lg"
                >
                  <option value="Due on receipt">Due on receipt</option>
                  <option value="Net 15">Net 15</option>
                  <option value="Net 30">Net 30</option>
                  <option value="Net 60">Net 60</option>
                </select>
                {errors.payment_terms && (
                  <p className="text-sm text-red-600 mt-1">{errors.payment_terms.message}</p>
                )}
              </div>
              <div>
                <Label htmlFor="due_date">Due Date *</Label>
                <Input
                  id="due_date"
                  type="date"
                  {...register('due_date')}
                />
                {errors.due_date && (
                  <p className="text-sm text-red-600 mt-1">{errors.due_date.message}</p>
                )}
              </div>
            </div>

            <div>
              <Label htmlFor="tax_rate">Tax Rate (%)</Label>
              <Input
                id="tax_rate"
                type="number"
                step="0.01"
                min="0"
                max="1"
                {...register('tax_rate', { valueAsNumber: true })}
                placeholder="0.08"
              />
              {errors.tax_rate && (
                <p className="text-sm text-red-600 mt-1">{errors.tax_rate.message}</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Line Items */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center">
                <Calculator className="w-5 h-5 mr-2" />
                Line Items
              </div>
              <Button type="button" variant="outline" onClick={addItem}>
                <Plus className="w-4 h-4 mr-2" />
                Add Item
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {fields.map((field, index) => (
              <div key={field.id} className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                <div className="md:col-span-5">
                  <Label htmlFor={`items.${index}.description`}>Description *</Label>
                  <Input
                    {...register(`items.${index}.description`)}
                    placeholder="Item description"
                  />
                  {errors.items?.[index]?.description && (
                    <p className="text-sm text-red-600 mt-1">
                      {errors.items[index]?.description?.message}
                    </p>
                  )}
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor={`items.${index}.quantity`}>Quantity *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0.01"
                    {...register(`items.${index}.quantity`, { valueAsNumber: true })}
                    placeholder="1"
                  />
                  {errors.items?.[index]?.quantity && (
                    <p className="text-sm text-red-600 mt-1">
                      {errors.items[index]?.quantity?.message}
                    </p>
                  )}
                </div>
                <div className="md:col-span-2">
                  <Label htmlFor={`items.${index}.unit_price`}>Unit Price *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0.01"
                    {...register(`items.${index}.unit_price`, { valueAsNumber: true })}
                    placeholder="0.00"
                  />
                  {errors.items?.[index]?.unit_price && (
                    <p className="text-sm text-red-600 mt-1">
                      {errors.items[index]?.unit_price?.message}
                    </p>
                  )}
                </div>
                <div className="md:col-span-2">
                  <Label>Total</Label>
                  <div className="p-2 bg-gray-50 border border-gray-300 rounded-lg">
                    {InvoiceManager.formatCurrency(
                      (Number(watchedItems[index]?.quantity) || 0) * 
                      (Number(watchedItems[index]?.unit_price) || 0)
                    )}
                  </div>
                </div>
                <div className="md:col-span-1">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removeItem(index)}
                    disabled={fields.length === 1}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}

            {errors.items && (
              <p className="text-sm text-red-600">{errors.items.message}</p>
            )}
          </CardContent>
        </Card>

        {/* Totals */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <DollarSign className="w-5 h-5 mr-2" />
              Invoice Totals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-w-sm ml-auto">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>{InvoiceManager.formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Tax ({((watchedTaxRate || 0) * 100).toFixed(1)}%):</span>
                <span>{InvoiceManager.formatCurrency(taxAmount)}</span>
              </div>
              <div className="flex justify-between font-bold text-lg border-t pt-2">
                <span>Total:</span>
                <span>{InvoiceManager.formatCurrency(total)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notes */}
        <Card>
          <CardHeader>
            <CardTitle>Additional Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              {...register('notes')}
              placeholder="Add any additional notes or terms..."
              rows={3}
            />
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <div className="flex items-center space-x-3">
            <Button type="submit" disabled={loading}>
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save {invoice ? 'Changes' : 'Invoice'}
                </>
              )}
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}

