'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { ReceiptManager } from '@/lib/receipt-manager'
import type { ReceiptData } from '@/lib/receipt-manager'
import { 
  X,
  Download,
  Edit,
  Save,
  RotateCcw,
  ExternalLink,
  FileImage,
  FileText,
  Calendar,
  DollarSign,
  Store,
  Hash,
  Receipt,
  Tag,
  Clock,
  User,
  CheckCircle,
  AlertCircle,
  Loader2,
  Eye,
  ShoppingCart
} from 'lucide-react'

interface ReceiptViewerProps {
  receipt: ReceiptData
  onClose: () => void
  onUpdate?: (receipt: ReceiptData) => void
}

export function ReceiptViewer({ receipt, onClose, onUpdate }: ReceiptViewerProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [notes, setNotes] = useState(receipt.notes || '')
  const [isReprocessing, setIsReprocessing] = useState(false)

  const handleSaveNotes = async () => {
    try {
      await ReceiptManager.updateReceiptNotes(receipt.id, notes)
      setIsEditing(false)
      onUpdate?.({ ...receipt, notes })
    } catch (error) {
      console.error('Error updating notes:', error)
    }
  }

  const handleReprocess = async () => {
    setIsReprocessing(true)
    try {
      // In a real implementation, we would fetch the file and reprocess
      // For now, we'll simulate the reprocessing
      await new Promise(resolve => setTimeout(resolve, 3000))
      
      // Simulate updated data
      const updatedReceipt = {
        ...receipt,
        status: 'completed' as const,
        confidence_score: 0.95,
        processed_date: new Date().toISOString()
      }
      
      onUpdate?.(updatedReceipt)
    } catch (error) {
      console.error('Error reprocessing receipt:', error)
    } finally {
      setIsReprocessing(false)
    }
  }

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) {
      return <FileImage className="w-6 h-6 text-blue-600" />
    }
    return <FileText className="w-6 h-6 text-red-600" />
  }

  const getStatusIcon = (status: ReceiptData['status']) => {
    switch (status) {
      case 'uploading':
        return <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
      case 'processing':
        return <Clock className="w-5 h-5 text-yellow-600" />
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case 'failed':
        return <AlertCircle className="w-5 h-5 text-red-600" />
      default:
        return null
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-green-600 bg-green-100'
    if (confidence >= 0.7) return 'text-yellow-600 bg-yellow-100'
    return 'text-red-600 bg-red-100'
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            {getFileIcon(receipt.file_type)}
            <div>
              <h2 className="text-xl font-semibold text-gray-900">{receipt.file_name}</h2>
              <p className="text-sm text-gray-500">
                {ReceiptManager.formatFileSize(receipt.file_size)} • Uploaded {formatDate(receipt.upload_date)}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-2">
              {getStatusIcon(receipt.status)}
              <Badge className={ReceiptManager.getStatusColor(receipt.status)}>
                {receipt.status}
              </Badge>
            </div>
            
            <Button variant="outline" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Receipt Preview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Eye className="w-5 h-5 mr-2" />
                Receipt Preview
              </CardTitle>
            </CardHeader>
            <CardContent>
              {receipt.file_type.startsWith('image/') ? (
                <div className="flex justify-center">
                  <img
                    src={receipt.file_url}
                    alt={receipt.file_name}
                    className="max-w-full max-h-96 object-contain border rounded-lg shadow-sm"
                  />
                </div>
              ) : (
                <div className="flex items-center justify-center h-48 bg-gray-100 rounded-lg">
                  <div className="text-center">
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">PDF Preview</p>
                    <Button variant="outline" size="sm" className="mt-2">
                      <Download className="w-4 h-4 mr-2" />
                      Download PDF
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Extracted Data */}
          {receipt.extracted_data && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <Receipt className="w-5 h-5 mr-2" />
                    Extracted Data
                  </CardTitle>
                  
                  <div className="flex items-center space-x-3">
                    {receipt.confidence_score && (
                      <Badge className={getConfidenceColor(receipt.confidence_score)}>
                        {Math.round(receipt.confidence_score * 100)}% confidence
                      </Badge>
                    )}
                    
                    {receipt.status === 'failed' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleReprocess}
                        disabled={isReprocessing}
                      >
                        {isReprocessing ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <RotateCcw className="w-4 h-4 mr-2" />
                        )}
                        {isReprocessing ? 'Reprocessing...' : 'Retry OCR'}
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Basic Information */}
                  <div className="space-y-4">
                    <h3 className="font-medium text-gray-900">Basic Information</h3>
                    
                    {receipt.extracted_data.merchant_name && (
                      <div className="flex items-center space-x-3">
                        <Store className="w-5 h-5 text-gray-400" />
                        <div>
                          <label className="text-sm font-medium text-gray-700">Merchant</label>
                          <p className="text-sm text-gray-900">{receipt.extracted_data.merchant_name}</p>
                        </div>
                      </div>
                    )}
                    
                    {receipt.extracted_data.date && (
                      <div className="flex items-center space-x-3">
                        <Calendar className="w-5 h-5 text-gray-400" />
                        <div>
                          <label className="text-sm font-medium text-gray-700">Date</label>
                          <p className="text-sm text-gray-900">
                            {new Date(receipt.extracted_data.date).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </p>
                        </div>
                      </div>
                    )}
                    
                    {receipt.extracted_data.receipt_number && (
                      <div className="flex items-center space-x-3">
                        <Hash className="w-5 h-5 text-gray-400" />
                        <div>
                          <label className="text-sm font-medium text-gray-700">Receipt Number</label>
                          <p className="text-sm text-gray-900">{receipt.extracted_data.receipt_number}</p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Financial Information */}
                  <div className="space-y-4">
                    <h3 className="font-medium text-gray-900">Financial Details</h3>
                    
                    {receipt.extracted_data.total_amount && (
                      <div className="flex items-center space-x-3">
                        <DollarSign className="w-5 h-5 text-gray-400" />
                        <div>
                          <label className="text-sm font-medium text-gray-700">Total Amount</label>
                          <p className="text-lg font-semibold text-green-600">
                            ${receipt.extracted_data.total_amount.toFixed(2)}
                          </p>
                        </div>
                      </div>
                    )}
                    
                    {receipt.extracted_data.tax_amount && (
                      <div className="flex items-center space-x-3">
                        <Tag className="w-5 h-5 text-gray-400" />
                        <div>
                          <label className="text-sm font-medium text-gray-700">Tax Amount</label>
                          <p className="text-sm text-gray-900">
                            ${receipt.extracted_data.tax_amount.toFixed(2)}
                          </p>
                        </div>
                      </div>
                    )}
                    
                    {receipt.extracted_data.payment_method && (
                      <div className="flex items-center space-x-3">
                        <Receipt className="w-5 h-5 text-gray-400" />
                        <div>
                          <label className="text-sm font-medium text-gray-700">Payment Method</label>
                          <p className="text-sm text-gray-900">{receipt.extracted_data.payment_method}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Line Items */}
                {receipt.extracted_data.items && receipt.extracted_data.items.length > 0 && (
                  <div className="mt-6">
                    <h3 className="font-medium text-gray-900 mb-4 flex items-center">
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      Line Items
                    </h3>
                    
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="text-left p-3 font-medium text-gray-700">Description</th>
                            <th className="text-center p-3 font-medium text-gray-700">Qty</th>
                            <th className="text-right p-3 font-medium text-gray-700">Unit Price</th>
                            <th className="text-right p-3 font-medium text-gray-700">Total</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {receipt.extracted_data.items.map((item, index) => (
                            <tr key={index}>
                              <td className="p-3 text-gray-900">{item.description}</td>
                              <td className="p-3 text-center text-gray-600">{item.quantity || 1}</td>
                              <td className="p-3 text-right text-gray-600">
                                {item.unit_price ? `$${item.unit_price.toFixed(2)}` : '-'}
                              </td>
                              <td className="p-3 text-right font-medium text-gray-900">
                                {item.total ? `$${item.total.toFixed(2)}` : '-'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Transaction Link */}
          {receipt.transaction_id && (
            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <div>
                      <p className="font-medium text-green-900">Transaction Created</p>
                      <p className="text-sm text-green-700">
                        This receipt has been automatically converted to a transaction.
                      </p>
                    </div>
                  </div>
                  
                  <Button variant="outline" size="sm">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Transaction
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Notes */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Edit className="w-5 h-5 mr-2" />
                  Notes
                </CardTitle>
                
                {!isEditing ? (
                  <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                ) : (
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(false)}>
                      Cancel
                    </Button>
                    <Button size="sm" onClick={handleSaveNotes}>
                      <Save className="w-4 h-4 mr-2" />
                      Save
                    </Button>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add notes about this receipt..."
                  rows={4}
                />
              ) : (
                <p className="text-gray-600">
                  {notes || 'No notes added yet.'}
                </p>
              )}
            </CardContent>
          </Card>

          {/* Metadata */}
          <Card className="bg-gray-50">
            <CardHeader>
              <CardTitle className="text-sm">Receipt Metadata</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Receipt ID:</span>
                <span className="font-mono text-gray-900">{receipt.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">File Type:</span>
                <span className="text-gray-900">{receipt.file_type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Upload Date:</span>
                <span className="text-gray-900">{formatDate(receipt.upload_date)}</span>
              </div>
              {receipt.processed_date && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Processed Date:</span>
                  <span className="text-gray-900">{formatDate(receipt.processed_date)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-gray-600">Created By:</span>
                <span className="text-gray-900">{receipt.created_by}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

