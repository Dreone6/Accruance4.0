'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { DuplicateDetectionService } from '@/lib/duplicate-detection'
import { ReceiptManager } from '@/lib/receipt-manager'
import type { DuplicateGroup } from '@/lib/duplicate-detection'
import type { ReceiptData } from '@/lib/receipt-manager'
import { 
  AlertTriangle,
  Trash2,
  Eye,
  CheckCircle,
  X,
  RefreshCw,
  FileImage,
  FileText,
  Calendar,
  DollarSign,
  Store,
  HardDrive,
  BarChart3
} from 'lucide-react'

interface DuplicateDetectionInterfaceProps {
  organizationId: string
  onDuplicatesResolved?: () => void
}

export function DuplicateDetectionInterface({ organizationId, onDuplicatesResolved }: DuplicateDetectionInterfaceProps) {
  const [duplicateGroups, setDuplicateGroups] = useState<DuplicateGroup[]>([])
  const [loading, setLoading] = useState(true)
  const [resolving, setResolving] = useState<Set<string>>(new Set())
  const [stats, setStats] = useState({
    totalReceipts: 0,
    duplicateGroups: 0,
    potentialDuplicates: 0,
    storageWasted: 0
  })

  const loadDuplicates = async () => {
    setLoading(true)
    try {
      // Load all receipts
      const { receipts } = await ReceiptManager.getReceipts(organizationId)
      
      // Find duplicate groups
      const groups = await DuplicateDetectionService.findDuplicateGroups(receipts)
      setDuplicateGroups(groups)

      // Get statistics
      const duplicateStats = await DuplicateDetectionService.getDuplicateStats(organizationId)
      setStats(duplicateStats)
    } catch (error) {
      console.error('Error loading duplicates:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadDuplicates()
  }, [organizationId])

  const handleResolveDuplicate = async (group: DuplicateGroup, keepReceiptId: string) => {
    setResolving(prev => new Set(prev.add(group.id)))
    
    try {
      const removeIds = group.receipts
        .filter(r => r.id !== keepReceiptId)
        .map(r => r.id)

      await DuplicateDetectionService.resolveDuplicateGroup(group.id, keepReceiptId, removeIds)
      
      // Refresh data
      await loadDuplicates()
      onDuplicatesResolved?.()
    } catch (error) {
      console.error('Error resolving duplicate:', error)
    } finally {
      setResolving(prev => {
        const newSet = new Set(prev)
        newSet.delete(group.id)
        return newSet
      })
    }
  }

  const handleAutoResolve = async (group: DuplicateGroup) => {
    let keepReceiptId: string

    switch (group.suggestedAction) {
      case 'keep_first':
        keepReceiptId = group.receipts[0].id
        break
      case 'keep_highest_quality':
        // Keep the receipt with highest confidence score
        keepReceiptId = group.receipts.reduce((best, current) => 
          (current.confidence_score || 0) > (best.confidence_score || 0) ? current : best
        ).id
        break
      default:
        return // Don't auto-resolve manual review cases
    }

    await handleResolveDuplicate(group, keepReceiptId)
  }

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) {
      return <FileImage className="w-4 h-4 text-blue-600" />
    }
    return <FileText className="w-4 h-4 text-red-600" />
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    })
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(Math.abs(amount))
  }

  const getActionBadgeColor = (action: DuplicateGroup['suggestedAction']) => {
    switch (action) {
      case 'keep_first':
        return 'text-green-600 bg-green-100'
      case 'keep_highest_quality':
        return 'text-blue-600 bg-blue-100'
      case 'manual_review':
        return 'text-orange-600 bg-orange-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  const getActionText = (action: DuplicateGroup['suggestedAction']) => {
    switch (action) {
      case 'keep_first':
        return 'Auto: Keep First'
      case 'keep_highest_quality':
        return 'Auto: Keep Best Quality'
      case 'manual_review':
        return 'Manual Review Required'
      default:
        return 'Unknown'
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <RefreshCw className="w-6 h-6 animate-spin mr-2" />
            <span>Scanning for duplicates...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            Duplicate Detection Summary
          </CardTitle>
          <CardDescription>
            Automatically detect and resolve duplicate receipts to save storage and maintain clean records.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">{stats.totalReceipts}</div>
              <div className="text-sm text-gray-600">Total Receipts</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{stats.duplicateGroups}</div>
              <div className="text-sm text-gray-600">Duplicate Groups</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{stats.potentialDuplicates}</div>
              <div className="text-sm text-gray-600">Potential Duplicates</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {DuplicateDetectionService.formatFileSize(stats.storageWasted)}
              </div>
              <div className="text-sm text-gray-600">Storage Wasted</div>
            </div>
          </div>

          {stats.duplicateGroups > 0 && (
            <div className="mt-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 text-orange-600" />
                <span className="text-sm font-medium text-orange-900">
                  {stats.duplicateGroups} duplicate groups found. 
                  Resolving these could free up {DuplicateDetectionService.formatFileSize(stats.storageWasted)} of storage.
                </span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Duplicate Groups */}
      {duplicateGroups.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Duplicates Found</h3>
            <p className="text-gray-600">
              Great! Your receipt library is clean and doesn't contain any duplicate receipts.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">Duplicate Groups</h3>
            <Button variant="outline" onClick={loadDuplicates}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>

          {duplicateGroups.map((group) => (
            <Card key={group.id} className="border-orange-200">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <AlertTriangle className="w-5 h-5 text-orange-600" />
                    <div>
                      <CardTitle className="text-lg">
                        Duplicate Group ({group.receipts.length} receipts)
                      </CardTitle>
                      <CardDescription>
                        {Math.round(group.confidence * 100)}% confidence match
                      </CardDescription>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Badge className={getActionBadgeColor(group.suggestedAction)}>
                      {getActionText(group.suggestedAction)}
                    </Badge>
                    <Badge className={DuplicateDetectionService.getConfidenceColor(group.confidence)}>
                      {Math.round(group.confidence * 100)}% match
                    </Badge>
                  </div>
                </div>

                {/* Match Reasons */}
                <div className="flex flex-wrap gap-2 mt-2">
                  {group.reasons.map((reason, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {reason}
                    </Badge>
                  ))}
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Receipts in Group */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {group.receipts.map((receipt, index) => (
                    <div key={receipt.id} className="border rounded-lg p-3 hover:bg-gray-50">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {getFileIcon(receipt.file_type)}
                          <span className="text-sm font-medium text-gray-900 truncate">
                            {receipt.file_name}
                          </span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          #{index + 1}
                        </Badge>
                      </div>

                      <div className="space-y-1 text-xs text-gray-600">
                        <div className="flex items-center justify-between">
                          <span>Size:</span>
                          <span>{DuplicateDetectionService.formatFileSize(receipt.file_size)}</span>
                        </div>
                        
                        {receipt.confidence_score && (
                          <div className="flex items-center justify-between">
                            <span>OCR Quality:</span>
                            <span>{Math.round(receipt.confidence_score * 100)}%</span>
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between">
                          <span>Uploaded:</span>
                          <span>{formatDate(receipt.upload_date)}</span>
                        </div>

                        {receipt.extracted_data?.merchant_name && (
                          <div className="flex items-center space-x-1 mt-2">
                            <Store className="w-3 h-3" />
                            <span className="truncate">{receipt.extracted_data.merchant_name}</span>
                          </div>
                        )}

                        {receipt.extracted_data?.total_amount && (
                          <div className="flex items-center space-x-1">
                            <DollarSign className="w-3 h-3" />
                            <span>{formatCurrency(receipt.extracted_data.total_amount)}</span>
                          </div>
                        )}

                        {receipt.extracted_data?.date && (
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-3 h-3" />
                            <span>{formatDate(receipt.extracted_data.date)}</span>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between mt-3 pt-2 border-t">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleResolveDuplicate(group, receipt.id)}
                          disabled={resolving.has(group.id)}
                        >
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Keep This
                        </Button>
                        
                        <Button variant="ghost" size="sm">
                          <Eye className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="text-sm text-gray-600">
                    Choose which receipt to keep, or use auto-resolve based on our recommendation.
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {group.suggestedAction !== 'manual_review' && (
                      <Button
                        variant="outline"
                        onClick={() => handleAutoResolve(group)}
                        disabled={resolving.has(group.id)}
                      >
                        {resolving.has(group.id) ? (
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <CheckCircle className="w-4 h-4 mr-2" />
                        )}
                        Auto-Resolve
                      </Button>
                    )}
                    
                    <Button
                      variant="ghost"
                      onClick={() => {
                        // Mark as reviewed/ignored
                        console.log('Ignoring duplicate group:', group.id)
                      }}
                    >
                      <X className="w-4 h-4 mr-2" />
                      Ignore
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Help Information */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h4 className="font-medium text-blue-900 mb-2">How Duplicate Detection Works</h4>
          <div className="text-sm text-blue-700 space-y-1">
            <p>• <strong>Amount Matching:</strong> Compares receipt totals for exact or near-exact matches</p>
            <p>• <strong>Date Analysis:</strong> Checks transaction dates within a reasonable timeframe</p>
            <p>• <strong>Merchant Recognition:</strong> Matches business names and locations</p>
            <p>• <strong>File Analysis:</strong> Compares file sizes, names, and metadata</p>
            <p>• <strong>Line Item Comparison:</strong> Analyzes individual purchase items when available</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

