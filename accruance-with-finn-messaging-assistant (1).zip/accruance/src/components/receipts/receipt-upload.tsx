'use client'

import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { ReceiptManager } from '@/lib/receipt-manager'
import type { ReceiptData } from '@/lib/receipt-manager'
import { 
  Upload,
  FileImage,
  FileText,
  X,
  CheckCircle,
  AlertCircle,
  Loader2,
  Camera,
  Scan,
  Receipt,
  DollarSign,
  Calendar,
  Store,
  Hash
} from 'lucide-react'

interface ReceiptUploadProps {
  organizationId: string
  userId: string
  onUploadComplete: (receipt: ReceiptData) => void
  onUploadError: (error: string) => void
}

export function ReceiptUpload({ organizationId, userId, onUploadComplete, onUploadError }: ReceiptUploadProps) {
  const [uploadingFiles, setUploadingFiles] = useState<Map<string, { file: File, progress: number, status: string }>>(new Map())

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    for (const file of acceptedFiles) {
      const fileId = `${file.name}_${Date.now()}`
      
      // Add to uploading files
      setUploadingFiles(prev => new Map(prev.set(fileId, { 
        file, 
        progress: 0, 
        status: 'uploading' 
      })))

      try {
        // Simulate upload progress
        const progressInterval = setInterval(() => {
          setUploadingFiles(prev => {
            const current = prev.get(fileId)
            if (current && current.progress < 90) {
              return new Map(prev.set(fileId, { 
                ...current, 
                progress: current.progress + 10 
              }))
            }
            return prev
          })
        }, 200)

        // Process the receipt
        const receipt = await ReceiptManager.uploadReceipt(organizationId, file, userId)
        
        clearInterval(progressInterval)
        
        // Complete upload
        setUploadingFiles(prev => new Map(prev.set(fileId, { 
          file, 
          progress: 100, 
          status: 'completed' 
        })))

        // Remove from uploading after delay
        setTimeout(() => {
          setUploadingFiles(prev => {
            const newMap = new Map(prev)
            newMap.delete(fileId)
            return newMap
          })
        }, 2000)

        onUploadComplete(receipt)
      } catch (error) {
        setUploadingFiles(prev => new Map(prev.set(fileId, { 
          file, 
          progress: 0, 
          status: 'failed' 
        })))
        
        onUploadError(error instanceof Error ? error.message : 'Upload failed')
        
        // Remove failed upload after delay
        setTimeout(() => {
          setUploadingFiles(prev => {
            const newMap = new Map(prev)
            newMap.delete(fileId)
            return newMap
          })
        }, 3000)
      }
    }
  }, [organizationId, userId, onUploadComplete, onUploadError])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif', '.bmp'],
      'application/pdf': ['.pdf']
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: true
  })

  const removeUploadingFile = (fileId: string) => {
    setUploadingFiles(prev => {
      const newMap = new Map(prev)
      newMap.delete(fileId)
      return newMap
    })
  }

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) {
      return <FileImage className="w-8 h-8 text-blue-600" />
    }
    return <FileText className="w-8 h-8 text-red-600" />
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'uploading':
        return <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case 'failed':
        return <AlertCircle className="w-4 h-4 text-red-600" />
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Receipt className="w-5 h-5 mr-2" />
            Upload Receipts
          </CardTitle>
          <CardDescription>
            Drag and drop receipt images or PDFs, or click to browse. Our AI will automatically extract transaction data.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
              isDragActive 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-300 hover:border-blue-400 hover:bg-gray-50'
            }`}
          >
            <input {...getInputProps()} />
            
            <div className="flex flex-col items-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                {isDragActive ? (
                  <Upload className="w-8 h-8 text-white animate-bounce" />
                ) : (
                  <Camera className="w-8 h-8 text-white" />
                )}
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {isDragActive ? 'Drop receipts here' : 'Upload receipt images'}
                </h3>
                <p className="text-gray-600 mb-4">
                  Supports JPEG, PNG, GIF, BMP, and PDF files up to 10MB
                </p>
                
                <div className="flex items-center justify-center space-x-6 text-sm text-gray-500">
                  <div className="flex items-center space-x-2">
                    <Scan className="w-4 h-4" />
                    <span>AI OCR Processing</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <DollarSign className="w-4 h-4" />
                    <span>Auto Transaction Creation</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Store className="w-4 h-4" />
                    <span>Merchant Detection</span>
                  </div>
                </div>
              </div>
              
              <Button variant="outline" className="mt-4">
                <Upload className="w-4 h-4 mr-2" />
                Choose Files
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upload Progress */}
      {uploadingFiles.size > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Processing Receipts</CardTitle>
            <CardDescription>
              AI is extracting data from your receipts...
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {Array.from(uploadingFiles.entries()).map(([fileId, { file, progress, status }]) => (
              <div key={fileId} className="flex items-center space-x-4 p-4 border rounded-lg">
                <div className="flex-shrink-0">
                  {getFileIcon(file.type)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {file.name}
                    </p>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(status)}
                      <Badge className={ReceiptManager.getStatusColor(status as any)}>
                        {status}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                    <span>{ReceiptManager.formatFileSize(file.size)}</span>
                    <span>{progress}%</span>
                  </div>
                  
                  <Progress value={progress} className="h-2" />
                  
                  {status === 'uploading' && (
                    <p className="text-xs text-blue-600 mt-1">
                      Uploading and processing with AI OCR...
                    </p>
                  )}
                  
                  {status === 'completed' && (
                    <p className="text-xs text-green-600 mt-1">
                      ✓ Data extracted successfully
                    </p>
                  )}
                  
                  {status === 'failed' && (
                    <p className="text-xs text-red-600 mt-1">
                      ✗ Processing failed - please try again
                    </p>
                  )}
                </div>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeUploadingFile(fileId)}
                  className="flex-shrink-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Upload Tips */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="p-6">
          <h3 className="font-medium text-blue-900 mb-3">Tips for Better OCR Results</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-blue-700">
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <span>Ensure receipt is well-lit and clearly visible</span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <span>Avoid shadows and reflections on the receipt</span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <span>Keep the receipt flat and straight</span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <span>Higher resolution images work better</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

