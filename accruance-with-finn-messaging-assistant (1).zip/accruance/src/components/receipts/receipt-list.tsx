'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ReceiptManager } from '@/lib/receipt-manager'
import type { ReceiptData } from '@/lib/receipt-manager'
import { 
  Search,
  Filter,
  Download,
  Eye,
  Trash2,
  Edit,
  RefreshCw,
  FileImage,
  FileText,
  Calendar,
  DollarSign,
  Store,
  Hash,
  MoreHorizontal,
  ExternalLink,
  RotateCcw,
  CheckCircle,
  AlertCircle,
  Clock,
  Loader2
} from 'lucide-react'

interface ReceiptListProps {
  organizationId: string
  refreshTrigger?: number
  onReceiptSelect?: (receipt: ReceiptData) => void
}

export function ReceiptList({ organizationId, refreshTrigger, onReceiptSelect }: ReceiptListProps) {
  const [receipts, setReceipts] = useState<ReceiptData[]>([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({
    status: 'all',
    search: '',
    dateFrom: '',
    dateTo: ''
  })
  const [showFilters, setShowFilters] = useState(false)

  const loadReceipts = async () => {
    setLoading(true)
    try {
      const result = await ReceiptManager.getReceipts(organizationId, {
        status: filters.status !== 'all' ? filters.status : undefined,
        search: filters.search || undefined,
        dateFrom: filters.dateFrom || undefined,
        dateTo: filters.dateTo || undefined
      })
      setReceipts(result.receipts)
    } catch (error) {
      console.error('Error loading receipts:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadReceipts()
  }, [organizationId, filters, refreshTrigger])

  const handleDeleteReceipt = async (receiptId: string) => {
    try {
      await ReceiptManager.deleteReceipt(receiptId)
      loadReceipts()
    } catch (error) {
      console.error('Error deleting receipt:', error)
    }
  }

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) {
      return <FileImage className="w-5 h-5 text-blue-600" />
    }
    return <FileText className="w-5 h-5 text-red-600" />
  }

  const getStatusIcon = (status: ReceiptData['status']) => {
    switch (status) {
      case 'uploading':
        return <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
      case 'processing':
        return <Clock className="w-4 h-4 text-yellow-600" />
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case 'failed':
        return <AlertCircle className="w-4 h-4 text-red-600" />
      default:
        return null
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getConfidenceDisplay = (confidence?: number) => {
    if (!confidence) return null
    
    const percentage = Math.round(confidence * 100)
    const color = ReceiptManager.getConfidenceColor(confidence)
    
    return (
      <Badge variant="outline" className={`text-xs ${color}`}>
        {percentage}% confidence
      </Badge>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Receipt Library</h2>
          <p className="text-gray-600">Manage and view your uploaded receipts</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
          <Button variant="outline" onClick={loadReceipts}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search receipts by filename, merchant, or receipt number..."
                value={filters.search}
                onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                className="pl-10"
              />
            </div>
            
            <select
              className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={filters.status}
              onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
            >
              <option value="all">All Status</option>
              <option value="uploading">Uploading</option>
              <option value="processing">Processing</option>
              <option value="completed">Completed</option>
              <option value="failed">Failed</option>
            </select>
          </div>

          {showFilters && (
            <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">Date From</label>
                <Input
                  type="date"
                  value={filters.dateFrom}
                  onChange={(e) => setFilters(prev => ({ ...prev, dateFrom: e.target.value }))}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Date To</label>
                <Input
                  type="date"
                  value={filters.dateTo}
                  onChange={(e) => setFilters(prev => ({ ...prev, dateTo: e.target.value }))}
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Receipts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          // Loading skeleton
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded mb-4"></div>
                <div className="h-3 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded mb-4"></div>
                <div className="h-8 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))
        ) : receipts.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileImage className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No receipts found</h3>
            <p className="text-gray-500">
              {filters.search || filters.status !== 'all'
                ? 'Try adjusting your filters or search terms.'
                : 'Upload your first receipt to get started.'
              }
            </p>
          </div>
        ) : (
          receipts.map((receipt) => (
            <Card key={receipt.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    {getFileIcon(receipt.file_type)}
                    <div className="min-w-0 flex-1">
                      <h3 className="font-medium text-gray-900 truncate">
                        {receipt.file_name}
                      </h3>
                      <p className="text-sm text-gray-500">
                        {ReceiptManager.formatFileSize(receipt.file_size)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(receipt.status)}
                    <Badge className={ReceiptManager.getStatusColor(receipt.status)}>
                      {receipt.status}
                    </Badge>
                  </div>
                </div>

                {/* Extracted Data */}
                {receipt.extracted_data && (
                  <div className="space-y-3 mb-4">
                    {receipt.extracted_data.merchant_name && (
                      <div className="flex items-center space-x-2">
                        <Store className="w-4 h-4 text-gray-400" />
                        <span className="text-sm font-medium text-gray-900">
                          {receipt.extracted_data.merchant_name}
                        </span>
                      </div>
                    )}
                    
                    {receipt.extracted_data.date && (
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          {new Date(receipt.extracted_data.date).toLocaleDateString()}
                        </span>
                      </div>
                    )}
                    
                    {receipt.extracted_data.total_amount && (
                      <div className="flex items-center space-x-2">
                        <DollarSign className="w-4 h-4 text-gray-400" />
                        <span className="text-sm font-medium text-green-600">
                          ${receipt.extracted_data.total_amount.toFixed(2)}
                        </span>
                      </div>
                    )}
                    
                    {receipt.extracted_data.receipt_number && (
                      <div className="flex items-center space-x-2">
                        <Hash className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          {receipt.extracted_data.receipt_number}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {/* Confidence Score */}
                {receipt.confidence_score && (
                  <div className="mb-4">
                    {getConfidenceDisplay(receipt.confidence_score)}
                  </div>
                )}

                {/* Transaction Link */}
                {receipt.transaction_id && (
                  <div className="mb-4">
                    <Badge variant="outline" className="text-xs text-blue-600 bg-blue-50">
                      <ExternalLink className="w-3 h-3 mr-1" />
                      Transaction Created
                    </Badge>
                  </div>
                )}

                {/* Upload Date */}
                <div className="text-xs text-gray-500 mb-4">
                  Uploaded {formatDate(receipt.upload_date)}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-4 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onReceiptSelect?.(receipt)}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    View
                  </Button>
                  
                  <div className="flex items-center space-x-1">
                    {receipt.status === 'failed' && (
                      <Button variant="ghost" size="sm" title="Retry Processing">
                        <RotateCcw className="w-4 h-4" />
                      </Button>
                    )}
                    
                    <Button variant="ghost" size="sm" title="Edit Notes">
                      <Edit className="w-4 h-4" />
                    </Button>
                    
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleDeleteReceipt(receipt.id)}
                      title="Delete Receipt"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Summary Stats */}
      {receipts.length > 0 && (
        <Card className="bg-gradient-to-r from-gray-50 to-blue-50">
          <CardContent className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-gray-900">{receipts.length}</div>
                <div className="text-sm text-gray-600">Total Receipts</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">
                  {receipts.filter(r => r.status === 'completed').length}
                </div>
                <div className="text-sm text-gray-600">Processed</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-600">
                  {receipts.filter(r => r.transaction_id).length}
                </div>
                <div className="text-sm text-gray-600">Auto-Created Transactions</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-600">
                  ${receipts
                    .filter(r => r.extracted_data?.total_amount)
                    .reduce((sum, r) => sum + (r.extracted_data?.total_amount || 0), 0)
                    .toFixed(2)}
                </div>
                <div className="text-sm text-gray-600">Total Amount</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

