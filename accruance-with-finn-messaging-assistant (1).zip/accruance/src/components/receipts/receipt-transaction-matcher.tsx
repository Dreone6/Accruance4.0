'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ReceiptManager } from '@/lib/receipt-manager'
import { BookkeepingEngine } from '@/lib/bookkeeping'
import type { ReceiptData } from '@/lib/receipt-manager'
import type { Transaction } from '@/lib/bookkeeping'
import { 
  Link,
  Unlink,
  Search,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Calendar,
  DollarSign,
  Store,
  ArrowRight,
  RefreshCw,
  Filter
} from 'lucide-react'

interface ReceiptTransactionMatcherProps {
  organizationId: string
  onMatchComplete?: (receiptId: string, transactionId: string) => void
}

interface MatchSuggestion {
  receipt: ReceiptData
  transaction: Transaction
  confidence: number
  reasons: string[]
}

export function ReceiptTransactionMatcher({ organizationId, onMatchComplete }: ReceiptTransactionMatcherProps) {
  const [unmatchedReceipts, setUnmatchedReceipts] = useState<ReceiptData[]>([])
  const [unmatchedTransactions, setUnmatchedTransactions] = useState<Transaction[]>([])
  const [matchSuggestions, setMatchSuggestions] = useState<MatchSuggestion[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedReceipt, setSelectedReceipt] = useState<ReceiptData | null>(null)

  const loadUnmatchedData = async () => {
    setLoading(true)
    try {
      // Load unmatched receipts (those without transaction_id)
      const receiptsResult = await ReceiptManager.getReceipts(organizationId)
      const unmatched = receiptsResult.receipts.filter(r => 
        r.status === 'completed' && !r.transaction_id && r.extracted_data?.total_amount
      )
      setUnmatchedReceipts(unmatched)

      // Load unmatched transactions (those without receipt references)
      const transactionsResult = await BookkeepingEngine.getTransactions(organizationId, { type: 'all' })
      const unmatchedTxns = transactionsResult.transactions.filter(t => 
        t.type === 'expense' && !t.reference?.startsWith('receipt_')
      )
      setUnmatchedTransactions(unmatchedTxns)

      // Generate match suggestions
      const suggestions = generateMatchSuggestions(unmatched, unmatchedTxns)
      setMatchSuggestions(suggestions)
    } catch (error) {
      console.error('Error loading unmatched data:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadUnmatchedData()
  }, [organizationId])

  const generateMatchSuggestions = (receipts: ReceiptData[], transactions: Transaction[]): MatchSuggestion[] => {
    const suggestions: MatchSuggestion[] = []

    for (const receipt of receipts) {
      if (!receipt.extracted_data?.total_amount) continue

      for (const transaction of transactions) {
        const confidence = calculateMatchConfidence(receipt, transaction)
        if (confidence > 0.6) { // Only suggest matches with >60% confidence
          const reasons = getMatchReasons(receipt, transaction)
          suggestions.push({
            receipt,
            transaction,
            confidence,
            reasons
          })
        }
      }
    }

    // Sort by confidence (highest first)
    return suggestions.sort((a, b) => b.confidence - a.confidence)
  }

  const calculateMatchConfidence = (receipt: ReceiptData, transaction: Transaction): number => {
    let confidence = 0
    const receiptData = receipt.extracted_data!

    // Amount matching (most important factor)
    const receiptAmount = Math.abs(receiptData.total_amount!)
    const transactionAmount = Math.abs(transaction.amount)
    const amountDiff = Math.abs(receiptAmount - transactionAmount)
    
    if (amountDiff === 0) {
      confidence += 0.5 // Perfect amount match
    } else if (amountDiff <= 0.01) {
      confidence += 0.45 // Very close amount match
    } else if (amountDiff <= 1.00) {
      confidence += 0.3 // Close amount match
    } else if (amountDiff <= 5.00) {
      confidence += 0.1 // Somewhat close amount match
    }

    // Date matching
    if (receiptData.date && transaction.date) {
      const receiptDate = new Date(receiptData.date)
      const transactionDate = new Date(transaction.date)
      const daysDiff = Math.abs((receiptDate.getTime() - transactionDate.getTime()) / (1000 * 60 * 60 * 24))
      
      if (daysDiff === 0) {
        confidence += 0.3 // Same day
      } else if (daysDiff <= 1) {
        confidence += 0.2 // Within 1 day
      } else if (daysDiff <= 3) {
        confidence += 0.1 // Within 3 days
      }
    }

    // Merchant/description matching
    if (receiptData.merchant_name && transaction.description) {
      const merchantLower = receiptData.merchant_name.toLowerCase()
      const descriptionLower = transaction.description.toLowerCase()
      
      if (descriptionLower.includes(merchantLower) || merchantLower.includes(descriptionLower)) {
        confidence += 0.2 // Merchant name appears in description
      } else {
        // Check for partial matches
        const merchantWords = merchantLower.split(' ')
        const descriptionWords = descriptionLower.split(' ')
        const commonWords = merchantWords.filter(word => 
          word.length > 2 && descriptionWords.some(dWord => dWord.includes(word))
        )
        if (commonWords.length > 0) {
          confidence += 0.1 // Partial merchant match
        }
      }
    }

    return Math.min(confidence, 1.0) // Cap at 100%
  }

  const getMatchReasons = (receipt: ReceiptData, transaction: Transaction): string[] => {
    const reasons: string[] = []
    const receiptData = receipt.extracted_data!

    // Amount reasons
    const receiptAmount = Math.abs(receiptData.total_amount!)
    const transactionAmount = Math.abs(transaction.amount)
    const amountDiff = Math.abs(receiptAmount - transactionAmount)
    
    if (amountDiff === 0) {
      reasons.push('Exact amount match')
    } else if (amountDiff <= 0.01) {
      reasons.push('Very close amount match')
    } else if (amountDiff <= 1.00) {
      reasons.push('Close amount match')
    }

    // Date reasons
    if (receiptData.date && transaction.date) {
      const receiptDate = new Date(receiptData.date)
      const transactionDate = new Date(transaction.date)
      const daysDiff = Math.abs((receiptDate.getTime() - transactionDate.getTime()) / (1000 * 60 * 60 * 24))
      
      if (daysDiff === 0) {
        reasons.push('Same date')
      } else if (daysDiff <= 1) {
        reasons.push('Within 1 day')
      } else if (daysDiff <= 3) {
        reasons.push('Within 3 days')
      }
    }

    // Merchant reasons
    if (receiptData.merchant_name && transaction.description) {
      const merchantLower = receiptData.merchant_name.toLowerCase()
      const descriptionLower = transaction.description.toLowerCase()
      
      if (descriptionLower.includes(merchantLower) || merchantLower.includes(descriptionLower)) {
        reasons.push('Merchant name match')
      }
    }

    return reasons
  }

  const handleCreateMatch = async (receiptId: string, transactionId: string) => {
    try {
      // Update receipt with transaction reference
      await ReceiptManager.updateReceiptNotes(receiptId, `Matched to transaction: ${transactionId}`)
      
      // Update transaction with receipt reference
      // In a real implementation, this would update the transaction's reference field
      console.log(`Creating match: Receipt ${receiptId} <-> Transaction ${transactionId}`)
      
      onMatchComplete?.(receiptId, transactionId)
      loadUnmatchedData() // Refresh data
    } catch (error) {
      console.error('Error creating match:', error)
    }
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-green-600 bg-green-100'
    if (confidence >= 0.7) return 'text-blue-600 bg-blue-100'
    if (confidence >= 0.5) return 'text-yellow-600 bg-yellow-100'
    return 'text-red-600 bg-red-100'
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(Math.abs(amount))
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    })
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <RefreshCw className="w-6 h-6 animate-spin mr-2" />
            <span>Loading unmatched data...</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Link className="w-5 h-5 mr-2" />
            Receipt-Transaction Matching
          </CardTitle>
          <CardDescription>
            Automatically match receipts with existing transactions to maintain accurate records.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">{unmatchedReceipts.length}</div>
              <div className="text-sm text-gray-600">Unmatched Receipts</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600">{unmatchedTransactions.length}</div>
              <div className="text-sm text-gray-600">Unmatched Transactions</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">{matchSuggestions.length}</div>
              <div className="text-sm text-gray-600">Match Suggestions</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Match Suggestions */}
      {matchSuggestions.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Search className="w-5 h-5 mr-2" />
              Suggested Matches
            </CardTitle>
            <CardDescription>
              AI-powered suggestions based on amount, date, and merchant matching.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {matchSuggestions.slice(0, 10).map((suggestion, index) => (
              <div key={index} className="border rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-center justify-between mb-3">
                  <Badge className={getConfidenceColor(suggestion.confidence)}>
                    {Math.round(suggestion.confidence * 100)}% match
                  </Badge>
                  <Button
                    size="sm"
                    onClick={() => handleCreateMatch(suggestion.receipt.id, suggestion.transaction.id)}
                  >
                    <Link className="w-4 h-4 mr-2" />
                    Create Match
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Receipt Info */}
                  <div className="space-y-2">
                    <h4 className="font-medium text-gray-900 flex items-center">
                      <Store className="w-4 h-4 mr-2" />
                      Receipt: {suggestion.receipt.file_name}
                    </h4>
                    <div className="text-sm text-gray-600 space-y-1">
                      {suggestion.receipt.extracted_data?.merchant_name && (
                        <div>Merchant: {suggestion.receipt.extracted_data.merchant_name}</div>
                      )}
                      {suggestion.receipt.extracted_data?.date && (
                        <div className="flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          {formatDate(suggestion.receipt.extracted_data.date)}
                        </div>
                      )}
                      {suggestion.receipt.extracted_data?.total_amount && (
                        <div className="flex items-center">
                          <DollarSign className="w-3 h-3 mr-1" />
                          {formatCurrency(suggestion.receipt.extracted_data.total_amount)}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Transaction Info */}
                  <div className="space-y-2">
                    <h4 className="font-medium text-gray-900 flex items-center">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Transaction: {suggestion.transaction.description}
                    </h4>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {formatDate(suggestion.transaction.date)}
                      </div>
                      <div className="flex items-center">
                        <DollarSign className="w-3 h-3 mr-1" />
                        {formatCurrency(suggestion.transaction.amount)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Match Reasons */}
                <div className="mt-3 pt-3 border-t">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-700">Match reasons:</span>
                    {suggestion.reasons.map((reason, i) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        {reason}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Manual Matching */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Unmatched Receipts */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Unmatched Receipts</CardTitle>
            <CardDescription>
              Receipts that haven't been linked to transactions yet.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 max-h-96 overflow-y-auto">
            {unmatchedReceipts.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <CheckCircle className="w-8 h-8 mx-auto mb-2" />
                <p>All receipts are matched!</p>
              </div>
            ) : (
              unmatchedReceipts.map((receipt) => (
                <div
                  key={receipt.id}
                  className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                    selectedReceipt?.id === receipt.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setSelectedReceipt(receipt)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">{receipt.file_name}</h4>
                      <div className="text-sm text-gray-600">
                        {receipt.extracted_data?.merchant_name && (
                          <span>{receipt.extracted_data.merchant_name} • </span>
                        )}
                        {receipt.extracted_data?.total_amount && (
                          <span>{formatCurrency(receipt.extracted_data.total_amount)}</span>
                        )}
                      </div>
                    </div>
                    {receipt.extracted_data?.date && (
                      <div className="text-xs text-gray-500">
                        {formatDate(receipt.extracted_data.date)}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Unmatched Transactions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Unmatched Transactions</CardTitle>
            <CardDescription>
              Transactions that could be matched with receipts.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 max-h-96 overflow-y-auto">
            {unmatchedTransactions.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <CheckCircle className="w-8 h-8 mx-auto mb-2" />
                <p>All transactions are matched!</p>
              </div>
            ) : (
              unmatchedTransactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="border rounded-lg p-3 hover:bg-gray-50 cursor-pointer"
                  onClick={() => selectedReceipt && handleCreateMatch(selectedReceipt.id, transaction.id)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">{transaction.description}</h4>
                      <div className="text-sm text-gray-600">
                        {formatCurrency(transaction.amount)}
                      </div>
                    </div>
                    <div className="text-xs text-gray-500">
                      {formatDate(transaction.date)}
                    </div>
                  </div>
                  {selectedReceipt && (
                    <div className="mt-2 pt-2 border-t">
                      <Button size="sm" className="w-full">
                        <Link className="w-4 h-4 mr-2" />
                        Match with {selectedReceipt.file_name}
                      </Button>
                    </div>
                  )}
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* Instructions */}
      {unmatchedReceipts.length > 0 && unmatchedTransactions.length > 0 && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900">Manual Matching Instructions</h4>
                <p className="text-sm text-blue-700 mt-1">
                  Click on a receipt from the left panel, then click on a matching transaction from the right panel to create a manual match.
                  The system will automatically suggest the best matches based on amount, date, and merchant information.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

