'use client'

import { useState, useRef, useCallback } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ReceiptManager } from '@/lib/receipt-manager'
import type { ReceiptData } from '@/lib/receipt-manager'
import { 
  Camera,
  CameraOff,
  Capture,
  RotateCcw,
  CheckCircle,
  X,
  Loader2,
  Download,
  Upload,
  Smartphone,
  Zap,
  Eye,
  Settings
} from 'lucide-react'

interface MobileCameraIntegrationProps {
  organizationId: string
  userId: string
  onCaptureComplete: (receipt: ReceiptData) => void
  onError: (error: string) => void
}

export function MobileCameraIntegration({ 
  organizationId, 
  userId, 
  onCaptureComplete, 
  onError 
}: MobileCameraIntegrationProps) {
  const [isActive, setIsActive] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [capturedImage, setCapturedImage] = useState<string | null>(null)
  const [processing, setProcessing] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment')
  
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const startCamera = useCallback(async () => {
    try {
      setCameraError(null)
      
      // Check if camera is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera not supported on this device')
      }

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: facingMode,
          width: { ideal: 1920, max: 1920 },
          height: { ideal: 1080, max: 1080 }
        },
        audio: false
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints)
      setStream(mediaStream)
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        videoRef.current.play()
      }
      
      setIsActive(true)
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to access camera'
      setCameraError(errorMessage)
      onError(errorMessage)
    }
  }, [facingMode, onError])

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop())
      setStream(null)
    }
    setIsActive(false)
    setCapturedImage(null)
  }, [stream])

  const capturePhoto = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current
    const context = canvas.getContext('2d')

    if (!context) return

    // Set canvas dimensions to match video
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight

    // Draw the video frame to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height)

    // Convert to blob and create object URL
    canvas.toBlob((blob) => {
      if (blob) {
        const imageUrl = URL.createObjectURL(blob)
        setCapturedImage(imageUrl)
      }
    }, 'image/jpeg', 0.9)
  }, [])

  const retakePhoto = useCallback(() => {
    setCapturedImage(null)
  }, [])

  const processCapture = useCallback(async () => {
    if (!capturedImage || !canvasRef.current) return

    setProcessing(true)
    try {
      // Convert canvas to File object
      const canvas = canvasRef.current
      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((blob) => {
          if (blob) resolve(blob)
        }, 'image/jpeg', 0.9)
      })

      const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
      const file = new File([blob], `camera-receipt-${timestamp}.jpg`, {
        type: 'image/jpeg'
      })

      // Process the receipt using ReceiptManager
      const receipt = await ReceiptManager.uploadReceipt(organizationId, file, userId)
      
      onCaptureComplete(receipt)
      stopCamera()
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to process capture'
      onError(errorMessage)
    } finally {
      setProcessing(false)
    }
  }, [capturedImage, organizationId, userId, onCaptureComplete, onError, stopCamera])

  const switchCamera = useCallback(() => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user')
    if (isActive) {
      stopCamera()
      // Restart with new facing mode
      setTimeout(startCamera, 100)
    }
  }, [isActive, stopCamera, startCamera])

  const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Camera className="w-5 h-5 mr-2" />
            Mobile Camera Capture
          </CardTitle>
          <CardDescription>
            Use your device's camera to capture receipts instantly with real-time OCR processing.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Smartphone className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-gray-600">
                  {isMobile ? 'Mobile device detected' : 'Desktop camera available'}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-green-600" />
                <span className="text-sm text-gray-600">Real-time processing</span>
              </div>
            </div>
            
            {!isActive ? (
              <Button onClick={startCamera} disabled={!!cameraError}>
                <Camera className="w-4 h-4 mr-2" />
                Start Camera
              </Button>
            ) : (
              <Button variant="outline" onClick={stopCamera}>
                <CameraOff className="w-4 h-4 mr-2" />
                Stop Camera
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Camera Error */}
      {cameraError && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <X className="w-5 h-5 text-red-600" />
              <div>
                <h4 className="font-medium text-red-900">Camera Error</h4>
                <p className="text-sm text-red-700">{cameraError}</p>
                <div className="mt-2">
                  <Button variant="outline" size="sm" onClick={startCamera}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Retry
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Camera Interface */}
      {isActive && (
        <Card>
          <CardContent className="p-0">
            <div className="relative bg-black rounded-lg overflow-hidden">
              {/* Video Stream */}
              <video
                ref={videoRef}
                className="w-full h-auto max-h-96 object-cover"
                playsInline
                muted
              />
              
              {/* Capture Overlay */}
              {!capturedImage && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="absolute inset-4 border-2 border-white border-dashed rounded-lg opacity-50"></div>
                  <div className="absolute top-4 left-4 right-4">
                    <div className="bg-black bg-opacity-50 text-white text-sm p-2 rounded">
                      Position receipt within the frame for best results
                    </div>
                  </div>
                </div>
              )}

              {/* Captured Image Overlay */}
              {capturedImage && (
                <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
                  <img
                    src={capturedImage}
                    alt="Captured receipt"
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              )}

              {/* Camera Controls */}
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-center justify-between">
                  {/* Camera Switch */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={switchCamera}
                    className="bg-white bg-opacity-90 hover:bg-opacity-100"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>

                  {/* Capture Button */}
                  {!capturedImage ? (
                    <Button
                      size="lg"
                      onClick={capturePhoto}
                      className="bg-white text-black hover:bg-gray-100 rounded-full w-16 h-16"
                    >
                      <Capture className="w-8 h-8" />
                    </Button>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        onClick={retakePhoto}
                        className="bg-white bg-opacity-90 hover:bg-opacity-100"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Retake
                      </Button>
                      <Button
                        onClick={processCapture}
                        disabled={processing}
                        className="bg-green-600 hover:bg-green-700 text-white"
                      >
                        {processing ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <CheckCircle className="w-4 h-4 mr-2" />
                        )}
                        {processing ? 'Processing...' : 'Process Receipt'}
                      </Button>
                    </div>
                  )}

                  {/* Settings */}
                  <Button
                    variant="outline"
                    size="sm"
                    className="bg-white bg-opacity-90 hover:bg-opacity-100"
                  >
                    <Settings className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Hidden Canvas for Image Processing */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Camera Tips */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h4 className="font-medium text-blue-900 mb-3">Camera Capture Tips</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-blue-700">
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <span>Hold device steady and ensure good lighting</span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <span>Position receipt flat within the frame</span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <span>Avoid shadows and reflections on the receipt</span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
              <span>Use rear camera for better quality</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Feature Highlights */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
        <CardContent className="p-4">
          <h4 className="font-medium text-green-900 mb-3">Mobile Camera Features</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <Camera className="w-4 h-4 text-green-600" />
              <span className="text-green-700">High-resolution capture</span>
            </div>
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4 text-green-600" />
              <span className="text-green-700">Real-time OCR processing</span>
            </div>
            <div className="flex items-center space-x-2">
              <Smartphone className="w-4 h-4 text-green-600" />
              <span className="text-green-700">Mobile-optimized interface</span>
            </div>
            <div className="flex items-center space-x-2">
              <RotateCcw className="w-4 h-4 text-green-600" />
              <span className="text-green-700">Front/rear camera switching</span>
            </div>
            <div className="flex items-center space-x-2">
              <Eye className="w-4 h-4 text-green-600" />
              <span className="text-green-700">Live preview with guides</span>
            </div>
            <div className="flex items-center space-x-2">
              <Upload className="w-4 h-4 text-green-600" />
              <span className="text-green-700">Instant upload and processing</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

