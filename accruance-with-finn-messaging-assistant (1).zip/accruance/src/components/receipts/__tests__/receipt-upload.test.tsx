import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ReceiptUpload } from '@/components/receipts/receipt-upload'

// Mock the receipt manager
jest.mock('@/lib/receipt-manager', () => ({
  ReceiptManager: {
    processReceipt: jest.fn().mockResolvedValue({
      id: 'test-receipt-1',
      merchant: 'Test Store',
      date: '2024-01-15',
      total: 25.99,
      confidence: 0.89,
      line_items: [
        { description: 'Test Item', quantity: 1, price: 25.99 }
      ],
    }),
    uploadReceipt: jest.fn().mockResolvedValue({
      url: 'https://example.com/receipt.jpg',
      filename: 'receipt.jpg',
    }),
  },
}))

describe('ReceiptUpload Component', () => {
  const defaultProps = {
    onUploadComplete: jest.fn(),
    onError: jest.fn(),
  }

  beforeEach(() => {
    jest.clearAllMocks()
  })

  test('renders upload interface', () => {
    render(<ReceiptUpload {...defaultProps} />)
    
    expect(screen.getByText(/drag & drop receipt images/i)).toBeInTheDocument()
    expect(screen.getByText(/or click to browse/i)).toBeInTheDocument()
    expect(screen.getByText(/supports jpeg, png, gif, bmp, pdf/i)).toBeInTheDocument()
  })

  test('handles file selection', async () => {
    const user = userEvent.setup()
    render(<ReceiptUpload {...defaultProps} />)
    
    const file = new File(['test'], 'receipt.jpg', { type: 'image/jpeg' })
    const input = screen.getByLabelText(/upload receipt/i)
    
    await user.upload(input, file)

    await waitFor(() => {
      expect(screen.getByText('receipt.jpg')).toBeInTheDocument()
      expect(screen.getByText(/processing/i)).toBeInTheDocument()
    })
  })

  test('validates file types', async () => {
    const user = userEvent.setup()
    render(<ReceiptUpload {...defaultProps} />)
    
    const file = new File(['test'], 'document.txt', { type: 'text/plain' })
    const input = screen.getByLabelText(/upload receipt/i)
    
    await user.upload(input, file)

    await waitFor(() => {
      expect(screen.getByText(/invalid file type/i)).toBeInTheDocument()
    })
  })

  test('validates file size', async () => {
    const user = userEvent.setup()
    render(<ReceiptUpload {...defaultProps} />)
    
    // Create a file larger than 10MB
    const largeFile = new File(['x'.repeat(11 * 1024 * 1024)], 'large.jpg', { type: 'image/jpeg' })
    const input = screen.getByLabelText(/upload receipt/i)
    
    await user.upload(input, largeFile)

    await waitFor(() => {
      expect(screen.getByText(/file too large/i)).toBeInTheDocument()
    })
  })

  test('displays OCR results', async () => {
    const user = userEvent.setup()
    render(<ReceiptUpload {...defaultProps} />)
    
    const file = new File(['test'], 'receipt.jpg', { type: 'image/jpeg' })
    const input = screen.getByLabelText(/upload receipt/i)
    
    await user.upload(input, file)

    await waitFor(() => {
      expect(screen.getByText('Test Store')).toBeInTheDocument()
      expect(screen.getByText('$25.99')).toBeInTheDocument()
      expect(screen.getByText('89%')).toBeInTheDocument()
    })
  })

  test('handles upload errors', async () => {
    const mockOnError = jest.fn()
    const user = userEvent.setup()
    
    // Mock an error
    require('@/lib/receipt-manager').ReceiptManager.processReceipt.mockRejectedValueOnce(
      new Error('OCR processing failed')
    )
    
    render(<ReceiptUpload {...defaultProps} onError={mockOnError} />)
    
    const file = new File(['test'], 'receipt.jpg', { type: 'image/jpeg' })
    const input = screen.getByLabelText(/upload receipt/i)
    
    await user.upload(input, file)

    await waitFor(() => {
      expect(mockOnError).toHaveBeenCalledWith(expect.any(Error))
    })
  })

  test('shows processing progress', async () => {
    const user = userEvent.setup()
    render(<ReceiptUpload {...defaultProps} />)
    
    const file = new File(['test'], 'receipt.jpg', { type: 'image/jpeg' })
    const input = screen.getByLabelText(/upload receipt/i)
    
    await user.upload(input, file)

    // Check for progress indicators
    expect(screen.getByRole('progressbar')).toBeInTheDocument()
    expect(screen.getByText(/processing receipt/i)).toBeInTheDocument()
  })
})

