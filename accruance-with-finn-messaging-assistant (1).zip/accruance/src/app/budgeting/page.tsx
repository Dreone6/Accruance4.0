'use client'

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { TrendingUp, Calculator, Target, BarChart3, PlusCircle, Settings, Download, DollarSign, Users, Zap, AlertTriangle, CheckCircle, Clock, ArrowRight } from 'lucide-react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart as RechartsPieChart, Cell } from 'recharts';

interface BudgetScenario {
  id: string;
  name: string;
  description: string;
  scenario_type: string;
  period_start: string;
  period_end: string;
  frequency: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface BudgetDriver {
  id: string;
  name: string;
  description: string;
  driver_type: string;
  category: string;
  unit_type: string;
  calculation_method: string;
  formula?: string;
  is_active: boolean;
  sort_order: number;
  budget_driver_values: DriverValue[];
}

interface DriverValue {
  id: string;
  period_start: string;
  period_end: string;
  value: number;
  growth_rate?: number;
  confidence_level: number;
  notes?: string;
  is_actual: boolean;
}

interface BudgetTemplate {
  id: string;
  name: string;
  description: string;
  business_type: string;
  template_data: any;
}

export default function BudgetingPage() {
  const [scenarios, setScenarios] = useState<BudgetScenario[]>([]);
  const [templates, setTemplates] = useState<BudgetTemplate[]>([]);
  const [selectedScenario, setSelectedScenario] = useState<BudgetScenario | null>(null);
  const [drivers, setDrivers] = useState<BudgetDriver[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showNewScenarioDialog, setShowNewScenarioDialog] = useState(false);
  const [showNewDriverDialog, setShowNewDriverDialog] = useState(false);

  // Form states
  const [newScenario, setNewScenario] = useState({
    name: '',
    description: '',
    scenarioType: 'budget',
    templateId: '',
    periodStart: '',
    periodEnd: '',
    frequency: 'monthly'
  });

  const [newDriver, setNewDriver] = useState({
    name: '',
    description: '',
    driverType: 'revenue',
    category: '',
    unitType: 'currency',
    calculationMethod: 'direct',
    formula: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // Load templates
      const templatesResponse = await fetch('/api/budgeting?action=templates');
      if (templatesResponse.ok) {
        const templatesData = await templatesResponse.json();
        setTemplates(templatesData.templates);
      }

      // Load scenarios
      const scenariosResponse = await fetch('/api/budgeting?action=scenarios');
      if (scenariosResponse.ok) {
        const scenariosData = await scenariosResponse.json();
        setScenarios(scenariosData.scenarios);
      }

    } catch (error) {
      console.error('Error loading data:', error);
      setError('Failed to load budgeting data');
    } finally {
      setLoading(false);
    }
  };

  const loadScenarioDetails = async (scenarioId: string) => {
    try {
      const response = await fetch(`/api/budgeting?action=scenario&scenarioId=${scenarioId}`);
      if (response.ok) {
        const data = await response.json();
        setSelectedScenario(data.scenario);
        setDrivers(data.drivers);
      }
    } catch (error) {
      console.error('Error loading scenario details:', error);
      setError('Failed to load scenario details');
    }
  };

  const createScenario = async () => {
    try {
      const response = await fetch('/api/budgeting', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create_scenario',
          ...newScenario
        })
      });

      if (response.ok) {
        const data = await response.json();
        setScenarios([data.scenario, ...scenarios]);
        setShowNewScenarioDialog(false);
        setNewScenario({
          name: '',
          description: '',
          scenarioType: 'budget',
          templateId: '',
          periodStart: '',
          periodEnd: '',
          frequency: 'monthly'
        });
        
        // Load the new scenario
        await loadScenarioDetails(data.scenario.id);
      } else {
        throw new Error('Failed to create scenario');
      }
    } catch (error) {
      console.error('Error creating scenario:', error);
      setError('Failed to create scenario');
    }
  };

  const createDriver = async () => {
    if (!selectedScenario) return;

    try {
      const response = await fetch('/api/budgeting', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create_driver',
          scenarioId: selectedScenario.id,
          ...newDriver
        })
      });

      if (response.ok) {
        const data = await response.json();
        setDrivers([...drivers, data.driver]);
        setShowNewDriverDialog(false);
        setNewDriver({
          name: '',
          description: '',
          driverType: 'revenue',
          category: '',
          unitType: 'currency',
          calculationMethod: 'direct',
          formula: ''
        });
      } else {
        throw new Error('Failed to create driver');
      }
    } catch (error) {
      console.error('Error creating driver:', error);
      setError('Failed to create driver');
    }
  };

  const updateDriverValue = async (driverId: string, periodStart: string, periodEnd: string, value: number) => {
    try {
      const response = await fetch('/api/budgeting', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update_driver_values',
          driverId,
          values: [{
            periodStart,
            periodEnd,
            value,
            isActual: false,
            source: 'manual'
          }]
        })
      });

      if (response.ok) {
        // Reload scenario details to get updated values
        if (selectedScenario) {
          await loadScenarioDetails(selectedScenario.id);
        }
      }
    } catch (error) {
      console.error('Error updating driver value:', error);
      setError('Failed to update driver value');
    }
  };

  const calculateBudget = async () => {
    if (!selectedScenario) return;

    try {
      const response = await fetch('/api/budgeting', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'calculate_budget',
          scenarioId: selectedScenario.id,
          periodStart: selectedScenario.period_start,
          periodEnd: selectedScenario.period_end
        })
      });

      if (response.ok) {
        const data = await response.json();
        // Reload scenario to get updated calculations
        await loadScenarioDetails(selectedScenario.id);
      }
    } catch (error) {
      console.error('Error calculating budget:', error);
      setError('Failed to calculate budget');
    }
  };

  const generateForecast = async () => {
    if (!selectedScenario) return;

    try {
      const response = await fetch('/api/budgeting', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'generate_forecast',
          scenarioId: selectedScenario.id,
          periodsAhead: 12
        })
      });

      if (response.ok) {
        const data = await response.json();
        // Handle forecast data
        console.log('Forecast generated:', data.forecast);
      }
    } catch (error) {
      console.error('Error generating forecast:', error);
      setError('Failed to generate forecast');
    }
  };

  const getDriverTypeIcon = (type: string) => {
    switch (type) {
      case 'revenue': return <DollarSign className="w-4 h-4 text-green-600" />;
      case 'expense': return <TrendingUp className="w-4 h-4 text-red-600" />;
      case 'operational': return <Users className="w-4 h-4 text-blue-600" />;
      default: return <Zap className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Active</Badge>;
      case 'draft':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Draft</Badge>;
      case 'archived':
        return <Badge variant="outline">Archived</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Sample data for charts
  const forecastData = [
    { month: 'Jan', revenue: 120000, expenses: 80000, net: 40000 },
    { month: 'Feb', revenue: 135000, expenses: 85000, net: 50000 },
    { month: 'Mar', revenue: 150000, expenses: 90000, net: 60000 },
    { month: 'Apr', revenue: 165000, expenses: 95000, net: 70000 },
    { month: 'May', revenue: 180000, expenses: 100000, net: 80000 },
    { month: 'Jun', revenue: 195000, expenses: 105000, net: 90000 }
  ];

  const driverBreakdown = [
    { name: 'New Customers', value: 35, color: '#8884d8' },
    { name: 'Existing Customers', value: 45, color: '#82ca9d' },
    { name: 'Upsells', value: 20, color: '#ffc658' }
  ];

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Driver-Based Budgeting & Forecasting</h1>
          <p className="text-gray-600">Create intelligent budgets driven by business metrics and generate rolling forecasts</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={showNewScenarioDialog} onOpenChange={setShowNewScenarioDialog}>
            <DialogTrigger asChild>
              <Button>
                <PlusCircle className="w-4 h-4 mr-2" />
                New Scenario
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Create Budget Scenario</DialogTitle>
                <DialogDescription>Set up a new budget or forecast scenario</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Scenario Name</Label>
                  <Input
                    id="name"
                    value={newScenario.name}
                    onChange={(e) => setNewScenario({...newScenario, name: e.target.value})}
                    placeholder="e.g., 2024 Annual Budget"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newScenario.description}
                    onChange={(e) => setNewScenario({...newScenario, description: e.target.value})}
                    placeholder="Brief description of this scenario"
                  />
                </div>
                <div>
                  <Label htmlFor="template">Template</Label>
                  <Select value={newScenario.templateId} onValueChange={(value) => setNewScenario({...newScenario, templateId: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">No template</SelectItem>
                      {templates.map(template => (
                        <SelectItem key={template.id} value={template.id}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="periodStart">Start Date</Label>
                    <Input
                      id="periodStart"
                      type="date"
                      value={newScenario.periodStart}
                      onChange={(e) => setNewScenario({...newScenario, periodStart: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="periodEnd">End Date</Label>
                    <Input
                      id="periodEnd"
                      type="date"
                      value={newScenario.periodEnd}
                      onChange={(e) => setNewScenario({...newScenario, periodEnd: e.target.value})}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowNewScenarioDialog(false)}>
                    Cancel
                  </Button>
                  <Button onClick={createScenario}>
                    Create Scenario
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {error && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
          <TabsTrigger value="drivers">Drivers</TabsTrigger>
          <TabsTrigger value="forecast">Forecast</TabsTrigger>
          <TabsTrigger value="worksheets">Worksheets</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6">
          {/* Dashboard Overview */}
          <div className="grid md:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Active Scenarios</p>
                    <p className="text-2xl font-bold">{scenarios.filter(s => s.status === 'active').length}</p>
                  </div>
                  <Target className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Drivers</p>
                    <p className="text-2xl font-bold">{drivers.length}</p>
                  </div>
                  <Zap className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Forecast Accuracy</p>
                    <p className="text-2xl font-bold">87%</p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Next Period Revenue</p>
                    <p className="text-2xl font-bold">{formatCurrency(195000)}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Forecast</CardTitle>
                <CardDescription>6-month rolling forecast with confidence intervals</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={forecastData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                    <Area type="monotone" dataKey="revenue" stroke="#8884d8" fill="#8884d8" fillOpacity={0.3} />
                    <Area type="monotone" dataKey="expenses" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.3} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue Driver Breakdown</CardTitle>
                <CardDescription>Contribution by revenue source</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={driverBreakdown}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({name, value}) => `${name}: ${value}%`}
                    >
                      {driverBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Recent Scenarios */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Scenarios</CardTitle>
              <CardDescription>Your most recently updated budget scenarios</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {scenarios.slice(0, 5).map(scenario => (
                  <div key={scenario.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div>
                        <h4 className="font-medium">{scenario.name}</h4>
                        <p className="text-sm text-gray-600">{scenario.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {getStatusBadge(scenario.status)}
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setActiveTab('drivers');
                          loadScenarioDetails(scenario.id);
                        }}
                      >
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scenarios" className="space-y-6">
          <div className="grid gap-6">
            {scenarios.map(scenario => (
              <Card key={scenario.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{scenario.name}</CardTitle>
                      <CardDescription>{scenario.description}</CardDescription>
                    </div>
                    {getStatusBadge(scenario.status)}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Type:</span>
                      <p className="text-gray-600 capitalize">{scenario.scenario_type}</p>
                    </div>
                    <div>
                      <span className="font-medium">Period:</span>
                      <p className="text-gray-600">{formatDate(scenario.period_start)} - {formatDate(scenario.period_end)}</p>
                    </div>
                    <div>
                      <span className="font-medium">Frequency:</span>
                      <p className="text-gray-600 capitalize">{scenario.frequency}</p>
                    </div>
                    <div>
                      <span className="font-medium">Last Updated:</span>
                      <p className="text-gray-600">{formatDate(scenario.updated_at)}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setActiveTab('drivers');
                        loadScenarioDetails(scenario.id);
                      }}
                    >
                      <Settings className="w-4 h-4 mr-2" />
                      Manage Drivers
                    </Button>
                    <Button variant="outline" size="sm">
                      <Calculator className="w-4 h-4 mr-2" />
                      Calculate Budget
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="drivers" className="space-y-6">
          {selectedScenario ? (
            <>
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold">{selectedScenario.name}</h2>
                  <p className="text-gray-600">Manage drivers for this scenario</p>
                </div>
                <div className="flex gap-2">
                  <Dialog open={showNewDriverDialog} onOpenChange={setShowNewDriverDialog}>
                    <DialogTrigger asChild>
                      <Button>
                        <PlusCircle className="w-4 h-4 mr-2" />
                        Add Driver
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Create Budget Driver</DialogTitle>
                        <DialogDescription>Add a new driver to calculate budget line items</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="driverName">Driver Name</Label>
                          <Input
                            id="driverName"
                            value={newDriver.name}
                            onChange={(e) => setNewDriver({...newDriver, name: e.target.value})}
                            placeholder="e.g., Monthly Recurring Revenue"
                          />
                        </div>
                        <div>
                          <Label htmlFor="driverDescription">Description</Label>
                          <Textarea
                            id="driverDescription"
                            value={newDriver.description}
                            onChange={(e) => setNewDriver({...newDriver, description: e.target.value})}
                            placeholder="Brief description of this driver"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="driverType">Type</Label>
                            <Select value={newDriver.driverType} onValueChange={(value) => setNewDriver({...newDriver, driverType: value})}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="revenue">Revenue</SelectItem>
                                <SelectItem value="expense">Expense</SelectItem>
                                <SelectItem value="operational">Operational</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="unitType">Unit Type</Label>
                            <Select value={newDriver.unitType} onValueChange={(value) => setNewDriver({...newDriver, unitType: value})}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="currency">Currency</SelectItem>
                                <SelectItem value="count">Count</SelectItem>
                                <SelectItem value="percentage">Percentage</SelectItem>
                                <SelectItem value="hours">Hours</SelectItem>
                                <SelectItem value="units">Units</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="category">Category</Label>
                          <Input
                            id="category"
                            value={newDriver.category}
                            onChange={(e) => setNewDriver({...newDriver, category: e.target.value})}
                            placeholder="e.g., Sales, Marketing, Operations"
                          />
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" onClick={() => setShowNewDriverDialog(false)}>
                            Cancel
                          </Button>
                          <Button onClick={createDriver}>
                            Create Driver
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                  <Button onClick={calculateBudget}>
                    <Calculator className="w-4 h-4 mr-2" />
                    Calculate Budget
                  </Button>
                </div>
              </div>

              <div className="grid gap-6">
                {drivers.map(driver => (
                  <Card key={driver.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {getDriverTypeIcon(driver.driver_type)}
                          <div>
                            <CardTitle className="text-lg">{driver.name}</CardTitle>
                            <CardDescription>{driver.description}</CardDescription>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="capitalize">{driver.driver_type}</Badge>
                          <Badge variant="outline">{driver.unit_type}</Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="grid md:grid-cols-6 gap-4">
                          {/* Sample periods - in real implementation, these would be generated based on scenario dates */}
                          {['Jan 2024', 'Feb 2024', 'Mar 2024', 'Apr 2024', 'May 2024', 'Jun 2024'].map((period, index) => (
                            <div key={period} className="space-y-2">
                              <Label className="text-xs font-medium">{period}</Label>
                              <Input
                                type="number"
                                placeholder="0"
                                className="text-sm"
                                onChange={(e) => {
                                  const value = parseFloat(e.target.value) || 0;
                                  const periodStart = new Date(2024, index, 1).toISOString().split('T')[0];
                                  const periodEnd = new Date(2024, index + 1, 0).toISOString().split('T')[0];
                                  updateDriverValue(driver.id, periodStart, periodEnd, value);
                                }}
                              />
                            </div>
                          ))}
                        </div>
                        
                        {driver.budget_driver_values && driver.budget_driver_values.length > 0 && (
                          <div className="mt-4">
                            <h4 className="text-sm font-medium mb-2">Current Values</h4>
                            <div className="grid md:grid-cols-6 gap-2 text-xs">
                              {driver.budget_driver_values.slice(0, 6).map(value => (
                                <div key={value.id} className="p-2 bg-gray-50 rounded">
                                  <div className="font-medium">
                                    {driver.unit_type === 'currency' ? formatCurrency(value.value) : value.value}
                                  </div>
                                  <div className="text-gray-500">
                                    {formatDate(value.period_start)}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Target className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Scenario Selected</h3>
                <p className="text-gray-600 mb-4">Select a scenario from the Scenarios tab to manage its drivers</p>
                <Button onClick={() => setActiveTab('scenarios')}>
                  View Scenarios
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="forecast" className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">Rolling Forecast</h2>
              <p className="text-gray-600">Generate intelligent forecasts based on your drivers</p>
            </div>
            <Button onClick={generateForecast}>
              <LineChart className="w-4 h-4 mr-2" />
              Generate Forecast
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>12-Month Rolling Forecast</CardTitle>
              <CardDescription>Revenue and expense projections with confidence intervals</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={forecastData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Legend />
                  <Line type="monotone" dataKey="revenue" stroke="#8884d8" strokeWidth={2} />
                  <Line type="monotone" dataKey="expenses" stroke="#82ca9d" strokeWidth={2} />
                  <Line type="monotone" dataKey="net" stroke="#ffc658" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Forecast Accuracy</CardTitle>
                <CardDescription>Historical accuracy by forecast horizon</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>1 Month Ahead</span>
                    <div className="flex items-center gap-2">
                      <Progress value={95} className="w-20" />
                      <span className="text-sm font-medium">95%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>3 Months Ahead</span>
                    <div className="flex items-center gap-2">
                      <Progress value={87} className="w-20" />
                      <span className="text-sm font-medium">87%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>6 Months Ahead</span>
                    <div className="flex items-center gap-2">
                      <Progress value={78} className="w-20" />
                      <span className="text-sm font-medium">78%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>12 Months Ahead</span>
                    <div className="flex items-center gap-2">
                      <Progress value={65} className="w-20" />
                      <span className="text-sm font-medium">65%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Key Assumptions</CardTitle>
                <CardDescription>Critical assumptions driving the forecast</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Customer Growth Rate</span>
                    <span className="font-medium">15% monthly</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Average Revenue per User</span>
                    <span className="font-medium">{formatCurrency(125)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Churn Rate</span>
                    <span className="font-medium">3.5% monthly</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Cost Inflation</span>
                    <span className="font-medium">2.5% annually</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="worksheets" className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold">Guided Worksheets</h2>
            <p className="text-gray-600">Step-by-step worksheets to build comprehensive budgets</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Planning Worksheet</CardTitle>
                <CardDescription>Plan your revenue streams and growth assumptions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Completion</span>
                    <div className="flex items-center gap-2">
                      <Progress value={75} className="w-20" />
                      <span className="text-sm font-medium">75%</span>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>✅ Customer segments defined</p>
                    <p>✅ Pricing strategy set</p>
                    <p>⏳ Growth assumptions in progress</p>
                    <p>⏳ Seasonality factors pending</p>
                  </div>
                  <Button variant="outline" className="w-full">
                    Continue Worksheet
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Headcount Planning Worksheet</CardTitle>
                <CardDescription>Plan hiring and compensation across departments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Completion</span>
                    <div className="flex items-center gap-2">
                      <Progress value={40} className="w-20" />
                      <span className="text-sm font-medium">40%</span>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>✅ Current headcount documented</p>
                    <p>⏳ Hiring plan in progress</p>
                    <p>⏳ Compensation bands pending</p>
                    <p>⏳ Benefits costs pending</p>
                  </div>
                  <Button variant="outline" className="w-full">
                    Continue Worksheet
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Marketing Budget Worksheet</CardTitle>
                <CardDescription>Allocate marketing spend across channels and campaigns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Completion</span>
                    <div className="flex items-center gap-2">
                      <Progress value={60} className="w-20" />
                      <span className="text-sm font-medium">60%</span>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>✅ Channel strategy defined</p>
                    <p>✅ CAC targets set</p>
                    <p>✅ Campaign budgets allocated</p>
                    <p>⏳ ROI assumptions pending</p>
                  </div>
                  <Button variant="outline" className="w-full">
                    Continue Worksheet
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Operations Budget Worksheet</CardTitle>
                <CardDescription>Plan operational expenses and infrastructure costs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Completion</span>
                    <div className="flex items-center gap-2">
                      <Progress value={25} className="w-20" />
                      <span className="text-sm font-medium">25%</span>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>✅ Fixed costs identified</p>
                    <p>⏳ Variable costs in progress</p>
                    <p>⏳ Technology costs pending</p>
                    <p>⏳ Facilities costs pending</p>
                  </div>
                  <Button variant="outline" className="w-full">
                    Start Worksheet
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

