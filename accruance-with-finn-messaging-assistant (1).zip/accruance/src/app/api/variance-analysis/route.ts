import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// GET /api/variance-analysis - Get variance analysis data
export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');

    // Get authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    switch (action) {
      case 'periods':
        return await getVariancePeriods(supabase, user.id);
      case 'items':
        const periodId = searchParams.get('periodId');
        return await getVarianceItems(supabase, user.id, periodId);
      case 'summary':
        const summaryPeriodId = searchParams.get('periodId');
        return await getVarianceSummary(supabase, user.id, summaryPeriodId);
      default:
        return await getVarianceOverview(supabase, user.id);
    }
  } catch (error) {
    console.error('Variance analysis error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/variance-analysis - Create or update variance analysis data
export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = await request.json();
    const { action, ...data } = body;

    // Get authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    switch (action) {
      case 'create_period':
        return await createVariancePeriod(supabase, user.id, data);
      case 'calculate_variances':
        return await calculateVariances(supabase, user.id, data);
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (error) {
    console.error('Variance analysis error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Helper functions
async function getVariancePeriods(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from('variance_analysis_periods')
    .select('*')
    .eq('user_id', userId)
    .order('period_start', { ascending: false });

  if (error) throw error;
  return NextResponse.json({ periods: data || [] });
}

async function getVarianceItems(supabase: any, userId: string, periodId: string) {
  if (!periodId) {
    return NextResponse.json({ error: 'Period ID required' }, { status: 400 });
  }

  const { data, error } = await supabase
    .from('variance_analysis_items')
    .select('*')
    .eq('period_id', periodId)
    .order('sort_order');

  if (error) throw error;
  return NextResponse.json({ items: data || [] });
}

async function getVarianceSummary(supabase: any, userId: string, periodId?: string) {
  const { data, error } = await supabase
    .rpc('get_variance_analysis_summary', { 
      user_id: userId, 
      period_id: periodId 
    });

  if (error) throw error;
  return NextResponse.json({ summary: data || {} });
}

async function getVarianceOverview(supabase: any, userId: string) {
  const { data: periods } = await supabase
    .from('variance_analysis_periods')
    .select('*')
    .eq('user_id', userId)
    .order('period_start', { ascending: false })
    .limit(5);

  return NextResponse.json({ periods: periods || [] });
}

async function createVariancePeriod(supabase: any, userId: string, data: any) {
  const { name, periodStart, periodEnd } = data;

  if (!name || !periodStart || !periodEnd) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  const { data: period, error } = await supabase
    .from('variance_analysis_periods')
    .insert({
      user_id: userId,
      name,
      period_start: periodStart,
      period_end: periodEnd,
      period_type: 'monthly',
      status: 'active'
    })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ period });
}

async function calculateVariances(supabase: any, userId: string, data: any) {
  const { periodId } = data;

  if (!periodId) {
    return NextResponse.json({ error: 'Period ID required' }, { status: 400 });
  }

  const { data: result, error } = await supabase
    .rpc('calculate_variance_analysis', { period_id: periodId });

  if (error) throw error;
  return NextResponse.json({ calculation: result });
}

