import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { searchParams } = new URL(request.url)
    const check = searchParams.get('check') || 'summary'

    switch (check) {
      case 'health':
        return await getDatabaseHealth(supabase)
      case 'integrity':
        return await getDataIntegrity(supabase)
      case 'performance':
        return await getPerformanceMetrics(supabase)
      case 'user':
        const userId = searchParams.get('userId')
        if (!userId) {
          return NextResponse.json({ error: 'User ID required' }, { status: 400 })
        }
        return await getUserPermissions(supabase, userId)
      default:
        return await getHealthSummary(supabase)
    }
  } catch (error) {
    console.error('Database health check error:', error)
    return NextResponse.json({ 
      error: 'Health check failed',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

async function getDatabaseHealth(supabase: any) {
  const { data, error } = await supabase.rpc('check_database_health')
  
  if (error) {
    return NextResponse.json({ error: 'Database health check failed', details: error.message }, { status: 500 })
  }

  const summary = {
    overall_status: data.every((check: any) => check.status === 'PASS') ? 'HEALTHY' : 'ISSUES_FOUND',
    total_checks: data.length,
    passed: data.filter((check: any) => check.status === 'PASS').length,
    failed: data.filter((check: any) => check.status === 'FAIL').length,
    checks: data
  }

  return NextResponse.json({ health: summary })
}

async function getDataIntegrity(supabase: any) {
  const { data, error } = await supabase.rpc('check_data_integrity')
  
  if (error) {
    return NextResponse.json({ error: 'Data integrity check failed', details: error.message }, { status: 500 })
  }

  const summary = {
    overall_status: data.every((check: any) => check.status === 'PASS') ? 'CLEAN' : 'ISSUES_FOUND',
    total_checks: data.length,
    passed: data.filter((check: any) => check.status === 'PASS').length,
    failed: data.filter((check: any) => check.status === 'FAIL').length,
    total_issues: data.reduce((sum: number, check: any) => sum + (check.count_found || 0), 0),
    checks: data
  }

  return NextResponse.json({ integrity: summary })
}

async function getPerformanceMetrics(supabase: any) {
  const { data, error } = await supabase.rpc('check_performance_metrics')
  
  if (error) {
    return NextResponse.json({ error: 'Performance check failed', details: error.message }, { status: 500 })
  }

  const summary = {
    overall_status: data.every((metric: any) => metric.status === 'OK') ? 'OPTIMAL' : 'NEEDS_ATTENTION',
    total_metrics: data.length,
    optimal: data.filter((metric: any) => metric.status === 'OK').length,
    warnings: data.filter((metric: any) => metric.status === 'WARNING').length,
    metrics: data
  }

  return NextResponse.json({ performance: summary })
}

async function getUserPermissions(supabase: any, userId: string) {
  const { data, error } = await supabase.rpc('validate_user_permissions', { user_id: userId })
  
  if (error) {
    return NextResponse.json({ error: 'User permission check failed', details: error.message }, { status: 500 })
  }

  const summary = {
    user_id: userId,
    overall_status: data.every((check: any) => check.has_access) ? 'VALID' : 'INVALID',
    total_checks: data.length,
    passed: data.filter((check: any) => check.has_access).length,
    failed: data.filter((check: any) => !check.has_access).length,
    permissions: data
  }

  return NextResponse.json({ user_permissions: summary })
}

async function getHealthSummary(supabase: any) {
  const { data, error } = await supabase
    .from('database_health_summary')
    .select('*')
    .single()
  
  if (error) {
    return NextResponse.json({ error: 'Health summary failed', details: error.message }, { status: 500 })
  }

  // Get additional system info
  const systemInfo = await getSystemInfo(supabase)

  return NextResponse.json({ 
    summary: data,
    system_info: systemInfo,
    timestamp: new Date().toISOString()
  })
}

async function getSystemInfo(supabase: any) {
  try {
    // Get table count
    const { data: tables } = await supabase
      .from('information_schema.tables')
      .select('count(*)')
      .eq('table_schema', 'public')
      .eq('table_type', 'BASE TABLE')

    // Get user count
    const { data: userCount } = await supabase
      .from('user_profiles')
      .select('count(*)')

    // Get transaction count
    const { data: transactionCount } = await supabase
      .from('transactions')
      .select('count(*)')

    // Get organization count
    const { data: orgCount } = await supabase
      .from('organizations')
      .select('count(*)')

    return {
      database_tables: tables?.[0]?.count || 0,
      total_users: userCount?.[0]?.count || 0,
      total_transactions: transactionCount?.[0]?.count || 0,
      total_organizations: orgCount?.[0]?.count || 0,
      supabase_version: 'Latest',
      environment: process.env.NODE_ENV || 'development'
    }
  } catch (error) {
    console.error('Error getting system info:', error)
    return {
      error: 'Could not retrieve system information'
    }
  }
}

// POST endpoint for running maintenance tasks
export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { action } = body

    switch (action) {
      case 'vacuum_analyze':
        return await runVacuumAnalyze(supabase)
      case 'reindex':
        return await runReindex(supabase)
      case 'cleanup_logs':
        return await cleanupOldLogs(supabase)
      default:
        return NextResponse.json({ error: 'Invalid maintenance action' }, { status: 400 })
    }
  } catch (error) {
    console.error('Maintenance task error:', error)
    return NextResponse.json({ 
      error: 'Maintenance task failed',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

async function runVacuumAnalyze(supabase: any) {
  // Note: VACUUM and ANALYZE require superuser privileges
  // This would typically be run by database administrators
  return NextResponse.json({ 
    message: 'VACUUM ANALYZE should be run by database administrator',
    recommendation: 'Schedule regular VACUUM ANALYZE on large tables'
  })
}

async function runReindex(supabase: any) {
  // Note: REINDEX requires elevated privileges
  return NextResponse.json({ 
    message: 'REINDEX should be run by database administrator',
    recommendation: 'Consider REINDEX on heavily updated indexes'
  })
}

async function cleanupOldLogs(supabase: any) {
  try {
    // Clean up audit logs older than 1 year
    const oneYearAgo = new Date()
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1)

    const { data, error } = await supabase
      .from('audit_logs')
      .delete()
      .lt('created_at', oneYearAgo.toISOString())

    if (error) {
      return NextResponse.json({ error: 'Log cleanup failed', details: error.message }, { status: 500 })
    }

    return NextResponse.json({ 
      message: 'Old audit logs cleaned up successfully',
      cutoff_date: oneYearAgo.toISOString()
    })
  } catch (error) {
    return NextResponse.json({ 
      error: 'Log cleanup failed',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

