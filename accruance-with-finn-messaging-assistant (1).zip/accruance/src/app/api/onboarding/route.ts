import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { 
      company_name,
      business_type,
      tax_id,
      address,
      phone,
      website,
      fiscal_year_end,
      accounting_method,
      chart_of_accounts_template
    } = body

    // Validate required fields
    if (!company_name || !business_type) {
      return NextResponse.json(
        { error: 'Company name and business type are required' }, 
        { status: 400 }
      )
    }

    // Create or update organization
    const { data: organization, error: orgError } = await supabase
      .from('organizations')
      .upsert({
        name: company_name,
        business_type,
        tax_id,
        address,
        phone,
        website,
        fiscal_year_end,
        accounting_method: accounting_method || 'accrual',
        settings: {
          chart_of_accounts_template: chart_of_accounts_template || 'standard'
        },
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (orgError) {
      return NextResponse.json({ error: orgError.message }, { status: 500 })
    }

    // Update user profile with organization
    const { error: userError } = await supabase
      .from('user_profiles')
      .update({
        company: company_name,
        updated_at: new Date().toISOString()
      })
      .eq('id', user.id)

    if (userError) {
      console.error('Error updating user profile:', userError)
    }

    // Create user-organization relationship
    const { error: relationError } = await supabase
      .from('user_organizations')
      .upsert({
        user_id: user.id,
        organization_id: organization.id,
        role: 'owner',
        created_at: new Date().toISOString()
      })

    if (relationError) {
      console.error('Error creating user-organization relationship:', relationError)
    }

    // Set up default categories based on template
    const defaultCategories = [
      { name: 'Office Supplies', type: 'expense', color: '#3B82F6' },
      { name: 'Travel', type: 'expense', color: '#10B981' },
      { name: 'Marketing', type: 'expense', color: '#F59E0B' },
      { name: 'Software', type: 'expense', color: '#8B5CF6' },
      { name: 'Professional Services', type: 'expense', color: '#EF4444' },
      { name: 'Sales Revenue', type: 'income', color: '#059669' },
      { name: 'Consulting Revenue', type: 'income', color: '#0EA5E9' },
      { name: 'Other Income', type: 'income', color: '#84CC16' }
    ]

    const { error: categoriesError } = await supabase
      .from('categories')
      .insert(
        defaultCategories.map(cat => ({
          ...cat,
          user_id: user.id,
          organization_id: organization.id,
          created_at: new Date().toISOString()
        }))
      )

    if (categoriesError) {
      console.error('Error creating default categories:', categoriesError)
    }

    return NextResponse.json({
      organization,
      message: 'Onboarding completed successfully'
    }, { status: 201 })

  } catch (error) {
    console.error('Onboarding error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

