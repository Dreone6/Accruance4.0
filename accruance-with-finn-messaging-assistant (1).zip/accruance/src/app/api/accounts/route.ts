import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type')
    const active = searchParams.get('active')

    let query = supabase
      .from('accounts')
      .select('*')
      .eq('user_id', user.id)
      .order('account_number')

    // Filter by account type if specified
    if (type) {
      query = query.eq('type', type)
    }

    // Filter by active status if specified
    if (active !== null) {
      query = query.eq('is_active', active === 'true')
    }

    const { data: accounts, error } = await query

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ accounts })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { 
      name, 
      type, 
      account_number, 
      description,
      parent_account_id,
      is_active = true
    } = body

    // Validate required fields
    if (!name || !type || !account_number) {
      return NextResponse.json(
        { error: 'Missing required fields: name, type, account_number' }, 
        { status: 400 }
      )
    }

    // Validate account type
    const validTypes = ['asset', 'liability', 'equity', 'revenue', 'expense']
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        { error: 'Invalid account type' }, 
        { status: 400 }
      )
    }

    // Check if account number already exists for this user
    const { data: existingAccount } = await supabase
      .from('accounts')
      .select('id')
      .eq('user_id', user.id)
      .eq('account_number', account_number)
      .single()

    if (existingAccount) {
      return NextResponse.json(
        { error: 'Account number already exists' }, 
        { status: 409 }
      )
    }

    // Create account
    const { data: account, error } = await supabase
      .from('accounts')
      .insert({
        user_id: user.id,
        name,
        type,
        account_number,
        description,
        parent_account_id,
        is_active,
        balance: 0,
        created_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ account }, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { 
      id,
      name, 
      description,
      is_active
    } = body

    if (!id) {
      return NextResponse.json(
        { error: 'Account ID is required' }, 
        { status: 400 }
      )
    }

    // Update account
    const { data: account, error } = await supabase
      .from('accounts')
      .update({
        name,
        description,
        is_active,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .eq('user_id', user.id)
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    if (!account) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 })
    }

    return NextResponse.json({ account })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'Account ID is required' }, 
        { status: 400 }
      )
    }

    // Check if account has transactions
    const { data: transactions } = await supabase
      .from('transactions')
      .select('id')
      .eq('account_id', id)
      .limit(1)

    if (transactions && transactions.length > 0) {
      return NextResponse.json(
        { error: 'Cannot delete account with existing transactions' }, 
        { status: 409 }
      )
    }

    // Delete account
    const { error } = await supabase
      .from('accounts')
      .delete()
      .eq('id', id)
      .eq('user_id', user.id)

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ message: 'Account deleted successfully' })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

