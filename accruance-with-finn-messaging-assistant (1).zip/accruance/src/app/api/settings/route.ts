import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: settings, error } = await supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', user.id)
      .single()

    if (error && error.code !== 'PGRST116') { // Not found error
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Return default settings if none exist
    if (!settings) {
      const defaultSettings = {
        email_notifications: true,
        push_notifications: true,
        currency: 'USD',
        timezone: 'UTC',
        date_format: 'MM/DD/YYYY',
        number_format: 'US',
        theme: 'light',
        language: 'en',
        settings: {}
      }
      return NextResponse.json({ settings: defaultSettings })
    }

    return NextResponse.json({ settings })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const {
      email_notifications,
      push_notifications,
      currency,
      timezone,
      date_format,
      number_format,
      theme,
      language,
      settings
    } = body

    const { data: updatedSettings, error } = await supabase
      .from('user_settings')
      .upsert({
        user_id: user.id,
        email_notifications,
        push_notifications,
        currency,
        timezone,
        date_format,
        number_format,
        theme,
        language,
        settings,
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ settings: updatedSettings })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

