import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')
    const startDate = searchParams.get('startDate')
    const endDate = searchParams.get('endDate')
    const accountId = searchParams.get('accountId')

    const offset = (page - 1) * limit

    let query = supabase
      .from('journal_entries')
      .select(`
        *,
        journal_entry_lines (
          id,
          account_id,
          debit_amount,
          credit_amount,
          description,
          accounts (
            id,
            name,
            account_number,
            type
          )
        )
      `)
      .eq('user_id', user.id)
      .order('date', { ascending: false })
      .range(offset, offset + limit - 1)

    // Filter by date range
    if (startDate) {
      query = query.gte('date', startDate)
    }
    if (endDate) {
      query = query.lte('date', endDate)
    }

    // Filter by account if specified
    if (accountId) {
      query = query.eq('journal_entry_lines.account_id', accountId)
    }

    const { data: journalEntries, error } = await query

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ journalEntries })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { 
      date,
      reference_number,
      description,
      lines
    } = body

    // Validate required fields
    if (!date || !description || !lines || !Array.isArray(lines) || lines.length < 2) {
      return NextResponse.json(
        { error: 'Missing required fields or insufficient journal entry lines' }, 
        { status: 400 }
      )
    }

    // Validate that debits equal credits
    const totalDebits = lines.reduce((sum, line) => sum + (line.debit_amount || 0), 0)
    const totalCredits = lines.reduce((sum, line) => sum + (line.credit_amount || 0), 0)

    if (Math.abs(totalDebits - totalCredits) > 0.01) {
      return NextResponse.json(
        { error: 'Debits must equal credits in a journal entry' }, 
        { status: 400 }
      )
    }

    // Validate that each line has either debit or credit (not both)
    for (const line of lines) {
      if ((line.debit_amount && line.credit_amount) || (!line.debit_amount && !line.credit_amount)) {
        return NextResponse.json(
          { error: 'Each line must have either debit or credit amount, not both or neither' }, 
          { status: 400 }
        )
      }
      if (!line.account_id) {
        return NextResponse.json(
          { error: 'Each line must have an account_id' }, 
          { status: 400 }
        )
      }
    }

    // Start transaction
    const { data: journalEntry, error: journalError } = await supabase
      .from('journal_entries')
      .insert({
        user_id: user.id,
        date,
        reference_number,
        description,
        total_amount: totalDebits,
        status: 'posted',
        created_at: new Date().toISOString()
      })
      .select()
      .single()

    if (journalError) {
      return NextResponse.json({ error: journalError.message }, { status: 500 })
    }

    // Insert journal entry lines
    const journalEntryLines = lines.map(line => ({
      journal_entry_id: journalEntry.id,
      account_id: line.account_id,
      debit_amount: line.debit_amount || 0,
      credit_amount: line.credit_amount || 0,
      description: line.description || description
    }))

    const { data: insertedLines, error: linesError } = await supabase
      .from('journal_entry_lines')
      .insert(journalEntryLines)
      .select(`
        *,
        accounts (
          id,
          name,
          account_number,
          type
        )
      `)

    if (linesError) {
      // Rollback journal entry if lines insertion fails
      await supabase
        .from('journal_entries')
        .delete()
        .eq('id', journalEntry.id)
      
      return NextResponse.json({ error: linesError.message }, { status: 500 })
    }

    // Update account balances
    for (const line of insertedLines) {
      const { error: balanceError } = await supabase.rpc('update_account_balance', {
        account_id: line.account_id,
        debit_amount: line.debit_amount,
        credit_amount: line.credit_amount
      })

      if (balanceError) {
        console.error('Balance update error:', balanceError)
      }
    }

    return NextResponse.json({ 
      journalEntry: {
        ...journalEntry,
        journal_entry_lines: insertedLines
      }
    }, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { 
      id,
      description,
      reference_number,
      status
    } = body

    if (!id) {
      return NextResponse.json(
        { error: 'Journal entry ID is required' }, 
        { status: 400 }
      )
    }

    // Update journal entry (only allow updating description, reference, and status)
    const { data: journalEntry, error } = await supabase
      .from('journal_entries')
      .update({
        description,
        reference_number,
        status,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .eq('user_id', user.id)
      .select(`
        *,
        journal_entry_lines (
          id,
          account_id,
          debit_amount,
          credit_amount,
          description,
          accounts (
            id,
            name,
            account_number,
            type
          )
        )
      `)
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    if (!journalEntry) {
      return NextResponse.json({ error: 'Journal entry not found' }, { status: 404 })
    }

    return NextResponse.json({ journalEntry })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'Journal entry ID is required' }, 
        { status: 400 }
      )
    }

    // Get journal entry with lines for balance reversal
    const { data: journalEntry, error: fetchError } = await supabase
      .from('journal_entries')
      .select(`
        *,
        journal_entry_lines (
          account_id,
          debit_amount,
          credit_amount
        )
      `)
      .eq('id', id)
      .eq('user_id', user.id)
      .single()

    if (fetchError || !journalEntry) {
      return NextResponse.json({ error: 'Journal entry not found' }, { status: 404 })
    }

    // Reverse account balances
    for (const line of journalEntry.journal_entry_lines) {
      const { error: balanceError } = await supabase.rpc('update_account_balance', {
        account_id: line.account_id,
        debit_amount: -line.debit_amount, // Reverse the amounts
        credit_amount: -line.credit_amount
      })

      if (balanceError) {
        console.error('Balance reversal error:', balanceError)
      }
    }

    // Delete journal entry lines first (due to foreign key constraint)
    const { error: linesError } = await supabase
      .from('journal_entry_lines')
      .delete()
      .eq('journal_entry_id', id)

    if (linesError) {
      return NextResponse.json({ error: linesError.message }, { status: 500 })
    }

    // Delete journal entry
    const { error: deleteError } = await supabase
      .from('journal_entries')
      .delete()
      .eq('id', id)
      .eq('user_id', user.id)

    if (deleteError) {
      return NextResponse.json({ error: deleteError.message }, { status: 500 })
    }

    return NextResponse.json({ message: 'Journal entry deleted successfully' })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

