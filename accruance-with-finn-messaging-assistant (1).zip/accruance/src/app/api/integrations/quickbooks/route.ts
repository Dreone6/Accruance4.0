import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// QuickBooks OAuth configuration
const QB_CONFIG = {
  clientId: process.env.QUICKBOOKS_CLIENT_ID,
  clientSecret: process.env.QUICKBOOKS_CLIENT_SECRET,
  redirectUri: process.env.QUICKBOOKS_REDIRECT_URI || `${process.env.NEXT_PUBLIC_APP_URL}/api/integrations/quickbooks/callback`,
  scope: 'com.intuit.quickbooks.accounting',
  baseUrl: process.env.NODE_ENV === 'production' 
    ? 'https://appcenter.intuit.com/connect/oauth2'
    : 'https://appcenter.intuit.com/connect/oauth2',
  apiBaseUrl: process.env.NODE_ENV === 'production'
    ? 'https://quickbooks-api.intuit.com'
    : 'https://sandbox-quickbooks.intuit.com'
};

// GET /api/integrations/quickbooks - Get integration status
export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    
    // Get authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get QuickBooks integration for user
    const { data: integration, error } = await supabase
      .from('integrations')
      .select('*')
      .eq('user_id', user.id)
      .eq('provider', 'quickbooks')
      .eq('is_active', true)
      .single();

    if (error && error.code !== 'PGRST116') {
      console.error('Error fetching integration:', error);
      return NextResponse.json({ error: 'Failed to fetch integration' }, { status: 500 });
    }

    // Get recent sync logs
    let syncLogs = [];
    if (integration) {
      const { data: logs } = await supabase
        .from('integration_sync_logs')
        .select('*')
        .eq('integration_id', integration.id)
        .order('created_at', { ascending: false })
        .limit(10);
      
      syncLogs = logs || [];
    }

    return NextResponse.json({
      connected: !!integration,
      integration: integration || null,
      syncLogs,
      authUrl: integration ? null : generateAuthUrl()
    });

  } catch (error) {
    console.error('QuickBooks integration error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/integrations/quickbooks - Initiate OAuth or trigger sync
export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = await request.json();
    const { action, ...params } = body;

    // Get authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    switch (action) {
      case 'connect':
        return handleConnect(user.id);
      
      case 'sync':
        return handleSync(supabase, user.id, params);
      
      case 'disconnect':
        return handleDisconnect(supabase, user.id);
      
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }

  } catch (error) {
    console.error('QuickBooks integration error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// PUT /api/integrations/quickbooks - Update integration settings
export async function PUT(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = await request.json();

    // Get authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get existing integration
    const { data: integration, error: fetchError } = await supabase
      .from('integrations')
      .select('*')
      .eq('user_id', user.id)
      .eq('provider', 'quickbooks')
      .single();

    if (fetchError || !integration) {
      return NextResponse.json({ error: 'Integration not found' }, { status: 404 });
    }

    // Update integration settings
    const { data: updated, error: updateError } = await supabase
      .from('integrations')
      .update({
        sync_frequency: body.sync_frequency || integration.sync_frequency,
        updated_at: new Date().toISOString()
      })
      .eq('id', integration.id)
      .select()
      .single();

    if (updateError) {
      console.error('Error updating integration:', updateError);
      return NextResponse.json({ error: 'Failed to update integration' }, { status: 500 });
    }

    return NextResponse.json({ integration: updated });

  } catch (error) {
    console.error('QuickBooks integration error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Helper functions
function generateAuthUrl(): string {
  const state = generateRandomState();
  const params = new URLSearchParams({
    client_id: QB_CONFIG.clientId!,
    scope: QB_CONFIG.scope,
    redirect_uri: QB_CONFIG.redirectUri!,
    response_type: 'code',
    access_type: 'offline',
    state
  });

  return `${QB_CONFIG.baseUrl}?${params.toString()}`;
}

function generateRandomState(): string {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

async function handleConnect(userId: string) {
  const authUrl = generateAuthUrl();
  return NextResponse.json({ authUrl });
}

async function handleSync(supabase: any, userId: string, params: any) {
  // Get integration
  const { data: integration, error } = await supabase
    .from('integrations')
    .select('*')
    .eq('user_id', userId)
    .eq('provider', 'quickbooks')
    .eq('is_active', true)
    .single();

  if (error || !integration) {
    return NextResponse.json({ error: 'Integration not found' }, { status: 404 });
  }

  // Check if token is still valid
  if (new Date(integration.token_expires_at) <= new Date()) {
    // Token expired, need to refresh
    const refreshResult = await refreshAccessToken(supabase, integration);
    if (!refreshResult.success) {
      return NextResponse.json({ error: 'Token refresh failed' }, { status: 401 });
    }
  }

  // Queue sync operation
  const syncType = params.syncType || 'incremental';
  const entityTypes = params.entityTypes || ['accounts', 'transactions', 'customers'];

  for (const entityType of entityTypes) {
    await supabase
      .from('integration_sync_queue')
      .insert({
        integration_id: integration.id,
        entity_type: entityType,
        sync_type: syncType,
        priority: 5,
        scheduled_at: new Date().toISOString()
      });
  }

  // Create sync log entry
  const { data: syncLog } = await supabase
    .from('integration_sync_logs')
    .insert({
      integration_id: integration.id,
      sync_type: syncType,
      status: 'pending',
      started_at: new Date().toISOString()
    })
    .select()
    .single();

  // Trigger background sync process (in a real implementation, this would be a queue worker)
  // For now, we'll return success and the sync would be processed by a background job
  
  return NextResponse.json({ 
    message: 'Sync queued successfully',
    syncLogId: syncLog?.id 
  });
}

async function handleDisconnect(supabase: any, userId: string) {
  // Deactivate integration
  const { error } = await supabase
    .from('integrations')
    .update({ 
      is_active: false,
      access_token: null,
      refresh_token: null,
      updated_at: new Date().toISOString()
    })
    .eq('user_id', userId)
    .eq('provider', 'quickbooks');

  if (error) {
    console.error('Error disconnecting integration:', error);
    return NextResponse.json({ error: 'Failed to disconnect' }, { status: 500 });
  }

  return NextResponse.json({ message: 'Integration disconnected successfully' });
}

async function refreshAccessToken(supabase: any, integration: any) {
  try {
    const response = await fetch(`${QB_CONFIG.baseUrl}/tokens/bearer`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${Buffer.from(`${QB_CONFIG.clientId}:${QB_CONFIG.clientSecret}`).toString('base64')}`
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: integration.refresh_token
      })
    });

    if (!response.ok) {
      throw new Error(`Token refresh failed: ${response.statusText}`);
    }

    const tokenData = await response.json();

    // Update integration with new tokens
    await supabase
      .from('integrations')
      .update({
        access_token: tokenData.access_token,
        refresh_token: tokenData.refresh_token || integration.refresh_token,
        token_expires_at: new Date(Date.now() + tokenData.expires_in * 1000).toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('id', integration.id);

    return { success: true };

  } catch (error) {
    console.error('Token refresh error:', error);
    return { success: false, error: error.message };
  }
}

