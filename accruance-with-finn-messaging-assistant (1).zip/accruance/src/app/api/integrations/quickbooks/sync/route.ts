import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// QuickBooks API configuration
const QB_CONFIG = {
  apiBaseUrl: process.env.NODE_ENV === 'production'
    ? 'https://quickbooks-api.intuit.com'
    : 'https://sandbox-quickbooks.intuit.com'
};

// POST /api/integrations/quickbooks/sync - Process sync queue
export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = await request.json();
    const { integrationId, entityType, syncType } = body;

    // Validate required parameters
    if (!integrationId || !entityType) {
      return NextResponse.json({ error: 'Missing required parameters' }, { status: 400 });
    }

    // Get integration details
    const { data: integration, error: integrationError } = await supabase
      .from('integrations')
      .select('*')
      .eq('id', integrationId)
      .eq('provider', 'quickbooks')
      .eq('is_active', true)
      .single();

    if (integrationError || !integration) {
      return NextResponse.json({ error: 'Integration not found' }, { status: 404 });
    }

    // Check token validity
    if (new Date(integration.token_expires_at) <= new Date()) {
      const refreshResult = await refreshAccessToken(supabase, integration);
      if (!refreshResult.success) {
        return NextResponse.json({ error: 'Token refresh failed' }, { status: 401 });
      }
      // Refetch integration with updated token
      const { data: updatedIntegration } = await supabase
        .from('integrations')
        .select('*')
        .eq('id', integrationId)
        .single();
      integration.access_token = updatedIntegration.access_token;
    }

    // Create sync log entry
    const { data: syncLog, error: logError } = await supabase
      .from('integration_sync_logs')
      .insert({
        integration_id: integrationId,
        sync_type: syncType || 'incremental',
        entity_type: entityType,
        status: 'running',
        started_at: new Date().toISOString()
      })
      .select()
      .single();

    if (logError) {
      console.error('Error creating sync log:', logError);
      return NextResponse.json({ error: 'Failed to create sync log' }, { status: 500 });
    }

    // Process sync based on entity type
    let syncResult;
    switch (entityType) {
      case 'accounts':
        syncResult = await syncAccounts(supabase, integration, syncLog.id);
        break;
      case 'customers':
        syncResult = await syncCustomers(supabase, integration, syncLog.id);
        break;
      case 'vendors':
        syncResult = await syncVendors(supabase, integration, syncLog.id);
        break;
      case 'items':
        syncResult = await syncItems(supabase, integration, syncLog.id);
        break;
      case 'transactions':
        syncResult = await syncTransactions(supabase, integration, syncLog.id);
        break;
      default:
        syncResult = { success: false, error: 'Unsupported entity type' };
    }

    // Update sync log with results
    await supabase
      .from('integration_sync_logs')
      .update({
        status: syncResult.success ? 'completed' : 'failed',
        records_processed: syncResult.processed || 0,
        records_created: syncResult.created || 0,
        records_updated: syncResult.updated || 0,
        records_failed: syncResult.failed || 0,
        error_message: syncResult.error || null,
        completed_at: new Date().toISOString()
      })
      .eq('id', syncLog.id);

    // Update integration last sync time if successful
    if (syncResult.success) {
      await supabase
        .from('integrations')
        .update({ last_sync_at: new Date().toISOString() })
        .eq('id', integrationId);
    }

    return NextResponse.json({
      success: syncResult.success,
      syncLogId: syncLog.id,
      ...syncResult
    });

  } catch (error) {
    console.error('Sync error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Sync accounts from QuickBooks
async function syncAccounts(supabase: any, integration: any, syncLogId: string) {
  try {
    const accounts = await fetchQuickBooksData(integration, 'accounts');
    let processed = 0, created = 0, updated = 0, failed = 0;

    for (const qbAccount of accounts) {
      try {
        processed++;

        // Check if account already exists
        const { data: existingMapping } = await supabase
          .from('integration_entity_mappings')
          .select('internal_id')
          .eq('integration_id', integration.id)
          .eq('entity_type', 'account')
          .eq('external_id', qbAccount.Id)
          .single();

        const accountData = {
          name: qbAccount.Name,
          type: mapAccountType(qbAccount.AccountType),
          subtype: qbAccount.AccountSubType,
          balance: parseFloat(qbAccount.CurrentBalance || '0'),
          is_active: qbAccount.Active !== false,
          external_id: qbAccount.Id,
          user_id: integration.user_id
        };

        if (existingMapping) {
          // Update existing account
          await supabase
            .from('accounts')
            .update(accountData)
            .eq('id', existingMapping.internal_id);
          updated++;
        } else {
          // Create new account
          const { data: newAccount, error: accountError } = await supabase
            .from('accounts')
            .insert(accountData)
            .select()
            .single();

          if (accountError) {
            console.error('Error creating account:', accountError);
            failed++;
            continue;
          }

          // Create entity mapping
          await supabase
            .from('integration_entity_mappings')
            .insert({
              integration_id: integration.id,
              entity_type: 'account',
              external_id: qbAccount.Id,
              internal_id: newAccount.id,
              external_data: qbAccount
            });

          created++;
        }

      } catch (error) {
        console.error('Error processing account:', error);
        failed++;
      }
    }

    return { success: true, processed, created, updated, failed };

  } catch (error) {
    console.error('Accounts sync error:', error);
    return { success: false, error: error.message };
  }
}

// Sync customers from QuickBooks
async function syncCustomers(supabase: any, integration: any, syncLogId: string) {
  try {
    const customers = await fetchQuickBooksData(integration, 'customers');
    let processed = 0, created = 0, updated = 0, failed = 0;

    for (const qbCustomer of customers) {
      try {
        processed++;

        const customerData = {
          name: qbCustomer.Name,
          company_name: qbCustomer.CompanyName || qbCustomer.Name,
          email: qbCustomer.PrimaryEmailAddr?.Address || null,
          phone: qbCustomer.PrimaryPhone?.FreeFormNumber || null,
          is_active: qbCustomer.Active !== false,
          external_id: qbCustomer.Id,
          user_id: integration.user_id
        };

        // Check if customer already exists
        const { data: existingMapping } = await supabase
          .from('integration_entity_mappings')
          .select('internal_id')
          .eq('integration_id', integration.id)
          .eq('entity_type', 'customer')
          .eq('external_id', qbCustomer.Id)
          .single();

        if (existingMapping) {
          // Update existing customer
          await supabase
            .from('customers')
            .update(customerData)
            .eq('id', existingMapping.internal_id);
          updated++;
        } else {
          // Create new customer
          const { data: newCustomer, error: customerError } = await supabase
            .from('customers')
            .insert(customerData)
            .select()
            .single();

          if (customerError) {
            console.error('Error creating customer:', customerError);
            failed++;
            continue;
          }

          // Create entity mapping
          await supabase
            .from('integration_entity_mappings')
            .insert({
              integration_id: integration.id,
              entity_type: 'customer',
              external_id: qbCustomer.Id,
              internal_id: newCustomer.id,
              external_data: qbCustomer
            });

          created++;
        }

      } catch (error) {
        console.error('Error processing customer:', error);
        failed++;
      }
    }

    return { success: true, processed, created, updated, failed };

  } catch (error) {
    console.error('Customers sync error:', error);
    return { success: false, error: error.message };
  }
}

// Sync transactions from QuickBooks
async function syncTransactions(supabase: any, integration: any, syncLogId: string) {
  try {
    // Fetch various transaction types from QuickBooks
    const transactionTypes = ['JournalEntry', 'Bill', 'Invoice', 'Payment'];
    let totalProcessed = 0, totalCreated = 0, totalUpdated = 0, totalFailed = 0;

    for (const txnType of transactionTypes) {
      const transactions = await fetchQuickBooksData(integration, txnType.toLowerCase());
      
      for (const qbTransaction of transactions) {
        try {
          totalProcessed++;

          const transactionData = await mapTransactionData(qbTransaction, txnType, integration.user_id);

          // Check if transaction already exists
          const { data: existingMapping } = await supabase
            .from('integration_entity_mappings')
            .select('internal_id')
            .eq('integration_id', integration.id)
            .eq('entity_type', 'transaction')
            .eq('external_id', qbTransaction.Id)
            .single();

          if (existingMapping) {
            // Update existing transaction
            await supabase
              .from('transactions')
              .update(transactionData)
              .eq('id', existingMapping.internal_id);
            totalUpdated++;
          } else {
            // Create new transaction
            const { data: newTransaction, error: transactionError } = await supabase
              .from('transactions')
              .insert(transactionData)
              .select()
              .single();

            if (transactionError) {
              console.error('Error creating transaction:', transactionError);
              totalFailed++;
              continue;
            }

            // Create entity mapping
            await supabase
              .from('integration_entity_mappings')
              .insert({
                integration_id: integration.id,
                entity_type: 'transaction',
                external_id: qbTransaction.Id,
                internal_id: newTransaction.id,
                external_data: qbTransaction
              });

            totalCreated++;
          }

        } catch (error) {
          console.error('Error processing transaction:', error);
          totalFailed++;
        }
      }
    }

    return { 
      success: true, 
      processed: totalProcessed, 
      created: totalCreated, 
      updated: totalUpdated, 
      failed: totalFailed 
    };

  } catch (error) {
    console.error('Transactions sync error:', error);
    return { success: false, error: error.message };
  }
}

// Helper functions
async function fetchQuickBooksData(integration: any, entityType: string) {
  const entityMap = {
    'accounts': 'Account',
    'customers': 'Customer',
    'vendors': 'Vendor',
    'items': 'Item',
    'journalentry': 'JournalEntry',
    'bill': 'Bill',
    'invoice': 'Invoice',
    'payment': 'Payment'
  };

  const qbEntityType = entityMap[entityType.toLowerCase()];
  if (!qbEntityType) {
    throw new Error(`Unsupported entity type: ${entityType}`);
  }

  const response = await fetch(
    `${QB_CONFIG.apiBaseUrl}/v3/company/${integration.realm_id}/query?query=SELECT * FROM ${qbEntityType}`,
    {
      headers: {
        'Authorization': `Bearer ${integration.access_token}`,
        'Accept': 'application/json'
      }
    }
  );

  if (!response.ok) {
    throw new Error(`QuickBooks API error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  return data.QueryResponse?.[qbEntityType] || [];
}

function mapAccountType(qbAccountType: string): string {
  const typeMap: { [key: string]: string } = {
    'Asset': 'asset',
    'Liability': 'liability',
    'Equity': 'equity',
    'Income': 'revenue',
    'Expense': 'expense'
  };

  return typeMap[qbAccountType] || 'other';
}

async function mapTransactionData(qbTransaction: any, txnType: string, userId: string) {
  // Basic transaction mapping - this would be more complex in a real implementation
  return {
    date: qbTransaction.TxnDate || new Date().toISOString().split('T')[0],
    amount: parseFloat(qbTransaction.TotalAmt || qbTransaction.Amount || '0'),
    description: qbTransaction.PrivateNote || qbTransaction.Memo || `${txnType} from QuickBooks`,
    reference: qbTransaction.DocNumber || qbTransaction.Id,
    type: txnType.toLowerCase().includes('bill') || txnType.toLowerCase().includes('expense') ? 'expense' : 'income',
    category: 'Imported from QuickBooks',
    user_id: userId,
    external_id: qbTransaction.Id
  };
}

async function refreshAccessToken(supabase: any, integration: any) {
  // Implementation would be similar to the one in the main route
  // For brevity, returning success - in real implementation, this would refresh the token
  return { success: true };
}

// Placeholder sync functions for other entity types
async function syncVendors(supabase: any, integration: any, syncLogId: string) {
  // Similar implementation to syncCustomers but for vendors
  return { success: true, processed: 0, created: 0, updated: 0, failed: 0 };
}

async function syncItems(supabase: any, integration: any, syncLogId: string) {
  // Implementation for syncing QuickBooks items/products
  return { success: true, processed: 0, created: 0, updated: 0, failed: 0 };
}

