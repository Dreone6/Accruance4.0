import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// QuickBooks OAuth configuration
const QB_CONFIG = {
  clientId: process.env.QUICKBOOKS_CLIENT_ID,
  clientSecret: process.env.QUICKBOOKS_CLIENT_SECRET,
  redirectUri: process.env.QUICKBOOKS_REDIRECT_URI || `${process.env.NEXT_PUBLIC_APP_URL}/api/integrations/quickbooks/callback`,
  baseUrl: process.env.NODE_ENV === 'production' 
    ? 'https://appcenter.intuit.com/connect/oauth2'
    : 'https://appcenter.intuit.com/connect/oauth2',
  apiBaseUrl: process.env.NODE_ENV === 'production'
    ? 'https://quickbooks-api.intuit.com'
    : 'https://sandbox-quickbooks.intuit.com'
};

// GET /api/integrations/quickbooks/callback - Handle OAuth callback
export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { searchParams } = new URL(request.url);
    
    const code = searchParams.get('code');
    const realmId = searchParams.get('realmId');
    const state = searchParams.get('state');
    const error = searchParams.get('error');

    // Check for OAuth errors
    if (error) {
      console.error('OAuth error:', error);
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/integrations?error=oauth_error&message=${encodeURIComponent(error)}`
      );
    }

    if (!code || !realmId) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/integrations?error=missing_params`
      );
    }

    // Get authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/auth/signin?redirect=/integrations`
      );
    }

    // Exchange authorization code for access token
    const tokenResponse = await exchangeCodeForTokens(code, realmId);
    if (!tokenResponse.success) {
      console.error('Token exchange failed:', tokenResponse.error);
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/integrations?error=token_exchange_failed`
      );
    }

    const { access_token, refresh_token, expires_in } = tokenResponse.data;

    // Get company info from QuickBooks
    const companyInfo = await getCompanyInfo(access_token, realmId);
    
    // Store integration in database
    const { data: integration, error: dbError } = await supabase
      .from('integrations')
      .upsert({
        user_id: user.id,
        provider: 'quickbooks',
        company_id: realmId,
        access_token,
        refresh_token,
        token_expires_at: new Date(Date.now() + expires_in * 1000).toISOString(),
        scope: 'com.intuit.quickbooks.accounting',
        realm_id: realmId,
        base_url: QB_CONFIG.apiBaseUrl,
        is_active: true,
        last_sync_at: null,
        sync_frequency: 'daily'
      }, {
        onConflict: 'user_id,provider,company_id'
      })
      .select()
      .single();

    if (dbError) {
      console.error('Database error:', dbError);
      return NextResponse.redirect(
        `${process.env.NEXT_PUBLIC_APP_URL}/integrations?error=database_error`
      );
    }

    // Store company information as integration settings
    if (companyInfo.success && integration) {
      await supabase
        .from('integration_settings')
        .upsert([
          {
            integration_id: integration.id,
            setting_key: 'company_name',
            setting_value: companyInfo.data.Name,
            setting_type: 'string',
            description: 'QuickBooks company name'
          },
          {
            integration_id: integration.id,
            setting_key: 'company_info',
            setting_value: JSON.stringify(companyInfo.data),
            setting_type: 'json',
            description: 'Complete QuickBooks company information'
          }
        ], {
          onConflict: 'integration_id,setting_key'
        });
    }

    // Create default field mappings
    await createDefaultFieldMappings(supabase, integration.id);

    // Queue initial sync
    await queueInitialSync(supabase, integration.id);

    // Redirect to success page
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}/integrations?success=quickbooks_connected&company=${encodeURIComponent(companyInfo.data?.Name || 'Unknown')}`
    );

  } catch (error) {
    console.error('QuickBooks callback error:', error);
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_APP_URL}/integrations?error=callback_error`
    );
  }
}

// Helper function to exchange authorization code for tokens
async function exchangeCodeForTokens(code: string, realmId: string) {
  try {
    const response = await fetch(`${QB_CONFIG.baseUrl}/tokens/bearer`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${Buffer.from(`${QB_CONFIG.clientId}:${QB_CONFIG.clientSecret}`).toString('base64')}`
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: QB_CONFIG.redirectUri!
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Token exchange failed: ${response.status} ${errorText}`);
    }

    const data = await response.json();
    return { success: true, data };

  } catch (error) {
    console.error('Token exchange error:', error);
    return { success: false, error: error.message };
  }
}

// Helper function to get company information
async function getCompanyInfo(accessToken: string, realmId: string) {
  try {
    const response = await fetch(
      `${QB_CONFIG.apiBaseUrl}/v3/company/${realmId}/companyinfo/${realmId}`,
      {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Accept': 'application/json'
        }
      }
    );

    if (!response.ok) {
      throw new Error(`Company info fetch failed: ${response.status}`);
    }

    const data = await response.json();
    return { 
      success: true, 
      data: data.QueryResponse?.CompanyInfo?.[0] || {} 
    };

  } catch (error) {
    console.error('Company info error:', error);
    return { success: false, error: error.message };
  }
}

// Helper function to create default field mappings
async function createDefaultFieldMappings(supabase: any, integrationId: string) {
  const defaultMappings = [
    // Account mappings
    { entity_type: 'account', source_field: 'Name', target_field: 'name' },
    { entity_type: 'account', source_field: 'AccountType', target_field: 'type' },
    { entity_type: 'account', source_field: 'AccountSubType', target_field: 'subtype' },
    { entity_type: 'account', source_field: 'CurrentBalance', target_field: 'balance' },
    { entity_type: 'account', source_field: 'Active', target_field: 'is_active' },
    
    // Transaction mappings (for Journal Entries, Bills, etc.)
    { entity_type: 'transaction', source_field: 'TxnDate', target_field: 'date' },
    { entity_type: 'transaction', source_field: 'Amount', target_field: 'amount' },
    { entity_type: 'transaction', source_field: 'Description', target_field: 'description' },
    { entity_type: 'transaction', source_field: 'DocNumber', target_field: 'reference' },
    
    // Customer mappings
    { entity_type: 'customer', source_field: 'Name', target_field: 'name' },
    { entity_type: 'customer', source_field: 'CompanyName', target_field: 'company_name' },
    { entity_type: 'customer', source_field: 'PrimaryEmailAddr.Address', target_field: 'email' },
    { entity_type: 'customer', source_field: 'Active', target_field: 'is_active' },
    
    // Vendor mappings
    { entity_type: 'vendor', source_field: 'Name', target_field: 'name' },
    { entity_type: 'vendor', source_field: 'CompanyName', target_field: 'company_name' },
    { entity_type: 'vendor', source_field: 'PrimaryEmailAddr.Address', target_field: 'email' },
    { entity_type: 'vendor', source_field: 'Active', target_field: 'is_active' }
  ];

  const mappingsToInsert = defaultMappings.map(mapping => ({
    integration_id: integrationId,
    ...mapping,
    transformation_rule: { type: 'direct' },
    is_active: true
  }));

  await supabase
    .from('integration_field_mappings')
    .upsert(mappingsToInsert, {
      onConflict: 'integration_id,entity_type,source_field'
    });
}

// Helper function to queue initial sync
async function queueInitialSync(supabase: any, integrationId: string) {
  const syncEntities = [
    { entity_type: 'accounts', priority: 1 },
    { entity_type: 'customers', priority: 2 },
    { entity_type: 'vendors', priority: 3 },
    { entity_type: 'items', priority: 4 },
    { entity_type: 'transactions', priority: 5 }
  ];

  const queueItems = syncEntities.map(entity => ({
    integration_id: integrationId,
    entity_type: entity.entity_type,
    sync_type: 'full',
    priority: entity.priority,
    scheduled_at: new Date().toISOString(),
    status: 'pending'
  }));

  await supabase
    .from('integration_sync_queue')
    .insert(queueItems);
}

