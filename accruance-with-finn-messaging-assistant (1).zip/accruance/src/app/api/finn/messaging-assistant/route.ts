import { NextRequest, NextResponse } from 'next/server'
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    const { data: { user }, error: authError } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get user's subscription and usage stats
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('subscription_plan, subscription_status')
      .eq('user_id', user.id)
      .single()

    if (!profile) {
      return NextResponse.json({ error: 'User profile not found' }, { status: 404 })
    }

    // Define usage limits by plan
    const usageLimits = {
      'free': 0,
      'essentials': 50,
      'professional': 200,
      'enterprise': 1000
    }

    const currentPlan = profile.subscription_plan || 'free'
    const usageLimit = usageLimits[currentPlan as keyof typeof usageLimits] || 0

    // Get current month's usage
    const startOfMonth = new Date()
    startOfMonth.setDate(1)
    startOfMonth.setHours(0, 0, 0, 0)

    const { count: currentUsage } = await supabase
      .from('finn_messaging_usage')
      .select('*', { count: 'exact' })
      .eq('user_id', user.id)
      .gte('created_at', startOfMonth.toISOString())

    const remainingUses = Math.max(0, usageLimit - (currentUsage || 0))
    const messagingAssistantAvailable = currentPlan !== 'free' && profile.subscription_status === 'active'

    return NextResponse.json({
      messaging_assistant_available: messagingAssistantAvailable,
      current_usage: currentUsage || 0,
      usage_limit: usageLimit,
      remaining_uses: remainingUses,
      subscription_plan: currentPlan,
      subscription_status: profile.subscription_status,
      upgrade_required: !messagingAssistantAvailable || remainingUses === 0
    })

  } catch (error) {
    console.error('Error fetching FINN usage stats:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    const { data: { user }, error: authError } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { action, message_text, recipient_context, conversation_context, tone_preference } = body

    // Check user's subscription plan for FINN messaging features
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('subscription_plan, subscription_status')
      .eq('user_id', user.id)
      .single()

    const currentPlan = profile?.subscription_plan || 'free'
    
    // Block free users
    if (currentPlan === 'free') {
      return NextResponse.json({ 
        error: 'FINN Messaging Assistant requires an Essentials+ subscription',
        upgrade_required: true,
        current_plan: currentPlan,
        feature: 'messaging_assistant'
      }, { status: 403 })
    }

    // Check if subscription is active
    if (profile?.subscription_status !== 'active') {
      return NextResponse.json({ 
        error: 'Active subscription required',
        subscription_status: profile?.subscription_status,
        upgrade_required: true
      }, { status: 403 })
    }

    // Check usage limits
    const usageLimits = {
      'essentials': 50,
      'professional': 200,
      'enterprise': 1000
    }

    const usageLimit = usageLimits[currentPlan as keyof typeof usageLimits] || 0

    const startOfMonth = new Date()
    startOfMonth.setDate(1)
    startOfMonth.setHours(0, 0, 0, 0)

    const { count: currentUsage } = await supabase
      .from('finn_messaging_usage')
      .select('*', { count: 'exact' })
      .eq('user_id', user.id)
      .gte('created_at', startOfMonth.toISOString())

    if ((currentUsage || 0) >= usageLimit) {
      return NextResponse.json({ 
        error: 'Monthly usage limit reached',
        current_usage: currentUsage,
        usage_limit: usageLimit,
        upgrade_required: currentPlan !== 'enterprise',
        current_plan: currentPlan
      }, { status: 403 })
    }

    // Log usage for this request
    const usageLogData = {
      user_id: user.id,
      action_type: action,
      message_length: message_text?.length || 0,
      recipient_context: recipient_context,
      conversation_context: conversation_context,
      processing_time_ms: Date.now(), // Will be updated after processing
      tokens_used: 0, // Will be updated after API call
      success: false, // Will be updated after processing
      error_message: null
    }

    const startTime = Date.now()

    let result
    let tokensUsed = 0

    switch (action) {
      case 'analyze_message':
        result = await analyzeMessage(message_text, recipient_context, conversation_context, supabase, user.id)
        break
      
      case 'suggest_improvements':
        result = await suggestImprovements(message_text, recipient_context, tone_preference, supabase, user.id)
        break
      
      case 'rewrite_message':
        result = await rewriteMessage(message_text, recipient_context, tone_preference, supabase, user.id)
        break
      
      case 'check_tone':
        result = await checkTone(message_text, tone_preference, supabase, user.id)
        break
      
      case 'suggest_responses':
        result = await suggestResponses(message_text, recipient_context, conversation_context, supabase, user.id)
        break
      
      case 'professional_polish':
        result = await professionalPolish(message_text, recipient_context, supabase, user.id)
        break
      
      case 'grammar_check':
        result = await grammarCheck(message_text, supabase, user.id)
        break
      
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
    }

    // Log successful usage
    const processingTime = Date.now() - startTime
    await supabase
      .from('finn_messaging_usage')
      .insert({
        ...usageLogData,
        processing_time_ms: processingTime,
        tokens_used: result.tokens_used || 0,
        success: true
      })

    // Add usage info to response
    const remainingUses = Math.max(0, usageLimit - (currentUsage || 0) - 1)
    
    return NextResponse.json({
      ...result,
      usage_info: {
        current_usage: (currentUsage || 0) + 1,
        usage_limit: usageLimit,
        remaining_uses: remainingUses,
        subscription_plan: currentPlan
      }
    })

  } catch (error) {
    console.error('FINN Messaging Assistant error:', error)
    
    // Log failed usage
    await supabase
      .from('finn_messaging_usage')
      .insert({
        ...usageLogData,
        processing_time_ms: Date.now() - startTime,
        success: false,
        error_message: error.message
      })
    
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

async function analyzeMessage(messageText: string, recipientContext: any, conversationContext: any, supabase: any, userId: string) {
  const prompt = `As FINN, Accruance's AI financial advisor, analyze this business message for professional communication:

Message: "${messageText}"

Recipient Context: ${JSON.stringify(recipientContext)}
Conversation Context: ${JSON.stringify(conversationContext)}

Provide analysis on:
1. Professional tone appropriateness
2. Clarity and conciseness
3. Business communication best practices
4. Potential improvements
5. Overall effectiveness score (1-10)

Format as JSON with: tone_analysis, clarity_score, professionalism_score, suggestions, overall_score`

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: "You are FINN, a professional financial advisor AI assistant helping users craft better business messages. Provide constructive, actionable feedback."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.7,
    max_tokens: 800
  })

  const analysis = JSON.parse(completion.choices[0].message.content || '{}')
  
  return NextResponse.json({
    action: 'analyze_message',
    analysis,
    timestamp: new Date().toISOString()
  })
}

async function suggestImprovements(messageText: string, recipientContext: any, tonePreference: string) {
  const prompt = `As FINN, suggest specific improvements for this business message:

Original Message: "${messageText}"
Recipient: ${JSON.stringify(recipientContext)}
Desired Tone: ${tonePreference}

Provide 3-5 specific, actionable suggestions to improve:
- Professional tone
- Clarity and impact
- Business appropriateness
- Engagement level

Format as JSON array of suggestions with: type, description, example_before, example_after`

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: "You are FINN, helping users improve their business communication. Focus on practical, specific improvements."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.7,
    max_tokens: 1000
  })

  const suggestions = JSON.parse(completion.choices[0].message.content || '[]')
  
  return NextResponse.json({
    action: 'suggest_improvements',
    suggestions,
    original_message: messageText,
    timestamp: new Date().toISOString()
  })
}

async function rewriteMessage(messageText: string, recipientContext: any, tonePreference: string) {
  const prompt = `As FINN, rewrite this business message to be more professional and effective:

Original: "${messageText}"
Recipient: ${JSON.stringify(recipientContext)}
Tone: ${tonePreference}

Rewrite the message to be:
- More professional and polished
- Clear and concise
- Appropriate for business context
- Engaging and actionable

Provide 2-3 alternative versions with different approaches.

Format as JSON with: rewritten_versions (array), improvements_made, tone_achieved`

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: "You are FINN, a professional communication expert. Rewrite messages to be more effective while maintaining the sender's intent."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.8,
    max_tokens: 1200
  })

  const rewrite = JSON.parse(completion.choices[0].message.content || '{}')
  
  return NextResponse.json({
    action: 'rewrite_message',
    ...rewrite,
    original_message: messageText,
    timestamp: new Date().toISOString()
  })
}

async function checkTone(messageText: string, desiredTone: string) {
  const prompt = `As FINN, analyze the tone of this business message:

Message: "${messageText}"
Desired Tone: ${desiredTone}

Analyze:
1. Current tone detected
2. Tone appropriateness (1-10)
3. Alignment with desired tone
4. Specific tone adjustments needed
5. Professional communication score

Format as JSON with: current_tone, tone_score, alignment_score, adjustments_needed, professional_score`

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: "You are FINN, an expert in professional communication tone analysis. Provide detailed, actionable feedback."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.6,
    max_tokens: 600
  })

  const toneAnalysis = JSON.parse(completion.choices[0].message.content || '{}')
  
  return NextResponse.json({
    action: 'check_tone',
    tone_analysis: toneAnalysis,
    message: messageText,
    timestamp: new Date().toISOString()
  })
}

async function suggestResponses(messageText: string, recipientContext: any, conversationContext: any) {
  const prompt = `As FINN, suggest professional response options to this message:

Received Message: "${messageText}"
Sender Context: ${JSON.stringify(recipientContext)}
Conversation History: ${JSON.stringify(conversationContext)}

Suggest 3-4 different response approaches:
1. Professional and formal
2. Friendly but professional
3. Direct and action-oriented
4. Consultative and helpful

Each response should be appropriate for business communication.

Format as JSON with: response_options (array with type, tone, message, rationale)`

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: "You are FINN, helping users craft appropriate business responses. Focus on professional, contextually relevant options."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.8,
    max_tokens: 1200
  })

  const responses = JSON.parse(completion.choices[0].message.content || '{}')
  
  return NextResponse.json({
    action: 'suggest_responses',
    ...responses,
    original_message: messageText,
    timestamp: new Date().toISOString()
  })
}

async function professionalPolish(messageText: string, recipientContext: any) {
  const prompt = `As FINN, polish this message for maximum professional impact:

Message: "${messageText}"
Recipient: ${JSON.stringify(recipientContext)}

Polish for:
- Executive-level professionalism
- Clear business communication
- Appropriate formality
- Confident but respectful tone
- Action-oriented language

Provide the polished version with explanation of changes made.

Format as JSON with: polished_message, changes_made, professionalism_score_before, professionalism_score_after`

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: "You are FINN, an expert in executive-level business communication. Polish messages to the highest professional standards."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.7,
    max_tokens: 800
  })

  const polished = JSON.parse(completion.choices[0].message.content || '{}')
  
  return NextResponse.json({
    action: 'professional_polish',
    ...polished,
    original_message: messageText,
    timestamp: new Date().toISOString()
  })
}

async function grammarCheck(messageText: string) {
  const prompt = `As FINN, check this message for grammar, spelling, and writing quality:

Message: "${messageText}"

Check for:
1. Grammar errors
2. Spelling mistakes
3. Punctuation issues
4. Sentence structure
5. Word choice improvements

Provide corrections and suggestions.

Format as JSON with: errors_found, corrections, improved_version, writing_score`

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [
      {
        role: "system",
        content: "You are FINN, providing grammar and writing assistance for business communication. Be thorough but constructive."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.3,
    max_tokens: 800
  })

  const grammarCheck = JSON.parse(completion.choices[0].message.content || '{}')
  
  return NextResponse.json({
    action: 'grammar_check',
    ...grammarCheck,
    original_message: messageText,
    timestamp: new Date().toISOString()
  })
}

export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies })
    const { data: { user }, error: authError } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get user's FINN messaging assistant usage stats
    const { data: usage } = await supabase
      .from('finn_messaging_usage')
      .select('*')
      .eq('user_id', user.id)
      .gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()) // Last 30 days
      .order('created_at', { ascending: false })

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('subscription_plan, subscription_status')
      .eq('user_id', user.id)
      .single()

    // Calculate usage limits based on plan
    const planLimits = {
      free: 0,
      essentials: 50,
      professional: 200,
      enterprise: 1000
    }

    const currentUsage = usage?.length || 0
    const limit = planLimits[profile?.subscription_plan as keyof typeof planLimits] || 0

    return NextResponse.json({
      messaging_assistant_available: limit > 0,
      current_usage: currentUsage,
      usage_limit: limit,
      remaining_uses: Math.max(0, limit - currentUsage),
      subscription_plan: profile?.subscription_plan,
      recent_usage: usage?.slice(0, 10) || []
    })

  } catch (error) {
    console.error('Error fetching FINN messaging stats:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

