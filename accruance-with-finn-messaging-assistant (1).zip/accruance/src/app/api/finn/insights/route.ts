import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { FinnAssistant } from '@/lib/finn-assistant'

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const period = searchParams.get('period') || 'month'

    // Initialize FINN assistant
    const finn = new FinnAssistant()

    // Get user's financial data
    const { data: transactions } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .order('date', { ascending: false })

    const { data: invoices } = await supabase
      .from('invoices')
      .select('*')
      .eq('user_id', user.id)

    const { data: receipts } = await supabase
      .from('receipts')
      .select('*')
      .eq('user_id', user.id)

    // Generate insights
    const insights = await finn.generateInsights({
      transactions: transactions || [],
      invoices: invoices || [],
      receipts: receipts || [],
      period
    })

    return NextResponse.json({ insights })

  } catch (error) {
    console.error('FINN insights error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

