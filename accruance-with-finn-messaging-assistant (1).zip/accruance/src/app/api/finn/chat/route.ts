import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { FinnAssistant } from '@/lib/finn-assistant'

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { message, context } = body

    if (!message) {
      return NextResponse.json(
        { error: 'Message is required' }, 
        { status: 400 }
      )
    }

    // Initialize FINN assistant
    const finn = new FinnAssistant()

    // Get user's financial data for context
    const { data: transactions } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .order('date', { ascending: false })
      .limit(100)

    const { data: invoices } = await supabase
      .from('invoices')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50)

    const { data: receipts } = await supabase
      .from('receipts')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50)

    // Prepare financial context
    const financialContext = {
      transactions: transactions || [],
      invoices: invoices || [],
      receipts: receipts || [],
      userContext: context || {}
    }

    // Process the query with FINN
    const response = await finn.processQuery(message, financialContext)

    // Save conversation to database
    await supabase
      .from('finn_conversations')
      .insert({
        user_id: user.id,
        message,
        response: response.message,
        context: financialContext,
        created_at: new Date().toISOString()
      })

    return NextResponse.json({
      message: response.message,
      suggestions: response.suggestions || [],
      insights: response.insights || [],
      actions: response.actions || []
    })

  } catch (error) {
    console.error('FINN API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get conversation history
    const { data: conversations, error } = await supabase
      .from('finn_conversations')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(50)

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ conversations })

  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

