import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const formData = await request.formData()
    const file = formData.get('file') as File
    const description = formData.get('description') as string
    const amount = formData.get('amount') as string
    const date = formData.get('date') as string
    const category_id = formData.get('category_id') as string

    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf']
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        { error: 'Invalid file type. Only JPEG, PNG, WebP, and PDF files are allowed.' },
        { status: 400 }
      )
    }

    // Validate file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json(
        { error: 'File size too large. Maximum size is 10MB.' },
        { status: 400 }
      )
    }

    // Create uploads directory if it doesn't exist
    const uploadsDir = join(process.cwd(), 'public', 'uploads', 'receipts')
    try {
      await mkdir(uploadsDir, { recursive: true })
    } catch (error) {
      // Directory might already exist
    }

    // Generate unique filename
    const timestamp = Date.now()
    const extension = file.name.split('.').pop()
    const filename = `receipt_${timestamp}_${user.id}.${extension}`
    const filepath = join(uploadsDir, filename)
    const publicPath = `/uploads/receipts/${filename}`

    // Save file
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    await writeFile(filepath, buffer)

    // Save receipt record to database
    const { data: receipt, error } = await supabase
      .from('receipts')
      .insert({
        user_id: user.id,
        filename: file.name,
        file_path: publicPath,
        file_size: file.size,
        file_type: file.type,
        description: description || null,
        amount: amount ? parseFloat(amount) : null,
        date: date || null,
        category_id: category_id || null,
        status: 'uploaded',
        created_at: new Date().toISOString()
      })
      .select(`
        *,
        categories (
          id,
          name,
          color
        )
      `)
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // TODO: Process with OCR service (mock for now)
    const ocrData = {
      vendor: 'Auto-detected Vendor',
      amount: amount ? parseFloat(amount) : 0,
      date: date || new Date().toISOString().split('T')[0],
      items: [
        { description: 'Auto-detected item', amount: amount ? parseFloat(amount) : 0 }
      ]
    }

    // Update receipt with OCR data
    const { data: updatedReceipt, error: updateError } = await supabase
      .from('receipts')
      .update({
        ocr_data: ocrData,
        status: 'processed'
      })
      .eq('id', receipt.id)
      .select(`
        *,
        categories (
          id,
          name,
          color
        )
      `)
      .single()

    if (updateError) {
      console.error('Error updating receipt with OCR data:', updateError)
    }

    return NextResponse.json({ 
      receipt: updatedReceipt || receipt,
      message: 'Receipt uploaded and processed successfully'
    }, { status: 201 })

  } catch (error) {
    console.error('Receipt upload error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { data: receipts, error } = await supabase
      .from('receipts')
      .select(`
        *,
        categories (
          id,
          name,
          color
        )
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ receipts })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

