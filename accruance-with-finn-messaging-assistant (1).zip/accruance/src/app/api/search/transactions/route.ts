import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { query, filters, sort, limit = 50, offset = 0 } = body

    let searchQuery = supabase
      .from('transactions')
      .select(`
        *,
        categories (
          id,
          name,
          color
        )
      `)
      .eq('user_id', user.id)

    // Apply text search
    if (query) {
      searchQuery = searchQuery.or(`description.ilike.%${query}%,notes.ilike.%${query}%,reference_number.ilike.%${query}%`)
    }

    // Apply filters
    if (filters) {
      if (filters.category_id) {
        searchQuery = searchQuery.eq('category_id', filters.category_id)
      }
      if (filters.type) {
        searchQuery = searchQuery.eq('type', filters.type)
      }
      if (filters.date_from) {
        searchQuery = searchQuery.gte('date', filters.date_from)
      }
      if (filters.date_to) {
        searchQuery = searchQuery.lte('date', filters.date_to)
      }
      if (filters.amount_min) {
        searchQuery = searchQuery.gte('amount', filters.amount_min)
      }
      if (filters.amount_max) {
        searchQuery = searchQuery.lte('amount', filters.amount_max)
      }
      if (filters.is_reviewed !== undefined) {
        searchQuery = searchQuery.eq('is_reviewed', filters.is_reviewed)
      }
    }

    // Apply sorting
    if (sort) {
      const { field, direction } = sort
      searchQuery = searchQuery.order(field, { ascending: direction === 'asc' })
    } else {
      searchQuery = searchQuery.order('date', { ascending: false })
    }

    // Apply pagination
    searchQuery = searchQuery.range(offset, offset + limit - 1)

    const { data: transactions, error, count } = await searchQuery

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      transactions,
      total: count,
      limit,
      offset
    })

  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

