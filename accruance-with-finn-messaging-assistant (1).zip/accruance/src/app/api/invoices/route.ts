import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get user's invoices
    const { data: invoices, error } = await supabase
      .from('invoices')
      .select(`
        *,
        payments (
          id,
          amount,
          status,
          payment_method,
          created_at
        )
      `)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ invoices })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { 
      client_name,
      client_email,
      client_address,
      invoice_number,
      issue_date,
      due_date,
      items,
      notes,
      tax_rate = 0
    } = body

    // Validate required fields
    if (!client_name || !client_email || !invoice_number || !issue_date || !due_date || !items?.length) {
      return NextResponse.json(
        { error: 'Missing required fields' }, 
        { status: 400 }
      )
    }

    // Calculate totals
    const subtotal = items.reduce((sum: number, item: any) => 
      sum + (item.quantity * item.rate), 0
    )
    const tax_amount = subtotal * (tax_rate / 100)
    const total = subtotal + tax_amount

    // Create invoice
    const { data: invoice, error } = await supabase
      .from('invoices')
      .insert({
        user_id: user.id,
        client_name,
        client_email,
        client_address,
        invoice_number,
        issue_date,
        due_date,
        items,
        notes,
        subtotal,
        tax_rate,
        tax_amount,
        total,
        status: 'draft',
        created_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ invoice }, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

