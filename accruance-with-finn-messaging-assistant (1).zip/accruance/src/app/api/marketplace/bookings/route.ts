import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
})

// Feature flag check
const isMarketplaceEnabled = () => {
  return process.env.MARKETPLACE_ENABLED === 'true' && 
         process.env.MARKETPLACE_BOOKINGS_ENABLED === 'true'
}

export async function GET(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace bookings not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const userType = searchParams.get('user_type') // 'client' or 'professional'

    let query = supabase
      .from('service_bookings')
      .select(`
        *,
        service:service_id (
          id,
          title,
          service_type,
          category:category_id (name)
        ),
        client:client_id (
          id,
          full_name,
          avatar_url,
          company
        ),
        professional:professional_id (
          id,
          full_name,
          avatar_url,
          company
        )
      `)

    // Filter by user role
    if (userType === 'client') {
      query = query.eq('client_id', user.id)
    } else if (userType === 'professional') {
      query = query.eq('professional_id', user.id)
    } else {
      // Show all bookings where user is involved
      query = query.or(`client_id.eq.${user.id},professional_id.eq.${user.id}`)
    }

    if (status) {
      query = query.eq('status', status)
    }

    query = query.order('created_at', { ascending: false })

    const { data: bookings, error } = await query

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ bookings })

  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace bookings not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const {
      service_id,
      scheduled_date,
      client_notes
    } = body

    if (!service_id) {
      return NextResponse.json({ error: 'Service ID is required' }, { status: 400 })
    }

    // Get service details
    const { data: service, error: serviceError } = await supabase
      .from('services')
      .select(`
        *,
        professional:professional_id (
          id,
          full_name,
          email
        )
      `)
      .eq('id', service_id)
      .eq('is_active', true)
      .single()

    if (serviceError || !service) {
      return NextResponse.json({ error: 'Service not found' }, { status: 404 })
    }

    // Prevent self-booking
    if (service.professional_id === user.id) {
      return NextResponse.json(
        { error: 'Cannot book your own service' }, 
        { status: 400 }
      )
    }

    // Get commission rate
    const { data: commissionSetting } = await supabase
      .from('marketplace_settings')
      .select('setting_value')
      .eq('setting_key', 'commission_rate')
      .single()

    const commissionRate = parseFloat(commissionSetting?.setting_value || '0.08')
    const totalAmount = service.price
    const platformFee = totalAmount * commissionRate
    const professionalAmount = totalAmount - platformFee

    // Create payment intent with Stripe
    let paymentIntentId = null
    if (process.env.MARKETPLACE_PAYMENTS_ENABLED === 'true') {
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(totalAmount * 100), // Convert to cents
        currency: 'usd',
        metadata: {
          service_id,
          client_id: user.id,
          professional_id: service.professional_id,
          platform_fee: platformFee.toString(),
          professional_amount: professionalAmount.toString()
        }
      })
      paymentIntentId = paymentIntent.id
    }

    // Create booking
    const { data: booking, error: bookingError } = await supabase
      .from('service_bookings')
      .insert({
        service_id,
        client_id: user.id,
        professional_id: service.professional_id,
        scheduled_date: scheduled_date || null,
        total_amount: totalAmount,
        platform_fee: platformFee,
        professional_amount: professionalAmount,
        stripe_payment_intent_id: paymentIntentId,
        client_notes,
        status: 'pending',
        payment_status: paymentIntentId ? 'pending' : 'paid',
        created_at: new Date().toISOString()
      })
      .select(`
        *,
        service:service_id (
          id,
          title,
          service_type
        ),
        professional:professional_id (
          id,
          full_name,
          email
        )
      `)
      .single()

    if (bookingError) {
      return NextResponse.json({ error: bookingError.message }, { status: 500 })
    }

    // TODO: Send notification to professional
    // TODO: Send confirmation email to client

    const response: any = { booking }
    if (paymentIntentId) {
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId)
      response.client_secret = paymentIntent.client_secret
    }

    return NextResponse.json(response, { status: 201 })

  } catch (error) {
    console.error('Booking creation error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace bookings not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const {
      booking_id,
      status,
      professional_notes,
      completion_date
    } = body

    if (!booking_id || !status) {
      return NextResponse.json(
        { error: 'Booking ID and status are required' }, 
        { status: 400 }
      )
    }

    // Get existing booking
    const { data: existingBooking, error: fetchError } = await supabase
      .from('service_bookings')
      .select('*')
      .eq('id', booking_id)
      .single()

    if (fetchError || !existingBooking) {
      return NextResponse.json({ error: 'Booking not found' }, { status: 404 })
    }

    // Check permissions
    const isClient = existingBooking.client_id === user.id
    const isProfessional = existingBooking.professional_id === user.id

    if (!isClient && !isProfessional) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    // Validate status transitions
    const allowedTransitions: Record<string, string[]> = {
      'pending': ['confirmed', 'cancelled'],
      'confirmed': ['in_progress', 'cancelled'],
      'in_progress': ['completed', 'cancelled'],
      'completed': [], // No transitions from completed
      'cancelled': [], // No transitions from cancelled
      'disputed': ['resolved', 'cancelled']
    }

    if (!allowedTransitions[existingBooking.status]?.includes(status)) {
      return NextResponse.json(
        { error: `Cannot transition from ${existingBooking.status} to ${status}` }, 
        { status: 400 }
      )
    }

    // Only professionals can confirm/start work, only clients can mark as completed
    if ((status === 'confirmed' || status === 'in_progress') && !isProfessional) {
      return NextResponse.json(
        { error: 'Only professionals can confirm or start work' }, 
        { status: 403 }
      )
    }

    if (status === 'completed' && !isClient) {
      return NextResponse.json(
        { error: 'Only clients can mark work as completed' }, 
        { status: 403 }
      )
    }

    const updateData: any = {
      status,
      updated_at: new Date().toISOString()
    }

    if (professional_notes && isProfessional) {
      updateData.professional_notes = professional_notes
    }

    if (status === 'completed') {
      updateData.completion_date = completion_date || new Date().toISOString()
      // Release payment if using escrow
      if (existingBooking.payment_status === 'held') {
        updateData.payment_status = 'released'
      }
    }

    const { data: booking, error: updateError } = await supabase
      .from('service_bookings')
      .update(updateData)
      .eq('id', booking_id)
      .select(`
        *,
        service:service_id (
          id,
          title,
          service_type
        ),
        client:client_id (
          id,
          full_name,
          email
        ),
        professional:professional_id (
          id,
          full_name,
          email
        )
      `)
      .single()

    if (updateError) {
      return NextResponse.json({ error: updateError.message }, { status: 500 })
    }

    // TODO: Send status update notifications
    // TODO: Handle payment release for completed bookings

    return NextResponse.json({ booking })

  } catch (error) {
    console.error('Booking update error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

