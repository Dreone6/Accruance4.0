import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

// Feature flag check
const isMarketplaceEnabled = () => {
  return process.env.MARKETPLACE_ENABLED === 'true'
}

export async function GET(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const search = searchParams.get('search') || ''
    const minPrice = searchParams.get('min_price')
    const maxPrice = searchParams.get('max_price')
    const serviceType = searchParams.get('service_type')
    const featured = searchParams.get('featured') === 'true'
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    let query = supabase
      .from('services')
      .select(`
        *,
        professional:professional_id (
          id,
          full_name,
          avatar_url,
          company
        ),
        category:category_id (
          id,
          name,
          icon
        ),
        professional_profile:professional_marketplace_profiles!professional_id (
          average_rating,
          completion_rate,
          total_bookings,
          response_time_hours
        )
      `)
      .eq('is_active', true)

    // Apply filters
    if (category) {
      query = query.eq('category_id', category)
    }

    if (search) {
      query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%`)
    }

    if (minPrice) {
      query = query.gte('price', parseFloat(minPrice))
    }

    if (maxPrice) {
      query = query.lte('price', parseFloat(maxPrice))
    }

    if (serviceType) {
      query = query.eq('service_type', serviceType)
    }

    if (featured) {
      query = query.eq('is_featured', true)
    }

    // Apply sorting and pagination
    query = query
      .order('is_featured', { ascending: false })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)

    const { data: services, error, count } = await query

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      services,
      total: count,
      limit,
      offset
    })

  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if user is a financial professional
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('user_type')
      .eq('id', user.id)
      .single()

    if (!profile || profile.user_type !== 'financial_professional') {
      return NextResponse.json(
        { error: 'Only financial professionals can create services' }, 
        { status: 403 }
      )
    }

    const body = await request.json()
    const {
      category_id,
      title,
      description,
      service_type,
      price,
      duration_estimate,
      requirements,
      deliverables,
      tags
    } = body

    if (!title || !description || !price || !category_id) {
      return NextResponse.json(
        { error: 'Title, description, price, and category are required' }, 
        { status: 400 }
      )
    }

    // Get minimum service price from settings
    const { data: minPriceSetting } = await supabase
      .from('marketplace_settings')
      .select('setting_value')
      .eq('setting_key', 'minimum_service_price')
      .single()

    const minPrice = parseFloat(minPriceSetting?.setting_value || '50')
    if (price < minPrice) {
      return NextResponse.json(
        { error: `Service price must be at least $${minPrice}` }, 
        { status: 400 }
      )
    }

    const { data: service, error: serviceError } = await supabase
      .from('services')
      .insert({
        professional_id: user.id,
        category_id,
        title,
        description,
        service_type: service_type || 'hourly',
        price,
        duration_estimate,
        requirements,
        deliverables,
        tags,
        created_at: new Date().toISOString()
      })
      .select(`
        *,
        category:category_id (
          id,
          name,
          icon
        )
      `)
      .single()

    if (serviceError) {
      return NextResponse.json({ error: serviceError.message }, { status: 500 })
    }

    // Create or update professional marketplace profile
    await supabase
      .from('professional_marketplace_profiles')
      .upsert({
        professional_id: user.id,
        is_marketplace_active: true,
        updated_at: new Date().toISOString()
      })

    return NextResponse.json({ service }, { status: 201 })

  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

