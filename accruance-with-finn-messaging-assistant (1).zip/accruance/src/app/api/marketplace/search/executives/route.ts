import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

// Feature flag check
const isMarketplaceEnabled = () => {
  return process.env.MARKETPLACE_ENABLED === 'true'
}

export async function GET(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    
    // Search parameters
    const query = searchParams.get('q') || ''
    const executiveRole = searchParams.get('executive_role')
    const seniorityLevel = searchParams.get('seniority_level')
    const minExperience = searchParams.get('min_experience')
    const maxHourlyRate = searchParams.get('max_hourly_rate')
    const industry = searchParams.get('industry')
    const companySize = searchParams.get('company_size')
    const engagementType = searchParams.get('engagement_type')
    const remotePreference = searchParams.get('remote_preference')
    
    // Location filters
    const latitude = searchParams.get('lat')
    const longitude = searchParams.get('lng')
    const radius = parseInt(searchParams.get('radius') || '50')
    
    // Sorting
    const sortBy = searchParams.get('sort') || 'relevance'
    // Options: relevance, hourly_rate_low, hourly_rate_high, experience, distance, rating
    
    // Pagination
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    // Use the database function for location-based search
    if (latitude && longitude) {
      const { data: executives, error } = await supabase
        .rpc('search_executive_services', {
          search_lat: parseFloat(latitude),
          search_lon: parseFloat(longitude),
          radius_miles: radius,
          executive_role_filter: executiveRole,
          seniority_filter: seniorityLevel,
          min_experience: minExperience ? parseInt(minExperience) : null,
          max_hourly_rate: maxHourlyRate ? parseFloat(maxHourlyRate) : null,
          industry_filter: industry,
          company_size_filter: companySize,
          engagement_type_filter: engagementType,
          remote_preference: remotePreference,
          sort_by: sortBy,
          limit_count: limit,
          offset_count: offset
        })

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 })
      }

      return NextResponse.json({
        executives,
        pagination: {
          limit,
          offset,
          hasMore: executives.length === limit
        },
        filters: {
          location: { latitude, longitude, radius },
          executiveRole,
          seniorityLevel,
          minExperience,
          maxHourlyRate,
          industry,
          companySize,
          engagementType,
          remotePreference,
          sortBy
        }
      })
    }

    // Fallback to regular search without location
    let query_builder = supabase
      .from('executive_service_profiles')
      .select(`
        *,
        professional:professional_id (
          id,
          full_name,
          avatar_url,
          company,
          city,
          state_province,
          bio
        ),
        professional_profile:professional_marketplace_profiles!professional_id (
          average_rating,
          completion_rate,
          total_bookings,
          response_time_hours,
          is_verified
        )
      `)
      .eq('is_active', true)

    // Apply text search
    if (query) {
      query_builder = query_builder.or(`professional.full_name.ilike.%${query}%,professional.company.ilike.%${query}%`)
    }

    // Apply filters
    if (executiveRole) {
      query_builder = query_builder.eq('executive_role', executiveRole)
    }

    if (seniorityLevel) {
      query_builder = query_builder.eq('seniority_level', seniorityLevel)
    }

    if (minExperience) {
      query_builder = query_builder.gte('years_experience', parseInt(minExperience))
    }

    if (maxHourlyRate) {
      query_builder = query_builder.lte('hourly_rate', parseFloat(maxHourlyRate))
    }

    if (industry) {
      query_builder = query_builder.contains('industries', [industry])
    }

    if (companySize) {
      query_builder = query_builder.contains('company_sizes', [companySize])
    }

    if (engagementType) {
      query_builder = query_builder.contains('engagement_types', [engagementType])
    }

    if (remotePreference) {
      query_builder = query_builder.eq('remote_work_preference', remotePreference)
    }

    // Apply sorting
    switch (sortBy) {
      case 'hourly_rate_low':
        query_builder = query_builder.order('hourly_rate', { ascending: true })
        break
      case 'hourly_rate_high':
        query_builder = query_builder.order('hourly_rate', { ascending: false })
        break
      case 'experience':
        query_builder = query_builder.order('years_experience', { ascending: false })
        break
      case 'rating':
        query_builder = query_builder.order('professional_profile.average_rating', { ascending: false })
        break
      default: // relevance
        query_builder = query_builder.order('created_at', { ascending: false })
    }

    // Apply pagination
    query_builder = query_builder.range(offset, offset + limit - 1)

    const { data: executives, error, count } = await query_builder

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      executives: executives || [],
      pagination: {
        limit,
        offset,
        total: count,
        hasMore: (offset + limit) < (count || 0)
      },
      filters: {
        query,
        executiveRole,
        seniorityLevel,
        minExperience,
        maxHourlyRate,
        industry,
        companySize,
        engagementType,
        remotePreference,
        sortBy
      }
    })

  } catch (error) {
    console.error('Executive search error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const {
      executiveRole,
      seniorityLevel,
      yearsExperience,
      industries,
      companySizes,
      functionalExpertise,
      engagementTypes,
      minEngagementDuration,
      maxEngagementDuration,
      availabilityHoursPerWeek,
      travelWillingness,
      remoteWorkPreference,
      hourlyRate,
      dailyRate,
      monthlyRetainer,
      equityConsideration,
      educationBackground,
      certifications,
      notableAchievements,
      previousCompanies,
      caseStudies,
      portfolioUrl,
      linkedinUrl
    } = body

    if (!executiveRole || !yearsExperience) {
      return NextResponse.json(
        { error: 'Executive role and years of experience are required' }, 
        { status: 400 }
      )
    }

    // Create or update executive service profile
    const { data: profile, error } = await supabase
      .from('executive_service_profiles')
      .upsert({
        professional_id: user.id,
        executive_role: executiveRole,
        seniority_level: seniorityLevel,
        years_experience: yearsExperience,
        industries: industries || [],
        company_sizes: companySizes || [],
        functional_expertise: functionalExpertise || [],
        engagement_types: engagementTypes || [],
        min_engagement_duration: minEngagementDuration,
        max_engagement_duration: maxEngagementDuration,
        availability_hours_per_week: availabilityHoursPerWeek,
        travel_willingness: travelWillingness,
        remote_work_preference: remoteWorkPreference,
        hourly_rate: hourlyRate,
        daily_rate: dailyRate,
        monthly_retainer: monthlyRetainer,
        equity_consideration: equityConsideration || false,
        education_background: educationBackground,
        certifications: certifications || [],
        notable_achievements: notableAchievements || [],
        previous_companies: previousCompanies || [],
        case_studies: caseStudies || [],
        portfolio_url: portfolioUrl,
        linkedin_url: linkedinUrl,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'professional_id,executive_role'
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ profile }, { status: 201 })

  } catch (error) {
    console.error('Executive profile creation error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

