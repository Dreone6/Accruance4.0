import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

// Feature flag check
const isMarketplaceEnabled = () => {
  return process.env.MARKETPLACE_ENABLED === 'true'
}

export async function GET(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    
    // Search parameters
    const query = searchParams.get('q') || ''
    const category = searchParams.get('category')
    const subcategory = searchParams.get('subcategory')
    const condition = searchParams.get('condition')
    const listingType = searchParams.get('listing_type')
    
    // Price filters
    const minPrice = searchParams.get('min_price')
    const maxPrice = searchParams.get('max_price')
    
    // Location filters
    const latitude = searchParams.get('lat')
    const longitude = searchParams.get('lng')
    const radius = parseInt(searchParams.get('radius') || '50')
    const city = searchParams.get('city')
    const state = searchParams.get('state')
    const pickupLocation = searchParams.get('pickup_location')
    
    // Equipment specific filters
    const brand = searchParams.get('brand')
    const yearMin = searchParams.get('year_min')
    const yearMax = searchParams.get('year_max')
    const hasWarranty = searchParams.get('has_warranty') === 'true'
    
    // Sorting
    const sortBy = searchParams.get('sort') || 'relevance'
    // Options: relevance, price_low, price_high, distance, newest, condition
    
    // Pagination
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    // Use the database function for location-based search
    if (latitude && longitude) {
      const { data: equipment, error } = await supabase
        .rpc('search_equipment_with_location', {
          search_lat: parseFloat(latitude),
          search_lon: parseFloat(longitude),
          radius_miles: radius,
          category_filter: category,
          condition_filter: condition,
          min_price: minPrice ? parseFloat(minPrice) : null,
          max_price: maxPrice ? parseFloat(maxPrice) : null,
          listing_type_filter: listingType,
          sort_by: sortBy,
          limit_count: limit,
          offset_count: offset
        })

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 })
      }

      return NextResponse.json({
        equipment,
        pagination: {
          limit,
          offset,
          hasMore: equipment.length === limit
        },
        filters: {
          location: { latitude, longitude, radius },
          category,
          condition,
          listingType,
          priceRange: { min: minPrice, max: maxPrice },
          sortBy
        }
      })
    }

    // Fallback to regular search without location
    let query_builder = supabase
      .from('equipment_listings')
      .select(`
        *,
        seller:seller_id (
          id,
          full_name,
          avatar_url,
          company,
          city,
          state_province
        )
      `)
      .eq('availability', 'available')

    // Apply text search
    if (query) {
      query_builder = query_builder.or(`title.ilike.%${query}%,description.ilike.%${query}%,brand.ilike.%${query}%,model.ilike.%${query}%`)
    }

    // Apply filters
    if (category) {
      query_builder = query_builder.eq('category', category)
    }

    if (subcategory) {
      query_builder = query_builder.eq('subcategory', subcategory)
    }

    if (condition) {
      query_builder = query_builder.eq('condition', condition)
    }

    if (listingType) {
      query_builder = query_builder.eq('listing_type', listingType)
    }

    if (minPrice) {
      query_builder = query_builder.gte('price', parseFloat(minPrice))
    }

    if (maxPrice) {
      query_builder = query_builder.lte('price', parseFloat(maxPrice))
    }

    if (city) {
      query_builder = query_builder.ilike('city', `%${city}%`)
    }

    if (state) {
      query_builder = query_builder.ilike('state_province', `%${state}%`)
    }

    if (pickupLocation) {
      query_builder = query_builder.eq('pickup_location', pickupLocation)
    }

    if (brand) {
      query_builder = query_builder.ilike('brand', `%${brand}%`)
    }

    if (yearMin) {
      query_builder = query_builder.gte('year_manufactured', parseInt(yearMin))
    }

    if (yearMax) {
      query_builder = query_builder.lte('year_manufactured', parseInt(yearMax))
    }

    if (hasWarranty) {
      query_builder = query_builder.not('warranty_remaining', 'is', null)
    }

    // Apply sorting
    switch (sortBy) {
      case 'price_low':
        query_builder = query_builder.order('price', { ascending: true })
        break
      case 'price_high':
        query_builder = query_builder.order('price', { ascending: false })
        break
      case 'newest':
        query_builder = query_builder.order('created_at', { ascending: false })
        break
      case 'condition':
        // Order by condition quality: new, like_new, good, fair, poor
        query_builder = query_builder.order('condition', { ascending: true })
        break
      default: // relevance
        query_builder = query_builder
          .order('is_featured', { ascending: false })
          .order('created_at', { ascending: false })
    }

    // Apply pagination
    query_builder = query_builder.range(offset, offset + limit - 1)

    const { data: equipment, error, count } = await query_builder

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      equipment: equipment || [],
      pagination: {
        limit,
        offset,
        total: count,
        hasMore: (offset + limit) < (count || 0)
      },
      filters: {
        query,
        category,
        subcategory,
        condition,
        listingType,
        priceRange: { min: minPrice, max: maxPrice },
        location: { city, state, pickupLocation },
        brand,
        yearRange: { min: yearMin, max: yearMax },
        hasWarranty,
        sortBy
      }
    })

  } catch (error) {
    console.error('Equipment search error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

