import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

// Feature flag check
const isMarketplaceEnabled = () => {
  return process.env.MARKETPLACE_ENABLED === 'true'
}

export async function GET(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    
    // Search parameters
    const query = searchParams.get('q') || ''
    const category = searchParams.get('category')
    const subcategory = searchParams.get('subcategory')
    const serviceType = searchParams.get('service_type')
    const locationType = searchParams.get('location_type')
    
    // Price filters
    const minPrice = searchParams.get('min_price')
    const maxPrice = searchParams.get('max_price')
    
    // Location filters
    const latitude = searchParams.get('lat')
    const longitude = searchParams.get('lng')
    const radius = parseInt(searchParams.get('radius') || '50')
    const city = searchParams.get('city')
    const state = searchParams.get('state')
    const country = searchParams.get('country')
    
    // Rating filter
    const minRating = searchParams.get('min_rating')
    
    // Sorting
    const sortBy = searchParams.get('sort') || 'relevance'
    // Options: relevance, price_low, price_high, distance, rating, newest
    
    // Pagination
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')
    
    // Professional filters
    const verified = searchParams.get('verified') === 'true'
    const responseTime = searchParams.get('response_time') // hours
    
    // Use the database function for location-based search
    if (latitude && longitude) {
      const { data: services, error } = await supabase
        .rpc('search_services_with_location', {
          search_lat: parseFloat(latitude),
          search_lon: parseFloat(longitude),
          radius_miles: radius,
          category_filter: category,
          service_type_filter: serviceType,
          min_price: minPrice ? parseFloat(minPrice) : null,
          max_price: maxPrice ? parseFloat(maxPrice) : null,
          location_type: locationType,
          sort_by: sortBy,
          limit_count: limit,
          offset_count: offset
        })

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 })
      }

      return NextResponse.json({
        services,
        pagination: {
          limit,
          offset,
          hasMore: services.length === limit
        },
        filters: {
          location: { latitude, longitude, radius },
          category,
          serviceType,
          locationType,
          priceRange: { min: minPrice, max: maxPrice },
          sortBy
        }
      })
    }

    // Fallback to regular search without location
    let query_builder = supabase
      .from('services')
      .select(`
        *,
        professional:professional_id (
          id,
          full_name,
          avatar_url,
          company,
          city,
          state_province
        ),
        category:category_id (
          id,
          name,
          icon
        ),
        professional_profile:professional_marketplace_profiles!professional_id (
          average_rating,
          completion_rate,
          total_bookings,
          response_time_hours,
          is_verified
        )
      `)
      .eq('is_active', true)

    // Apply text search
    if (query) {
      query_builder = query_builder.or(`title.ilike.%${query}%,description.ilike.%${query}%`)
    }

    // Apply filters
    if (category) {
      query_builder = query_builder.eq('category_id', category)
    }

    if (serviceType) {
      query_builder = query_builder.eq('service_type', serviceType)
    }

    if (locationType) {
      query_builder = query_builder.eq('service_location', locationType)
    }

    if (minPrice) {
      query_builder = query_builder.gte('price', parseFloat(minPrice))
    }

    if (maxPrice) {
      query_builder = query_builder.lte('price', parseFloat(maxPrice))
    }

    if (city) {
      query_builder = query_builder.ilike('city', `%${city}%`)
    }

    if (state) {
      query_builder = query_builder.ilike('state_province', `%${state}%`)
    }

    // Apply sorting
    switch (sortBy) {
      case 'price_low':
        query_builder = query_builder.order('price', { ascending: true })
        break
      case 'price_high':
        query_builder = query_builder.order('price', { ascending: false })
        break
      case 'rating':
        query_builder = query_builder.order('professional_profile.average_rating', { ascending: false })
        break
      case 'newest':
        query_builder = query_builder.order('created_at', { ascending: false })
        break
      default: // relevance
        query_builder = query_builder
          .order('is_featured', { ascending: false })
          .order('created_at', { ascending: false })
    }

    // Apply pagination
    query_builder = query_builder.range(offset, offset + limit - 1)

    const { data: services, error, count } = await query_builder

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Filter by professional criteria if specified
    let filteredServices = services || []
    
    if (verified) {
      filteredServices = filteredServices.filter(service => 
        service.professional_profile?.is_verified === true
      )
    }

    if (minRating) {
      filteredServices = filteredServices.filter(service => 
        (service.professional_profile?.average_rating || 0) >= parseFloat(minRating)
      )
    }

    if (responseTime) {
      filteredServices = filteredServices.filter(service => 
        (service.professional_profile?.response_time_hours || 24) <= parseInt(responseTime)
      )
    }

    return NextResponse.json({
      services: filteredServices,
      pagination: {
        limit,
        offset,
        total: count,
        hasMore: (offset + limit) < (count || 0)
      },
      filters: {
        query,
        category,
        subcategory,
        serviceType,
        locationType,
        priceRange: { min: minPrice, max: maxPrice },
        location: { city, state, country },
        minRating,
        verified,
        responseTime,
        sortBy
      }
    })

  } catch (error) {
    console.error('Service search error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  if (!isMarketplaceEnabled()) {
    return NextResponse.json({ error: 'Marketplace not available' }, { status: 404 })
  }

  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { searchName, filters, notificationEnabled = true } = body

    if (!searchName || !filters) {
      return NextResponse.json(
        { error: 'Search name and filters are required' }, 
        { status: 400 }
      )
    }

    // Save search for future notifications
    const { data: savedSearch, error } = await supabase
      .from('marketplace_saved_searches')
      .insert({
        user_id: user.id,
        search_name: searchName,
        search_type: 'services',
        filters: filters,
        notification_enabled: notificationEnabled
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ savedSearch }, { status: 201 })

  } catch (error) {
    console.error('Save search error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

