import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// POST /api/excel/authenticate - Authenticate Excel add-in
export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = await request.json();
    const { source } = body;

    // Get the authorization header
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Missing or invalid authorization header' }, { status: 401 });
    }

    const apiKey = authHeader.substring(7); // Remove 'Bearer ' prefix

    // Validate API key format (basic validation)
    if (!apiKey || apiKey.length < 20) {
      return NextResponse.json({ error: 'Invalid API key format' }, { status: 401 });
    }

    // In a real implementation, you would validate the API key against your database
    // For now, we'll use a simplified approach that checks if it matches a pattern
    
    // Check if this is a valid Supabase JWT token or custom API key
    let user = null;
    let isValidKey = false;

    try {
      // Try to decode as Supabase JWT
      const { data: { user: jwtUser }, error } = await supabase.auth.getUser(apiKey);
      if (jwtUser && !error) {
        user = jwtUser;
        isValidKey = true;
      }
    } catch (error) {
      // Not a JWT, check if it's a custom API key
      console.log('Not a JWT token, checking custom API key');
    }

    if (!isValidKey) {
      // Check against custom API keys stored in database
      const { data: apiKeyRecord, error: keyError } = await supabase
        .from('user_api_keys')
        .select('user_id, is_active, permissions, last_used_at')
        .eq('api_key_hash', hashApiKey(apiKey))
        .eq('is_active', true)
        .single();

      if (apiKeyRecord && !keyError) {
        // Get user details
        const { data: userData, error: userError } = await supabase
          .from('profiles')
          .select('id, email, full_name')
          .eq('id', apiKeyRecord.user_id)
          .single();

        if (userData && !userError) {
          user = {
            id: userData.id,
            email: userData.email,
            user_metadata: { full_name: userData.full_name }
          };
          isValidKey = true;

          // Update last used timestamp
          await supabase
            .from('user_api_keys')
            .update({ last_used_at: new Date().toISOString() })
            .eq('api_key_hash', hashApiKey(apiKey));
        }
      }
    }

    if (!isValidKey || !user) {
      return NextResponse.json({ error: 'Invalid API key' }, { status: 401 });
    }

    // Log the authentication for audit purposes
    await logExcelActivity(supabase, user.id, 'authentication', {
      source,
      timestamp: new Date().toISOString(),
      ip: request.headers.get('x-forwarded-for') || 'unknown'
    });

    // Return success response with user info
    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.full_name || user.email
      },
      baseUrl: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
      permissions: ['read', 'write'], // In real implementation, get from API key permissions
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
    });

  } catch (error) {
    console.error('Excel authentication error:', error);
    return NextResponse.json({ error: 'Authentication failed' }, { status: 500 });
  }
}

// GET /api/excel/authenticate - Get current authentication status
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ authenticated: false }, { status: 200 });
    }

    const apiKey = authHeader.substring(7);
    
    // Quick validation without full authentication
    if (!apiKey || apiKey.length < 20) {
      return NextResponse.json({ authenticated: false }, { status: 200 });
    }

    return NextResponse.json({ 
      authenticated: true,
      message: 'API key format is valid'
    });

  } catch (error) {
    console.error('Excel auth check error:', error);
    return NextResponse.json({ authenticated: false }, { status: 200 });
  }
}

// Helper functions
function hashApiKey(apiKey: string): string {
  // In a real implementation, use a proper hashing function like bcrypt or crypto
  // This is a simplified version for demonstration
  const crypto = require('crypto');
  return crypto.createHash('sha256').update(apiKey).digest('hex');
}

async function logExcelActivity(supabase: any, userId: string, activity: string, metadata: any) {
  try {
    await supabase
      .from('excel_activity_logs')
      .insert({
        user_id: userId,
        activity,
        metadata,
        created_at: new Date().toISOString()
      });
  } catch (error) {
    console.error('Error logging Excel activity:', error);
    // Don't throw - logging failure shouldn't break authentication
  }
}

// Create API keys management functions
export async function createApiKey(supabase: any, userId: string, name: string, permissions: string[] = ['read', 'write']) {
  try {
    // Generate a secure API key
    const crypto = require('crypto');
    const apiKey = 'acc_' + crypto.randomBytes(32).toString('hex');
    const hashedKey = hashApiKey(apiKey);

    // Store in database
    const { data, error } = await supabase
      .from('user_api_keys')
      .insert({
        user_id: userId,
        name,
        api_key_hash: hashedKey,
        permissions,
        is_active: true,
        created_at: new Date().toISOString(),
        last_used_at: null
      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    return {
      success: true,
      apiKey, // Return the plain key only once
      keyId: data.id,
      name: data.name
    };

  } catch (error) {
    console.error('Error creating API key:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

