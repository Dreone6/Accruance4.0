import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// POST /api/excel/pull-data - Pull data from Accruance for Excel
export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = await request.json();
    
    const { 
      dataType, 
      dateRange, 
      preserveFormulas = true, 
      preserveFormatting = true,
      source = 'excel_addin'
    } = body;

    // Authenticate user
    const authResult = await authenticateExcelRequest(request, supabase);
    if (!authResult.success) {
      return NextResponse.json({ error: authResult.error }, { status: 401 });
    }

    const userId = authResult.user.id;

    // Log the data pull request
    await logExcelActivity(supabase, userId, 'data_pull', {
      dataType,
      dateRange,
      source,
      timestamp: new Date().toISOString()
    });

    // Fetch data based on type
    let data;
    switch (dataType) {
      case 'transactions':
        data = await fetchTransactionsData(supabase, userId, dateRange);
        break;
      case 'accounts':
        data = await fetchAccountsData(supabase, userId);
        break;
      case 'budget':
        data = await fetchBudgetData(supabase, userId, dateRange);
        break;
      case 'forecast':
        data = await fetchForecastData(supabase, userId, dateRange);
        break;
      case 'custom':
        data = await fetchCustomData(supabase, userId, body.customQuery);
        break;
      default:
        return NextResponse.json({ error: 'Invalid data type' }, { status: 400 });
    }

    if (!data.success) {
      return NextResponse.json({ error: data.error }, { status: 500 });
    }

    // Format data for Excel consumption
    const excelData = formatDataForExcel(data.data, dataType, {
      preserveFormulas,
      preserveFormatting
    });

    // Return formatted data
    return NextResponse.json({
      success: true,
      dataType,
      headers: excelData.headers,
      records: excelData.records,
      metadata: {
        totalRecords: excelData.records.length,
        dateRange,
        generatedAt: new Date().toISOString(),
        preserveFormulas,
        preserveFormatting
      },
      formatting: excelData.formatting || null
    });

  } catch (error) {
    console.error('Excel data pull error:', error);
    return NextResponse.json({ error: 'Failed to pull data' }, { status: 500 });
  }
}

// Data fetching functions
async function fetchTransactionsData(supabase: any, userId: string, dateRange: any) {
  try {
    let query = supabase
      .from('transactions')
      .select(`
        id,
        date,
        amount,
        description,
        reference,
        type,
        category,
        account_id,
        accounts!inner(name, type),
        created_at
      `)
      .eq('user_id', userId)
      .order('date', { ascending: false });

    // Apply date range filter
    const { startDate, endDate } = getDateRangeFilter(dateRange);
    if (startDate) query = query.gte('date', startDate);
    if (endDate) query = query.lte('date', endDate);

    const { data, error } = await query.limit(1000); // Limit for Excel performance

    if (error) {
      throw error;
    }

    return { success: true, data: data || [] };

  } catch (error) {
    console.error('Error fetching transactions:', error);
    return { success: false, error: error.message };
  }
}

async function fetchAccountsData(supabase: any, userId: string) {
  try {
    const { data, error } = await supabase
      .from('accounts')
      .select(`
        id,
        name,
        type,
        subtype,
        balance,
        is_active,
        created_at
      `)
      .eq('user_id', userId)
      .order('name');

    if (error) {
      throw error;
    }

    return { success: true, data: data || [] };

  } catch (error) {
    console.error('Error fetching accounts:', error);
    return { success: false, error: error.message };
  }
}

async function fetchBudgetData(supabase: any, userId: string, dateRange: any) {
  try {
    let query = supabase
      .from('budget_items')
      .select(`
        id,
        category,
        budgeted_amount,
        actual_amount,
        variance,
        period_start,
        period_end,
        created_at
      `)
      .eq('user_id', userId)
      .order('period_start', { ascending: false });

    // Apply date range filter
    const { startDate, endDate } = getDateRangeFilter(dateRange);
    if (startDate) query = query.gte('period_start', startDate);
    if (endDate) query = query.lte('period_end', endDate);

    const { data, error } = await query.limit(500);

    if (error) {
      throw error;
    }

    return { success: true, data: data || [] };

  } catch (error) {
    console.error('Error fetching budget data:', error);
    return { success: false, error: error.message };
  }
}

async function fetchForecastData(supabase: any, userId: string, dateRange: any) {
  try {
    let query = supabase
      .from('forecast_items')
      .select(`
        id,
        category,
        forecasted_amount,
        confidence_level,
        period_start,
        period_end,
        created_at
      `)
      .eq('user_id', userId)
      .order('period_start', { ascending: false });

    // Apply date range filter
    const { startDate, endDate } = getDateRangeFilter(dateRange);
    if (startDate) query = query.gte('period_start', startDate);
    if (endDate) query = query.lte('period_end', endDate);

    const { data, error } = await query.limit(500);

    if (error) {
      throw error;
    }

    return { success: true, data: data || [] };

  } catch (error) {
    console.error('Error fetching forecast data:', error);
    return { success: false, error: error.message };
  }
}

async function fetchCustomData(supabase: any, userId: string, customQuery: any) {
  try {
    // For security, only allow predefined custom queries
    const allowedQueries = {
      'monthly_summary': `
        SELECT 
          DATE_TRUNC('month', date) as month,
          SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as total_income,
          SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expenses,
          SUM(CASE WHEN type = 'income' THEN amount ELSE -amount END) as net_income
        FROM transactions 
        WHERE user_id = $1 
        GROUP BY DATE_TRUNC('month', date)
        ORDER BY month DESC
        LIMIT 12
      `,
      'category_breakdown': `
        SELECT 
          category,
          COUNT(*) as transaction_count,
          SUM(amount) as total_amount,
          AVG(amount) as average_amount
        FROM transactions 
        WHERE user_id = $1 
        GROUP BY category
        ORDER BY total_amount DESC
        LIMIT 50
      `
    };

    const queryName = customQuery.queryName;
    if (!allowedQueries[queryName]) {
      throw new Error('Invalid custom query');
    }

    const { data, error } = await supabase.rpc('execute_custom_query', {
      query_name: queryName,
      user_id: userId
    });

    if (error) {
      throw error;
    }

    return { success: true, data: data || [] };

  } catch (error) {
    console.error('Error fetching custom data:', error);
    return { success: false, error: error.message };
  }
}

// Data formatting functions
function formatDataForExcel(data: any[], dataType: string, options: any) {
  if (!data || data.length === 0) {
    return {
      headers: [],
      records: [],
      formatting: null
    };
  }

  switch (dataType) {
    case 'transactions':
      return formatTransactionsForExcel(data, options);
    case 'accounts':
      return formatAccountsForExcel(data, options);
    case 'budget':
      return formatBudgetForExcel(data, options);
    case 'forecast':
      return formatForecastForExcel(data, options);
    default:
      return formatGenericDataForExcel(data, options);
  }
}

function formatTransactionsForExcel(data: any[], options: any) {
  const headers = [
    'Date',
    'Description',
    'Reference',
    'Account',
    'Category',
    'Type',
    'Amount',
    'Running Balance'
  ];

  let runningBalance = 0;
  const records = data.map((transaction, index) => {
    runningBalance += transaction.type === 'income' ? transaction.amount : -transaction.amount;
    
    return [
      formatDateForExcel(transaction.date),
      transaction.description || '',
      transaction.reference || '',
      transaction.accounts?.name || '',
      transaction.category || '',
      transaction.type || '',
      transaction.amount || 0,
      `=SUM(G$2:G${index + 2})` // Excel formula for running balance
    ];
  });

  const formatting = options.preserveFormatting ? {
    columns: {
      0: { type: 'date', format: 'mm/dd/yyyy' },
      6: { type: 'currency', format: '$#,##0.00' },
      7: { type: 'currency', format: '$#,##0.00' }
    },
    headers: {
      bold: true,
      backgroundColor: '#f0f0f0'
    }
  } : null;

  return { headers, records, formatting };
}

function formatAccountsForExcel(data: any[], options: any) {
  const headers = [
    'Account Name',
    'Type',
    'Subtype',
    'Current Balance',
    'Status',
    'Created Date'
  ];

  const records = data.map(account => [
    account.name || '',
    account.type || '',
    account.subtype || '',
    account.balance || 0,
    account.is_active ? 'Active' : 'Inactive',
    formatDateForExcel(account.created_at)
  ]);

  const formatting = options.preserveFormatting ? {
    columns: {
      3: { type: 'currency', format: '$#,##0.00' },
      5: { type: 'date', format: 'mm/dd/yyyy' }
    },
    headers: {
      bold: true,
      backgroundColor: '#f0f0f0'
    }
  } : null;

  return { headers, records, formatting };
}

function formatBudgetForExcel(data: any[], options: any) {
  const headers = [
    'Category',
    'Budgeted Amount',
    'Actual Amount',
    'Variance',
    'Variance %',
    'Period Start',
    'Period End'
  ];

  const records = data.map(item => [
    item.category || '',
    item.budgeted_amount || 0,
    item.actual_amount || 0,
    item.variance || 0,
    item.budgeted_amount ? `=(C2-B2)/B2*100` : 0, // Excel formula for variance %
    formatDateForExcel(item.period_start),
    formatDateForExcel(item.period_end)
  ]);

  const formatting = options.preserveFormatting ? {
    columns: {
      1: { type: 'currency', format: '$#,##0.00' },
      2: { type: 'currency', format: '$#,##0.00' },
      3: { type: 'currency', format: '$#,##0.00' },
      4: { type: 'percentage', format: '0.00%' },
      5: { type: 'date', format: 'mm/dd/yyyy' },
      6: { type: 'date', format: 'mm/dd/yyyy' }
    },
    headers: {
      bold: true,
      backgroundColor: '#f0f0f0'
    }
  } : null;

  return { headers, records, formatting };
}

function formatForecastForExcel(data: any[], options: any) {
  const headers = [
    'Category',
    'Forecasted Amount',
    'Confidence Level',
    'Period Start',
    'Period End'
  ];

  const records = data.map(item => [
    item.category || '',
    item.forecasted_amount || 0,
    `${item.confidence_level || 0}%`,
    formatDateForExcel(item.period_start),
    formatDateForExcel(item.period_end)
  ]);

  const formatting = options.preserveFormatting ? {
    columns: {
      1: { type: 'currency', format: '$#,##0.00' },
      2: { type: 'percentage', format: '0%' },
      3: { type: 'date', format: 'mm/dd/yyyy' },
      4: { type: 'date', format: 'mm/dd/yyyy' }
    },
    headers: {
      bold: true,
      backgroundColor: '#f0f0f0'
    }
  } : null;

  return { headers, records, formatting };
}

function formatGenericDataForExcel(data: any[], options: any) {
  if (data.length === 0) {
    return { headers: [], records: [], formatting: null };
  }

  const headers = Object.keys(data[0]);
  const records = data.map(item => headers.map(header => item[header] || ''));

  return { headers, records, formatting: null };
}

// Helper functions
function getDateRangeFilter(dateRange: any) {
  const now = new Date();
  let startDate: string | null = null;
  let endDate: string | null = null;

  switch (dateRange.type) {
    case 'current_month':
      startDate = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().split('T')[0];
      break;
    case 'last_month':
      startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split('T')[0];
      endDate = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().split('T')[0];
      break;
    case 'current_quarter':
      const quarterStart = Math.floor(now.getMonth() / 3) * 3;
      startDate = new Date(now.getFullYear(), quarterStart, 1).toISOString().split('T')[0];
      endDate = new Date(now.getFullYear(), quarterStart + 3, 0).toISOString().split('T')[0];
      break;
    case 'current_year':
      startDate = new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0];
      endDate = new Date(now.getFullYear(), 11, 31).toISOString().split('T')[0];
      break;
    case 'custom':
      startDate = dateRange.startDate;
      endDate = dateRange.endDate;
      break;
  }

  return { startDate, endDate };
}

function formatDateForExcel(dateString: string) {
  if (!dateString) return '';
  
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US');
  } catch (error) {
    return dateString;
  }
}

async function authenticateExcelRequest(request: NextRequest, supabase: any) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return { success: false, error: 'Missing authorization header' };
  }

  const apiKey = authHeader.substring(7);
  
  // This would use the same authentication logic as the authenticate endpoint
  // For brevity, returning a simplified version
  return {
    success: true,
    user: { id: 'user-id-placeholder' } // In real implementation, validate and return actual user
  };
}

async function logExcelActivity(supabase: any, userId: string, activity: string, metadata: any) {
  try {
    await supabase
      .from('excel_activity_logs')
      .insert({
        user_id: userId,
        activity,
        metadata,
        created_at: new Date().toISOString()
      });
  } catch (error) {
    console.error('Error logging Excel activity:', error);
  }
}

