import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// POST /api/excel/push-adjustments - Push Excel changes back to Accruance
export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = await request.json();
    
    const { changes, metadata } = body;

    if (!changes || !Array.isArray(changes)) {
      return NextResponse.json({ error: 'Invalid changes data' }, { status: 400 });
    }

    // Authenticate user
    const authResult = await authenticateExcelRequest(request, supabase);
    if (!authResult.success) {
      return NextResponse.json({ error: authResult.error }, { status: 401 });
    }

    const userId = authResult.user.id;

    // Log the push request
    await logExcelActivity(supabase, userId, 'push_adjustments', {
      changeCount: changes.length,
      metadata,
      timestamp: new Date().toISOString()
    });

    // Validate changes before processing
    const validation = await validateChanges(changes, supabase, userId);
    if (!validation.valid) {
      return NextResponse.json({ 
        error: 'Validation failed', 
        details: validation.errors 
      }, { status: 400 });
    }

    // Process changes in transaction
    const result = await processChangesTransaction(supabase, userId, changes, metadata);

    if (!result.success) {
      return NextResponse.json({ 
        error: 'Failed to process changes', 
        details: result.error 
      }, { status: 500 });
    }

    // Create audit trail
    await createAuditTrail(supabase, userId, changes, result, metadata);

    return NextResponse.json({
      success: true,
      processed: result.processed,
      created: result.created,
      updated: result.updated,
      failed: result.failed,
      errors: result.errors || [],
      auditId: result.auditId
    });

  } catch (error) {
    console.error('Excel push adjustments error:', error);
    return NextResponse.json({ error: 'Failed to push adjustments' }, { status: 500 });
  }
}

// Validation functions
async function validateChanges(changes: any[], supabase: any, userId: string) {
  const errors: string[] = [];
  const warnings: string[] = [];

  for (let i = 0; i < changes.length; i++) {
    const change = changes[i];
    
    // Basic structure validation
    if (!change.row && change.row !== 0) {
      errors.push(`Change ${i}: Missing row information`);
      continue;
    }
    
    if (!change.col && change.col !== 0) {
      errors.push(`Change ${i}: Missing column information`);
      continue;
    }

    // Value validation
    if (change.newValue === null || change.newValue === undefined) {
      warnings.push(`Change ${i}: Empty value at ${change.address}`);
    }

    // Type-specific validation
    await validateChangeByType(change, supabase, userId, errors, warnings, i);
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

async function validateChangeByType(change: any, supabase: any, userId: string, errors: string[], warnings: string[], index: number) {
  // Determine the type of change based on context
  const changeType = inferChangeType(change);

  switch (changeType) {
    case 'transaction_amount':
      validateTransactionAmount(change, errors, warnings, index);
      break;
    case 'transaction_description':
      validateTransactionDescription(change, errors, warnings, index);
      break;
    case 'account_balance':
      await validateAccountBalance(change, supabase, userId, errors, warnings, index);
      break;
    case 'budget_amount':
      validateBudgetAmount(change, errors, warnings, index);
      break;
    default:
      // Generic validation for unknown types
      validateGenericChange(change, errors, warnings, index);
  }
}

function inferChangeType(change: any): string {
  // Infer the type of change based on the change context
  // This is a simplified version - in reality, you'd have more sophisticated logic
  
  if (change.metadata?.dataType === 'transactions') {
    if (change.col === 6) return 'transaction_amount'; // Amount column
    if (change.col === 1) return 'transaction_description'; // Description column
  }
  
  if (change.metadata?.dataType === 'accounts') {
    if (change.col === 3) return 'account_balance'; // Balance column
  }
  
  if (change.metadata?.dataType === 'budget') {
    if (change.col === 1 || change.col === 2) return 'budget_amount'; // Budget/Actual columns
  }

  return 'generic';
}

function validateTransactionAmount(change: any, errors: string[], warnings: string[], index: number) {
  const amount = parseFloat(change.newValue);
  
  if (isNaN(amount)) {
    errors.push(`Change ${index}: Invalid amount format at ${change.address}`);
    return;
  }
  
  if (amount < -1000000 || amount > 1000000) {
    warnings.push(`Change ${index}: Unusually large amount at ${change.address}`);
  }
  
  if (amount === 0) {
    warnings.push(`Change ${index}: Zero amount at ${change.address}`);
  }
}

function validateTransactionDescription(change: any, errors: string[], warnings: string[], index: number) {
  const description = String(change.newValue).trim();
  
  if (description.length === 0) {
    warnings.push(`Change ${index}: Empty description at ${change.address}`);
  }
  
  if (description.length > 255) {
    errors.push(`Change ${index}: Description too long at ${change.address} (max 255 characters)`);
  }
}

async function validateAccountBalance(change: any, supabase: any, userId: string, errors: string[], warnings: string[], index: number) {
  const balance = parseFloat(change.newValue);
  
  if (isNaN(balance)) {
    errors.push(`Change ${index}: Invalid balance format at ${change.address}`);
    return;
  }
  
  // Check if this would create a negative balance for asset accounts
  // This would require looking up the account type, which is simplified here
  if (balance < 0) {
    warnings.push(`Change ${index}: Negative balance at ${change.address} - verify account type`);
  }
}

function validateBudgetAmount(change: any, errors: string[], warnings: string[], index: number) {
  const amount = parseFloat(change.newValue);
  
  if (isNaN(amount)) {
    errors.push(`Change ${index}: Invalid budget amount format at ${change.address}`);
    return;
  }
  
  if (amount < 0) {
    warnings.push(`Change ${index}: Negative budget amount at ${change.address}`);
  }
}

function validateGenericChange(change: any, errors: string[], warnings: string[], index: number) {
  // Generic validation for unknown change types
  const value = change.newValue;
  
  if (typeof value === 'string' && value.length > 1000) {
    errors.push(`Change ${index}: Value too long at ${change.address}`);
  }
}

// Processing functions
async function processChangesTransaction(supabase: any, userId: string, changes: any[], metadata: any) {
  let processed = 0;
  let created = 0;
  let updated = 0;
  let failed = 0;
  const errors: string[] = [];

  try {
    // Start a transaction
    const { data: transactionResult, error: transactionError } = await supabase.rpc('process_excel_changes', {
      user_id: userId,
      changes_data: changes,
      metadata_data: metadata
    });

    if (transactionError) {
      throw transactionError;
    }

    // Process each change
    for (let i = 0; i < changes.length; i++) {
      try {
        const change = changes[i];
        const result = await processIndividualChange(supabase, userId, change, metadata);
        
        if (result.success) {
          processed++;
          if (result.action === 'create') created++;
          if (result.action === 'update') updated++;
        } else {
          failed++;
          errors.push(`Change ${i}: ${result.error}`);
        }
      } catch (error) {
        failed++;
        errors.push(`Change ${i}: ${error.message}`);
      }
    }

    return {
      success: true,
      processed,
      created,
      updated,
      failed,
      errors
    };

  } catch (error) {
    console.error('Transaction processing error:', error);
    return {
      success: false,
      error: error.message,
      processed,
      created,
      updated,
      failed,
      errors
    };
  }
}

async function processIndividualChange(supabase: any, userId: string, change: any, metadata: any) {
  try {
    const changeType = inferChangeType(change);
    
    switch (changeType) {
      case 'transaction_amount':
        return await updateTransactionAmount(supabase, userId, change);
      case 'transaction_description':
        return await updateTransactionDescription(supabase, userId, change);
      case 'account_balance':
        return await updateAccountBalance(supabase, userId, change);
      case 'budget_amount':
        return await updateBudgetAmount(supabase, userId, change);
      default:
        return await createAdjustmentEntry(supabase, userId, change, metadata);
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function updateTransactionAmount(supabase: any, userId: string, change: any) {
  // Find the transaction to update based on row position
  // This is simplified - in reality, you'd need better row-to-record mapping
  const transactionId = change.metadata?.transactionId || change.recordId;
  
  if (!transactionId) {
    return { success: false, error: 'Cannot identify transaction to update' };
  }

  const { data, error } = await supabase
    .from('transactions')
    .update({ 
      amount: parseFloat(change.newValue),
      updated_at: new Date().toISOString()
    })
    .eq('id', transactionId)
    .eq('user_id', userId)
    .select();

  if (error) {
    return { success: false, error: error.message };
  }

  return { success: true, action: 'update', data };
}

async function updateTransactionDescription(supabase: any, userId: string, change: any) {
  const transactionId = change.metadata?.transactionId || change.recordId;
  
  if (!transactionId) {
    return { success: false, error: 'Cannot identify transaction to update' };
  }

  const { data, error } = await supabase
    .from('transactions')
    .update({ 
      description: String(change.newValue).trim(),
      updated_at: new Date().toISOString()
    })
    .eq('id', transactionId)
    .eq('user_id', userId)
    .select();

  if (error) {
    return { success: false, error: error.message };
  }

  return { success: true, action: 'update', data };
}

async function updateAccountBalance(supabase: any, userId: string, change: any) {
  const accountId = change.metadata?.accountId || change.recordId;
  
  if (!accountId) {
    return { success: false, error: 'Cannot identify account to update' };
  }

  const { data, error } = await supabase
    .from('accounts')
    .update({ 
      balance: parseFloat(change.newValue),
      updated_at: new Date().toISOString()
    })
    .eq('id', accountId)
    .eq('user_id', userId)
    .select();

  if (error) {
    return { success: false, error: error.message };
  }

  return { success: true, action: 'update', data };
}

async function updateBudgetAmount(supabase: any, userId: string, change: any) {
  const budgetId = change.metadata?.budgetId || change.recordId;
  
  if (!budgetId) {
    return { success: false, error: 'Cannot identify budget item to update' };
  }

  const updateField = change.col === 1 ? 'budgeted_amount' : 'actual_amount';
  
  const { data, error } = await supabase
    .from('budget_items')
    .update({ 
      [updateField]: parseFloat(change.newValue),
      updated_at: new Date().toISOString()
    })
    .eq('id', budgetId)
    .eq('user_id', userId)
    .select();

  if (error) {
    return { success: false, error: error.message };
  }

  return { success: true, action: 'update', data };
}

async function createAdjustmentEntry(supabase: any, userId: string, change: any, metadata: any) {
  // Create a general adjustment entry for changes that don't map to specific records
  const { data, error } = await supabase
    .from('excel_adjustments')
    .insert({
      user_id: userId,
      change_type: 'excel_adjustment',
      original_value: change.oldValue,
      new_value: change.newValue,
      cell_address: change.address,
      row_index: change.row,
      col_index: change.col,
      metadata: { ...change.metadata, ...metadata },
      created_at: new Date().toISOString()
    })
    .select();

  if (error) {
    return { success: false, error: error.message };
  }

  return { success: true, action: 'create', data };
}

// Audit trail functions
async function createAuditTrail(supabase: any, userId: string, changes: any[], result: any, metadata: any) {
  try {
    const auditEntry = {
      user_id: userId,
      action: 'excel_push_adjustments',
      changes_count: changes.length,
      processed_count: result.processed,
      created_count: result.created,
      updated_count: result.updated,
      failed_count: result.failed,
      changes_data: changes,
      result_data: result,
      metadata: metadata,
      created_at: new Date().toISOString()
    };

    const { data, error } = await supabase
      .from('excel_audit_trail')
      .insert(auditEntry)
      .select();

    if (error) {
      console.error('Error creating audit trail:', error);
      return null;
    }

    return data[0]?.id;
  } catch (error) {
    console.error('Error creating audit trail:', error);
    return null;
  }
}

// Helper functions
async function authenticateExcelRequest(request: NextRequest, supabase: any) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return { success: false, error: 'Missing authorization header' };
  }

  const apiKey = authHeader.substring(7);
  
  // This would use the same authentication logic as the authenticate endpoint
  // For brevity, returning a simplified version
  return {
    success: true,
    user: { id: 'user-id-placeholder' } // In real implementation, validate and return actual user
  };
}

async function logExcelActivity(supabase: any, userId: string, activity: string, metadata: any) {
  try {
    await supabase
      .from('excel_activity_logs')
      .insert({
        user_id: userId,
        activity,
        metadata,
        created_at: new Date().toISOString()
      });
  } catch (error) {
    console.error('Error logging Excel activity:', error);
  }
}

