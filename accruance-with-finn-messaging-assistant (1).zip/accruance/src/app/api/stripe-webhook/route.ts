import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createClient } from '@/lib/supabase/server'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
})

const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET!

// Helper function to determine subscription plan from Stripe subscription
function getSubscriptionPlan(subscription: Stripe.Subscription): string {
  const priceId = subscription.items.data[0]?.price?.id
  
  if (priceId === process.env.STRIPE_ESSENTIALS_PRICE_ID) {
    return 'essentials'
  } else if (priceId === process.env.STRIPE_PROFESSIONAL_PRICE_ID) {
    return 'professional'
  } else if (priceId === process.env.STRIPE_ENTERPRISE_PRICE_ID) {
    return 'enterprise'
  }
  
  return 'free'
}

export async function POST(request: NextRequest) {
  const body = await request.text()
  const sig = request.headers.get('stripe-signature')!

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, sig, endpointSecret)
  } catch (err) {
    console.error('Webhook signature verification failed:', err)
    return NextResponse.json({ error: 'Webhook signature verification failed' }, { status: 400 })
  }

  const supabase = createClient()

  try {
    // Handle the event
    switch (event.type) {
      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object as Stripe.PaymentIntent
        
        console.log('Payment succeeded:', paymentIntent.id)
        
        // Update invoice status in database
        if (paymentIntent.metadata.invoice_id) {
          const { error: invoiceError } = await supabase
            .from('invoices')
            .update({
              status: 'paid',
              paid_at: new Date().toISOString(),
              payment_intent_id: paymentIntent.id,
              updated_at: new Date().toISOString()
            })
            .eq('id', paymentIntent.metadata.invoice_id)

          if (invoiceError) {
            console.error('Error updating invoice:', invoiceError)
          }

          // Create payment record
          const { error: paymentError } = await supabase
            .from('payments')
            .insert({
              invoice_id: paymentIntent.metadata.invoice_id,
              amount: paymentIntent.amount / 100, // Convert from cents
              currency: paymentIntent.currency,
              payment_intent_id: paymentIntent.id,
              status: 'completed',
              payment_method: 'stripe',
              stripe_customer_id: paymentIntent.customer as string,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            })

          if (paymentError) {
            console.error('Error creating payment record:', paymentError)
          }

          // Log the payment
          await supabase
            .from('audit_logs')
            .insert({
              user_id: paymentIntent.metadata.user_id,
              action: 'payment_received',
              entity_type: 'payment',
              entity_ids: [paymentIntent.id],
              details: {
                amount: paymentIntent.amount / 100,
                currency: paymentIntent.currency,
                invoice_id: paymentIntent.metadata.invoice_id
              },
              created_at: new Date().toISOString()
            })
        }
        break

      case 'payment_intent.payment_failed':
        const failedPayment = event.data.object as Stripe.PaymentIntent
        
        console.log('Payment failed:', failedPayment.id)
        
        // Update invoice status
        if (failedPayment.metadata.invoice_id) {
          const { error } = await supabase
            .from('invoices')
            .update({
              status: 'payment_failed',
              payment_intent_id: failedPayment.id,
              updated_at: new Date().toISOString()
            })
            .eq('id', failedPayment.metadata.invoice_id)

          if (error) {
            console.error('Error updating failed payment:', error)
          }

          // Log the failed payment
          await supabase
            .from('audit_logs')
            .insert({
              user_id: failedPayment.metadata.user_id,
              action: 'payment_failed',
              entity_type: 'payment',
              entity_ids: [failedPayment.id],
              details: {
                amount: failedPayment.amount / 100,
                currency: failedPayment.currency,
                invoice_id: failedPayment.metadata.invoice_id,
                failure_reason: failedPayment.last_payment_error?.message
              },
              created_at: new Date().toISOString()
            })
        }
        break

      case 'invoice.payment_succeeded':
        const invoice = event.data.object as Stripe.Invoice
        console.log('Invoice payment succeeded:', invoice.id)
        break

      case 'customer.subscription.created':
        const subscription = event.data.object as Stripe.Subscription
        console.log('Subscription created:', subscription.id)
        
        // Update user profile with subscription info
        if (subscription.customer) {
          const { data: profile } = await supabase
            .from('user_profiles')
            .select('user_id')
            .eq('stripe_customer_id', subscription.customer)
            .single()

          if (profile) {
            await supabase
              .from('user_profiles')
              .update({
                stripe_subscription_id: subscription.id,
                subscription_status: subscription.status,
                subscription_plan: getSubscriptionPlan(subscription),
                updated_at: new Date().toISOString()
              })
              .eq('user_id', profile.user_id)

            // Log subscription creation
            await supabase
              .from('audit_logs')
              .insert({
                user_id: profile.user_id,
                action: 'subscription_created',
                entity_type: 'subscription',
                entity_ids: [subscription.id],
                details: {
                  plan: getSubscriptionPlan(subscription),
                  status: subscription.status,
                  amount: subscription.items.data[0]?.price?.unit_amount
                },
                created_at: new Date().toISOString()
              })
          }
        }
        break

      case 'customer.subscription.updated':
        const updatedSubscription = event.data.object as Stripe.Subscription
        console.log('Subscription updated:', updatedSubscription.id)
        
        // Update user profile
        if (updatedSubscription.customer) {
          const { data: profile } = await supabase
            .from('user_profiles')
            .select('user_id')
            .eq('stripe_customer_id', updatedSubscription.customer)
            .single()

          if (profile) {
            await supabase
              .from('user_profiles')
              .update({
                subscription_status: updatedSubscription.status,
                subscription_plan: getSubscriptionPlan(updatedSubscription),
                updated_at: new Date().toISOString()
              })
              .eq('user_id', profile.user_id)

            // Log subscription update
            await supabase
              .from('audit_logs')
              .insert({
                user_id: profile.user_id,
                action: 'subscription_updated',
                entity_type: 'subscription',
                entity_ids: [updatedSubscription.id],
                details: {
                  plan: getSubscriptionPlan(updatedSubscription),
                  status: updatedSubscription.status,
                  cancel_at_period_end: updatedSubscription.cancel_at_period_end
                },
                created_at: new Date().toISOString()
              })
          }
        }
        break

      case 'customer.subscription.deleted':
        const deletedSubscription = event.data.object as Stripe.Subscription
        console.log('Subscription deleted:', deletedSubscription.id)
        
        // Update user profile to free plan
        if (deletedSubscription.customer) {
          const { data: profile } = await supabase
            .from('user_profiles')
            .select('user_id')
            .eq('stripe_customer_id', deletedSubscription.customer)
            .single()

          if (profile) {
            await supabase
              .from('user_profiles')
              .update({
                stripe_subscription_id: null,
                subscription_status: 'canceled',
                subscription_plan: 'free',
                updated_at: new Date().toISOString()
              })
              .eq('user_id', profile.user_id)

            // Log subscription cancellation
            await supabase
              .from('audit_logs')
              .insert({
                user_id: profile.user_id,
                action: 'subscription_canceled',
                entity_type: 'subscription',
                entity_ids: [deletedSubscription.id],
                details: {
                  previous_plan: getSubscriptionPlan(deletedSubscription),
                  canceled_at: new Date().toISOString()
                },
                created_at: new Date().toISOString()
              })
          }
        }
        break

      case 'checkout.session.completed':
        const session = event.data.object as Stripe.Checkout.Session
        console.log('Checkout session completed:', session.id)
        
        // Handle successful subscription signup
        if (session.mode === 'subscription' && session.subscription) {
          const subscription = await stripe.subscriptions.retrieve(session.subscription as string)
          
          if (session.customer && session.metadata?.user_id) {
            await supabase
              .from('user_profiles')
              .update({
                stripe_customer_id: session.customer as string,
                stripe_subscription_id: subscription.id,
                subscription_status: subscription.status,
                subscription_plan: getSubscriptionPlan(subscription),
                updated_at: new Date().toISOString()
              })
              .eq('user_id', session.metadata.user_id)
          }
        }
        break

      case 'invoice.payment_succeeded':
        const successfulInvoice = event.data.object as Stripe.Invoice
        console.log('Invoice payment succeeded:', successfulInvoice.id)
        
        // Log successful payment
        if (successfulInvoice.customer && successfulInvoice.subscription) {
          const { data: profile } = await supabase
            .from('user_profiles')
            .select('user_id')
            .eq('stripe_customer_id', successfulInvoice.customer)
            .single()

          if (profile) {
            await supabase
              .from('audit_logs')
              .insert({
                user_id: profile.user_id,
                action: 'invoice_paid',
                entity_type: 'invoice',
                entity_ids: [successfulInvoice.id],
                details: {
                  amount: successfulInvoice.amount_paid / 100,
                  currency: successfulInvoice.currency,
                  subscription_id: successfulInvoice.subscription
                },
                created_at: new Date().toISOString()
              })
          }
        }
        break

      case 'invoice.payment_failed':
        const failedInvoice = event.data.object as Stripe.Invoice
        console.log('Invoice payment failed:', failedInvoice.id)
        
        // Log failed payment and potentially update subscription status
        if (failedInvoice.customer) {
          const { data: profile } = await supabase
            .from('user_profiles')
            .select('user_id')
            .eq('stripe_customer_id', failedInvoice.customer)
            .single()

          if (profile) {
            await supabase
              .from('audit_logs')
              .insert({
                user_id: profile.user_id,
                action: 'invoice_payment_failed',
                entity_type: 'invoice',
                entity_ids: [failedInvoice.id],
                details: {
                  amount: failedInvoice.amount_due / 100,
                  currency: failedInvoice.currency,
                  attempt_count: failedInvoice.attempt_count
                },
                created_at: new Date().toISOString()
              })
          }
        }
        break

      default:
        console.log(`Unhandled event type ${event.type}`)
    }

    return NextResponse.json({ received: true })

  } catch (error) {
    console.error('Webhook processing error:', error)
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 })
  }
}

