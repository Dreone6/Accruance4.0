import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { transaction_ids, category_id, bulk_action } = body

    if (!transaction_ids || !Array.isArray(transaction_ids) || transaction_ids.length === 0) {
      return NextResponse.json(
        { error: 'Transaction IDs are required' }, 
        { status: 400 }
      )
    }

    let result
    let message

    switch (bulk_action) {
      case 'categorize':
        if (!category_id) {
          return NextResponse.json(
            { error: 'Category ID is required for categorization' }, 
            { status: 400 }
          )
        }

        const { data: categorizedTransactions, error: categorizeError } = await supabase
          .from('transactions')
          .update({ 
            category_id,
            updated_at: new Date().toISOString()
          })
          .in('id', transaction_ids)
          .eq('user_id', user.id)
          .select()

        if (categorizeError) {
          return NextResponse.json({ error: categorizeError.message }, { status: 500 })
        }

        result = categorizedTransactions
        message = `Successfully categorized ${transaction_ids.length} transactions`
        break

      case 'delete':
        const { error: deleteError } = await supabase
          .from('transactions')
          .delete()
          .in('id', transaction_ids)
          .eq('user_id', user.id)

        if (deleteError) {
          return NextResponse.json({ error: deleteError.message }, { status: 500 })
        }

        result = { deleted_count: transaction_ids.length }
        message = `Successfully deleted ${transaction_ids.length} transactions`
        break

      case 'mark_reviewed':
        const { data: reviewedTransactions, error: reviewError } = await supabase
          .from('transactions')
          .update({ 
            is_reviewed: true,
            updated_at: new Date().toISOString()
          })
          .in('id', transaction_ids)
          .eq('user_id', user.id)
          .select()

        if (reviewError) {
          return NextResponse.json({ error: reviewError.message }, { status: 500 })
        }

        result = reviewedTransactions
        message = `Successfully marked ${transaction_ids.length} transactions as reviewed`
        break

      default:
        return NextResponse.json(
          { error: 'Invalid bulk action' }, 
          { status: 400 }
        )
    }

    // Log the bulk action
    await supabase
      .from('audit_logs')
      .insert({
        user_id: user.id,
        action: `bulk_${bulk_action}`,
        entity_type: 'transaction',
        entity_ids: transaction_ids,
        details: { bulk_action, category_id },
        created_at: new Date().toISOString()
      })

    return NextResponse.json({
      success: true,
      message,
      result
    })

  } catch (error) {
    console.error('Bulk actions error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

