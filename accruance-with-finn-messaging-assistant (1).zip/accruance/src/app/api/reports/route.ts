import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// GET /api/reports - Get reports and templates
export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    switch (action) {
      case 'templates':
        return await getReportTemplates(supabase, user.id);
      case 'reports':
        return await getCustomReports(supabase, user.id);
      case 'execute':
        const reportId = searchParams.get('reportId');
        return await executeReport(supabase, user.id, reportId);
      case 'drill-through':
        const sourceField = searchParams.get('sourceField');
        const sourceValue = searchParams.get('sourceValue');
        const sourceReportId = searchParams.get('sourceReportId');
        return await getDrillThroughData(supabase, user.id, sourceReportId, sourceField, sourceValue);
      default:
        return await getReportsOverview(supabase, user.id);
    }
  } catch (error) {
    console.error('Reports API error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/reports - Create or update reports
export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = await request.json();
    const { action, ...data } = body;

    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    switch (action) {
      case 'create_template':
        return await createReportTemplate(supabase, user.id, data);
      case 'create_report':
        return await createCustomReport(supabase, user.id, data);
      case 'update_report':
        return await updateCustomReport(supabase, user.id, data);
      case 'execute_report':
        return await executeCustomReport(supabase, user.id, data);
      case 'create_drill_through':
        return await createDrillThroughConfig(supabase, user.id, data);
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (error) {
    console.error('Reports API error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Helper functions
async function getReportTemplates(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from('report_templates')
    .select('*')
    .or(`user_id.eq.${userId},is_public.eq.true`)
    .order('name');

  if (error) throw error;
  return NextResponse.json({ templates: data || [] });
}

async function getCustomReports(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from('custom_reports')
    .select(`
      *,
      report_templates(name, category)
    `)
    .eq('user_id', userId)
    .order('updated_at', { ascending: false });

  if (error) throw error;
  return NextResponse.json({ reports: data || [] });
}

async function executeReport(supabase: any, userId: string, reportId: string) {
  if (!reportId) {
    return NextResponse.json({ error: 'Report ID required' }, { status: 400 });
  }

  const { data, error } = await supabase
    .rpc('execute_custom_report', {
      report_id: reportId,
      user_id: userId,
      parameters: {}
    });

  if (error) throw error;
  return NextResponse.json({ result: data });
}

async function getDrillThroughData(supabase: any, userId: string, sourceReportId: string, sourceField: string, sourceValue: string) {
  if (!sourceReportId || !sourceField || !sourceValue) {
    return NextResponse.json({ error: 'Missing required parameters' }, { status: 400 });
  }

  // Get transactions that match the drill-through criteria
  const { data: transactions, error } = await supabase
    .from('transactions')
    .select(`
      id,
      date,
      description,
      amount,
      accounts(name, type)
    `)
    .eq('user_id', userId)
    .ilike('description', `%${sourceValue}%`)
    .order('date', { ascending: false })
    .limit(100);

  if (error) throw error;

  return NextResponse.json({
    drillThroughData: {
      type: 'transaction_list',
      sourceField,
      sourceValue,
      data: transactions || []
    }
  });
}

async function getReportsOverview(supabase: any, userId: string) {
  // Get recent reports
  const { data: recentReports } = await supabase
    .from('custom_reports')
    .select('id, name, updated_at')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false })
    .limit(5);

  // Get template count
  const { data: templateCount } = await supabase
    .from('report_templates')
    .select('count(*)')
    .or(`user_id.eq.${userId},is_public.eq.true`)
    .single();

  return NextResponse.json({
    recentReports: recentReports || [],
    templateCount: templateCount?.count || 0
  });
}

async function createReportTemplate(supabase: any, userId: string, data: any) {
  const { name, description, category, reportType, reportConfig } = data;

  if (!name || !reportType || !reportConfig) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  const { data: template, error } = await supabase
    .from('report_templates')
    .insert({
      user_id: userId,
      name,
      description,
      category: category || 'custom',
      report_type: reportType,
      report_config: reportConfig,
      is_system_template: false,
      is_public: false
    })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ template });
}

async function createCustomReport(supabase: any, userId: string, data: any) {
  const { name, description, templateId, reportConfig, dataSources, filters } = data;

  if (!name || !reportConfig || !dataSources) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  const { data: report, error } = await supabase
    .from('custom_reports')
    .insert({
      user_id: userId,
      template_id: templateId,
      name,
      description,
      report_config: reportConfig,
      data_sources: dataSources,
      filters: filters || {},
      status: 'active'
    })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ report });
}

async function updateCustomReport(supabase: any, userId: string, data: any) {
  const { reportId, ...updates } = data;

  if (!reportId) {
    return NextResponse.json({ error: 'Report ID required' }, { status: 400 });
  }

  const { data: report, error } = await supabase
    .from('custom_reports')
    .update({
      ...updates,
      updated_at: new Date().toISOString()
    })
    .eq('id', reportId)
    .eq('user_id', userId)
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ report });
}

async function executeCustomReport(supabase: any, userId: string, data: any) {
  const { reportId, parameters } = data;

  if (!reportId) {
    return NextResponse.json({ error: 'Report ID required' }, { status: 400 });
  }

  const { data: result, error } = await supabase
    .rpc('execute_custom_report', {
      report_id: reportId,
      user_id: userId,
      parameters: parameters || {}
    });

  if (error) throw error;
  return NextResponse.json({ result });
}

async function createDrillThroughConfig(supabase: any, userId: string, data: any) {
  const { name, sourceReportId, sourceField, targetType, targetConfig } = data;

  if (!name || !sourceReportId || !sourceField || !targetType || !targetConfig) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  const { data: config, error } = await supabase
    .from('drill_through_configs')
    .insert({
      user_id: userId,
      source_report_id: sourceReportId,
      name,
      source_field: sourceField,
      target_type: targetType,
      target_config: targetConfig,
      is_enabled: true
    })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ config });
}

