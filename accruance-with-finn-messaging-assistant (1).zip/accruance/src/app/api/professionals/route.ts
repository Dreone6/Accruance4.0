import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'all'
    const search = searchParams.get('search') || ''
    const specialization = searchParams.get('specialization') || ''
    const limit = parseInt(searchParams.get('limit') || '20')
    const offset = parseInt(searchParams.get('offset') || '0')

    let query = supabase
      .from('user_profiles')
      .select(`
        id,
        first_name,
        last_name,
        full_name,
        avatar_url,
        company,
        user_type,
        specializations,
        years_experience,
        services_offered,
        client_types,
        is_verified,
        rating,
        total_reviews,
        created_at
      `)
      .neq('id', user.id) // Exclude current user
      .eq('is_active', true)

    // Filter by user type
    if (type !== 'all') {
      query = query.eq('user_type', type)
    }

    // Search by name or company
    if (search) {
      query = query.or(`full_name.ilike.%${search}%,company.ilike.%${search}%`)
    }

    // Filter by specialization for professionals
    if (specialization && type === 'financial_professional') {
      query = query.contains('specializations', [specialization])
    }

    // Apply pagination
    query = query
      .order('rating', { ascending: false })
      .order('total_reviews', { ascending: false })
      .range(offset, offset + limit - 1)

    const { data: professionals, error, count } = await query

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      professionals,
      total: count,
      limit,
      offset
    })

  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { professional_id, message } = body

    if (!professional_id) {
      return NextResponse.json(
        { error: 'Professional ID is required' }, 
        { status: 400 }
      )
    }

    // Check if already following
    const { data: existingFollow } = await supabase
      .from('user_follows')
      .select('id')
      .eq('follower_id', user.id)
      .eq('following_id', professional_id)
      .single()

    if (existingFollow) {
      return NextResponse.json(
        { error: 'Already following this professional' }, 
        { status: 400 }
      )
    }

    // Create follow relationship
    const { data: follow, error: followError } = await supabase
      .from('user_follows')
      .insert({
        follower_id: user.id,
        following_id: professional_id,
        created_at: new Date().toISOString()
      })
      .select()
      .single()

    if (followError) {
      return NextResponse.json({ error: followError.message }, { status: 500 })
    }

    // Send initial message if provided
    if (message) {
      const { error: messageError } = await supabase
        .from('messages')
        .insert({
          sender_id: user.id,
          recipient_id: professional_id,
          content: message,
          message_type: 'connection_request',
          created_at: new Date().toISOString()
        })

      if (messageError) {
        console.error('Error sending connection message:', messageError)
      }
    }

    // Create notification for the professional
    await supabase
      .from('notifications')
      .insert({
        user_id: professional_id,
        title: 'New Follower',
        message: `${user.user_metadata?.full_name || 'Someone'} started following you`,
        type: 'follow',
        action_url: `/profile/${user.id}`,
        created_at: new Date().toISOString()
      })

    return NextResponse.json({ follow }, { status: 201 })

  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

