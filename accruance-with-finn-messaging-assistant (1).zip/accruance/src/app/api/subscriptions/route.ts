import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createClient } from '@/lib/supabase/server'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
})

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const action = searchParams.get('action')

    switch (action) {
      case 'subscription':
        return await getUserSubscription(supabase, user.id)
      case 'plans':
        return await getSubscriptionPlans()
      case 'usage':
        return await getUsageMetrics(supabase, user.id)
      default:
        return await getSubscriptionOverview(supabase, user.id)
    }
  } catch (error) {
    console.error('Subscription API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { action, ...data } = body

    switch (action) {
      case 'create_subscription':
        return await createSubscription(supabase, user.id, data)
      case 'update_subscription':
        return await updateSubscription(supabase, user.id, data)
      case 'cancel_subscription':
        return await cancelSubscription(supabase, user.id, data)
      case 'create_customer':
        return await createStripeCustomer(supabase, user.id, data)
      case 'create_checkout_session':
        return await createCheckoutSession(supabase, user.id, data)
      case 'create_portal_session':
        return await createPortalSession(supabase, user.id)
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
    }
  } catch (error) {
    console.error('Subscription API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

async function getUserSubscription(supabase: any, userId: string) {
  // Get user profile with subscription info
  const { data: profile, error } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('user_id', userId)
    .single()

  if (error || !profile) {
    return NextResponse.json({ error: 'User profile not found' }, { status: 404 })
  }

  let stripeSubscription = null
  if (profile.stripe_subscription_id) {
    try {
      stripeSubscription = await stripe.subscriptions.retrieve(profile.stripe_subscription_id)
    } catch (error) {
      console.error('Error fetching Stripe subscription:', error)
    }
  }

  return NextResponse.json({
    subscription: {
      status: profile.subscription_status,
      plan: profile.subscription_plan,
      stripe_subscription_id: profile.stripe_subscription_id,
      stripe_customer_id: profile.stripe_customer_id,
      current_period_start: stripeSubscription?.current_period_start,
      current_period_end: stripeSubscription?.current_period_end,
      cancel_at_period_end: stripeSubscription?.cancel_at_period_end,
      stripe_subscription: stripeSubscription
    }
  })
}

async function getSubscriptionPlans() {
  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: 0,
      interval: 'month',
      features: [
        'Basic accounting features',
        'Up to 100 transactions per month',
        'Single user access',
        'Community support'
      ],
      limits: {
        transactions: 100,
        users: 1,
        integrations: 0
      }
    },
    {
      id: 'essentials',
      name: 'Essentials',
      price: 24.99,
      interval: 'month',
      stripe_price_id: process.env.STRIPE_ESSENTIALS_PRICE_ID,
      features: [
        'Unlimited transactions',
        'Multi-user access (up to 5 users)',
        'Basic reporting',
        'Email support',
        'QuickBooks integration'
      ],
      limits: {
        transactions: -1, // unlimited
        users: 5,
        integrations: 1
      }
    },
    {
      id: 'professional',
      name: 'Professional',
      price: 49.99,
      interval: 'month',
      stripe_price_id: process.env.STRIPE_PROFESSIONAL_PRICE_ID,
      features: [
        'All Essentials features',
        'Advanced reporting and analytics',
        'Excel add-in',
        'Budgeting and forecasting',
        'Variance analysis',
        'Priority support',
        'NetSuite integration'
      ],
      limits: {
        transactions: -1,
        users: 25,
        integrations: -1
      }
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: null, // Custom pricing
      interval: 'month',
      features: [
        'All Professional features',
        'Custom integrations',
        'Advanced security features',
        'Dedicated account manager',
        'On-premise deployment options',
        'SLA guarantees'
      ],
      limits: {
        transactions: -1,
        users: -1,
        integrations: -1
      }
    }
  ]

  return NextResponse.json({ plans })
}

async function getUsageMetrics(supabase: any, userId: string) {
  // Get current month usage
  const startOfMonth = new Date()
  startOfMonth.setDate(1)
  startOfMonth.setHours(0, 0, 0, 0)

  const { data: transactionCount } = await supabase
    .from('transactions')
    .select('count(*)')
    .eq('user_id', userId)
    .gte('created_at', startOfMonth.toISOString())
    .single()

  const { data: userCount } = await supabase
    .from('user_profiles')
    .select('count(*)')
    .eq('company_id', userId) // Assuming company_id links team members
    .single()

  return NextResponse.json({
    usage: {
      transactions: transactionCount?.count || 0,
      users: userCount?.count || 1,
      period: {
        start: startOfMonth.toISOString(),
        end: new Date().toISOString()
      }
    }
  })
}

async function createSubscription(supabase: any, userId: string, data: any) {
  const { price_id, payment_method_id } = data

  // Get user profile
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('user_id', userId)
    .single()

  if (!profile) {
    return NextResponse.json({ error: 'User profile not found' }, { status: 404 })
  }

  let customerId = profile.stripe_customer_id

  // Create Stripe customer if doesn't exist
  if (!customerId) {
    const customer = await stripe.customers.create({
      email: profile.email,
      name: `${profile.first_name} ${profile.last_name}`,
      metadata: {
        user_id: userId
      }
    })
    customerId = customer.id

    // Update profile with customer ID
    await supabase
      .from('user_profiles')
      .update({ stripe_customer_id: customerId })
      .eq('user_id', userId)
  }

  // Create subscription
  const subscription = await stripe.subscriptions.create({
    customer: customerId,
    items: [{ price: price_id }],
    payment_behavior: 'default_incomplete',
    payment_settings: { save_default_payment_method: 'on_subscription' },
    expand: ['latest_invoice.payment_intent'],
  })

  // Update user profile
  await supabase
    .from('user_profiles')
    .update({
      stripe_subscription_id: subscription.id,
      subscription_status: subscription.status,
      subscription_plan: data.plan_id
    })
    .eq('user_id', userId)

  return NextResponse.json({
    subscription_id: subscription.id,
    client_secret: (subscription.latest_invoice as any)?.payment_intent?.client_secret
  })
}

async function updateSubscription(supabase: any, userId: string, data: any) {
  const { subscription_id, price_id } = data

  // Get current subscription
  const subscription = await stripe.subscriptions.retrieve(subscription_id)

  // Update subscription
  const updatedSubscription = await stripe.subscriptions.update(subscription_id, {
    items: [{
      id: subscription.items.data[0].id,
      price: price_id,
    }],
    proration_behavior: 'create_prorations',
  })

  // Update user profile
  await supabase
    .from('user_profiles')
    .update({
      subscription_status: updatedSubscription.status,
      subscription_plan: data.plan_id
    })
    .eq('user_id', userId)

  return NextResponse.json({ subscription: updatedSubscription })
}

async function cancelSubscription(supabase: any, userId: string, data: any) {
  const { subscription_id, cancel_at_period_end = true } = data

  const subscription = await stripe.subscriptions.update(subscription_id, {
    cancel_at_period_end
  })

  // Update user profile
  await supabase
    .from('user_profiles')
    .update({
      subscription_status: subscription.status
    })
    .eq('user_id', userId)

  return NextResponse.json({ subscription })
}

async function createStripeCustomer(supabase: any, userId: string, data: any) {
  const { email, name } = data

  const customer = await stripe.customers.create({
    email,
    name,
    metadata: {
      user_id: userId
    }
  })

  // Update user profile
  await supabase
    .from('user_profiles')
    .update({ stripe_customer_id: customer.id })
    .eq('user_id', userId)

  return NextResponse.json({ customer })
}

async function createCheckoutSession(supabase: any, userId: string, data: any) {
  const { price_id, success_url, cancel_url } = data

  // Get user profile
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('user_id', userId)
    .single()

  const session = await stripe.checkout.sessions.create({
    customer_email: profile.email,
    line_items: [
      {
        price: price_id,
        quantity: 1,
      },
    ],
    mode: 'subscription',
    success_url,
    cancel_url,
    metadata: {
      user_id: userId
    }
  })

  return NextResponse.json({ checkout_url: session.url })
}

async function createPortalSession(supabase: any, userId: string) {
  // Get user profile
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('user_id', userId)
    .single()

  if (!profile.stripe_customer_id) {
    return NextResponse.json({ error: 'No Stripe customer found' }, { status: 404 })
  }

  const session = await stripe.billingPortal.sessions.create({
    customer: profile.stripe_customer_id,
    return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard`,
  })

  return NextResponse.json({ portal_url: session.url })
}

async function getSubscriptionOverview(supabase: any, userId: string) {
  const subscription = await getUserSubscription(supabase, userId)
  const usage = await getUsageMetrics(supabase, userId)
  const plans = await getSubscriptionPlans()

  return NextResponse.json({
    subscription: subscription.body,
    usage: usage.body,
    plans: plans.body
  })
}

