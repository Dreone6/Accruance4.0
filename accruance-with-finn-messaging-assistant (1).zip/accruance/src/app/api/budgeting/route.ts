import { NextRequest, NextResponse } from 'next/server';
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// GET /api/budgeting - Get budget scenarios and templates
export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');

    // Get authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    switch (action) {
      case 'templates':
        return await getBudgetTemplates(supabase);
      case 'scenarios':
        return await getBudgetScenarios(supabase, user.id);
      case 'scenario':
        const scenarioId = searchParams.get('scenarioId');
        return await getBudgetScenario(supabase, user.id, scenarioId);
      case 'drivers':
        const driversScenarioId = searchParams.get('scenarioId');
        return await getBudgetDrivers(supabase, user.id, driversScenarioId);
      case 'worksheets':
        const worksheetsScenarioId = searchParams.get('scenarioId');
        return await getBudgetWorksheets(supabase, user.id, worksheetsScenarioId);
      default:
        return await getBudgetDashboard(supabase, user.id);
    }

  } catch (error) {
    console.error('Budgeting GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST /api/budgeting - Create or update budget data
export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const body = await request.json();
    const { action, ...data } = body;

    // Get authenticated user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    switch (action) {
      case 'create_scenario':
        return await createBudgetScenario(supabase, user.id, data);
      case 'update_scenario':
        return await updateBudgetScenario(supabase, user.id, data);
      case 'create_driver':
        return await createBudgetDriver(supabase, user.id, data);
      case 'update_driver':
        return await updateBudgetDriver(supabase, user.id, data);
      case 'update_driver_values':
        return await updateDriverValues(supabase, user.id, data);
      case 'calculate_budget':
        return await calculateBudget(supabase, user.id, data);
      case 'generate_forecast':
        return await generateForecast(supabase, user.id, data);
      case 'save_worksheet':
        return await saveWorksheet(supabase, user.id, data);
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }

  } catch (error) {
    console.error('Budgeting POST error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// Helper functions for GET operations
async function getBudgetTemplates(supabase: any) {
  const { data, error } = await supabase
    .from('budget_templates')
    .select('*')
    .eq('is_public', true)
    .order('name');

  if (error) {
    throw error;
  }

  return NextResponse.json({ templates: data || [] });
}

async function getBudgetScenarios(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from('budget_scenarios')
    .select(`
      *,
      budget_templates(name, description)
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    throw error;
  }

  return NextResponse.json({ scenarios: data || [] });
}

async function getBudgetScenario(supabase: any, userId: string, scenarioId: string) {
  if (!scenarioId) {
    return NextResponse.json({ error: 'Scenario ID required' }, { status: 400 });
  }

  const { data: scenario, error: scenarioError } = await supabase
    .from('budget_scenarios')
    .select(`
      *,
      budget_templates(name, description, template_data)
    `)
    .eq('id', scenarioId)
    .eq('user_id', userId)
    .single();

  if (scenarioError) {
    throw scenarioError;
  }

  // Get drivers for this scenario
  const { data: drivers, error: driversError } = await supabase
    .from('budget_drivers')
    .select(`
      *,
      budget_driver_values(*)
    `)
    .eq('scenario_id', scenarioId)
    .order('sort_order');

  if (driversError) {
    throw driversError;
  }

  // Get line items for this scenario
  const { data: lineItems, error: lineItemsError } = await supabase
    .from('budget_line_items')
    .select('*')
    .eq('scenario_id', scenarioId)
    .order('sort_order');

  if (lineItemsError) {
    throw lineItemsError;
  }

  return NextResponse.json({
    scenario,
    drivers: drivers || [],
    lineItems: lineItems || []
  });
}

async function getBudgetDrivers(supabase: any, userId: string, scenarioId: string) {
  if (!scenarioId) {
    return NextResponse.json({ error: 'Scenario ID required' }, { status: 400 });
  }

  // Verify user owns the scenario
  const { data: scenario } = await supabase
    .from('budget_scenarios')
    .select('id')
    .eq('id', scenarioId)
    .eq('user_id', userId)
    .single();

  if (!scenario) {
    return NextResponse.json({ error: 'Scenario not found' }, { status: 404 });
  }

  const { data: drivers, error } = await supabase
    .from('budget_drivers')
    .select(`
      *,
      budget_driver_values(*),
      budget_driver_relationships!parent_driver_id(*)
    `)
    .eq('scenario_id', scenarioId)
    .order('sort_order');

  if (error) {
    throw error;
  }

  return NextResponse.json({ drivers: drivers || [] });
}

async function getBudgetWorksheets(supabase: any, userId: string, scenarioId: string) {
  if (!scenarioId) {
    return NextResponse.json({ error: 'Scenario ID required' }, { status: 400 });
  }

  // Verify user owns the scenario
  const { data: scenario } = await supabase
    .from('budget_scenarios')
    .select('id')
    .eq('id', scenarioId)
    .eq('user_id', userId)
    .single();

  if (!scenario) {
    return NextResponse.json({ error: 'Scenario not found' }, { status: 404 });
  }

  const { data: worksheets, error } = await supabase
    .from('budget_worksheets')
    .select('*')
    .eq('scenario_id', scenarioId)
    .order('sort_order');

  if (error) {
    throw error;
  }

  return NextResponse.json({ worksheets: worksheets || [] });
}

async function getBudgetDashboard(supabase: any, userId: string) {
  // Get recent scenarios
  const { data: scenarios } = await supabase
    .from('budget_scenarios')
    .select('*')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false })
    .limit(5);

  // Get summary statistics
  const { data: stats } = await supabase
    .rpc('get_budget_dashboard_stats', { user_id: userId });

  return NextResponse.json({
    recentScenarios: scenarios || [],
    stats: stats || {}
  });
}

// Helper functions for POST operations
async function createBudgetScenario(supabase: any, userId: string, data: any) {
  const { name, description, scenarioType, templateId, periodStart, periodEnd, frequency } = data;

  // Validate required fields
  if (!name || !periodStart || !periodEnd) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  // Create the scenario
  const { data: scenario, error: scenarioError } = await supabase
    .from('budget_scenarios')
    .insert({
      user_id: userId,
      name,
      description,
      scenario_type: scenarioType || 'budget',
      template_id: templateId,
      period_start: periodStart,
      period_end: periodEnd,
      frequency: frequency || 'monthly',
      status: 'draft'
    })
    .select()
    .single();

  if (scenarioError) {
    throw scenarioError;
  }

  // If using a template, create default drivers
  if (templateId) {
    await createDefaultDriversFromTemplate(supabase, scenario.id, templateId);
  }

  return NextResponse.json({ scenario });
}

async function updateBudgetScenario(supabase: any, userId: string, data: any) {
  const { scenarioId, ...updates } = data;

  if (!scenarioId) {
    return NextResponse.json({ error: 'Scenario ID required' }, { status: 400 });
  }

  const { data: scenario, error } = await supabase
    .from('budget_scenarios')
    .update({
      ...updates,
      updated_at: new Date().toISOString()
    })
    .eq('id', scenarioId)
    .eq('user_id', userId)
    .select()
    .single();

  if (error) {
    throw error;
  }

  return NextResponse.json({ scenario });
}

async function createBudgetDriver(supabase: any, userId: string, data: any) {
  const { scenarioId, name, description, driverType, category, unitType, calculationMethod, formula } = data;

  if (!scenarioId || !name || !driverType) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  // Verify user owns the scenario
  const { data: scenario } = await supabase
    .from('budget_scenarios')
    .select('id')
    .eq('id', scenarioId)
    .eq('user_id', userId)
    .single();

  if (!scenario) {
    return NextResponse.json({ error: 'Scenario not found' }, { status: 404 });
  }

  const { data: driver, error } = await supabase
    .from('budget_drivers')
    .insert({
      scenario_id: scenarioId,
      name,
      description,
      driver_type: driverType,
      category,
      unit_type: unitType,
      calculation_method: calculationMethod || 'direct',
      formula,
      is_active: true
    })
    .select()
    .single();

  if (error) {
    throw error;
  }

  return NextResponse.json({ driver });
}

async function updateBudgetDriver(supabase: any, userId: string, data: any) {
  const { driverId, ...updates } = data;

  if (!driverId) {
    return NextResponse.json({ error: 'Driver ID required' }, { status: 400 });
  }

  // Verify user owns the driver through scenario
  const { data: driver } = await supabase
    .from('budget_drivers')
    .select(`
      id,
      budget_scenarios!inner(user_id)
    `)
    .eq('id', driverId)
    .single();

  if (!driver || driver.budget_scenarios.user_id !== userId) {
    return NextResponse.json({ error: 'Driver not found' }, { status: 404 });
  }

  const { data: updatedDriver, error } = await supabase
    .from('budget_drivers')
    .update({
      ...updates,
      updated_at: new Date().toISOString()
    })
    .eq('id', driverId)
    .select()
    .single();

  if (error) {
    throw error;
  }

  return NextResponse.json({ driver: updatedDriver });
}

async function updateDriverValues(supabase: any, userId: string, data: any) {
  const { driverId, values } = data;

  if (!driverId || !Array.isArray(values)) {
    return NextResponse.json({ error: 'Driver ID and values array required' }, { status: 400 });
  }

  // Verify user owns the driver
  const { data: driver } = await supabase
    .from('budget_drivers')
    .select(`
      id,
      budget_scenarios!inner(user_id)
    `)
    .eq('id', driverId)
    .single();

  if (!driver || driver.budget_scenarios.user_id !== userId) {
    return NextResponse.json({ error: 'Driver not found' }, { status: 404 });
  }

  // Upsert driver values
  const valuesToUpsert = values.map(value => ({
    driver_id: driverId,
    period_start: value.periodStart,
    period_end: value.periodEnd,
    value: value.value,
    growth_rate: value.growthRate,
    confidence_level: value.confidenceLevel || 80,
    notes: value.notes,
    is_actual: value.isActual || false,
    source: value.source || 'manual'
  }));

  const { data: updatedValues, error } = await supabase
    .from('budget_driver_values')
    .upsert(valuesToUpsert, {
      onConflict: 'driver_id,period_start,period_end,is_actual'
    })
    .select();

  if (error) {
    throw error;
  }

  return NextResponse.json({ values: updatedValues });
}

async function calculateBudget(supabase: any, userId: string, data: any) {
  const { scenarioId, periodStart, periodEnd } = data;

  if (!scenarioId) {
    return NextResponse.json({ error: 'Scenario ID required' }, { status: 400 });
  }

  // Verify user owns the scenario
  const { data: scenario } = await supabase
    .from('budget_scenarios')
    .select('id')
    .eq('id', scenarioId)
    .eq('user_id', userId)
    .single();

  if (!scenario) {
    return NextResponse.json({ error: 'Scenario not found' }, { status: 404 });
  }

  // Call the database function to calculate budget line items
  const { data: result, error } = await supabase
    .rpc('calculate_budget_line_items', {
      scenario_id: scenarioId,
      period_start: periodStart,
      period_end: periodEnd
    });

  if (error) {
    throw error;
  }

  // Get the updated line items
  const { data: lineItems } = await supabase
    .from('budget_line_items')
    .select('*')
    .eq('scenario_id', scenarioId)
    .gte('period_start', periodStart)
    .lte('period_end', periodEnd)
    .order('sort_order');

  return NextResponse.json({
    calculatedItems: result,
    lineItems: lineItems || []
  });
}

async function generateForecast(supabase: any, userId: string, data: any) {
  const { scenarioId, periodsAhead = 12 } = data;

  if (!scenarioId) {
    return NextResponse.json({ error: 'Scenario ID required' }, { status: 400 });
  }

  // Verify user owns the scenario
  const { data: scenario } = await supabase
    .from('budget_scenarios')
    .select('id')
    .eq('id', scenarioId)
    .eq('user_id', userId)
    .single();

  if (!scenario) {
    return NextResponse.json({ error: 'Scenario not found' }, { status: 404 });
  }

  // Generate rolling forecast
  const { data: forecast, error } = await supabase
    .rpc('generate_rolling_forecast', {
      scenario_id: scenarioId,
      periods_ahead: periodsAhead
    });

  if (error) {
    throw error;
  }

  return NextResponse.json({ forecast });
}

async function saveWorksheet(supabase: any, userId: string, data: any) {
  const { scenarioId, worksheetType, worksheetData, completionStatus } = data;

  if (!scenarioId || !worksheetType || !worksheetData) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  // Verify user owns the scenario
  const { data: scenario } = await supabase
    .from('budget_scenarios')
    .select('id')
    .eq('id', scenarioId)
    .eq('user_id', userId)
    .single();

  if (!scenario) {
    return NextResponse.json({ error: 'Scenario not found' }, { status: 404 });
  }

  // Upsert worksheet
  const { data: worksheet, error } = await supabase
    .from('budget_worksheets')
    .upsert({
      scenario_id: scenarioId,
      worksheet_type: worksheetType,
      name: worksheetData.name || worksheetType,
      description: worksheetData.description,
      worksheet_data: worksheetData,
      completion_status: completionStatus || 'in_progress',
      completion_percentage: calculateCompletionPercentage(worksheetData)
    }, {
      onConflict: 'scenario_id,worksheet_type'
    })
    .select()
    .single();

  if (error) {
    throw error;
  }

  return NextResponse.json({ worksheet });
}

// Helper functions
async function createDefaultDriversFromTemplate(supabase: any, scenarioId: string, templateId: string) {
  // Get template data
  const { data: template } = await supabase
    .from('budget_templates')
    .select('template_data')
    .eq('id', templateId)
    .single();

  if (!template || !template.template_data?.drivers) {
    return;
  }

  // Create drivers from template
  const drivers = template.template_data.drivers.map((driver: any, index: number) => ({
    scenario_id: scenarioId,
    name: driver.name,
    description: driver.description || '',
    driver_type: driver.type,
    category: driver.category || 'general',
    unit_type: driver.unit,
    calculation_method: 'direct',
    is_active: true,
    sort_order: index
  }));

  await supabase
    .from('budget_drivers')
    .insert(drivers);
}

function calculateCompletionPercentage(worksheetData: any): number {
  if (!worksheetData || !worksheetData.fields) {
    return 0;
  }

  const totalFields = worksheetData.fields.length;
  const completedFields = worksheetData.fields.filter((field: any) => 
    field.value !== null && field.value !== undefined && field.value !== ''
  ).length;

  return Math.round((completedFields / totalFields) * 100);
}

