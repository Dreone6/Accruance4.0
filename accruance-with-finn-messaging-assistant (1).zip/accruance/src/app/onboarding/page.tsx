'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import { DatabaseService } from '@/lib/database'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { 
  Building2, 
  Users, 
  UserPlus, 
  ArrowRight, 
  ArrowLeft,
  Check,
  CreditCard,
  FileText,
  Upload,
  Zap
} from 'lucide-react'
import type { BusinessType, AccountingMethod, UserRole } from '@/lib/supabase'

type OnboardingStep = 'choice' | 'business-info' | 'banking' | 'documents' | 'complete'

export default function OnboardingPage() {
  const { user, refreshUser } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [step, setStep] = useState<OnboardingStep>('choice')
  const [progress, setProgress] = useState(0)
  
  // Organization creation form
  const [orgData, setOrgData] = useState({
    name: '',
    businessType: 'llc' as BusinessType,
    accountingMethod: 'accrual' as AccountingMethod,
    industry: 'general',
    monthlyRevenue: '',
    fiscalYearEnd: '',
    taxId: '',
    address: '',
    phone: '',
    website: '',
  })

  // Banking setup
  const [bankingSetup, setBankingSetup] = useState({
    connected: false,
    accountName: '',
    bankName: '',
  })

  // Documents upload
  const [documentsUploaded, setDocumentsUploaded] = useState({
    businessLicense: false,
    taxDocuments: false,
    bankStatements: false,
  })

  // Join organization form
  const [inviteCode, setInviteCode] = useState('')

  useEffect(() => {
    if (!user) {
      router.push('/auth/signin')
    }
  }, [user, router])

  useEffect(() => {
    // Update progress based on current step
    const stepProgress = {
      'choice': 0,
      'business-info': 25,
      'banking': 50,
      'documents': 75,
      'complete': 100
    }
    setProgress(stepProgress[step])
  }, [step])

  const handleCreateOrganization = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      // Create organization
      const organization = await DatabaseService.createOrganization({
        name: orgData.name,
        business_type: orgData.businessType,
        accounting_method: orgData.accountingMethod,
        industry: orgData.industry,
        monthly_revenue: orgData.monthlyRevenue ? parseFloat(orgData.monthlyRevenue) : undefined,
        fiscal_year_end: orgData.fiscalYearEnd || undefined,
        tax_id: orgData.taxId || undefined,
      })

      if (!organization) {
        throw new Error('Failed to create organization')
      }

      // Create user profile as owner
      const userProfile = await DatabaseService.createUser({
        id: user!.id,
        organization_id: organization.id,
        role: 'owner' as UserRole,
        first_name: user!.user_metadata?.first_name || '',
        last_name: user!.user_metadata?.last_name || '',
        email: user!.email!,
        onboarding_completed: false, // Will be set to true after complete onboarding
      })

      if (!userProfile) {
        throw new Error('Failed to create user profile')
      }

      // Create default chart of accounts
      await DatabaseService.createDefaultChartOfAccounts(
        organization.id,
        orgData.businessType,
        orgData.industry
      )

      // Move to banking setup
      setStep('banking')
    } catch (error) {
      console.error('Error creating organization:', error)
      setError('Failed to create organization. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleJoinOrganization = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      // TODO: Implement invite code validation and organization joining
      // For now, show error
      setError('Organization invites will be available soon. Please create a new organization.')
    } catch (error) {
      setError('Failed to join organization. Please check your invite code.')
    } finally {
      setLoading(false)
    }
  }

  const handleBankingSetup = () => {
    // Simulate banking connection
    setBankingSetup({
      connected: true,
      accountName: 'Business Checking',
      bankName: 'Chase Bank'
    })
    setStep('documents')
  }

  const handleSkipBanking = () => {
    setStep('documents')
  }

  const handleDocumentUpload = (docType: keyof typeof documentsUploaded) => {
    setDocumentsUploaded(prev => ({
      ...prev,
      [docType]: true
    }))
  }

  const handleCompleteOnboarding = async () => {
    setLoading(true)
    try {
      // Update user profile to mark onboarding as completed
      await DatabaseService.updateUser(user!.id, {
        onboarding_completed: true
      })

      // Refresh user data and redirect
      await refreshUser()
      setStep('complete')
      
      // Redirect to dashboard after a short delay
      setTimeout(() => {
        router.push('/dashboard')
      }, 2000)
    } catch (error) {
      console.error('Error completing onboarding:', error)
      setError('Failed to complete onboarding. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">A</span>
            </div>
            <span className="text-2xl font-bold text-gray-900">Accruance</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to Accruance!</h1>
          <p className="text-gray-600 mb-6">Let's get your financial dashboard set up in under 5 minutes</p>
          
          {step !== 'choice' && step !== 'complete' && (
            <div className="max-w-md mx-auto">
              <Progress value={progress} className="mb-2" />
              <p className="text-sm text-gray-500">Step {
                step === 'business-info' ? '1' : 
                step === 'banking' ? '2' : 
                step === 'documents' ? '3' : '4'
              } of 4</p>
            </div>
          )}
        </div>

        {step === 'choice' && (
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => setStep('business-info')}>
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Building2 className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle>Create Organization</CardTitle>
                <CardDescription>
                  Set up a new organization and become the owner
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Full administrative control
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Invite team members
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Customize settings
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Manage billing
                  </li>
                </ul>
                <Button className="w-full mt-4">
                  Create Organization
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:shadow-lg transition-shadow opacity-75">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <UserPlus className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle>Join Organization</CardTitle>
                <CardDescription>
                  Join an existing organization with an invite code
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Access shared data
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Collaborate with team
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Role-based permissions
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Quick setup
                  </li>
                </ul>
                <Button variant="outline" className="w-full mt-4" disabled>
                  Coming Soon
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {step === 'business-info' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building2 className="w-5 h-5 mr-2" />
                Business Information
              </CardTitle>
              <CardDescription>
                Tell us about your business to set up your financial dashboard
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateOrganization} className="space-y-6">
                {error && (
                  <div className="p-3 text-sm text-red-600 bg-red-50 border border-red-200 rounded-md">
                    {error}
                  </div>
                )}

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="orgName">Business Name *</Label>
                      <Input
                        id="orgName"
                        placeholder="Acme Corp"
                        value={orgData.name}
                        onChange={(e) => setOrgData(prev => ({ ...prev, name: e.target.value }))}
                        required
                        disabled={loading}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="businessType">Business Type *</Label>
                      <select
                        id="businessType"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        value={orgData.businessType}
                        onChange={(e) => setOrgData(prev => ({ ...prev, businessType: e.target.value as BusinessType }))}
                        required
                        disabled={loading}
                      >
                        <option value="sole_prop">Sole Proprietorship</option>
                        <option value="llc">LLC</option>
                        <option value="corp">Corporation</option>
                        <option value="s_corp">S Corporation</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="industry">Industry</Label>
                      <select
                        id="industry"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        value={orgData.industry}
                        onChange={(e) => setOrgData(prev => ({ ...prev, industry: e.target.value }))}
                        disabled={loading}
                      >
                        <option value="general">General Business</option>
                        <option value="retail">Retail</option>
                        <option value="restaurant">Restaurant</option>
                        <option value="consulting">Consulting</option>
                        <option value="ecommerce">E-commerce</option>
                        <option value="technology">Technology</option>
                        <option value="healthcare">Healthcare</option>
                        <option value="real_estate">Real Estate</option>
                        <option value="manufacturing">Manufacturing</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="accountingMethod">Accounting Method *</Label>
                      <select
                        id="accountingMethod"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                        value={orgData.accountingMethod}
                        onChange={(e) => setOrgData(prev => ({ ...prev, accountingMethod: e.target.value as AccountingMethod }))}
                        required
                        disabled={loading}
                      >
                        <option value="accrual">Accrual</option>
                        <option value="cash">Cash</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="monthlyRevenue">Monthly Revenue (Optional)</Label>
                      <Input
                        id="monthlyRevenue"
                        type="number"
                        placeholder="50000"
                        value={orgData.monthlyRevenue}
                        onChange={(e) => setOrgData(prev => ({ ...prev, monthlyRevenue: e.target.value }))}
                        disabled={loading}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="fiscalYearEnd">Fiscal Year End (Optional)</Label>
                      <Input
                        id="fiscalYearEnd"
                        type="date"
                        value={orgData.fiscalYearEnd}
                        onChange={(e) => setOrgData(prev => ({ ...prev, fiscalYearEnd: e.target.value }))}
                        disabled={loading}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="taxId">Tax ID / EIN (Optional)</Label>
                      <Input
                        id="taxId"
                        placeholder="12-3456789"
                        value={orgData.taxId}
                        onChange={(e) => setOrgData(prev => ({ ...prev, taxId: e.target.value }))}
                        disabled={loading}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number (Optional)</Label>
                      <Input
                        id="phone"
                        placeholder="(555) 123-4567"
                        value={orgData.phone}
                        onChange={(e) => setOrgData(prev => ({ ...prev, phone: e.target.value }))}
                        disabled={loading}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setStep('choice')}
                    disabled={loading}
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button type="submit" className="flex-1" disabled={loading}>
                    {loading ? 'Creating...' : 'Continue to Banking'}
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {step === 'banking' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="w-5 h-5 mr-2" />
                Connect Your Bank Account
              </CardTitle>
              <CardDescription>
                Connect your business bank account for automatic transaction import
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {!bankingSetup.connected ? (
                <>
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <CreditCard className="w-8 h-8 text-blue-600" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Secure Bank Connection</h3>
                    <p className="text-gray-600 mb-6 max-w-md mx-auto">
                      We use bank-level security to connect your account. Your login credentials are never stored.
                    </p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                      {['Chase', 'Bank of America', 'Wells Fargo', 'Citibank'].map((bank) => (
                        <div key={bank} className="p-3 border rounded-lg text-center">
                          <div className="w-8 h-8 bg-gray-200 rounded mx-auto mb-2"></div>
                          <p className="text-xs text-gray-600">{bank}</p>
                        </div>
                      ))}
                    </div>
                    
                    <p className="text-xs text-gray-500 mb-6">
                      + 12,000 other financial institutions
                    </p>
                  </div>

                  <div className="flex gap-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setStep('business-info')}
                      disabled={loading}
                    >
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Back
                    </Button>
                    <Button 
                      onClick={handleBankingSetup}
                      className="flex-1"
                      disabled={loading}
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      Connect Bank Account
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleSkipBanking}
                      disabled={loading}
                    >
                      Skip for Now
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Check className="w-8 h-8 text-green-600" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">Bank Account Connected!</h3>
                    <p className="text-gray-600 mb-4">
                      Successfully connected {bankingSetup.accountName} at {bankingSetup.bankName}
                    </p>
                    <Badge variant="success">Connected</Badge>
                  </div>

                  <div className="flex gap-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setBankingSetup({ connected: false, accountName: '', bankName: '' })}
                      disabled={loading}
                    >
                      Change Account
                    </Button>
                    <Button 
                      onClick={() => setStep('documents')}
                      className="flex-1"
                      disabled={loading}
                    >
                      Continue to Documents
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        )}

        {step === 'documents' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2" />
                Upload Documents (Optional)
              </CardTitle>
              <CardDescription>
                Upload key business documents to get the most out of Accruance
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-3 gap-4">
                <div className="border rounded-lg p-4 text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <FileText className="w-6 h-6 text-blue-600" />
                  </div>
                  <h4 className="font-medium mb-2">Business License</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Upload your business registration or license
                  </p>
                  {documentsUploaded.businessLicense ? (
                    <Badge variant="success">Uploaded</Badge>
                  ) : (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDocumentUpload('businessLicense')}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload
                    </Button>
                  )}
                </div>

                <div className="border rounded-lg p-4 text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <FileText className="w-6 h-6 text-green-600" />
                  </div>
                  <h4 className="font-medium mb-2">Tax Documents</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Previous year's tax returns or forms
                  </p>
                  {documentsUploaded.taxDocuments ? (
                    <Badge variant="success">Uploaded</Badge>
                  ) : (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDocumentUpload('taxDocuments')}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload
                    </Button>
                  )}
                </div>

                <div className="border rounded-lg p-4 text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <CreditCard className="w-6 h-6 text-purple-600" />
                  </div>
                  <h4 className="font-medium mb-2">Bank Statements</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    Recent bank statements for reconciliation
                  </p>
                  {documentsUploaded.bankStatements ? (
                    <Badge variant="success">Uploaded</Badge>
                  ) : (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDocumentUpload('bankStatements')}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload
                    </Button>
                  )}
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start">
                  <div className="w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center mr-3 mt-0.5">
                    <span className="text-white text-xs font-bold">i</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-blue-900 mb-1">Why upload documents?</h4>
                    <p className="text-sm text-blue-700">
                      Uploading these documents helps FINN, your AI CFO, provide better insights and 
                      ensures accurate categorization of your transactions from day one.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep('banking')}
                  disabled={loading}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                <Button 
                  onClick={handleCompleteOnboarding}
                  className="flex-1"
                  disabled={loading}
                >
                  {loading ? 'Completing Setup...' : 'Complete Setup'}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 'complete' && (
          <Card>
            <CardHeader className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-10 h-10 text-green-600" />
              </div>
              <CardTitle className="text-2xl">Welcome to Accruance!</CardTitle>
              <CardDescription className="text-lg">
                Your financial dashboard is ready. Let's start managing your finances smarter.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="p-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <Building2 className="w-6 h-6 text-blue-600" />
                  </div>
                  <h4 className="font-medium">Organization Created</h4>
                  <p className="text-sm text-gray-600">{orgData.name}</p>
                </div>
                <div className="p-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <FileText className="w-6 h-6 text-green-600" />
                  </div>
                  <h4 className="font-medium">Chart of Accounts</h4>
                  <p className="text-sm text-gray-600">Auto-generated for {orgData.industry}</p>
                </div>
                <div className="p-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <Zap className="w-6 h-6 text-purple-600" />
                  </div>
                  <h4 className="font-medium">FINN AI Ready</h4>
                  <p className="text-sm text-gray-600">Your AI CFO is ready to help</p>
                </div>
              </div>
              
              <p className="text-gray-600 mb-4">
                Redirecting to your dashboard...
              </p>
              
              <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

