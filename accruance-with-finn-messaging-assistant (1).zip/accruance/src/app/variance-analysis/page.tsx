'use client'

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TrendingUp, 
  TrendingDown,
  Target, 
  AlertTriangle,
  CheckCircle,
  ArrowUp,
  ArrowDown,
  DollarSign,
  RefreshCw
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';

interface VariancePeriod {
  id: string;
  name: string;
  period_start: string;
  period_end: string;
  is_current_period: boolean;
}

interface VarianceItem {
  id: string;
  line_item_name: string;
  line_item_type: string;
  actual_amount: number;
  budget_amount: number;
  budget_variance: number;
  budget_variance_percentage: number;
  is_favorable: boolean;
  significance_level: string;
}

export default function VarianceAnalysisPage() {
  const [periods, setPeriods] = useState<VariancePeriod[]>([]);
  const [selectedPeriod, setSelectedPeriod] = useState<VariancePeriod | null>(null);
  const [varianceItems, setVarianceItems] = useState<VarianceItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/variance-analysis?action=periods');
      if (response.ok) {
        const data = await response.json();
        setPeriods(data.periods);
        const currentPeriod = data.periods.find((p: VariancePeriod) => p.is_current_period);
        if (currentPeriod) {
          setSelectedPeriod(currentPeriod);
          await loadPeriodData(currentPeriod.id);
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadPeriodData = async (periodId: string) => {
    try {
      const response = await fetch(`/api/variance-analysis?action=items&periodId=${periodId}`);
      if (response.ok) {
        const data = await response.json();
        setVarianceItems(data.items);
      }
    } catch (error) {
      console.error('Error loading period data:', error);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatPercentage = (value: number) => {
    return `${(value * 100).toFixed(1)}%`;
  };

  const getVarianceIcon = (variance: number, isRevenue: boolean) => {
    const isPositive = variance > 0;
    const isFavorable = isRevenue ? isPositive : !isPositive;
    return isFavorable ? 
      <ArrowUp className="w-4 h-4 text-green-600" /> : 
      <ArrowDown className="w-4 h-4 text-red-600" />;
  };

  const getSignificanceBadge = (level: string) => {
    switch (level) {
      case 'critical':
        return <Badge className="bg-red-100 text-red-800">Critical</Badge>;
      case 'high':
        return <Badge className="bg-orange-100 text-orange-800">High</Badge>;
      default:
        return <Badge variant="outline">{level}</Badge>;
    }
  };

  // Sample data
  const performanceData = [
    { category: 'Revenue', actual: 250000, budget: 240000 },
    { category: 'COGS', actual: 120000, budget: 115000 },
    { category: 'OpEx', actual: 80000, budget: 85000 }
  ];

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Variance Analysis Dashboard</h1>
          <p className="text-gray-600">Analyze actual vs budget performance</p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedPeriod?.id || ''} onValueChange={(value) => {
            const period = periods.find(p => p.id === value);
            if (period) {
              setSelectedPeriod(period);
              loadPeriodData(period.id);
            }
          }}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              {periods.map(period => (
                <SelectItem key={period.id} value={period.id}>
                  {period.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="variances">Variances</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Revenue</p>
                    <p className="text-2xl font-bold">{formatCurrency(250000)}</p>
                    <p className="text-sm text-green-600">+4.2% vs Budget</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Expenses</p>
                    <p className="text-2xl font-bold">{formatCurrency(200000)}</p>
                    <p className="text-sm text-red-600">+2.8% vs Budget</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-red-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Net Income</p>
                    <p className="text-2xl font-bold">{formatCurrency(50000)}</p>
                    <p className="text-sm text-green-600">+8.5% vs Budget</p>
                  </div>
                  <Target className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Significant Variances</p>
                    <p className="text-2xl font-bold">5</p>
                    <p className="text-sm text-yellow-600">Requires attention</p>
                  </div>
                  <AlertTriangle className="w-8 h-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Actual vs Budget Performance</CardTitle>
              <CardDescription>Performance comparison across major categories</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="category" />
                  <YAxis />
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Legend />
                  <Bar dataKey="actual" fill="#8884d8" name="Actual" />
                  <Bar dataKey="budget" fill="#82ca9d" name="Budget" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="variances" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Variance Details</CardTitle>
              <CardDescription>Detailed breakdown of all variances</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {varianceItems.slice(0, 10).map(item => (
                  <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      {getVarianceIcon(item.budget_variance, item.line_item_type === 'revenue')}
                      <div>
                        <h4 className="font-medium">{item.line_item_name}</h4>
                        <p className="text-sm text-gray-600">{item.line_item_type}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="font-medium">{formatCurrency(item.actual_amount)}</p>
                        <p className="text-sm text-gray-600">
                          {formatCurrency(item.budget_variance)} ({formatPercentage(item.budget_variance_percentage)})
                        </p>
                      </div>
                      {getSignificanceBadge(item.significance_level)}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Variance Trends</CardTitle>
              <CardDescription>Historical variance patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={[
                  { month: 'Jan', variance: 5000 },
                  { month: 'Feb', variance: -3000 },
                  { month: 'Mar', variance: 8000 },
                  { month: 'Apr', variance: 12000 },
                  { month: 'May', variance: -2000 },
                  { month: 'Jun', variance: 15000 }
                ]}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Line type="monotone" dataKey="variance" stroke="#8884d8" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

