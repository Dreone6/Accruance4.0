'use client'

import { useState, useEffect } from 'react'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  User, 
  Building2, 
  Mail, 
  Phone, 
  Globe, 
  MapPin, 
  Camera, 
  Upload,
  Star,
  MessageCircle,
  Users,
  TrendingUp,
  DollarSign,
  Calendar,
  Award,
  Edit3,
  Save,
  X
} from 'lucide-react'

interface UserProfile {
  id: string
  first_name: string
  last_name: string
  full_name: string
  email: string
  avatar_url?: string
  company?: string
  user_type: 'small_business' | 'financial_professional'
  bio?: string
  phone?: string
  website_url?: string
  linkedin_url?: string
  specializations?: string[]
  years_experience?: string
  services_offered?: string[]
  client_types?: string[]
  hourly_rate?: number
  is_verified: boolean
  rating: number
  total_reviews: number
  created_at: string
}

export default function ProfilePage() {
  const { user } = useAuth()
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [editData, setEditData] = useState<Partial<UserProfile>>({})

  useEffect(() => {
    if (user) {
      fetchProfile()
    }
  }, [user])

  const fetchProfile = async () => {
    try {
      const response = await fetch('/api/profile')
      if (response.ok) {
        const data = await response.json()
        setProfile(data.profile)
        setEditData(data.profile)
      } else {
        setError('Failed to load profile')
      }
    } catch (error) {
      setError('Failed to load profile')
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    setError('')

    try {
      const response = await fetch('/api/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editData),
      })

      if (response.ok) {
        const data = await response.json()
        setProfile(data.profile)
        setEditing(false)
      } else {
        setError('Failed to update profile')
      }
    } catch (error) {
      setError('Failed to update profile')
    } finally {
      setSaving(false)
    }
  }

  const handleCancel = () => {
    setEditData(profile || {})
    setEditing(false)
    setError('')
  }

  const handleArrayChange = (field: string, value: string, checked: boolean) => {
    setEditData(prev => ({
      ...prev,
      [field]: checked 
        ? [...(prev[field as keyof typeof prev] as string[] || []), value]
        : (prev[field as keyof typeof prev] as string[] || []).filter(item => item !== value)
    }))
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading profile...</p>
        </div>
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle>Profile Not Found</CardTitle>
            <CardDescription>Unable to load your profile information</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={fetchProfile} className="w-full">
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Profile</h1>
              <p className="text-gray-600">Manage your account information and preferences</p>
            </div>
            <div className="flex gap-2">
              {editing ? (
                <>
                  <Button variant="outline" onClick={handleCancel} disabled={saving}>
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                  <Button onClick={handleSave} disabled={saving}>
                    <Save className="w-4 h-4 mr-2" />
                    {saving ? 'Saving...' : 'Save Changes'}
                  </Button>
                </>
              ) : (
                <Button onClick={() => setEditing(true)}>
                  <Edit3 className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              )}
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
            <p className="text-red-600">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="relative inline-block">
                    <div className="w-24 h-24 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      {profile.avatar_url ? (
                        <img 
                          src={profile.avatar_url} 
                          alt={profile.full_name}
                          className="w-24 h-24 rounded-full object-cover"
                        />
                      ) : (
                        <span className="text-white font-bold text-2xl">
                          {profile.first_name?.[0]}{profile.last_name?.[0]}
                        </span>
                      )}
                    </div>
                    {editing && (
                      <Button
                        size="sm"
                        className="absolute bottom-0 right-0 rounded-full w-8 h-8 p-0"
                      >
                        <Camera className="w-4 h-4" />
                      </Button>
                    )}
                  </div>

                  <h2 className="text-xl font-semibold text-gray-900 mb-1">
                    {profile.full_name}
                  </h2>
                  
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Badge variant={profile.user_type === 'financial_professional' ? 'default' : 'secondary'}>
                      {profile.user_type === 'financial_professional' ? 'Financial Professional' : 'Business Owner'}
                    </Badge>
                    {profile.is_verified && (
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        <Award className="w-3 h-3 mr-1" />
                        Verified
                      </Badge>
                    )}
                  </div>

                  {profile.user_type === 'financial_professional' && (
                    <div className="flex items-center justify-center gap-1 mb-4">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= profile.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">
                        {profile.rating.toFixed(1)} ({profile.total_reviews} reviews)
                      </span>
                    </div>
                  )}

                  {profile.company && (
                    <p className="text-gray-600 mb-4">{profile.company}</p>
                  )}

                  {profile.bio && (
                    <p className="text-sm text-gray-600 mb-4">{profile.bio}</p>
                  )}

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-center gap-2 text-gray-600">
                      <Mail className="w-4 h-4" />
                      {profile.email}
                    </div>
                    {profile.phone && (
                      <div className="flex items-center justify-center gap-2 text-gray-600">
                        <Phone className="w-4 h-4" />
                        {profile.phone}
                      </div>
                    )}
                    {profile.website_url && (
                      <div className="flex items-center justify-center gap-2 text-gray-600">
                        <Globe className="w-4 h-4" />
                        <a href={profile.website_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                          Website
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">Member since</span>
                  </div>
                  <span className="text-sm font-medium">
                    {new Date(profile.created_at).toLocaleDateString()}
                  </span>
                </div>
                
                {profile.user_type === 'financial_professional' && (
                  <>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-600">Experience</span>
                      </div>
                      <span className="text-sm font-medium">
                        {profile.years_experience || 'Not specified'}
                      </span>
                    </div>
                    
                    {profile.hourly_rate && (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <DollarSign className="w-4 h-4 text-gray-500" />
                          <span className="text-sm text-gray-600">Hourly Rate</span>
                        </div>
                        <span className="text-sm font-medium">
                          ${profile.hourly_rate}/hr
                        </span>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
                <CardDescription>
                  Your personal and contact information
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {editing ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input
                          id="firstName"
                          value={editData.first_name || ''}
                          onChange={(e) => setEditData(prev => ({ ...prev, first_name: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input
                          id="lastName"
                          value={editData.last_name || ''}
                          onChange={(e) => setEditData(prev => ({ ...prev, last_name: e.target.value }))}
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="company">Company/Firm Name</Label>
                      <Input
                        id="company"
                        value={editData.company || ''}
                        onChange={(e) => setEditData(prev => ({ ...prev, company: e.target.value }))}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <textarea
                        id="bio"
                        className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        value={editData.bio || ''}
                        onChange={(e) => setEditData(prev => ({ ...prev, bio: e.target.value }))}
                        placeholder="Tell us about yourself..."
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          value={editData.phone || ''}
                          onChange={(e) => setEditData(prev => ({ ...prev, phone: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="website">Website</Label>
                        <Input
                          id="website"
                          value={editData.website_url || ''}
                          onChange={(e) => setEditData(prev => ({ ...prev, website_url: e.target.value }))}
                        />
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Name</Label>
                      <p className="mt-1">{profile.full_name}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-500">Email</Label>
                      <p className="mt-1">{profile.email}</p>
                    </div>
                    {profile.company && (
                      <div>
                        <Label className="text-sm font-medium text-gray-500">Company</Label>
                        <p className="mt-1">{profile.company}</p>
                      </div>
                    )}
                    {profile.phone && (
                      <div>
                        <Label className="text-sm font-medium text-gray-500">Phone</Label>
                        <p className="mt-1">{profile.phone}</p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Professional Information (for financial professionals) */}
            {profile.user_type === 'financial_professional' && (
              <Card>
                <CardHeader>
                  <CardTitle>Professional Information</CardTitle>
                  <CardDescription>
                    Your expertise and service offerings
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {editing ? (
                    <>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="experience">Years of Experience</Label>
                          <select
                            id="experience"
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                            value={editData.years_experience || ''}
                            onChange={(e) => setEditData(prev => ({ ...prev, years_experience: e.target.value }))}
                          >
                            <option value="">Select experience</option>
                            <option value="0-2">0-2 years</option>
                            <option value="3-5">3-5 years</option>
                            <option value="6-10">6-10 years</option>
                            <option value="11-20">11-20 years</option>
                            <option value="20+">20+ years</option>
                          </select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="hourlyRate">Hourly Rate ($)</Label>
                          <Input
                            id="hourlyRate"
                            type="number"
                            value={editData.hourly_rate || ''}
                            onChange={(e) => setEditData(prev => ({ ...prev, hourly_rate: parseFloat(e.target.value) }))}
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Specializations</Label>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            'Tax Preparation',
                            'Bookkeeping',
                            'Financial Planning',
                            'Business Consulting',
                            'Audit & Assurance',
                            'Payroll Services'
                          ].map((spec) => (
                            <label key={spec} className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                checked={editData.specializations?.includes(spec) || false}
                                onChange={(e) => handleArrayChange('specializations', spec, e.target.checked)}
                                className="rounded border-gray-300"
                              />
                              <span className="text-sm">{spec}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      {profile.specializations && profile.specializations.length > 0 && (
                        <div>
                          <Label className="text-sm font-medium text-gray-500">Specializations</Label>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {profile.specializations.map((spec) => (
                              <Badge key={spec} variant="secondary">{spec}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {profile.services_offered && profile.services_offered.length > 0 && (
                        <div>
                          <Label className="text-sm font-medium text-gray-500">Services Offered</Label>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {profile.services_offered.map((service) => (
                              <Badge key={service} variant="outline">{service}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

