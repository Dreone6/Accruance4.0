'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Eye, EyeOff, ArrowLeft, Check, AlertCircle, Building2, Users, Calculator, TrendingUp } from 'lucide-react'
import Link from 'next/link'

type UserType = 'small_business' | 'financial_professional'

export default function SignUpPage() {
  const [step, setStep] = useState<'type' | 'details' | 'questionnaire' | 'success'>('type')
  const [userType, setUserType] = useState<UserType>('small_business')
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    // Business user fields
    companyName: '',
    businessType: '',
    industry: '',
    monthlyRevenue: '',
    employees: '',
    currentSoftware: '',
    painPoints: [] as string[],
    // Professional fields
    firmName: '',
    licenseNumber: '',
    specializations: [] as string[],
    yearsExperience: '',
    clientTypes: [] as string[],
    servicesOffered: [] as string[],
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()
  const { signUp } = useAuth()

  const passwordRequirements = [
    { text: 'At least 8 characters', met: formData.password.length >= 8 },
    { text: 'Contains uppercase letter', met: /[A-Z]/.test(formData.password) },
    { text: 'Contains lowercase letter', met: /[a-z]/.test(formData.password) },
    { text: 'Contains number', met: /\d/.test(formData.password) },
  ]

  const isPasswordValid = passwordRequirements.every(req => req.met)
  const doPasswordsMatch = formData.password === formData.confirmPassword && formData.confirmPassword !== ''

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const handleArrayChange = (field: string, value: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: checked 
        ? [...(prev[field as keyof typeof prev] as string[]), value]
        : (prev[field as keyof typeof prev] as string[]).filter(item => item !== value)
    }))
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    if (!isPasswordValid) {
      setError('Please meet all password requirements')
      setLoading(false)
      return
    }

    if (!doPasswordsMatch) {
      setError('Passwords do not match')
      setLoading(false)
      return
    }

    try {
      const metadata = {
        first_name: formData.firstName,
        last_name: formData.lastName,
        full_name: `${formData.firstName} ${formData.lastName}`,
        user_type: userType,
        ...(userType === 'small_business' ? {
          company_name: formData.companyName,
          business_type: formData.businessType,
          industry: formData.industry,
          monthly_revenue: formData.monthlyRevenue,
          employees: formData.employees,
          current_software: formData.currentSoftware,
          pain_points: formData.painPoints,
        } : {
          firm_name: formData.firmName,
          license_number: formData.licenseNumber,
          specializations: formData.specializations,
          years_experience: formData.yearsExperience,
          client_types: formData.clientTypes,
          services_offered: formData.servicesOffered,
        })
      }

      const { data, error } = await signUp(formData.email, formData.password, metadata)

      if (error) {
        setError(error.message)
      } else {
        setStep('success')
      }
    } catch (error) {
      setError('An unexpected error occurred')
    } finally {
      setLoading(false)
    }
  }

  if (step === 'success') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <Card>
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle>Welcome to Accruance!</CardTitle>
              <CardDescription>
                Check your email at {formData.email} to verify your account
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 text-center mb-4">
                Click the verification link to complete your registration and access your personalized dashboard.
              </p>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => router.push('/auth/signin')}
              >
                Continue to Sign In
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="mb-8 text-center">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Link>
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">A</span>
            </div>
            <span className="text-2xl font-bold text-gray-900">Accruance</span>
          </div>
          <p className="text-gray-600">Join the future of financial management</p>
        </div>

        {step === 'type' && (
          <div className="grid md:grid-cols-2 gap-6">
            <Card 
              className={`cursor-pointer transition-all ${userType === 'small_business' ? 'ring-2 ring-blue-500 bg-blue-50' : 'hover:shadow-lg'}`}
              onClick={() => setUserType('small_business')}
            >
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Building2 className="w-8 h-8 text-blue-600" />
                </div>
                <CardTitle>Small Business Owner</CardTitle>
                <CardDescription>
                  Manage your business finances with AI-powered insights
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Automated bookkeeping
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Real-time financial dashboard
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    FINN AI financial advisor
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Connect with professionals
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card 
              className={`cursor-pointer transition-all ${userType === 'financial_professional' ? 'ring-2 ring-green-500 bg-green-50' : 'hover:shadow-lg'}`}
              onClick={() => setUserType('financial_professional')}
            >
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-green-600" />
                </div>
                <CardTitle>Financial Professional</CardTitle>
                <CardDescription>
                  Expand your practice and serve clients better
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Client management tools
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Professional networking
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Advanced analytics
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-600 mr-2" />
                    Referral opportunities
                  </li>
                </ul>
              </CardContent>
            </Card>

            <div className="md:col-span-2 flex justify-center">
              <Button 
                onClick={() => setStep('details')}
                className="px-8"
                disabled={!userType}
              >
                Continue as {userType === 'small_business' ? 'Business Owner' : 'Financial Professional'}
                <ArrowLeft className="w-4 h-4 ml-2 rotate-180" />
              </Button>
            </div>
          </div>
        )}

        {step === 'details' && (
          <Card>
            <CardHeader>
              <CardTitle>Account Details</CardTitle>
              <CardDescription>
                Create your {userType === 'small_business' ? 'business' : 'professional'} account
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={(e) => { e.preventDefault(); setStep('questionnaire'); }} className="space-y-4">
                {error && (
                  <div className="flex items-center gap-2 p-3 text-sm text-red-600 bg-red-50 border border-red-200 rounded-md">
                    <AlertCircle className="h-4 w-4" />
                    {error}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      type="text"
                      placeholder="John"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      required
                      disabled={loading}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      type="text"
                      placeholder="Doe"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      required
                      disabled={loading}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="john@company.com"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    disabled={loading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      name="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Create a strong password"
                      value={formData.password}
                      onChange={handleInputChange}
                      required
                      disabled={loading}
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {formData.password && (
                    <div className="space-y-1">
                      {passwordRequirements.map((req, index) => (
                        <div key={index} className="flex items-center text-xs">
                          <div className={`w-3 h-3 rounded-full mr-2 flex items-center justify-center ${
                            req.met ? 'bg-green-100' : 'bg-gray-100'
                          }`}>
                            {req.met && <Check className="w-2 h-2 text-green-600" />}
                          </div>
                          <span className={req.met ? 'text-green-600' : 'text-gray-500'}>
                            {req.text}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <div className="relative">
                    <Input
                      id="confirmPassword"
                      name="confirmPassword"
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="Confirm your password"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      required
                      disabled={loading}
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {formData.confirmPassword && (
                    <div className="flex items-center text-xs">
                      <div className={`w-3 h-3 rounded-full mr-2 flex items-center justify-center ${
                        doPasswordsMatch ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {doPasswordsMatch && <Check className="w-2 h-2 text-green-600" />}
                      </div>
                      <span className={doPasswordsMatch ? 'text-green-600' : 'text-red-500'}>
                        {doPasswordsMatch ? 'Passwords match' : 'Passwords do not match'}
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex gap-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setStep('type')}
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button 
                    type="submit" 
                    className="flex-1" 
                    disabled={loading || !isPasswordValid || !doPasswordsMatch}
                  >
                    Continue to Questionnaire
                    <ArrowLeft className="w-4 h-4 ml-2 rotate-180" />
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {step === 'questionnaire' && userType === 'small_business' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building2 className="w-5 h-5 mr-2" />
                Tell us about your business
              </CardTitle>
              <CardDescription>
                Help us customize Accruance for your specific needs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSignUp} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="companyName">Company Name</Label>
                      <Input
                        id="companyName"
                        name="companyName"
                        placeholder="Acme Corp"
                        value={formData.companyName}
                        onChange={handleInputChange}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="businessType">Business Type</Label>
                      <select
                        id="businessType"
                        name="businessType"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        value={formData.businessType}
                        onChange={handleInputChange}
                        required
                      >
                        <option value="">Select business type</option>
                        <option value="sole_proprietorship">Sole Proprietorship</option>
                        <option value="llc">LLC</option>
                        <option value="corporation">Corporation</option>
                        <option value="s_corp">S Corporation</option>
                        <option value="partnership">Partnership</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="industry">Industry</Label>
                      <select
                        id="industry"
                        name="industry"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        value={formData.industry}
                        onChange={handleInputChange}
                        required
                      >
                        <option value="">Select industry</option>
                        <option value="retail">Retail</option>
                        <option value="restaurant">Restaurant/Food Service</option>
                        <option value="consulting">Consulting</option>
                        <option value="ecommerce">E-commerce</option>
                        <option value="technology">Technology</option>
                        <option value="healthcare">Healthcare</option>
                        <option value="real_estate">Real Estate</option>
                        <option value="manufacturing">Manufacturing</option>
                        <option value="construction">Construction</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="monthlyRevenue">Monthly Revenue</Label>
                      <select
                        id="monthlyRevenue"
                        name="monthlyRevenue"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        value={formData.monthlyRevenue}
                        onChange={handleInputChange}
                      >
                        <option value="">Select range</option>
                        <option value="0-5k">$0 - $5,000</option>
                        <option value="5k-25k">$5,000 - $25,000</option>
                        <option value="25k-100k">$25,000 - $100,000</option>
                        <option value="100k-500k">$100,000 - $500,000</option>
                        <option value="500k+">$500,000+</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="employees">Number of Employees</Label>
                      <select
                        id="employees"
                        name="employees"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        value={formData.employees}
                        onChange={handleInputChange}
                      >
                        <option value="">Select range</option>
                        <option value="1">Just me</option>
                        <option value="2-5">2-5 employees</option>
                        <option value="6-20">6-20 employees</option>
                        <option value="21-50">21-50 employees</option>
                        <option value="50+">50+ employees</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="currentSoftware">Current Accounting Software</Label>
                      <select
                        id="currentSoftware"
                        name="currentSoftware"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        value={formData.currentSoftware}
                        onChange={handleInputChange}
                      >
                        <option value="">Select current solution</option>
                        <option value="none">No current software</option>
                        <option value="quickbooks">QuickBooks</option>
                        <option value="xero">Xero</option>
                        <option value="freshbooks">FreshBooks</option>
                        <option value="wave">Wave</option>
                        <option value="excel">Excel/Spreadsheets</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>What are your biggest financial management challenges? (Select all that apply)</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      'Tracking expenses',
                      'Managing cash flow',
                      'Tax preparation',
                      'Invoice management',
                      'Financial reporting',
                      'Receipt organization',
                      'Bank reconciliation',
                      'Payroll management'
                    ].map((challenge) => (
                      <label key={challenge} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={formData.painPoints.includes(challenge)}
                          onChange={(e) => handleArrayChange('painPoints', challenge, e.target.checked)}
                          className="rounded border-gray-300"
                        />
                        <span className="text-sm">{challenge}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setStep('details')}
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button 
                    type="submit" 
                    className="flex-1" 
                    disabled={loading}
                  >
                    {loading ? 'Creating account...' : 'Create Account'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {step === 'questionnaire' && userType === 'financial_professional' && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                Professional Information
              </CardTitle>
              <CardDescription>
                Help us understand your practice and expertise
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSignUp} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="firmName">Firm/Company Name</Label>
                      <Input
                        id="firmName"
                        name="firmName"
                        placeholder="Smith & Associates CPA"
                        value={formData.firmName}
                        onChange={handleInputChange}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="licenseNumber">License Number (Optional)</Label>
                      <Input
                        id="licenseNumber"
                        name="licenseNumber"
                        placeholder="CPA License #"
                        value={formData.licenseNumber}
                        onChange={handleInputChange}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="yearsExperience">Years of Experience</Label>
                      <select
                        id="yearsExperience"
                        name="yearsExperience"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        value={formData.yearsExperience}
                        onChange={handleInputChange}
                        required
                      >
                        <option value="">Select experience</option>
                        <option value="0-2">0-2 years</option>
                        <option value="3-5">3-5 years</option>
                        <option value="6-10">6-10 years</option>
                        <option value="11-20">11-20 years</option>
                        <option value="20+">20+ years</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Specializations (Select all that apply)</Label>
                      <div className="grid grid-cols-1 gap-2">
                        {[
                          'Tax Preparation',
                          'Bookkeeping',
                          'Financial Planning',
                          'Business Consulting',
                          'Audit & Assurance',
                          'Payroll Services'
                        ].map((spec) => (
                          <label key={spec} className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              checked={formData.specializations.includes(spec)}
                              onChange={(e) => handleArrayChange('specializations', spec, e.target.checked)}
                              className="rounded border-gray-300"
                            />
                            <span className="text-sm">{spec}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Client Types (Select all that apply)</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        'Small Businesses',
                        'Startups',
                        'E-commerce',
                        'Restaurants',
                        'Real Estate',
                        'Healthcare',
                        'Technology',
                        'Non-profits'
                      ].map((type) => (
                        <label key={type} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={formData.clientTypes.includes(type)}
                            onChange={(e) => handleArrayChange('clientTypes', type, e.target.checked)}
                            className="rounded border-gray-300"
                          />
                          <span className="text-sm">{type}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Services Offered (Select all that apply)</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        'Monthly Bookkeeping',
                        'Tax Filing',
                        'Financial Statements',
                        'Cash Flow Analysis',
                        'Business Setup',
                        'Compliance Support',
                        'Financial Consulting',
                        'Software Training'
                      ].map((service) => (
                        <label key={service} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={formData.servicesOffered.includes(service)}
                            onChange={(e) => handleArrayChange('servicesOffered', service, e.target.checked)}
                            className="rounded border-gray-300"
                          />
                          <span className="text-sm">{service}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setStep('details')}
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button 
                    type="submit" 
                    className="flex-1" 
                    disabled={loading}
                  >
                    {loading ? 'Creating account...' : 'Create Professional Account'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

