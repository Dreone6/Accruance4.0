'use client'

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Check, Crown, Zap, Star, CreditCard, Calendar, Users, TrendingUp } from 'lucide-react'

interface Plan {
  id: string
  name: string
  price: number | null
  interval: string
  features: string[]
  limits: {
    transactions: number
    users: number
    integrations: number
  }
  stripe_price_id?: string
}

interface Subscription {
  status: string
  plan: string
  stripe_subscription_id?: string
  stripe_customer_id?: string
  current_period_start?: number
  current_period_end?: number
  cancel_at_period_end?: boolean
}

interface Usage {
  transactions: number
  users: number
  period: {
    start: string
    end: string
  }
}

export default function SubscriptionPage() {
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [plans, setPlans] = useState<Plan[]>([])
  const [usage, setUsage] = useState<Usage | null>(null)
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState(false)

  useEffect(() => {
    fetchSubscriptionData()
  }, [])

  const fetchSubscriptionData = async () => {
    try {
      const response = await fetch('/api/subscriptions')
      if (response.ok) {
        const data = await response.json()
        setSubscription(data.subscription?.subscription)
        setPlans(data.plans?.plans || [])
        setUsage(data.usage?.usage)
      }
    } catch (error) {
      console.error('Error fetching subscription data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleUpgrade = async (planId: string, priceId: string) => {
    setActionLoading(true)
    try {
      const response = await fetch('/api/subscriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create_checkout_session',
          price_id: priceId,
          success_url: `${window.location.origin}/subscription?success=true`,
          cancel_url: `${window.location.origin}/subscription?canceled=true`
        })
      })

      if (response.ok) {
        const data = await response.json()
        window.location.href = data.checkout_url
      } else {
        alert('Failed to create checkout session')
      }
    } catch (error) {
      console.error('Error creating checkout session:', error)
      alert('Failed to upgrade subscription')
    } finally {
      setActionLoading(false)
    }
  }

  const handleManageBilling = async () => {
    setActionLoading(true)
    try {
      const response = await fetch('/api/subscriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create_portal_session'
        })
      })

      if (response.ok) {
        const data = await response.json()
        window.location.href = data.portal_url
      } else {
        alert('Failed to open billing portal')
      }
    } catch (error) {
      console.error('Error opening billing portal:', error)
      alert('Failed to open billing portal')
    } finally {
      setActionLoading(false)
    }
  }

  const formatPrice = (price: number | null) => {
    if (price === null) return 'Custom'
    if (price === 0) return 'Free'
    return `$${price.toFixed(2)}`
  }

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleDateString()
  }

  const getUsagePercentage = (used: number, limit: number) => {
    if (limit === -1) return 0 // Unlimited
    return Math.min((used / limit) * 100, 100)
  }

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case 'free': return <Users className="h-5 w-5" />
      case 'essentials': return <Zap className="h-5 w-5" />
      case 'professional': return <Crown className="h-5 w-5" />
      case 'enterprise': return <Star className="h-5 w-5" />
      default: return <Users className="h-5 w-5" />
    }
  }

  const getPlanColor = (planId: string) => {
    switch (planId) {
      case 'free': return 'bg-gray-100 text-gray-800'
      case 'essentials': return 'bg-blue-100 text-blue-800'
      case 'professional': return 'bg-purple-100 text-purple-800'
      case 'enterprise': return 'bg-gold-100 text-gold-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-lg">Loading subscription...</div>
        </div>
      </div>
    )
  }

  const currentPlan = plans.find(p => p.id === subscription?.plan) || plans[0]

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Subscription</h1>
          <p className="text-gray-600">Manage your Accruance subscription and billing</p>
        </div>
        {subscription?.stripe_customer_id && (
          <Button onClick={handleManageBilling} disabled={actionLoading}>
            <CreditCard className="h-4 w-4 mr-2" />
            Manage Billing
          </Button>
        )}
      </div>

      {/* Current Subscription */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {getPlanIcon(currentPlan.id)}
            Current Plan: {currentPlan.name}
          </CardTitle>
          <CardDescription>
            Your current subscription details and usage
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Badge className={getPlanColor(currentPlan.id)}>
                  {currentPlan.name}
                </Badge>
                {subscription?.status && (
                  <Badge variant={subscription.status === 'active' ? 'default' : 'secondary'}>
                    {subscription.status}
                  </Badge>
                )}
              </div>
              <div className="text-2xl font-bold">{formatPrice(currentPlan.price)}</div>
              <div className="text-sm text-gray-600">per {currentPlan.interval}</div>
              
              {subscription?.current_period_end && (
                <div className="mt-3 text-sm">
                  <div className="flex items-center gap-1 text-gray-600">
                    <Calendar className="h-3 w-3" />
                    Renews {formatDate(subscription.current_period_end)}
                  </div>
                  {subscription.cancel_at_period_end && (
                    <div className="text-orange-600 mt-1">
                      Cancels at period end
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Usage Metrics */}
            {usage && (
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Transactions this month</span>
                    <span>{usage.transactions} / {currentPlan.limits.transactions === -1 ? '∞' : currentPlan.limits.transactions}</span>
                  </div>
                  <Progress 
                    value={getUsagePercentage(usage.transactions, currentPlan.limits.transactions)} 
                    className="h-2"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Team members</span>
                    <span>{usage.users} / {currentPlan.limits.users === -1 ? '∞' : currentPlan.limits.users}</span>
                  </div>
                  <Progress 
                    value={getUsagePercentage(usage.users, currentPlan.limits.users)} 
                    className="h-2"
                  />
                </div>
              </div>
            )}

            {/* Features */}
            <div>
              <h4 className="font-medium mb-2">Plan Features</h4>
              <ul className="space-y-1 text-sm">
                {currentPlan.features.slice(0, 4).map((feature, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <Check className="h-3 w-3 text-green-600" />
                    {feature}
                  </li>
                ))}
                {currentPlan.features.length > 4 && (
                  <li className="text-gray-500">
                    +{currentPlan.features.length - 4} more features
                  </li>
                )}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Available Plans */}
      <Card>
        <CardHeader>
          <CardTitle>Available Plans</CardTitle>
          <CardDescription>
            Choose the plan that best fits your business needs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className={`border rounded-lg p-6 relative ${
                  plan.id === currentPlan.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
                }`}
              >
                {plan.id === 'professional' && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-purple-600 text-white">Most Popular</Badge>
                  </div>
                )}
                
                <div className="text-center mb-4">
                  <div className="flex justify-center mb-2">
                    {getPlanIcon(plan.id)}
                  </div>
                  <h3 className="text-lg font-semibold">{plan.name}</h3>
                  <div className="text-2xl font-bold mt-2">{formatPrice(plan.price)}</div>
                  {plan.price !== null && (
                    <div className="text-sm text-gray-600">per {plan.interval}</div>
                  )}
                </div>

                <ul className="space-y-2 mb-6">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <Check className="h-3 w-3 text-green-600 mt-0.5 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <div className="space-y-2 text-xs text-gray-600 mb-4">
                  <div>Transactions: {plan.limits.transactions === -1 ? 'Unlimited' : plan.limits.transactions}</div>
                  <div>Users: {plan.limits.users === -1 ? 'Unlimited' : plan.limits.users}</div>
                  <div>Integrations: {plan.limits.integrations === -1 ? 'Unlimited' : plan.limits.integrations}</div>
                </div>

                {plan.id === currentPlan.id ? (
                  <Button className="w-full" disabled>
                    Current Plan
                  </Button>
                ) : plan.id === 'enterprise' ? (
                  <Button className="w-full" variant="outline">
                    Contact Sales
                  </Button>
                ) : plan.stripe_price_id ? (
                  <Button
                    className="w-full"
                    onClick={() => handleUpgrade(plan.id, plan.stripe_price_id!)}
                    disabled={actionLoading}
                  >
                    {plan.price === 0 ? 'Downgrade' : 'Upgrade'}
                  </Button>
                ) : (
                  <Button className="w-full" disabled>
                    Coming Soon
                  </Button>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Billing History */}
      {subscription?.stripe_customer_id && (
        <Card>
          <CardHeader>
            <CardTitle>Billing Information</CardTitle>
            <CardDescription>
              Manage your payment methods and view billing history
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">
                Manage your billing information, payment methods, and download invoices
              </p>
              <Button onClick={handleManageBilling} disabled={actionLoading}>
                Open Billing Portal
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

