import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/lib/auth-context";

export const metadata: Metadata = {
  title: "Accruance - AI-Powered Financial Dashboard | Smart Accounting Software",
  description: "Revolutionize your accounting with FINN, your AI CFO. Smart categorization, real-time insights, and automated bookkeeping that makes financial management effortless.",
  keywords: "accounting software, AI CFO, financial dashboard, bookkeeping, invoicing, receipt management, QuickBooks alternative, Xero alternative",
  authors: [{ name: "Accruance Team" }],
  openGraph: {
    title: "Accruance - AI-Powered Financial Dashboard",
    description: "Smart accounting software with AI-powered insights and automation",
    type: "website",
    url: "https://accruance.com",
  },
  twitter: {
    card: "summary_large_image",
    title: "Accruance - AI-Powered Financial Dashboard",
    description: "Smart accounting software with AI-powered insights and automation",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">
        <AuthProvider>
          {children}
        </AuthProvider>
      </body>
    </html>
  );
}