'use client'

import { useEffect, useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MetricsCards } from '@/components/dashboard/metrics-cards'
import { FinancialChart } from '@/components/dashboard/financial-chart'
import { RecentTransactions } from '@/components/dashboard/recent-transactions'
import { CategoryBreakdownChart } from '@/components/dashboard/category-breakdown'
import { DashboardService } from '@/lib/dashboard'
import type { DashboardMetrics, ChartDataPoint, TransactionSummary, CategoryBreakdown } from '@/lib/dashboard'
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  Users, 
  FileText,
  Receipt,
  CreditCard,
  AlertCircle,
  Plus,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Settings,
  RefreshCw,
  Bell,
  Download
} from 'lucide-react'

export default function DashboardPage() {
  const { user, appUser, organization } = useAuth()
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null)
  const [chartData, setChartData] = useState<ChartDataPoint[]>([])
  const [transactions, setTransactions] = useState<TransactionSummary[]>([])
  const [categories, setCategories] = useState<CategoryBreakdown[]>([])
  const [chartPeriod, setChartPeriod] = useState<'week' | 'month' | 'quarter'>('month')

  const loadDashboardData = async () => {
    if (!organization?.id) return

    try {
      const [metricsData, chartDataResult, transactionsData, categoriesData] = await Promise.all([
        DashboardService.getRealtimeMetrics(organization.id),
        DashboardService.getChartData(organization.id, chartPeriod),
        DashboardService.getRecentTransactions(organization.id, 8),
        DashboardService.getCategoryBreakdown(organization.id)
      ])

      setMetrics(metricsData)
      setChartData(chartDataResult)
      setTransactions(transactionsData)
      setCategories(categoriesData)
    } catch (error) {
      console.error('Error loading dashboard data:', error)
    }
  }

  const handleRefresh = async () => {
    setRefreshing(true)
    await loadDashboardData()
    setRefreshing(false)
  }

  const handlePeriodChange = async (period: 'week' | 'month' | 'quarter') => {
    setChartPeriod(period)
    if (organization?.id) {
      const newChartData = await DashboardService.getChartData(organization.id, period)
      setChartData(newChartData)
    }
  }

  useEffect(() => {
    const initializeDashboard = async () => {
      await loadDashboardData()
      setLoading(false)
    }

    if (organization?.id) {
      initializeDashboard()
    }
  }, [organization?.id])

  // Real-time updates simulation
  useEffect(() => {
    const interval = setInterval(() => {
      if (organization?.id && !loading) {
        loadDashboardData()
      }
    }, 30000) // Refresh every 30 seconds

    return () => clearInterval(interval)
  }, [organization?.id, loading])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!metrics) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-gray-600">Failed to load dashboard data</p>
          <Button onClick={handleRefresh} className="mt-4">
            Try Again
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">A</span>
                </div>
                <span className="text-xl font-bold text-gray-900">Accruance</span>
              </div>
              <div className="text-gray-400">|</div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">{organization?.name || 'Dashboard'}</h1>
                <p className="text-sm text-gray-500">Welcome back, {appUser?.first_name || user?.email}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleRefresh}
                disabled={refreshing}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              <Button variant="outline" size="sm">
                <Bell className="w-4 h-4 mr-2" />
                Alerts
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <Button size="sm">
                <Plus className="w-4 h-4 mr-2" />
                Add Transaction
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        {/* Real-time Status Indicator */}
        <div className="mb-6">
          <div className="flex items-center justify-between bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <div>
                <p className="text-sm font-medium text-gray-900">Real-time Dashboard</p>
                <p className="text-xs text-gray-600">Last updated: {new Date().toLocaleTimeString()}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="success" className="text-xs">
                Live Data
              </Badge>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>
        </div>

        {/* KPI Metrics */}
        <div className="mb-6">
          <MetricsCards metrics={metrics} />
        </div>

        {/* Charts and Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <FinancialChart 
            data={chartData} 
            period={chartPeriod}
            onPeriodChange={handlePeriodChange}
          />
          <CategoryBreakdownChart categories={categories} />
        </div>

        {/* Transactions and Sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Transactions */}
          <div className="lg:col-span-2">
            <RecentTransactions transactions={transactions} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Transaction
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Receipt className="w-4 h-4 mr-2" />
                  Upload Receipt
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <FileText className="w-4 h-4 mr-2" />
                  Create Invoice
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View Reports
                </Button>
              </CardContent>
            </Card>

            {/* FINN AI Assistant */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mr-2">
                    <span className="text-white font-bold text-sm">F</span>
                  </div>
                  FINN AI CFO
                </CardTitle>
                <CardDescription>
                  Your AI-powered financial assistant
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-4">
                  <p className="text-sm text-purple-800 mb-2">
                    💡 <strong>Insight:</strong> Your expenses are 8.2% lower than last month. Great job controlling costs!
                  </p>
                  <p className="text-xs text-purple-600">
                    Based on your recent transaction patterns
                  </p>
                </div>
                <Button className="w-full">
                  Chat with FINN
                </Button>
              </CardContent>
            </Card>

            {/* Cash Flow Alert */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-orange-600">
                  <AlertCircle className="w-5 h-5 mr-2" />
                  Cash Flow Alert
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  You have $15,000 in outstanding invoices. Consider following up with clients.
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  View Outstanding Invoices
                </Button>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3 text-sm">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-600">Invoice #1234 paid</span>
                  <span className="text-xs text-gray-400">2m ago</span>
                </div>
                <div className="flex items-center space-x-3 text-sm">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-gray-600">New transaction imported</span>
                  <span className="text-xs text-gray-400">5m ago</span>
                </div>
                <div className="flex items-center space-x-3 text-sm">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span className="text-gray-600">FINN categorized 3 transactions</span>
                  <span className="text-xs text-gray-400">10m ago</span>
                </div>
                <Button variant="outline" size="sm" className="w-full mt-3">
                  View All Activity
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

