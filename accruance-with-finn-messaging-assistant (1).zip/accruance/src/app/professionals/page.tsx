'use client'

import { useState, useEffect } from 'react'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Search, 
  Filter, 
  Users, 
  Star, 
  MessageCircle, 
  UserPlus,
  MapPin,
  DollarSign,
  Award,
  Building2,
  TrendingUp
} from 'lucide-react'

interface Professional {
  id: string
  full_name: string
  avatar_url?: string
  company?: string
  user_type: string
  specializations?: string[]
  years_experience?: string
  services_offered?: string[]
  client_types?: string[]
  hourly_rate?: number
  is_verified: boolean
  rating: number
  total_reviews: number
  bio?: string
}

export default function ProfessionalsPage() {
  const { user } = useAuth()
  const [professionals, setProfessionals] = useState<Professional[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedSpecialization, setSelectedSpecialization] = useState('')
  const [followingIds, setFollowingIds] = useState<Set<string>>(new Set())

  useEffect(() => {
    fetchProfessionals()
  }, [searchTerm, selectedSpecialization])

  const fetchProfessionals = async () => {
    try {
      const params = new URLSearchParams({
        type: 'financial_professional',
        ...(searchTerm && { search: searchTerm }),
        ...(selectedSpecialization && { specialization: selectedSpecialization }),
        limit: '20'
      })

      const response = await fetch(`/api/professionals?${params}`)
      if (response.ok) {
        const data = await response.json()
        setProfessionals(data.professionals || [])
      }
    } catch (error) {
      console.error('Error fetching professionals:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleFollow = async (professionalId: string) => {
    try {
      const response = await fetch('/api/professionals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          professional_id: professionalId,
          message: `Hi! I'd like to connect and learn more about your services.`
        }),
      })

      if (response.ok) {
        setFollowingIds(prev => new Set([...prev, professionalId]))
      }
    } catch (error) {
      console.error('Error following professional:', error)
    }
  }

  const handleMessage = async (professionalId: string) => {
    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          recipient_id: professionalId,
          content: `Hi! I'm interested in learning more about your financial services. Could we schedule a consultation?`,
        }),
      })

      if (response.ok) {
        // Redirect to messages or show success
        alert('Message sent successfully!')
      }
    } catch (error) {
      console.error('Error sending message:', error)
    }
  }

  const specializations = [
    'Tax Preparation',
    'Bookkeeping',
    'Financial Planning',
    'Business Consulting',
    'Audit & Assurance',
    'Payroll Services'
  ]

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Financial Professionals</h1>
          <p className="text-gray-600">Connect with verified financial experts to grow your business</p>
        </div>

        {/* Search and Filters */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search by name or company..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="md:w-64">
                <select
                  value={selectedSpecialization}
                  onChange={(e) => setSelectedSpecialization(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                >
                  <option value="">All Specializations</option>
                  {specializations.map((spec) => (
                    <option key={spec} value={spec}>{spec}</option>
                  ))}
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Finding professionals...</p>
          </div>
        ) : professionals.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No professionals found</h3>
              <p className="text-gray-600">Try adjusting your search criteria</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {professionals.map((professional) => (
              <Card key={professional.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="text-center mb-4">
                    <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3">
                      {professional.avatar_url ? (
                        <img 
                          src={professional.avatar_url} 
                          alt={professional.full_name}
                          className="w-16 h-16 rounded-full object-cover"
                        />
                      ) : (
                        <span className="text-white font-bold text-lg">
                          {professional.full_name.split(' ').map(n => n[0]).join('')}
                        </span>
                      )}
                    </div>
                    
                    <h3 className="font-semibold text-gray-900 mb-1">
                      {professional.full_name}
                    </h3>
                    
                    <div className="flex items-center justify-center gap-2 mb-2">
                      {professional.is_verified && (
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          <Award className="w-3 h-3 mr-1" />
                          Verified
                        </Badge>
                      )}
                    </div>

                    {professional.company && (
                      <p className="text-sm text-gray-600 mb-2">{professional.company}</p>
                    )}

                    <div className="flex items-center justify-center gap-1 mb-3">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= professional.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">
                        {professional.rating.toFixed(1)} ({professional.total_reviews})
                      </span>
                    </div>
                  </div>

                  {/* Specializations */}
                  {professional.specializations && professional.specializations.length > 0 && (
                    <div className="mb-4">
                      <div className="flex flex-wrap gap-1 justify-center">
                        {professional.specializations.slice(0, 3).map((spec) => (
                          <Badge key={spec} variant="secondary" className="text-xs">
                            {spec}
                          </Badge>
                        ))}
                        {professional.specializations.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{professional.specializations.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Quick Info */}
                  <div className="space-y-2 mb-4 text-sm">
                    {professional.years_experience && (
                      <div className="flex items-center justify-center gap-2 text-gray-600">
                        <TrendingUp className="w-4 h-4" />
                        {professional.years_experience} experience
                      </div>
                    )}
                    {professional.hourly_rate && (
                      <div className="flex items-center justify-center gap-2 text-gray-600">
                        <DollarSign className="w-4 h-4" />
                        ${professional.hourly_rate}/hr
                      </div>
                    )}
                  </div>

                  {professional.bio && (
                    <p className="text-sm text-gray-600 text-center mb-4 line-clamp-2">
                      {professional.bio}
                    </p>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => handleMessage(professional.id)}
                    >
                      <MessageCircle className="w-4 h-4 mr-1" />
                      Message
                    </Button>
                    <Button
                      size="sm"
                      className="flex-1"
                      onClick={() => handleFollow(professional.id)}
                      disabled={followingIds.has(professional.id)}
                    >
                      <UserPlus className="w-4 h-4 mr-1" />
                      {followingIds.has(professional.id) ? 'Following' : 'Follow'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Call to Action for Professionals */}
        {user?.user_metadata?.user_type !== 'financial_professional' && (
          <Card className="mt-12 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
            <CardContent className="pt-6">
              <div className="text-center">
                <Building2 className="w-12 h-12 mx-auto mb-4 opacity-90" />
                <h3 className="text-xl font-semibold mb-2">Are you a financial professional?</h3>
                <p className="mb-4 opacity-90">
                  Join our network and connect with businesses looking for your expertise
                </p>
                <Button variant="secondary">
                  Join as Professional
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

