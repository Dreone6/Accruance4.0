'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { InvoiceForm } from '@/components/invoicing/invoice-form'
import { InvoiceList } from '@/components/invoicing/invoice-list'
import { InvoiceViewer } from '@/components/invoicing/invoice-viewer'
import type { InvoiceData } from '@/lib/invoice-manager'

type ViewMode = 'list' | 'create' | 'edit' | 'view'

export default function InvoicesPage() {
  const { organization, user } = useAuth()
  const [viewMode, setViewMode] = useState<ViewMode>('list')
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceData | null>(null)
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  const handleCreateInvoice = () => {
    setSelectedInvoice(null)
    setViewMode('create')
  }

  const handleEditInvoice = (invoice: InvoiceData) => {
    setSelectedInvoice(invoice)
    setViewMode('edit')
  }

  const handleViewInvoice = (invoice: InvoiceData) => {
    setSelectedInvoice(invoice)
    setViewMode('view')
  }

  const handleSaveInvoice = (invoice: InvoiceData) => {
    setRefreshTrigger(prev => prev + 1)
    setViewMode('list')
    setSelectedInvoice(null)
  }

  const handleCancelForm = () => {
    setViewMode('list')
    setSelectedInvoice(null)
  }

  const handleCloseViewer = () => {
    setViewMode('list')
    setSelectedInvoice(null)
  }

  const handleInvoiceUpdate = (updatedInvoice: InvoiceData) => {
    setSelectedInvoice(updatedInvoice)
    setRefreshTrigger(prev => prev + 1)
  }

  if (!organization?.id || !user?.id) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Please complete your organization setup first.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">A</span>
                </div>
                <span className="text-xl font-bold text-gray-900">Accruance</span>
              </div>
              <div className="text-gray-400">|</div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">
                  {viewMode === 'create' ? 'Create Invoice' :
                   viewMode === 'edit' ? 'Edit Invoice' :
                   viewMode === 'view' ? 'Invoice Details' : 'Invoicing & Payments'}
                </h1>
                <p className="text-sm text-gray-500">{organization?.name}</p>
              </div>
            </div>

            {/* Navigation */}
            {(viewMode === 'create' || viewMode === 'edit') && (
              <div className="flex items-center space-x-3">
                <button
                  onClick={handleCancelForm}
                  className="px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg text-sm font-medium transition-colors"
                >
                  ← Back to Invoices
                </button>
              </div>
            )}

            {viewMode === 'view' && (
              <div className="flex items-center space-x-3">
                <button
                  onClick={handleCloseViewer}
                  className="px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg text-sm font-medium transition-colors"
                >
                  ← Back to Invoices
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        {viewMode === 'list' && (
          <div className="max-w-7xl mx-auto">
            <InvoiceList
              organizationId={organization.id}
              onCreateInvoice={handleCreateInvoice}
              onEditInvoice={handleEditInvoice}
              onViewInvoice={handleViewInvoice}
              refreshTrigger={refreshTrigger}
            />
          </div>
        )}

        {(viewMode === 'create' || viewMode === 'edit') && (
          <div className="max-w-4xl mx-auto">
            <InvoiceForm
              organizationId={organization.id}
              invoice={selectedInvoice || undefined}
              onSave={handleSaveInvoice}
              onCancel={handleCancelForm}
            />
          </div>
        )}

        {viewMode === 'view' && selectedInvoice && (
          <InvoiceViewer
            invoice={selectedInvoice}
            onClose={handleCloseViewer}
            onEdit={handleEditInvoice}
            onUpdate={handleInvoiceUpdate}
          />
        )}
      </main>
    </div>
  )
}

