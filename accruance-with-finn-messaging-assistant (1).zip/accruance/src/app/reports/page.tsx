'use client'

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Plus, Play, Edit, Trash2, Download, Search, Filter, BarChart3 } from 'lucide-react'

interface ReportTemplate {
  id: string
  name: string
  description?: string
  category: string
  report_type: string
  is_system_template: boolean
  is_public: boolean
}

interface CustomReport {
  id: string
  name: string
  description?: string
  template_id?: string
  report_config: any
  data_sources: any
  filters: any
  is_shared: boolean
  status: string
  created_at: string
  report_templates?: ReportTemplate
}

interface ReportExecution {
  execution_id: string
  report_id: string
  data: any[]
  columns: any[]
  row_count: number
}

export default function ReportsPage() {
  const [reports, setReports] = useState<CustomReport[]>([])
  const [templates, setTemplates] = useState<ReportTemplate[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [showBuilder, setShowBuilder] = useState(false)
  const [editingReport, setEditingReport] = useState<CustomReport | null>(null)
  const [executionResult, setExecutionResult] = useState<ReportExecution | null>(null)
  const [searchTerm, setSearchTerm] = useState('')

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    template_id: '',
    report_config: {
      type: 'table',
      dimensions: [],
      measures: [],
      filters: []
    },
    data_sources: {
      primary: 'transactions',
      joins: []
    },
    filters: {}
  })

  useEffect(() => {
    fetchReports()
    fetchTemplates()
  }, [])

  const fetchReports = async () => {
    try {
      const response = await fetch('/api/reports?action=reports')
      if (response.ok) {
        const data = await response.json()
        setReports(data.reports || [])
      }
    } catch (error) {
      console.error('Error fetching reports:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchTemplates = async () => {
    try {
      const response = await fetch('/api/reports?action=templates')
      if (response.ok) {
        const data = await response.json()
        setTemplates(data.templates || [])
      }
    } catch (error) {
      console.error('Error fetching templates:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: editingReport ? 'update_report' : 'create_report',
          reportId: editingReport?.id,
          ...formData
        })
      })

      if (response.ok) {
        await fetchReports()
        resetForm()
      } else {
        const error = await response.json()
        alert(error.error || 'Failed to save report')
      }
    } catch (error) {
      console.error('Error saving report:', error)
      alert('Failed to save report')
    } finally {
      setLoading(false)
    }
  }

  const executeReport = async (reportId: string) => {
    setLoading(true)
    try {
      const response = await fetch(`/api/reports?action=execute&reportId=${reportId}`)
      if (response.ok) {
        const data = await response.json()
        setExecutionResult(data.result)
        setShowBuilder(true)
      } else {
        const error = await response.json()
        alert(error.error || 'Failed to execute report')
      }
    } catch (error) {
      console.error('Error executing report:', error)
      alert('Failed to execute report')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (reportId: string) => {
    if (!confirm('Are you sure you want to delete this report?')) return

    try {
      const response = await fetch(`/api/reports?id=${reportId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        await fetchReports()
      } else {
        const error = await response.json()
        alert(error.error || 'Failed to delete report')
      }
    } catch (error) {
      console.error('Error deleting report:', error)
      alert('Failed to delete report')
    }
  }

  const createFromTemplate = (template: ReportTemplate) => {
    setFormData({
      name: `${template.name} - Copy`,
      description: template.description || '',
      template_id: template.id,
      report_config: {
        type: template.report_type,
        dimensions: [],
        measures: [],
        filters: []
      },
      data_sources: {
        primary: 'transactions',
        joins: []
      },
      filters: {}
    })
    setShowForm(true)
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      template_id: '',
      report_config: {
        type: 'table',
        dimensions: [],
        measures: [],
        filters: []
      },
      data_sources: {
        primary: 'transactions',
        joins: []
      },
      filters: {}
    })
    setEditingReport(null)
    setShowForm(false)
    setShowBuilder(false)
    setExecutionResult(null)
  }

  const filteredReports = reports.filter(report =>
    report.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    report.description?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const systemTemplates = templates.filter(t => t.is_system_template)
  const customTemplates = templates.filter(t => !t.is_system_template)

  if (loading && reports.length === 0) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-lg">Loading reports...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Reports</h1>
          <p className="text-gray-600">Create and manage custom financial reports</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            New Report
          </Button>
          <Button variant="outline" onClick={() => setShowBuilder(true)} className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Report Builder
          </Button>
        </div>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search reports..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Report Builder */}
      {showBuilder && (
        <Card>
          <CardHeader>
            <CardTitle>Report Builder</CardTitle>
            <CardDescription>
              Drag and drop to build custom reports
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Data Sources */}
              <div>
                <h3 className="font-medium mb-3">Data Sources</h3>
                <div className="space-y-2">
                  {['Transactions', 'Accounts', 'Invoices', 'Receipts', 'Budget Items'].map((source) => (
                    <div
                      key={source}
                      className="p-2 border rounded cursor-pointer hover:bg-gray-50"
                      draggable
                    >
                      {source}
                    </div>
                  ))}
                </div>
              </div>

              {/* Report Canvas */}
              <div>
                <h3 className="font-medium mb-3">Report Canvas</h3>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 min-h-64">
                  {executionResult ? (
                    <div>
                      <h4 className="font-medium mb-2">Report Results</h4>
                      <div className="text-sm text-gray-600 mb-3">
                        {executionResult.row_count} rows returned
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              {executionResult.columns.map((col: any, index: number) => (
                                <th key={index} className="text-left p-2">{col.name}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {executionResult.data.slice(0, 10).map((row: any, index: number) => (
                              <tr key={index} className="border-b">
                                {executionResult.columns.map((col: any, colIndex: number) => (
                                  <td key={colIndex} className="p-2">{row[col.name]}</td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center text-gray-500">
                      Drag data sources here to build your report
                    </div>
                  )}
                </div>
              </div>

              {/* Report Properties */}
              <div>
                <h3 className="font-medium mb-3">Properties</h3>
                <div className="space-y-3">
                  <div>
                    <Label>Report Type</Label>
                    <select className="w-full border rounded px-3 py-2">
                      <option>Table</option>
                      <option>Chart</option>
                      <option>Summary</option>
                    </select>
                  </div>
                  <div>
                    <Label>Date Range</Label>
                    <select className="w-full border rounded px-3 py-2">
                      <option>This Month</option>
                      <option>Last Month</option>
                      <option>This Year</option>
                      <option>Custom</option>
                    </select>
                  </div>
                  <Button className="w-full">
                    Generate Report
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Report Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{editingReport ? 'Edit Report' : 'Create New Report'}</CardTitle>
            <CardDescription>
              {editingReport ? 'Update report configuration' : 'Create a custom report from scratch or template'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Report Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="template_id">Template (Optional)</Label>
                  <select
                    id="template_id"
                    value={formData.template_id}
                    onChange={(e) => setFormData({ ...formData, template_id: e.target.value })}
                    className="w-full border rounded px-3 py-2"
                  >
                    <option value="">No Template</option>
                    {templates.map((template) => (
                      <option key={template.id} value={template.id}>
                        {template.name} ({template.category})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Optional description"
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={loading}>
                  {loading ? 'Saving...' : editingReport ? 'Update Report' : 'Create Report'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* System Templates */}
      {systemTemplates.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>System Templates</CardTitle>
            <CardDescription>
              Pre-built financial report templates
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {systemTemplates.map((template) => (
                <div key={template.id} className="border rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium">{template.name}</h3>
                    <Badge variant="outline">{template.category}</Badge>
                  </div>
                  {template.description && (
                    <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                  )}
                  <Button
                    size="sm"
                    onClick={() => createFromTemplate(template)}
                    className="w-full"
                  >
                    Use Template
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Custom Reports */}
      <Card>
        <CardHeader>
          <CardTitle>My Reports ({filteredReports.length})</CardTitle>
          <CardDescription>
            Your custom reports and saved configurations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredReports.map((report) => (
              <div
                key={report.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <span className="font-medium">{report.name}</span>
                    <Badge className={report.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                      {report.status}
                    </Badge>
                    {report.is_shared && (
                      <Badge variant="outline">Shared</Badge>
                    )}
                  </div>
                  {report.description && (
                    <p className="text-sm text-gray-600 mt-1">{report.description}</p>
                  )}
                  <div className="text-xs text-gray-500 mt-1">
                    Created {new Date(report.created_at).toLocaleDateString()}
                    {report.report_templates && ` • Template: ${report.report_templates.name}`}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => executeReport(report.id)}
                    className="flex items-center gap-1"
                  >
                    <Play className="h-3 w-3" />
                    Run
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingReport(report)
                      setFormData({
                        name: report.name,
                        description: report.description || '',
                        template_id: report.template_id || '',
                        report_config: report.report_config,
                        data_sources: report.data_sources,
                        filters: report.filters
                      })
                      setShowForm(true)
                    }}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(report.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
            {filteredReports.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                {searchTerm 
                  ? 'No reports match your search' 
                  : 'No reports found. Create your first report to get started.'}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

