'use client'

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  CheckCircle, 
  XCircle, 
  Clock, 
  RefreshCw, 
  Settings, 
  ExternalLink,
  AlertTriangle,
  Database,
  Sync,
  Calendar
} from 'lucide-react';

interface Integration {
  id: string;
  provider: string;
  company_id: string;
  is_active: boolean;
  last_sync_at: string | null;
  sync_frequency: string;
  created_at: string;
}

interface SyncLog {
  id: string;
  sync_type: string;
  entity_type: string;
  status: string;
  records_processed: number;
  records_created: number;
  records_updated: number;
  records_failed: number;
  error_message: string | null;
  started_at: string;
  completed_at: string | null;
}

export default function IntegrationsPage() {
  const [quickbooksIntegration, setQuickbooksIntegration] = useState<Integration | null>(null);
  const [netsuiteIntegration, setNetsuiteIntegration] = useState<Integration | null>(null);
  const [quickbooksSyncLogs, setQuickbooksSyncLogs] = useState<SyncLog[]>([]);
  const [netsuiteSyncLogs, setNetsuiteSyncLogs] = useState<SyncLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState<{ [key: string]: boolean }>({});
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadIntegrations();
  }, []);

  const loadIntegrations = async () => {
    try {
      setLoading(true);
      
      // Load QuickBooks integration
      const qbResponse = await fetch('/api/integrations/quickbooks');
      if (qbResponse.ok) {
        const qbData = await qbResponse.json();
        setQuickbooksIntegration(qbData.integration);
        setQuickbooksSyncLogs(qbData.syncLogs || []);
      }

      // Load NetSuite integration
      const nsResponse = await fetch('/api/integrations/netsuite');
      if (nsResponse.ok) {
        const nsData = await nsResponse.json();
        setNetsuiteIntegration(nsData.integration);
        setNetsuiteSyncLogs(nsData.syncLogs || []);
      }

    } catch (error) {
      console.error('Error loading integrations:', error);
      setError('Failed to load integrations');
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async (provider: string) => {
    try {
      const response = await fetch(`/api/integrations/${provider}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'connect' })
      });

      if (response.ok) {
        const data = await response.json();
        window.location.href = data.authUrl;
      } else {
        throw new Error('Failed to initiate connection');
      }
    } catch (error) {
      console.error('Connection error:', error);
      setError(`Failed to connect to ${provider}`);
    }
  };

  const handleSync = async (provider: string, syncType = 'incremental') => {
    try {
      setSyncing(prev => ({ ...prev, [provider]: true }));
      
      const response = await fetch(`/api/integrations/${provider}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          action: 'sync',
          syncType,
          entityTypes: ['accounts', 'transactions', 'customers']
        })
      });

      if (response.ok) {
        // Reload integrations to get updated sync logs
        setTimeout(() => {
          loadIntegrations();
        }, 2000);
      } else {
        throw new Error('Sync failed');
      }
    } catch (error) {
      console.error('Sync error:', error);
      setError(`Failed to sync ${provider} data`);
    } finally {
      setSyncing(prev => ({ ...prev, [provider]: false }));
    }
  };

  const handleDisconnect = async (provider: string) => {
    if (!confirm(`Are you sure you want to disconnect ${provider}?`)) {
      return;
    }

    try {
      const response = await fetch(`/api/integrations/${provider}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'disconnect' })
      });

      if (response.ok) {
        loadIntegrations();
      } else {
        throw new Error('Failed to disconnect');
      }
    } catch (error) {
      console.error('Disconnect error:', error);
      setError(`Failed to disconnect ${provider}`);
    }
  };

  const updateSyncFrequency = async (provider: string, frequency: string) => {
    try {
      const response = await fetch(`/api/integrations/${provider}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sync_frequency: frequency })
      });

      if (response.ok) {
        loadIntegrations();
      } else {
        throw new Error('Failed to update sync frequency');
      }
    } catch (error) {
      console.error('Update error:', error);
      setError(`Failed to update ${provider} settings`);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'failed':
        return <Badge className="bg-red-100 text-red-800"><XCircle className="w-3 h-3 mr-1" />Failed</Badge>;
      case 'running':
        return <Badge className="bg-blue-100 text-blue-800"><RefreshCw className="w-3 h-3 mr-1 animate-spin" />Running</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const IntegrationCard = ({ 
    provider, 
    integration, 
    syncLogs, 
    onConnect, 
    onSync, 
    onDisconnect, 
    onUpdateFrequency 
  }: {
    provider: string;
    integration: Integration | null;
    syncLogs: SyncLog[];
    onConnect: () => void;
    onSync: (type: string) => void;
    onDisconnect: () => void;
    onUpdateFrequency: (freq: string) => void;
  }) => (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              {provider === 'quickbooks' ? 'QuickBooks Online' : 'NetSuite'}
            </CardTitle>
            <CardDescription>
              {integration ? 'Connected and syncing data' : 'Connect your accounting system'}
            </CardDescription>
          </div>
          {integration ? (
            <Badge className="bg-green-100 text-green-800">
              <CheckCircle className="w-3 h-3 mr-1" />
              Connected
            </Badge>
          ) : (
            <Badge variant="outline">Not Connected</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {integration ? (
          <>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Last Sync:</span>
                <p className="text-gray-600">
                  {integration.last_sync_at 
                    ? formatDate(integration.last_sync_at)
                    : 'Never'
                  }
                </p>
              </div>
              <div>
                <span className="font-medium">Sync Frequency:</span>
                <Select 
                  value={integration.sync_frequency} 
                  onValueChange={(value) => onUpdateFrequency(value)}
                >
                  <SelectTrigger className="w-full mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2">
              <Button 
                onClick={() => onSync('incremental')}
                disabled={syncing[provider]}
                size="sm"
              >
                {syncing[provider] ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Sync className="w-4 h-4 mr-2" />
                )}
                Sync Now
              </Button>
              <Button 
                onClick={() => onSync('full')}
                disabled={syncing[provider]}
                variant="outline"
                size="sm"
              >
                Full Sync
              </Button>
              <Button 
                onClick={onDisconnect}
                variant="destructive"
                size="sm"
              >
                Disconnect
              </Button>
            </div>

            {/* Recent Sync Logs */}
            <div className="space-y-2">
              <h4 className="font-medium text-sm">Recent Sync Activity</h4>
              {syncLogs.length > 0 ? (
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {syncLogs.slice(0, 5).map((log) => (
                    <div key={log.id} className="flex items-center justify-between p-2 bg-gray-50 rounded text-sm">
                      <div className="flex items-center gap-2">
                        {getStatusBadge(log.status)}
                        <span>{log.entity_type}</span>
                        <span className="text-gray-500">({log.sync_type})</span>
                      </div>
                      <div className="text-right text-xs text-gray-500">
                        <div>{formatDate(log.started_at)}</div>
                        {log.status === 'completed' && (
                          <div>
                            {log.records_created} created, {log.records_updated} updated
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500">No sync activity yet</p>
              )}
            </div>
          </>
        ) : (
          <div className="text-center py-6">
            <p className="text-gray-600 mb-4">
              Connect your {provider === 'quickbooks' ? 'QuickBooks Online' : 'NetSuite'} account to automatically sync your financial data.
            </p>
            <Button onClick={onConnect}>
              <ExternalLink className="w-4 h-4 mr-2" />
              Connect {provider === 'quickbooks' ? 'QuickBooks' : 'NetSuite'}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Integrations</h1>
        <p className="text-gray-600">Connect your accounting systems to automatically sync financial data</p>
      </div>

      {error && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="quickbooks">QuickBooks</TabsTrigger>
          <TabsTrigger value="netsuite">NetSuite</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <IntegrationCard
              provider="quickbooks"
              integration={quickbooksIntegration}
              syncLogs={quickbooksSyncLogs}
              onConnect={() => handleConnect('quickbooks')}
              onSync={(type) => handleSync('quickbooks', type)}
              onDisconnect={() => handleDisconnect('quickbooks')}
              onUpdateFrequency={(freq) => updateSyncFrequency('quickbooks', freq)}
            />
            <IntegrationCard
              provider="netsuite"
              integration={netsuiteIntegration}
              syncLogs={netsuiteSyncLogs}
              onConnect={() => handleConnect('netsuite')}
              onSync={(type) => handleSync('netsuite', type)}
              onDisconnect={() => handleDisconnect('netsuite')}
              onUpdateFrequency={(freq) => updateSyncFrequency('netsuite', freq)}
            />
          </div>

          {/* Integration Status Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Integration Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {(quickbooksIntegration ? 1 : 0) + (netsuiteIntegration ? 1 : 0)}
                  </div>
                  <div className="text-sm text-gray-600">Connected Systems</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {quickbooksSyncLogs.filter(log => log.status === 'completed').length + 
                     netsuiteSyncLogs.filter(log => log.status === 'completed').length}
                  </div>
                  <div className="text-sm text-gray-600">Successful Syncs</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">
                    {quickbooksSyncLogs.filter(log => log.status === 'failed').length + 
                     netsuiteSyncLogs.filter(log => log.status === 'failed').length}
                  </div>
                  <div className="text-sm text-gray-600">Failed Syncs</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quickbooks">
          <IntegrationCard
            provider="quickbooks"
            integration={quickbooksIntegration}
            syncLogs={quickbooksSyncLogs}
            onConnect={() => handleConnect('quickbooks')}
            onSync={(type) => handleSync('quickbooks', type)}
            onDisconnect={() => handleDisconnect('quickbooks')}
            onUpdateFrequency={(freq) => updateSyncFrequency('quickbooks', freq)}
          />
        </TabsContent>

        <TabsContent value="netsuite">
          <IntegrationCard
            provider="netsuite"
            integration={netsuiteIntegration}
            syncLogs={netsuiteSyncLogs}
            onConnect={() => handleConnect('netsuite')}
            onSync={(type) => handleSync('netsuite', type)}
            onDisconnect={() => handleDisconnect('netsuite')}
            onUpdateFrequency={(freq) => updateSyncFrequency('netsuite', freq)}
          />
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Integration Settings</CardTitle>
              <CardDescription>Configure global integration preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Default Sync Frequency</label>
                <Select defaultValue="daily">
                  <SelectTrigger className="w-full mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Sync Notifications</label>
                <div className="mt-2 space-y-2">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" defaultChecked />
                    Email notifications for sync failures
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Daily sync summary emails
                  </label>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

