'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { TransactionForm } from '@/components/bookkeeping/transaction-form'
import { TransactionList } from '@/components/bookkeeping/transaction-list'
import { RecategorizationInterface } from '@/components/bookkeeping/recategorization-interface'
import { AuditTrail } from '@/components/bookkeeping/audit-trail'
import { BulkActionsInterface } from '@/components/bookkeeping/bulk-actions-interface'
import { BookkeepingEngine } from '@/lib/bookkeeping'
import type { Transaction, TransactionFormData, BulkAction } from '@/lib/bookkeeping'

type ViewMode = 'list' | 'form' | 'recategorize' | 'audit'

export default function TransactionsPage() {
  const { organization } = useAuth()
  const [viewMode, setViewMode] = useState<ViewMode>('list')
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null)
  const [selectedTransactions, setSelectedTransactions] = useState<Transaction[]>([])
  const [refreshKey, setRefreshKey] = useState(0)

  const handleCreateTransaction = () => {
    setEditingTransaction(null)
    setViewMode('form')
  }

  const handleEditTransaction = (transaction: Transaction) => {
    setEditingTransaction(transaction)
    setViewMode('form')
  }

  const handleRecategorizeTransaction = (transaction: Transaction) => {
    setEditingTransaction(transaction)
    setViewMode('recategorize')
  }

  const handleViewAuditTrail = (transaction: Transaction) => {
    setEditingTransaction(transaction)
    setViewMode('audit')
  }

  const handleFormSubmit = async (data: TransactionFormData) => {
    if (!organization?.id) return

    try {
      if (editingTransaction) {
        await BookkeepingEngine.updateTransaction(editingTransaction.id, data)
        await BookkeepingEngine.createAuditEntry(
          editingTransaction.id,
          'updated',
          editingTransaction,
          data
        )
      } else {
        const newTransaction = await BookkeepingEngine.createTransaction(organization.id, data)
        await BookkeepingEngine.createAuditEntry(
          newTransaction.id,
          'created',
          null,
          data
        )
      }

      setViewMode('list')
      setEditingTransaction(null)
      setRefreshKey(prev => prev + 1)
    } catch (error) {
      console.error('Error saving transaction:', error)
    }
  }

  const handleRecategorizationSave = async (categoryId: string, confidence?: number) => {
    if (!editingTransaction) return

    try {
      await BookkeepingEngine.updateTransaction(editingTransaction.id, { category_id: categoryId })
      await BookkeepingEngine.createAuditEntry(
        editingTransaction.id,
        'categorized',
        { category_id: editingTransaction.category_id },
        { category_id: categoryId, confidence }
      )

      setViewMode('list')
      setEditingTransaction(null)
      setRefreshKey(prev => prev + 1)
    } catch (error) {
      console.error('Error recategorizing transaction:', error)
    }
  }

  const handleBulkAction = async (action: BulkAction) => {
    if (selectedTransactions.length === 0) return

    try {
      const transactionIds = selectedTransactions.map(t => t.id)
      await BookkeepingEngine.bulkUpdateTransactions(transactionIds, action)
      
      // Create audit entries for bulk actions
      for (const transaction of selectedTransactions) {
        await BookkeepingEngine.createAuditEntry(
          transaction.id,
          action.type as any,
          null,
          action
        )
      }

      setSelectedTransactions([])
      setRefreshKey(prev => prev + 1)
    } catch (error) {
      console.error('Error performing bulk action:', error)
    }
  }

  const handleCancel = () => {
    setViewMode('list')
    setEditingTransaction(null)
  }

  if (!organization?.id) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Please complete your organization setup first.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">A</span>
                </div>
                <span className="text-xl font-bold text-gray-900">Accruance</span>
              </div>
              <div className="text-gray-400">|</div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">
                  {viewMode === 'form' ? (editingTransaction ? 'Edit Transaction' : 'New Transaction') :
                   viewMode === 'recategorize' ? 'Recategorize Transaction' :
                   viewMode === 'audit' ? 'Audit Trail' : 'Transactions'}
                </h1>
                <p className="text-sm text-gray-500">{organization?.name}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        {/* Bulk Actions Interface */}
        {selectedTransactions.length > 0 && viewMode === 'list' && (
          <div className="mb-6">
            <BulkActionsInterface
              selectedTransactions={selectedTransactions}
              onBulkAction={handleBulkAction}
              onClearSelection={() => setSelectedTransactions([])}
            />
          </div>
        )}

        {/* Content based on view mode */}
        {viewMode === 'form' && (
          <div className="max-w-4xl mx-auto">
            <TransactionForm
              onSubmit={handleFormSubmit}
              onCancel={handleCancel}
              initialData={editingTransaction ? {
                date: editingTransaction.date,
                description: editingTransaction.description,
                amount: Math.abs(editingTransaction.amount),
                type: editingTransaction.amount >= 0 ? 'income' : 'expense',
                category_id: editingTransaction.category_id,
                account_id: editingTransaction.account_id,
                reference: editingTransaction.reference || '',
                notes: editingTransaction.notes || ''
              } : undefined}
              organizationId={organization.id}
            />
          </div>
        )}

        {viewMode === 'recategorize' && editingTransaction && (
          <div className="max-w-4xl mx-auto">
            <RecategorizationInterface
              transaction={editingTransaction}
              onSave={handleRecategorizationSave}
              onCancel={handleCancel}
            />
          </div>
        )}

        {viewMode === 'audit' && editingTransaction && (
          <div className="max-w-4xl mx-auto">
            <AuditTrail
              transaction={editingTransaction}
              onClose={handleCancel}
            />
          </div>
        )}

        {viewMode === 'list' && (
          <div className="max-w-7xl mx-auto">
            <TransactionList
              key={refreshKey}
              organizationId={organization.id}
              onEditTransaction={handleEditTransaction}
              onCreateTransaction={handleCreateTransaction}
              onRecategorizeTransaction={handleRecategorizeTransaction}
              onViewAuditTrail={handleViewAuditTrail}
              selectedTransactions={selectedTransactions}
              onSelectionChange={setSelectedTransactions}
            />
          </div>
        )}
      </main>
    </div>
  )
}

