'use client'

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Plus, Edit, Trash2, Search, Calendar, DollarSign } from 'lucide-react'

interface Account {
  id: string
  name: string
  account_number: string
  type: string
}

interface JournalEntryLine {
  id?: string
  account_id: string
  debit_amount: number
  credit_amount: number
  description: string
  accounts?: Account
}

interface JournalEntry {
  id: string
  date: string
  reference_number?: string
  description: string
  total_amount: number
  status: string
  journal_entry_lines: JournalEntryLine[]
  created_at: string
}

export default function JournalEntriesPage() {
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>([])
  const [accounts, setAccounts] = useState<Account[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null)

  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    reference_number: '',
    description: '',
    lines: [
      { account_id: '', debit_amount: 0, credit_amount: 0, description: '' },
      { account_id: '', debit_amount: 0, credit_amount: 0, description: '' }
    ] as JournalEntryLine[]
  })

  useEffect(() => {
    fetchJournalEntries()
    fetchAccounts()
  }, [])

  const fetchJournalEntries = async () => {
    try {
      const response = await fetch('/api/journal-entries')
      if (response.ok) {
        const data = await response.json()
        setJournalEntries(data.journalEntries || [])
      }
    } catch (error) {
      console.error('Error fetching journal entries:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchAccounts = async () => {
    try {
      const response = await fetch('/api/accounts?active=true')
      if (response.ok) {
        const data = await response.json()
        setAccounts(data.accounts || [])
      }
    } catch (error) {
      console.error('Error fetching accounts:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validate that debits equal credits
    const totalDebits = formData.lines.reduce((sum, line) => sum + (line.debit_amount || 0), 0)
    const totalCredits = formData.lines.reduce((sum, line) => sum + (line.credit_amount || 0), 0)
    
    if (Math.abs(totalDebits - totalCredits) > 0.01) {
      alert('Debits must equal credits in a journal entry')
      return
    }

    // Validate that each line has either debit or credit (not both)
    for (const line of formData.lines) {
      if ((line.debit_amount && line.credit_amount) || (!line.debit_amount && !line.credit_amount)) {
        alert('Each line must have either debit or credit amount, not both or neither')
        return
      }
      if (!line.account_id) {
        alert('Each line must have an account selected')
        return
      }
    }

    setLoading(true)

    try {
      const response = await fetch('/api/journal-entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })

      if (response.ok) {
        await fetchJournalEntries()
        resetForm()
      } else {
        const error = await response.json()
        alert(error.error || 'Failed to save journal entry')
      }
    } catch (error) {
      console.error('Error saving journal entry:', error)
      alert('Failed to save journal entry')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (entryId: string) => {
    if (!confirm('Are you sure you want to delete this journal entry? This will reverse all account balances.')) return

    try {
      const response = await fetch(`/api/journal-entries?id=${entryId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        await fetchJournalEntries()
      } else {
        const error = await response.json()
        alert(error.error || 'Failed to delete journal entry')
      }
    } catch (error) {
      console.error('Error deleting journal entry:', error)
      alert('Failed to delete journal entry')
    }
  }

  const addLine = () => {
    setFormData({
      ...formData,
      lines: [...formData.lines, { account_id: '', debit_amount: 0, credit_amount: 0, description: '' }]
    })
  }

  const removeLine = (index: number) => {
    if (formData.lines.length > 2) {
      const newLines = formData.lines.filter((_, i) => i !== index)
      setFormData({ ...formData, lines: newLines })
    }
  }

  const updateLine = (index: number, field: keyof JournalEntryLine, value: any) => {
    const newLines = [...formData.lines]
    newLines[index] = { ...newLines[index], [field]: value }
    
    // If updating debit, clear credit and vice versa
    if (field === 'debit_amount' && value > 0) {
      newLines[index].credit_amount = 0
    } else if (field === 'credit_amount' && value > 0) {
      newLines[index].debit_amount = 0
    }
    
    setFormData({ ...formData, lines: newLines })
  }

  const resetForm = () => {
    setFormData({
      date: new Date().toISOString().split('T')[0],
      reference_number: '',
      description: '',
      lines: [
        { account_id: '', debit_amount: 0, credit_amount: 0, description: '' },
        { account_id: '', debit_amount: 0, credit_amount: 0, description: '' }
      ]
    })
    setEditingEntry(null)
    setShowForm(false)
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount)
  }

  const getTotalDebits = () => {
    return formData.lines.reduce((sum, line) => sum + (line.debit_amount || 0), 0)
  }

  const getTotalCredits = () => {
    return formData.lines.reduce((sum, line) => sum + (line.credit_amount || 0), 0)
  }

  const isBalanced = () => {
    return Math.abs(getTotalDebits() - getTotalCredits()) < 0.01
  }

  if (loading && journalEntries.length === 0) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-lg">Loading journal entries...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Journal Entries</h1>
          <p className="text-gray-600">Manage double-entry bookkeeping transactions</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          New Journal Entry
        </Button>
      </div>

      {/* Journal Entry Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create Journal Entry</CardTitle>
            <CardDescription>
              Enter a double-entry journal entry with debits and credits
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="date">Date *</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="reference_number">Reference Number</Label>
                  <Input
                    id="reference_number"
                    value={formData.reference_number}
                    onChange={(e) => setFormData({ ...formData, reference_number: e.target.value })}
                    placeholder="Optional reference"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Input
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                    placeholder="Journal entry description"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">Journal Entry Lines</h3>
                  <Button type="button" onClick={addLine} size="sm">
                    Add Line
                  </Button>
                </div>

                <div className="space-y-3">
                  {formData.lines.map((line, index) => (
                    <div key={index} className="grid grid-cols-12 gap-2 items-center p-3 border rounded">
                      <div className="col-span-4">
                        <select
                          value={line.account_id}
                          onChange={(e) => updateLine(index, 'account_id', e.target.value)}
                          className="w-full border rounded px-2 py-1 text-sm"
                          required
                        >
                          <option value="">Select Account</option>
                          {accounts.map((account) => (
                            <option key={account.id} value={account.id}>
                              {account.account_number} - {account.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="col-span-2">
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Debit"
                          value={line.debit_amount || ''}
                          onChange={(e) => updateLine(index, 'debit_amount', parseFloat(e.target.value) || 0)}
                          className="text-sm"
                        />
                      </div>
                      <div className="col-span-2">
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Credit"
                          value={line.credit_amount || ''}
                          onChange={(e) => updateLine(index, 'credit_amount', parseFloat(e.target.value) || 0)}
                          className="text-sm"
                        />
                      </div>
                      <div className="col-span-3">
                        <Input
                          placeholder="Line description"
                          value={line.description}
                          onChange={(e) => updateLine(index, 'description', e.target.value)}
                          className="text-sm"
                        />
                      </div>
                      <div className="col-span-1">
                        {formData.lines.length > 2 && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => removeLine(index)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-4 p-3 bg-gray-50 rounded">
                  <div className="flex justify-between items-center">
                    <div className="flex gap-6">
                      <div>
                        <span className="text-sm text-gray-600">Total Debits: </span>
                        <span className="font-medium">{formatCurrency(getTotalDebits())}</span>
                      </div>
                      <div>
                        <span className="text-sm text-gray-600">Total Credits: </span>
                        <span className="font-medium">{formatCurrency(getTotalCredits())}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {isBalanced() ? (
                        <Badge className="bg-green-100 text-green-800">Balanced</Badge>
                      ) : (
                        <Badge className="bg-red-100 text-red-800">Out of Balance</Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={loading || !isBalanced()}>
                  {loading ? 'Saving...' : 'Create Journal Entry'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Journal Entries List */}
      <Card>
        <CardHeader>
          <CardTitle>Journal Entries ({journalEntries.length})</CardTitle>
          <CardDescription>
            Your double-entry bookkeeping transactions
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {journalEntries.map((entry) => (
              <div key={entry.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <div className="flex items-center gap-3">
                      <span className="font-medium">{entry.description}</span>
                      {entry.reference_number && (
                        <Badge variant="outline">Ref: {entry.reference_number}</Badge>
                      )}
                      <Badge className="bg-blue-100 text-blue-800">{entry.status}</Badge>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {new Date(entry.date).toLocaleDateString()} • {formatCurrency(entry.total_amount)}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDelete(entry.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>

                <div className="space-y-2">
                  {entry.journal_entry_lines.map((line, index) => (
                    <div key={line.id || index} className="grid grid-cols-12 gap-2 text-sm py-1">
                      <div className="col-span-5 text-gray-600">
                        {line.accounts?.account_number} - {line.accounts?.name}
                      </div>
                      <div className="col-span-2 text-right">
                        {line.debit_amount > 0 && formatCurrency(line.debit_amount)}
                      </div>
                      <div className="col-span-2 text-right">
                        {line.credit_amount > 0 && formatCurrency(line.credit_amount)}
                      </div>
                      <div className="col-span-3 text-gray-600">
                        {line.description}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            {journalEntries.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No journal entries found. Create your first journal entry to get started.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

