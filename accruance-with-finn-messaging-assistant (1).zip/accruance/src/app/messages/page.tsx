'use client'

import { useState, useEffect, useRef } from 'react'
import { useAuth } from '@/lib/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import FinnMessagingAssistant from '@/components/finn/messaging-assistant'
import { 
  Send, 
  MessageCircle, 
  Users, 
  Search,
  Phone,
  Video,
  Paperclip,
  Smile,
  MoreVertical,
  Bot
} from 'lucide-react'

interface Message {
  id: string
  content: string
  sender_id: string
  recipient_id: string
  created_at: string
  is_read: boolean
  message_type: string
  sender: {
    id: string
    full_name: string
    avatar_url?: string
  }
}

interface Conversation {
  id: string
  participant1_id: string
  participant2_id: string
  updated_at: string
  participant1: {
    id: string
    full_name: string
    avatar_url?: string
    user_type: string
  }
  participant2: {
    id: string
    full_name: string
    avatar_url?: string
    user_type: string
  }
  last_message?: {
    content: string
    created_at: string
    sender_id: string
    is_read: boolean
  }
}

export default function MessagesPage() {
  const { user } = useAuth()
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [finnAssistantVisible, setFinnAssistantVisible] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (user) {
      fetchConversations()
    }
  }, [user])

  useEffect(() => {
    if (selectedConversation) {
      fetchMessages(selectedConversation)
    }
  }, [selectedConversation])

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const fetchConversations = async () => {
    try {
      const response = await fetch('/api/messages')
      if (response.ok) {
        const data = await response.json()
        setConversations(data.conversations || [])
        if (data.conversations?.length > 0 && !selectedConversation) {
          setSelectedConversation(data.conversations[0].id)
        }
      }
    } catch (error) {
      console.error('Error fetching conversations:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchMessages = async (conversationId: string) => {
    try {
      const response = await fetch(`/api/messages?conversation_id=${conversationId}`)
      if (response.ok) {
        const data = await response.json()
        setMessages(data.messages || [])
      }
    } catch (error) {
      console.error('Error fetching messages:', error)
    }
  }

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim() || !selectedConversation || sending) return

    setSending(true)
    const currentConversation = conversations.find(c => c.id === selectedConversation)
    if (!currentConversation) return

    const recipientId = currentConversation.participant1_id === user?.id 
      ? currentConversation.participant2_id 
      : currentConversation.participant1_id

    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          recipient_id: recipientId,
          content: newMessage.trim(),
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setMessages(prev => [...prev, data.message])
        setNewMessage('')
        fetchConversations() // Refresh to update last message
      }
    } catch (error) {
      console.error('Error sending message:', error)
    } finally {
      setSending(false)
    }
  }

  const getOtherParticipant = (conversation: Conversation) => {
    return conversation.participant1_id === user?.id 
      ? conversation.participant2 
      : conversation.participant1
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    } else if (diffInHours < 168) { // 7 days
      return date.toLocaleDateString([], { weekday: 'short' })
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading messages...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="flex h-screen">
          {/* Conversations Sidebar */}
          <div className="w-1/3 bg-white border-r border-gray-200 flex flex-col">
            {/* Header */}
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-xl font-semibold text-gray-900">Messages</h1>
                <Button size="sm" variant="outline">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  New
                </Button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search conversations..."
                  className="pl-10"
                />
              </div>
            </div>

            {/* Conversations List */}
            <div className="flex-1 overflow-y-auto">
              {conversations.length === 0 ? (
                <div className="text-center py-12">
                  <MessageCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No conversations yet</h3>
                  <p className="text-gray-600 mb-4">Start connecting with financial professionals</p>
                  <Button size="sm">
                    Find Professionals
                  </Button>
                </div>
              ) : (
                conversations.map((conversation) => {
                  const otherParticipant = getOtherParticipant(conversation)
                  const isSelected = selectedConversation === conversation.id
                  const isUnread = conversation.last_message && 
                    !conversation.last_message.is_read && 
                    conversation.last_message.sender_id !== user?.id

                  return (
                    <div
                      key={conversation.id}
                      className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${
                        isSelected ? 'bg-blue-50 border-blue-200' : ''
                      }`}
                      onClick={() => setSelectedConversation(conversation.id)}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
                          {otherParticipant.avatar_url ? (
                            <img 
                              src={otherParticipant.avatar_url} 
                              alt={otherParticipant.full_name}
                              className="w-10 h-10 rounded-full object-cover"
                            />
                          ) : (
                            <span className="text-white font-medium text-sm">
                              {otherParticipant.full_name.split(' ').map(n => n[0]).join('')}
                            </span>
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h3 className={`text-sm font-medium truncate ${
                              isUnread ? 'text-gray-900' : 'text-gray-700'
                            }`}>
                              {otherParticipant.full_name}
                            </h3>
                            {conversation.last_message && (
                              <span className="text-xs text-gray-500 flex-shrink-0">
                                {formatTime(conversation.last_message.created_at)}
                              </span>
                            )}
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <Badge 
                              variant={otherParticipant.user_type === 'financial_professional' ? 'default' : 'secondary'}
                              className="text-xs"
                            >
                              {otherParticipant.user_type === 'financial_professional' ? 'Professional' : 'Business'}
                            </Badge>
                            {isUnread && (
                              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                            )}
                          </div>
                          
                          {conversation.last_message && (
                            <p className={`text-sm truncate mt-1 ${
                              isUnread ? 'text-gray-900 font-medium' : 'text-gray-600'
                            }`}>
                              {conversation.last_message.content}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  )
                })
              )}
            </div>
          </div>

          {/* Chat Area */}
          <div className="flex-1 flex flex-col bg-white">
            {selectedConversation ? (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b border-gray-200 bg-white">
                  {(() => {
                    const currentConversation = conversations.find(c => c.id === selectedConversation)
                    if (!currentConversation) return null
                    const otherParticipant = getOtherParticipant(currentConversation)
                    
                    return (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full flex items-center justify-center">
                            {otherParticipant.avatar_url ? (
                              <img 
                                src={otherParticipant.avatar_url} 
                                alt={otherParticipant.full_name}
                                className="w-10 h-10 rounded-full object-cover"
                              />
                            ) : (
                              <span className="text-white font-medium text-sm">
                                {otherParticipant.full_name.split(' ').map(n => n[0]).join('')}
                              </span>
                            )}
                          </div>
                          <div>
                            <h2 className="text-lg font-semibold text-gray-900">
                              {otherParticipant.full_name}
                            </h2>
                            <Badge 
                              variant={otherParticipant.user_type === 'financial_professional' ? 'default' : 'secondary'}
                              className="text-xs"
                            >
                              {otherParticipant.user_type === 'financial_professional' ? 'Financial Professional' : 'Business Owner'}
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Button variant="outline" size="sm">
                            <Phone className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Video className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    )
                  })()}
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => {
                    const isOwn = message.sender_id === user?.id
                    
                    return (
                      <div
                        key={message.id}
                        className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                          isOwn 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-gray-100 text-gray-900'
                        }`}>
                          <p className="text-sm">{message.content}</p>
                          <p className={`text-xs mt-1 ${
                            isOwn ? 'text-blue-100' : 'text-gray-500'
                          }`}>
                            {formatTime(message.created_at)}
                          </p>
                        </div>
                      </div>
                    )
                  })}
                  <div ref={messagesEndRef} />
                </div>

                {/* Message Input */}
                <div className="p-4 border-t border-gray-200 bg-white">
                  <form onSubmit={sendMessage} className="flex items-center space-x-2">
                    <Button type="button" variant="outline" size="sm">
                      <Paperclip className="w-4 h-4" />
                    </Button>
                    <div className="flex-1 relative">
                      <Input
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type a message..."
                        disabled={sending}
                      />
                      <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setFinnAssistantVisible(!finnAssistantVisible)}
                          className={`${finnAssistantVisible ? 'bg-blue-100 text-blue-600' : ''}`}
                          title="FINN Assistant - Perfect your message"
                        >
                          <Bot className="w-4 h-4" />
                        </Button>
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="sm"
                        >
                          <Smile className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <Button type="submit" disabled={!newMessage.trim() || sending}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </form>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Select a conversation</h3>
                  <p className="text-gray-600">Choose a conversation from the sidebar to start messaging</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* FINN Messaging Assistant */}
      {selectedConversation && (
        <FinnMessagingAssistant
          messageText={newMessage}
          onMessageChange={setNewMessage}
          recipientContext={(() => {
            const currentConversation = conversations.find(c => c.id === selectedConversation)
            if (!currentConversation) return null
            return getOtherParticipant(currentConversation)
          })()}
          conversationContext={{
            conversation_id: selectedConversation,
            message_history: messages.slice(-5), // Last 5 messages for context
            conversation_type: 'professional_networking'
          }}
          isVisible={finnAssistantVisible}
          onToggleVisibility={() => setFinnAssistantVisible(!finnAssistantVisible)}
          onSendMessage={() => {
            if (newMessage.trim()) {
              const form = document.querySelector('form') as HTMLFormElement
              if (form) {
                form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }))
              }
            }
          }}
        />
      )}
    </div>
  )
}

