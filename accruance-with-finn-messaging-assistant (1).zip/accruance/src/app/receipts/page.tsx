'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { ReceiptUpload } from '@/components/receipts/receipt-upload'
import { ReceiptList } from '@/components/receipts/receipt-list'
import { ReceiptViewer } from '@/components/receipts/receipt-viewer'
import { ReceiptTransactionMatcher } from '@/components/receipts/receipt-transaction-matcher'
import { DuplicateDetectionInterface } from '@/components/receipts/duplicate-detection-interface'
import { MobileCameraIntegration } from '@/components/receipts/mobile-camera-integration'
import type { ReceiptData } from '@/lib/receipt-manager'

type ViewMode = 'list' | 'upload' | 'viewer' | 'camera' | 'matching' | 'duplicates'

export default function ReceiptsPage() {
  const { organization, user } = useAuth()
  const [viewMode, setViewMode] = useState<ViewMode>('list')
  const [selectedReceipt, setSelectedReceipt] = useState<ReceiptData | null>(null)
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  const handleUploadComplete = (receipt: ReceiptData) => {
    setRefreshTrigger(prev => prev + 1)
    console.log('Receipt uploaded successfully:', receipt)
  }

  const handleUploadError = (error: string) => {
    console.error('Upload error:', error)
  }

  const handleReceiptSelect = (receipt: ReceiptData) => {
    setSelectedReceipt(receipt)
    setViewMode('viewer')
  }

  const handleReceiptUpdate = (updatedReceipt: ReceiptData) => {
    setSelectedReceipt(updatedReceipt)
    setRefreshTrigger(prev => prev + 1)
  }

  const handleCloseViewer = () => {
    setSelectedReceipt(null)
    setViewMode('list')
  }

  const handleMatchComplete = () => {
    setRefreshTrigger(prev => prev + 1)
  }

  const handleDuplicatesResolved = () => {
    setRefreshTrigger(prev => prev + 1)
  }

  if (!organization?.id || !user?.id) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Please complete your organization setup first.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">A</span>
                </div>
                <span className="text-xl font-bold text-gray-900">Accruance</span>
              </div>
              <div className="text-gray-400">|</div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">
                  {viewMode === 'upload' ? 'Upload Receipts' :
                   viewMode === 'camera' ? 'Camera Capture' :
                   viewMode === 'matching' ? 'Receipt Matching' :
                   viewMode === 'duplicates' ? 'Duplicate Detection' :
                   viewMode === 'viewer' ? 'Receipt Details' : 'Receipt Management'}
                </h1>
                <p className="text-sm text-gray-500">{organization?.name}</p>
              </div>
            </div>

            {/* Navigation */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode('list')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  viewMode === 'list'
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Library
              </button>
              <button
                onClick={() => setViewMode('upload')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  viewMode === 'upload'
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Upload
              </button>
              <button
                onClick={() => setViewMode('camera')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  viewMode === 'camera'
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Camera
              </button>
              <button
                onClick={() => setViewMode('matching')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  viewMode === 'matching'
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Matching
              </button>
              <button
                onClick={() => setViewMode('duplicates')}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  viewMode === 'duplicates'
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                Duplicates
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        {viewMode === 'upload' && (
          <div className="max-w-4xl mx-auto">
            <ReceiptUpload
              organizationId={organization.id}
              userId={user.id}
              onUploadComplete={handleUploadComplete}
              onUploadError={handleUploadError}
            />
          </div>
        )}

        {viewMode === 'camera' && (
          <div className="max-w-4xl mx-auto">
            <MobileCameraIntegration
              organizationId={organization.id}
              userId={user.id}
              onCaptureComplete={handleUploadComplete}
              onError={handleUploadError}
            />
          </div>
        )}

        {viewMode === 'list' && (
          <div className="max-w-7xl mx-auto">
            <ReceiptList
              organizationId={organization.id}
              refreshTrigger={refreshTrigger}
              onReceiptSelect={handleReceiptSelect}
            />
          </div>
        )}

        {viewMode === 'matching' && (
          <div className="max-w-6xl mx-auto">
            <ReceiptTransactionMatcher
              organizationId={organization.id}
              onMatchComplete={handleMatchComplete}
            />
          </div>
        )}

        {viewMode === 'duplicates' && (
          <div className="max-w-6xl mx-auto">
            <DuplicateDetectionInterface
              organizationId={organization.id}
              onDuplicatesResolved={handleDuplicatesResolved}
            />
          </div>
        )}

        {viewMode === 'viewer' && selectedReceipt && (
          <ReceiptViewer
            receipt={selectedReceipt}
            onClose={handleCloseViewer}
            onUpdate={handleReceiptUpdate}
          />
        )}
      </main>
    </div>
  )
}

