## 📋 Description
Brief description of the changes in this PR.

## 🔗 Related Issues
Fixes #(issue number)
Relates to #(issue number)

## 🎯 Type of Change
- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Code refactoring
- [ ] Security fix

## 🧪 Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed
- [ ] Cross-browser testing (if applicable)
- [ ] Mobile testing (if applicable)

## 📸 Screenshots/Videos
If applicable, add screenshots or videos to demonstrate the changes.

## 🔍 Code Review Checklist
- [ ] Code follows the project's style guidelines
- [ ] Self-review of code completed
- [ ] Code is commented, particularly in hard-to-understand areas
- [ ] Corresponding changes to documentation made
- [ ] No new warnings introduced
- [ ] Tests added that prove the fix is effective or feature works
- [ ] New and existing unit tests pass locally

## 🚀 Deployment Notes
Any special deployment considerations:
- [ ] Database migrations required
- [ ] Environment variables added/changed
- [ ] Third-party service configuration needed
- [ ] Cache clearing required

## 🔒 Security Considerations
- [ ] No sensitive data exposed
- [ ] Authentication/authorization properly implemented
- [ ] Input validation added where needed
- [ ] SQL injection prevention considered
- [ ] XSS prevention considered

## 📊 Performance Impact
- [ ] No performance degradation
- [ ] Performance improvements included
- [ ] Database query optimization considered
- [ ] Bundle size impact minimal

## 🌐 Accessibility
- [ ] Keyboard navigation works
- [ ] Screen reader compatible
- [ ] Color contrast meets standards
- [ ] Alt text added for images

## 📱 Mobile Responsiveness
- [ ] Works on mobile devices
- [ ] Touch interactions work properly
- [ ] Responsive design maintained

## 🔄 Breaking Changes
List any breaking changes and migration steps:

## 📚 Documentation
- [ ] README updated
- [ ] API documentation updated
- [ ] Code comments added
- [ ] Changelog updated

## ✅ Final Checklist
- [ ] All tests pass
- [ ] Code review completed
- [ ] Documentation updated
- [ ] Ready for deployment

