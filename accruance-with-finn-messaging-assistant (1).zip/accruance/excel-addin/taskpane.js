// Accruance Excel Add-in - Taskpane JavaScript
// Handles two-way sync between Excel and Accruance

Office.onReady((info) => {
    if (info.host === Office.HostType.Excel) {
        document.getElementById('connectBtn').onclick = connectToAccruance;
        document.getElementById('refreshBtn').onclick = refreshData;
        document.getElementById('pushBtn').onclick = pushAdjustments;
        document.getElementById('dateRange').onchange = handleDateRangeChange;
        
        // Load saved settings
        loadSettings();
        
        // Check if already connected
        checkConnection();
    }
});

// Global variables
let accruanceConfig = {
    apiKey: '',
    baseUrl: '',
    connected: false,
    autoRefreshInterval: null
};

let syncState = {
    isRefreshing: false,
    isPushing: false,
    lastRefresh: null,
    originalData: null,
    currentRange: null
};

// Authentication and Connection
async function connectToAccruance() {
    const apiKey = document.getElementById('apiKey').value.trim();
    
    if (!apiKey) {
        showMessage('Please enter your Accruance API key', 'error');
        return;
    }

    try {
        showLoading('connectBtn', true);
        
        // Validate API key with Accruance
        const response = await fetch('/api/excel/authenticate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({ source: 'excel_addin' })
        });

        if (response.ok) {
            const data = await response.json();
            
            accruanceConfig.apiKey = apiKey;
            accruanceConfig.baseUrl = data.baseUrl || window.location.origin;
            accruanceConfig.connected = true;
            
            // Save to Office settings
            await saveSettings();
            
            updateConnectionStatus(true, data.user?.email);
            showSyncSection();
            showMessage('Successfully connected to Accruance!', 'success');
            
        } else {
            throw new Error('Invalid API key or connection failed');
        }
        
    } catch (error) {
        console.error('Connection error:', error);
        showMessage('Failed to connect to Accruance. Please check your API key.', 'error');
        accruanceConfig.connected = false;
        updateConnectionStatus(false);
    } finally {
        showLoading('connectBtn', false);
    }
}

async function checkConnection() {
    try {
        const settings = await loadSettings();
        if (settings.apiKey) {
            document.getElementById('apiKey').value = settings.apiKey;
            await connectToAccruance();
        }
    } catch (error) {
        console.error('Error checking connection:', error);
    }
}

// Data Refresh (Pull from Accruance)
async function refreshData() {
    if (!accruanceConfig.connected) {
        showMessage('Please connect to Accruance first', 'error');
        return;
    }

    if (syncState.isRefreshing) {
        showMessage('Refresh already in progress', 'warning');
        return;
    }

    try {
        syncState.isRefreshing = true;
        showLoading('refreshBtn', true);
        showProgress(0, 'Preparing to refresh data...');

        await Excel.run(async (context) => {
            const worksheet = context.workbook.worksheets.getActiveWorksheet();
            
            // Get or detect data range
            const range = await getDataRange(context, worksheet);
            syncState.currentRange = range.address;
            
            showProgress(20, 'Backing up existing data...');
            
            // Backup existing data and formulas
            const backup = await backupExcelData(context, range);
            syncState.originalData = backup;
            
            showProgress(40, 'Fetching data from Accruance...');
            
            // Fetch fresh data from Accruance
            const accruanceData = await fetchAccruanceData();
            
            showProgress(60, 'Updating Excel with new data...');
            
            // Update Excel while preserving formulas
            await updateExcelData(context, range, accruanceData, backup);
            
            showProgress(80, 'Finalizing...');
            
            await context.sync();
            
            showProgress(100, 'Refresh complete!');
            
            syncState.lastRefresh = new Date();
            showMessage(`Data refreshed successfully! ${accruanceData.records.length} records updated.`, 'success');
            
            // Show preview
            showDataPreview(accruanceData);
            
        });
        
    } catch (error) {
        console.error('Refresh error:', error);
        showMessage(`Refresh failed: ${error.message}`, 'error');
        
        // Attempt to restore backup if available
        if (syncState.originalData) {
            await restoreBackup();
        }
        
    } finally {
        syncState.isRefreshing = false;
        showLoading('refreshBtn', false);
        hideProgress();
    }
}

// Data Push (Send changes to Accruance)
async function pushAdjustments() {
    if (!accruanceConfig.connected) {
        showMessage('Please connect to Accruance first', 'error');
        return;
    }

    if (syncState.isPushing) {
        showMessage('Push already in progress', 'warning');
        return;
    }

    if (!syncState.originalData) {
        showMessage('No baseline data available. Please refresh data first.', 'error');
        return;
    }

    try {
        syncState.isPushing = true;
        showLoading('pushBtn', true);
        showProgress(0, 'Analyzing changes...');

        await Excel.run(async (context) => {
            const worksheet = context.workbook.worksheets.getActiveWorksheet();
            const range = worksheet.getRange(syncState.currentRange);
            
            showProgress(20, 'Detecting modifications...');
            
            // Detect changes
            const changes = await detectChanges(context, range, syncState.originalData);
            
            if (changes.length === 0) {
                showMessage('No changes detected to push', 'info');
                return;
            }

            showProgress(40, 'Validating changes...');
            
            // Validate changes
            const validation = await validateChanges(changes);
            if (!validation.valid) {
                showMessage(`Validation failed: ${validation.errors.join(', ')}`, 'error');
                return;
            }

            showProgress(60, 'Pushing changes to Accruance...');
            
            // Push to Accruance
            const pushResult = await pushToAccruance(changes);
            
            showProgress(80, 'Updating audit trail...');
            
            // Update audit trail
            await updateAuditTrail(changes, pushResult);
            
            showProgress(100, 'Push complete!');
            
            showMessage(`Successfully pushed ${changes.length} changes to Accruance`, 'success');
            
            // Update original data to reflect pushed changes
            syncState.originalData = await backupExcelData(context, range);
            
        });
        
    } catch (error) {
        console.error('Push error:', error);
        showMessage(`Push failed: ${error.message}`, 'error');
    } finally {
        syncState.isPushing = false;
        showLoading('pushBtn', false);
        hideProgress();
    }
}

// Helper Functions

async function getDataRange(context, worksheet) {
    const rangeInput = document.getElementById('dataRange').value.trim();
    
    if (rangeInput) {
        return worksheet.getRange(rangeInput);
    } else {
        // Auto-detect data range
        const usedRange = worksheet.getUsedRange();
        await context.sync();
        return usedRange;
    }
}

async function backupExcelData(context, range) {
    range.load(['values', 'formulas', 'format', 'address']);
    await context.sync();
    
    return {
        address: range.address,
        values: range.values,
        formulas: range.formulas,
        format: {
            // Store formatting information
            fill: range.format.fill,
            font: range.format.font,
            borders: range.format.borders
        },
        timestamp: new Date().toISOString()
    };
}

async function fetchAccruanceData() {
    const dataType = document.getElementById('dataType').value;
    const dateRange = getDateRangeParams();
    
    const response = await fetch('/api/excel/pull-data', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accruanceConfig.apiKey}`
        },
        body: JSON.stringify({
            dataType,
            dateRange,
            preserveFormulas: document.getElementById('preserveFormulas').checked,
            preserveFormatting: document.getElementById('preserveFormatting').checked
        })
    });

    if (!response.ok) {
        throw new Error(`Failed to fetch data: ${response.statusText}`);
    }

    return await response.json();
}

async function updateExcelData(context, range, accruanceData, backup) {
    const preserveFormulas = document.getElementById('preserveFormulas').checked;
    const preserveFormatting = document.getElementById('preserveFormatting').checked;
    
    // Clear existing data
    range.clear();
    
    // Set headers
    if (accruanceData.headers) {
        const headerRange = range.getCell(0, 0).getResizedRange(0, accruanceData.headers.length - 1);
        headerRange.values = [accruanceData.headers];
        
        // Apply header formatting
        headerRange.format.font.bold = true;
        headerRange.format.fill.color = '#f0f0f0';
    }
    
    // Set data values
    if (accruanceData.records && accruanceData.records.length > 0) {
        const dataStartRow = accruanceData.headers ? 1 : 0;
        const dataRange = range.getCell(dataStartRow, 0)
            .getResizedRange(accruanceData.records.length - 1, accruanceData.records[0].length - 1);
        
        dataRange.values = accruanceData.records;
    }
    
    // Restore formulas if preserving
    if (preserveFormulas && backup.formulas) {
        await restoreFormulas(context, range, backup.formulas, accruanceData);
    }
    
    // Restore formatting if preserving
    if (preserveFormatting && backup.format) {
        await restoreFormatting(context, range, backup.format);
    }
    
    await context.sync();
}

async function restoreFormulas(context, range, originalFormulas, newData) {
    // Intelligent formula restoration
    // This preserves formulas that reference other cells while updating data cells
    
    for (let row = 0; row < originalFormulas.length; row++) {
        for (let col = 0; col < originalFormulas[row].length; col++) {
            const formula = originalFormulas[row][col];
            
            if (formula && formula.startsWith('=')) {
                // This is a formula - preserve it
                const cell = range.getCell(row, col);
                cell.formulas = [[formula]];
            }
        }
    }
    
    await context.sync();
}

async function restoreFormatting(context, range, originalFormat) {
    // Restore basic formatting
    if (originalFormat.fill) {
        range.format.fill.color = originalFormat.fill.color;
    }
    
    if (originalFormat.font) {
        range.format.font.name = originalFormat.font.name;
        range.format.font.size = originalFormat.font.size;
        range.format.font.bold = originalFormat.font.bold;
    }
    
    await context.sync();
}

async function detectChanges(context, range, originalData) {
    range.load(['values', 'formulas']);
    await context.sync();
    
    const changes = [];
    const currentValues = range.values;
    const originalValues = originalData.values;
    
    for (let row = 0; row < currentValues.length; row++) {
        for (let col = 0; col < currentValues[row].length; col++) {
            const currentValue = currentValues[row][col];
            const originalValue = originalValues[row] ? originalValues[row][col] : null;
            
            if (currentValue !== originalValue) {
                changes.push({
                    row,
                    col,
                    address: range.getCell(row, col).address,
                    oldValue: originalValue,
                    newValue: currentValue,
                    type: 'value_change'
                });
            }
        }
    }
    
    return changes;
}

async function validateChanges(changes) {
    const validateData = document.getElementById('validateData').checked;
    
    if (!validateData) {
        return { valid: true, errors: [] };
    }
    
    const errors = [];
    
    for (const change of changes) {
        // Basic validation rules
        if (change.newValue === null || change.newValue === '') {
            errors.push(`Empty value at ${change.address}`);
        }
        
        // Type validation
        if (typeof change.oldValue === 'number' && isNaN(Number(change.newValue))) {
            errors.push(`Invalid number format at ${change.address}`);
        }
        
        // Date validation
        if (change.oldValue instanceof Date && isNaN(Date.parse(change.newValue))) {
            errors.push(`Invalid date format at ${change.address}`);
        }
    }
    
    return {
        valid: errors.length === 0,
        errors
    };
}

async function pushToAccruance(changes) {
    const response = await fetch('/api/excel/push-adjustments', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accruanceConfig.apiKey}`
        },
        body: JSON.stringify({
            changes,
            metadata: {
                range: syncState.currentRange,
                timestamp: new Date().toISOString(),
                source: 'excel_addin'
            }
        })
    });

    if (!response.ok) {
        throw new Error(`Failed to push changes: ${response.statusText}`);
    }

    return await response.json();
}

async function updateAuditTrail(changes, pushResult) {
    // Log the changes for audit purposes
    console.log('Audit Trail:', {
        changes,
        pushResult,
        timestamp: new Date().toISOString(),
        user: accruanceConfig.userEmail
    });
}

// UI Helper Functions

function updateConnectionStatus(connected, userEmail = '') {
    const statusElement = document.getElementById('connectionStatus');
    const statusText = document.getElementById('statusText');
    
    if (connected) {
        statusElement.className = 'status connected';
        statusText.textContent = `Connected to Accruance${userEmail ? ` (${userEmail})` : ''}`;
    } else {
        statusElement.className = 'status disconnected';
        statusText.textContent = 'Not connected to Accruance';
    }
}

function showSyncSection() {
    document.getElementById('authSection').classList.add('hidden');
    document.getElementById('syncSection').classList.remove('hidden');
    document.getElementById('settingsSection').classList.remove('hidden');
}

function showProgress(percent, message) {
    const container = document.getElementById('progressContainer');
    const fill = document.getElementById('progressFill');
    const text = document.getElementById('progressText');
    
    container.classList.remove('hidden');
    fill.style.width = `${percent}%`;
    text.textContent = message;
}

function hideProgress() {
    document.getElementById('progressContainer').classList.add('hidden');
}

function showLoading(buttonId, loading) {
    const button = document.getElementById(buttonId);
    const icon = button.querySelector('span');
    
    if (loading) {
        button.disabled = true;
        if (icon) icon.innerHTML = '<div class="loading"></div>';
    } else {
        button.disabled = false;
        if (icon) {
            if (buttonId === 'refreshBtn') icon.textContent = '🔄';
            if (buttonId === 'pushBtn') icon.textContent = '⬆️';
        }
    }
}

function showMessage(message, type) {
    const messagesContainer = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    
    messageDiv.className = `${type}-message`;
    messageDiv.textContent = message;
    
    messagesContainer.appendChild(messageDiv);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.parentNode.removeChild(messageDiv);
        }
    }, 5000);
}

function showDataPreview(data) {
    const preview = document.getElementById('dataPreview');
    const previewSection = document.getElementById('previewSection');
    
    if (data.records && data.records.length > 0) {
        const previewText = data.records.slice(0, 5)
            .map(record => record.join('\t'))
            .join('\n');
        
        preview.textContent = `${data.headers ? data.headers.join('\t') + '\n' : ''}${previewText}`;
        previewSection.classList.remove('hidden');
    }
}

function handleDateRangeChange() {
    const dateRange = document.getElementById('dateRange').value;
    const customRange = document.getElementById('customDateRange');
    
    if (dateRange === 'custom') {
        customRange.classList.remove('hidden');
    } else {
        customRange.classList.add('hidden');
    }
}

function getDateRangeParams() {
    const dateRange = document.getElementById('dateRange').value;
    
    if (dateRange === 'custom') {
        return {
            type: 'custom',
            startDate: document.getElementById('startDate').value,
            endDate: document.getElementById('endDate').value
        };
    }
    
    return { type: dateRange };
}

// Settings Management

async function saveSettings() {
    try {
        await Office.context.roamingSettings.set('accruanceApiKey', accruanceConfig.apiKey);
        await Office.context.roamingSettings.set('accruanceBaseUrl', accruanceConfig.baseUrl);
        await Office.context.roamingSettings.saveAsync();
    } catch (error) {
        console.error('Error saving settings:', error);
    }
}

async function loadSettings() {
    try {
        const apiKey = await Office.context.roamingSettings.get('accruanceApiKey');
        const baseUrl = await Office.context.roamingSettings.get('accruanceBaseUrl');
        
        return { apiKey, baseUrl };
    } catch (error) {
        console.error('Error loading settings:', error);
        return {};
    }
}

// Auto-refresh functionality
function setupAutoRefresh() {
    const interval = parseInt(document.getElementById('autoRefresh').value);
    
    if (accruanceConfig.autoRefreshInterval) {
        clearInterval(accruanceConfig.autoRefreshInterval);
    }
    
    if (interval > 0) {
        accruanceConfig.autoRefreshInterval = setInterval(() => {
            if (accruanceConfig.connected && !syncState.isRefreshing) {
                refreshData();
            }
        }, interval * 1000);
    }
}

// Event listeners for settings
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('autoRefresh').addEventListener('change', setupAutoRefresh);
});

