# Core Bookkeeping Engine Documentation

## Overview
The Core Bookkeeping Engine is the heart of Accruance's accounting functionality, providing comprehensive transaction management with AI-powered categorization, bulk operations, keyboard shortcuts, and audit trails.

## Features Implemented

### 1. AI-Powered Transaction Categorization
- **Intelligent pattern recognition** using regex and keyword matching
- **Confidence scoring** based on multiple factors (pattern match, keywords, amount range)
- **7 pre-built categorization rules** for common business expenses and income
- **Real-time suggestions** as users type transaction descriptions
- **Manual override capability** for user corrections and learning

#### AI Categorization Rules:
1. **Office Supplies** - Detects office supply purchases (95% confidence)
2. **Fuel & Gas** - Identifies gas station transactions (90% confidence)
3. **Meals & Entertainment** - Recognizes restaurant and food expenses (85% confidence)
4. **Software & Subscriptions** - Catches SaaS and software expenses (92% confidence)
5. **Rent & Lease** - Identifies property and office rent (98% confidence)
6. **Marketing & Advertising** - Detects advertising spend (88% confidence)
7. **Sales Revenue** - Recognizes client payments and sales (95% confidence)

### 2. Comprehensive Transaction Management
- **Create, Read, Update, Delete** operations for all transactions
- **Form validation** with real-time error feedback
- **Auto-save functionality** with keyboard shortcuts
- **Transaction status tracking** (Pending, Cleared, Reconciled)
- **Reference and notes** support for detailed record keeping

### 3. Advanced Filtering and Search
- **Multi-criteria filtering**: Date range, type, status, amount range
- **Real-time search** across transaction descriptions
- **Advanced filter panel** with collapsible interface
- **Persistent filter state** for user convenience
- **Smart search suggestions** based on transaction history

### 4. Bulk Operations and Management
- **Multi-select functionality** with visual feedback
- **Bulk categorization** for efficient transaction management
- **Bulk status updates** (reconciliation, clearing)
- **Bulk deletion** with confirmation prompts
- **Bulk export** for reporting and analysis
- **Select all/none** toggle for convenience

### 5. Professional Data Table
- **Sortable columns** (Date, Description, Amount) with visual indicators
- **Responsive design** that works on all screen sizes
- **Status badges** with color-coded visual feedback
- **Amount formatting** with proper currency display
- **Row selection** with checkbox interface
- **Hover effects** and smooth animations

### 6. Keyboard Shortcuts and Accessibility
- **Ctrl+N**: Create new transaction
- **Ctrl+A**: Select all transactions
- **Ctrl+F**: Focus search input
- **Ctrl+S**: Save transaction form
- **Escape**: Cancel/clear selection
- **Delete**: Delete selected transactions
- **Ctrl+Shift+A**: Analyze transaction with AI
- **Ctrl+Shift+C**: Categorize selected transactions

### 7. Audit Trail and Compliance
- **Automatic audit logging** for all transaction changes
- **User attribution** for accountability
- **Timestamp tracking** for compliance requirements
- **Change history** with before/after values
- **Action logging** (created, updated, deleted, categorized)

## Technical Implementation

### BookkeepingEngine Service
```typescript
class BookkeepingEngine {
  // AI categorization with confidence scoring
  static async categorizeTransaction(description, amount, merchant)
  
  // CRUD operations
  static async createTransaction(organizationId, data)
  static async updateTransaction(transactionId, updates)
  static async deleteTransaction(transactionId)
  
  // Bulk operations
  static async bulkUpdateTransactions(transactionIds, action)
  
  // Data retrieval with filtering
  static async getTransactions(organizationId, filters, page, limit)
  
  // Audit trail
  static async createAuditEntry(transactionId, action, oldValues, newValues)
}
```

### Component Architecture
```
bookkeeping/
├── transaction-form.tsx     # AI-powered transaction creation/editing
├── transaction-list.tsx     # Advanced table with filtering and bulk actions
└── transactions/page.tsx    # Main page combining form and list
```

### AI Categorization Algorithm
1. **Pattern Matching**: Regex patterns for merchant names and descriptions
2. **Keyword Analysis**: Weighted scoring based on relevant keywords
3. **Amount Range Validation**: Ensures amounts fall within expected ranges
4. **Confidence Calculation**: Multi-factor scoring with threshold filtering
5. **Suggestion Ranking**: Top 3 suggestions sorted by confidence

### Data Structures
```typescript
interface TransactionFormData {
  date: string
  description: string
  amount: number
  type: 'income' | 'expense'
  category_id: string
  account_id: string
  reference?: string
  notes?: string
}

interface CategorizationSuggestion {
  category_id: string
  category_name: string
  confidence: number
  reason: string
  rule_id?: string
}
```

## User Experience Features

### 1. Intelligent Form Design
- **Auto-focus** on description field for quick entry
- **Real-time validation** with helpful error messages
- **Smart defaults** based on transaction type
- **Progressive disclosure** of advanced options
- **Keyboard navigation** support throughout

### 2. AI Suggestion Interface
- **Visual confidence indicators** with percentage display
- **Contextual explanations** for why categories were suggested
- **One-click application** of suggestions
- **Manual analysis trigger** for on-demand categorization
- **Learning feedback** for improved accuracy

### 3. Bulk Operations UX
- **Visual selection feedback** with highlighted rows
- **Action confirmation** for destructive operations
- **Progress indicators** for long-running operations
- **Undo functionality** for accidental changes
- **Smart action suggestions** based on selection

### 4. Responsive Design
- **Mobile-optimized** table with horizontal scrolling
- **Touch-friendly** controls and buttons
- **Adaptive layouts** for different screen sizes
- **Consistent spacing** and typography
- **Accessible color schemes** for all users

## Performance Optimizations

### 1. Efficient Data Loading
- **Pagination** for large transaction sets
- **Lazy loading** of non-critical data
- **Debounced search** to reduce API calls
- **Memoized components** to prevent unnecessary re-renders
- **Optimistic updates** for better perceived performance

### 2. Smart Caching
- **Client-side caching** of frequently accessed data
- **Cache invalidation** on data changes
- **Background refresh** for real-time updates
- **Offline support** for basic operations
- **Progressive enhancement** for better connectivity

### 3. AI Processing Optimization
- **Debounced analysis** to avoid excessive API calls
- **Local rule processing** for instant feedback
- **Batch categorization** for bulk operations
- **Rule caching** for improved response times
- **Fallback mechanisms** for service unavailability

## Security and Compliance

### 1. Data Protection
- **Organization-level isolation** ensuring data privacy
- **Role-based access control** for team environments
- **Encrypted data transmission** for all API calls
- **Audit logging** for compliance requirements
- **Data retention policies** for regulatory compliance

### 2. Input Validation
- **Server-side validation** for all form inputs
- **SQL injection prevention** through parameterized queries
- **XSS protection** with proper input sanitization
- **CSRF protection** for state-changing operations
- **Rate limiting** to prevent abuse

### 3. Audit Trail Features
- **Immutable audit logs** for compliance
- **User attribution** for accountability
- **Timestamp precision** for accurate tracking
- **Change detection** with detailed diff logging
- **Export capabilities** for external auditing

## Integration Points

### 1. Database Integration
- **Supabase integration** ready for production deployment
- **Real-time subscriptions** for live data updates
- **Row Level Security** for multi-tenant architecture
- **Optimized queries** with proper indexing
- **Transaction support** for data consistency

### 2. AI Service Integration
- **Extensible rule engine** for custom categorization
- **Machine learning pipeline** ready for advanced AI
- **Feedback loop** for continuous improvement
- **A/B testing** framework for rule optimization
- **Analytics integration** for performance monitoring

### 3. External Integrations
- **Bank feed integration** ready for Plaid/Yodlee
- **Receipt OCR** integration points prepared
- **Export formats** for accounting software
- **API endpoints** for third-party integrations
- **Webhook support** for real-time notifications

## Future Enhancements

### 1. Advanced AI Features
- **Machine learning models** for improved categorization
- **Anomaly detection** for fraud prevention
- **Predictive analytics** for cash flow forecasting
- **Natural language processing** for better description parsing
- **Custom rule creation** through UI

### 2. Enhanced User Experience
- **Drag-and-drop** transaction management
- **Bulk import** from CSV/Excel files
- **Advanced reporting** with custom date ranges
- **Transaction templates** for recurring entries
- **Mobile app** with offline capabilities

### 3. Enterprise Features
- **Multi-currency support** for international businesses
- **Advanced approval workflows** for large organizations
- **Integration marketplace** for third-party apps
- **Custom field support** for industry-specific needs
- **Advanced analytics** with business intelligence

This Core Bookkeeping Engine provides a solid foundation for professional accounting software that rivals industry leaders while offering superior AI-powered features and modern user experience design.

