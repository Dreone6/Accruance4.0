# 🚀 Accruance Deployment Guide

This guide covers deploying Accruance to production environments with best practices for security, performance, and scalability.

## 📋 Pre-Deployment Checklist

### ✅ Environment Setup
- [ ] Production Supabase project created
- [ ] Production Stripe account configured
- [ ] OpenAI API key obtained
- [ ] Mapbox token configured
- [ ] Domain name registered
- [ ] SSL certificate ready
- [ ] CDN configured (optional)

### ✅ Security Checklist
- [ ] Environment variables secured
- [ ] Database RLS policies enabled
- [ ] API rate limiting configured
- [ ] CORS policies set
- [ ] Security headers configured
- [ ] Audit logging enabled

### ✅ Performance Checklist
- [ ] Database indexes optimized
- [ ] Image optimization enabled
- [ ] Caching strategy implemented
- [ ] Bundle size analyzed
- [ ] Performance monitoring setup

## 🌐 Deployment Options

### Option 1: Vercel (Recommended)

#### Why Vercel?
- **Seamless Next.js integration**
- **Automatic deployments from Git**
- **Global CDN included**
- **Serverless functions**
- **Built-in analytics**

#### Setup Steps:

1. **Connect Repository**
```bash
# Push your code to GitHub first
git add .
git commit -m "Ready for production deployment"
git push origin main
```

2. **Import to Vercel**
- Go to [vercel.com](https://vercel.com)
- Click "New Project"
- Import your GitHub repository
- Configure build settings (auto-detected)

3. **Environment Variables**
Add these in Vercel dashboard:
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
OPENAI_API_KEY=sk-your_openai_key
NEXT_PUBLIC_MAPBOX_TOKEN=pk.your_mapbox_token
STRIPE_SECRET_KEY=sk_live_your_stripe_key
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_your_stripe_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
NEXT_PUBLIC_APP_URL=https://your-domain.com
```

4. **Custom Domain**
- Add your domain in Vercel dashboard
- Configure DNS records
- SSL automatically provisioned

#### Vercel Configuration File
Create `vercel.json`:
```json
{
  "framework": "nextjs",
  "buildCommand": "npm run build",
  "devCommand": "npm run dev",
  "installCommand": "npm install",
  "functions": {
    "src/app/api/**/*.ts": {
      "maxDuration": 30
    }
  },
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        {
          "key": "Access-Control-Allow-Origin",
          "value": "*"
        },
        {
          "key": "Access-Control-Allow-Methods",
          "value": "GET, POST, PUT, DELETE, OPTIONS"
        },
        {
          "key": "Access-Control-Allow-Headers",
          "value": "Content-Type, Authorization"
        }
      ]
    }
  ],
  "rewrites": [
    {
      "source": "/api/stripe-webhook",
      "destination": "/api/stripe-webhook"
    }
  ]
}
```

### Option 2: Netlify

#### Setup Steps:
1. **Connect Repository**
- Go to [netlify.com](https://netlify.com)
- Click "New site from Git"
- Connect your GitHub repository

2. **Build Settings**
```
Build command: npm run build
Publish directory: .next
```

3. **Environment Variables**
Add the same variables as Vercel in Netlify dashboard

### Option 3: Self-Hosted (Advanced)

#### Server Requirements:
- **Node.js 18+**
- **PM2 for process management**
- **Nginx for reverse proxy**
- **SSL certificate (Let's Encrypt)**

#### Setup Steps:

1. **Server Setup**
```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2
npm install -g pm2

# Install Nginx
sudo apt update
sudo apt install nginx
```

2. **Application Deployment**
```bash
# Clone repository
git clone https://github.com/your-username/accruance.git
cd accruance

# Install dependencies
npm install

# Build application
npm run build

# Start with PM2
pm2 start npm --name "accruance" -- start
pm2 save
pm2 startup
```

3. **Nginx Configuration**
Create `/etc/nginx/sites-available/accruance`:
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

4. **SSL with Let's Encrypt**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## 🗄️ Database Setup

### Production Supabase Configuration

1. **Create Production Project**
- Go to [supabase.com](https://supabase.com)
- Create new project
- Choose production-ready region
- Configure strong database password

2. **Run Migrations**
```bash
# Install Supabase CLI
npm install -g supabase

# Link to production project
supabase link --project-ref your-project-ref

# Run migrations
supabase db push
```

3. **Configure RLS Policies**
All RLS policies are included in migrations, but verify:
```sql
-- Check RLS is enabled
SELECT schemaname, tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public' AND rowsecurity = true;

-- Check policies exist
SELECT schemaname, tablename, policyname 
FROM pg_policies 
WHERE schemaname = 'public';
```

4. **Database Performance**
```sql
-- Create additional indexes for production
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_transactions_organization_date 
ON transactions(organization_id, date DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_invoices_organization_status_date 
ON invoices(organization_id, status, created_at DESC);

-- Analyze tables
ANALYZE;
```

## 💳 Stripe Configuration

### Production Setup

1. **Activate Stripe Account**
- Complete business verification
- Add bank account details
- Configure tax settings

2. **Webhook Configuration**
```bash
# Webhook URL for production
https://your-domain.com/api/stripe-webhook

# Events to listen for:
- customer.subscription.created
- customer.subscription.updated
- customer.subscription.deleted
- invoice.payment_succeeded
- invoice.payment_failed
- checkout.session.completed
```

3. **Product and Price Setup**
Create products in Stripe dashboard:
- **Free Plan**: $0/month
- **Essentials**: $24.99/month
- **Professional**: $49.99/month
- **Enterprise**: Custom pricing

## 🔐 Security Configuration

### Environment Variables Security
```bash
# Use strong, unique values for production
NEXTAUTH_SECRET=$(openssl rand -base64 32)
STRIPE_WEBHOOK_SECRET=whsec_production_secret
SUPABASE_JWT_SECRET=your_jwt_secret
```

### Security Headers
Add to `next.config.js`:
```javascript
const securityHeaders = [
  {
    key: 'X-DNS-Prefetch-Control',
    value: 'on'
  },
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload'
  },
  {
    key: 'X-XSS-Protection',
    value: '1; mode=block'
  },
  {
    key: 'X-Frame-Options',
    value: 'DENY'
  },
  {
    key: 'X-Content-Type-Options',
    value: 'nosniff'
  },
  {
    key: 'Referrer-Policy',
    value: 'origin-when-cross-origin'
  }
]

module.exports = {
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: securityHeaders,
      },
    ]
  },
}
```

## 📊 Monitoring & Analytics

### Application Monitoring

1. **Vercel Analytics** (if using Vercel)
```bash
npm install @vercel/analytics
```

2. **Sentry for Error Tracking**
```bash
npm install @sentry/nextjs
```

3. **PostHog for User Analytics**
```bash
npm install posthog-js
```

### Database Monitoring
```sql
-- Create monitoring views
CREATE VIEW performance_metrics AS
SELECT 
  schemaname,
  tablename,
  pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size,
  pg_stat_get_tuples_inserted(c.oid) as inserts,
  pg_stat_get_tuples_updated(c.oid) as updates,
  pg_stat_get_tuples_deleted(c.oid) as deletes
FROM pg_tables t
JOIN pg_class c ON c.relname = t.tablename
WHERE schemaname = 'public';
```

## 🚀 Performance Optimization

### Next.js Optimizations
```javascript
// next.config.js
module.exports = {
  experimental: {
    optimizeCss: true,
    optimizeImages: true,
  },
  images: {
    domains: ['your-domain.com'],
    formats: ['image/webp', 'image/avif'],
  },
  compress: true,
  poweredByHeader: false,
}
```

### Database Optimizations
```sql
-- Connection pooling settings
ALTER SYSTEM SET max_connections = 100;
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET work_mem = '4MB';
```

## 🔄 CI/CD Pipeline

### GitHub Actions (Already configured)
- **Automated testing** on pull requests
- **Security scanning** with CodeQL
- **Dependency updates** weekly
- **Automatic deployment** to staging/production

### Deployment Workflow
1. **Development** → Push to `develop` branch
2. **Staging** → Auto-deploy to staging environment
3. **Production** → Merge to `main` → Auto-deploy to production
4. **Rollback** → Revert commit if issues detected

## 📋 Post-Deployment Checklist

### ✅ Functionality Testing
- [ ] User registration/login works
- [ ] Payment processing functional
- [ ] FINN AI assistant responding
- [ ] Marketplace search working
- [ ] Email notifications sending
- [ ] Database operations successful

### ✅ Performance Testing
- [ ] Page load times < 3 seconds
- [ ] API response times < 500ms
- [ ] Database queries optimized
- [ ] CDN caching working
- [ ] Mobile performance acceptable

### ✅ Security Testing
- [ ] SSL certificate valid
- [ ] Security headers present
- [ ] RLS policies enforced
- [ ] API rate limiting active
- [ ] Webhook signatures verified

### ✅ Monitoring Setup
- [ ] Error tracking configured
- [ ] Performance monitoring active
- [ ] Database monitoring enabled
- [ ] Uptime monitoring setup
- [ ] Alert notifications configured

## 🆘 Troubleshooting

### Common Issues

#### Build Failures
```bash
# Clear cache and rebuild
rm -rf .next node_modules
npm install
npm run build
```

#### Database Connection Issues
```bash
# Check environment variables
echo $NEXT_PUBLIC_SUPABASE_URL
echo $NEXT_PUBLIC_SUPABASE_ANON_KEY

# Test connection
npx supabase status
```

#### Stripe Webhook Issues
```bash
# Test webhook locally
stripe listen --forward-to localhost:3000/api/stripe-webhook
```

### Support Contacts
- **Vercel Support**: [vercel.com/support](https://vercel.com/support)
- **Supabase Support**: [supabase.com/support](https://supabase.com/support)
- **Stripe Support**: [stripe.com/support](https://stripe.com/support)

---

**🎉 Congratulations! Your Accruance application is now live in production!**

For ongoing maintenance and updates, refer to the [Maintenance Guide](./maintenance-guide.md).

