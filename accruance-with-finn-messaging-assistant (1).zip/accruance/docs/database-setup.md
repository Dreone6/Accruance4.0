# Supabase Database Setup Guide

## Overview
This document outlines the database schema and setup process for Accruance, an AI-powered accounting dashboard SaaS.

## Database Schema

### Core Tables

1. **organizations** - Multi-tenant organization data
2. **users** - User profiles extending Supabase auth
3. **accounts** - Chart of accounts
4. **transactions** - Financial transactions
5. **invoices** - Invoice management
6. **invoice_line_items** - Invoice line items
7. **receipts** - Receipt management with OCR
8. **bank_connections** - Plaid bank integrations
9. **ai_categorization_rules** - AI learning rules
10. **reports_cache** - Performance optimization

### Key Features

- **Row Level Security (RLS)** - All tables have proper RLS policies
- **Multi-tenant Architecture** - Organization-based data isolation
- **Role-based Access Control** - Owner, Admin, Accountant, Read-only roles
- **Industry-specific Templates** - Auto-generated chart of accounts
- **AI Integration Ready** - Tables designed for ML categorization
- **Audit Trail** - Automatic updated_at timestamps

## Setup Instructions

### 1. Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Create a new project
3. Note your project URL and anon key

### 2. Run Migrations
Execute the migration files in order:
1. `001_initial_schema.sql` - Core tables and indexes
2. `002_rls_policies.sql` - Row Level Security policies
3. `003_chart_of_accounts_templates.sql` - Industry templates

### 3. Configure Environment Variables
Copy `.env.example` to `.env.local` and fill in your values:
```bash
cp .env.example .env.local
```

### 4. Enable Required Extensions
In Supabase SQL Editor, ensure these extensions are enabled:
- `uuid-ossp` (for UUID generation)

### 5. Configure Storage Buckets
Create storage buckets for:
- `receipts` - Receipt images and PDFs
- `documents` - W9 forms and other documents
- `invoices` - Generated invoice PDFs

### 6. Set Up Authentication
Configure Supabase Auth:
- Enable email/password authentication
- Configure OAuth providers (Google, Microsoft)
- Set up email templates
- Configure redirect URLs

## Database Functions

### create_default_chart_of_accounts()
Creates industry-specific chart of accounts for new organizations.

**Parameters:**
- `org_id` - Organization UUID
- `business_type_param` - Business type enum
- `industry_param` - Industry string (optional, defaults to 'general')

**Usage:**
```sql
SELECT create_default_chart_of_accounts(
  'org-uuid-here',
  'llc',
  'ecommerce'
);
```

### get_industry_categories()
Returns industry-specific transaction categories for AI training.

**Parameters:**
- `industry_param` - Industry string

**Usage:**
```sql
SELECT * FROM get_industry_categories('retail');
```

## Security Considerations

### Row Level Security Policies
- Users can only access data from their organization
- Role-based permissions (Owner > Admin > Accountant > Read-only)
- Automatic policy enforcement at database level

### Data Encryption
- All sensitive data encrypted at rest
- API keys and tokens stored securely
- PCI compliance for payment data

### Access Control
- Service role key for server-side operations
- Anon key for client-side operations
- Proper CORS configuration

## Performance Optimization

### Indexes
- Organization-based indexes for multi-tenant queries
- Date-based indexes for transaction queries
- Category indexes for reporting

### Caching
- Reports cache table for expensive queries
- Automatic cache invalidation
- Configurable TTL per report type

### Query Optimization
- Proper use of foreign keys
- Efficient RLS policies
- Pagination for large datasets

## Backup and Recovery

### Automated Backups
- Daily automated backups via Supabase
- Point-in-time recovery available
- Cross-region backup replication

### Data Export
- CSV export functionality
- Full database dumps
- Selective data export by organization

## Monitoring and Maintenance

### Health Checks
- Database connectivity monitoring
- Query performance tracking
- Storage usage monitoring

### Maintenance Tasks
- Regular VACUUM and ANALYZE
- Index maintenance
- Cache cleanup
- Audit log rotation

## Development Workflow

### Local Development
1. Use Supabase CLI for local development
2. Run migrations locally first
3. Test RLS policies thoroughly
4. Validate data integrity

### Staging Environment
1. Separate Supabase project for staging
2. Production data subset for testing
3. Migration testing before production

### Production Deployment
1. Backup before migrations
2. Run migrations during maintenance window
3. Validate data integrity post-migration
4. Monitor performance metrics

## Troubleshooting

### Common Issues
1. **RLS Policy Errors** - Check user organization membership
2. **Migration Failures** - Verify dependencies and constraints
3. **Performance Issues** - Check query plans and indexes
4. **Connection Issues** - Verify environment variables

### Debug Queries
```sql
-- Check user organization access
SELECT u.*, o.name as org_name 
FROM users u 
LEFT JOIN organizations o ON u.organization_id = o.id 
WHERE u.id = auth.uid();

-- Verify RLS policies
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual 
FROM pg_policies 
WHERE schemaname = 'public';

-- Check table sizes
SELECT schemaname, tablename, 
       pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public' 
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

