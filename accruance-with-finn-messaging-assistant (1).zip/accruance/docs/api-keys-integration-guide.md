# 🔑 Accruance API Keys & Integration Guide

## 📋 **Required API Keys for Day-One Functionality**

### **✅ Already Provided (Configured)**
1. **Supabase**
   - URL: `https://fjdtrrzicohjizdmzmwm.supabase.co`
   - Anon Key: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` ✅ CONFIGURED

2. **Stripe**
   - Publishable Key: `pk_test_51RWR5qQhzbuTbHPSilhDbHiewEj7hjAcTdWJtyDjSuLMbcRXj6TlhTO9FxATjjKWsKGIS2p5c0o5PIO3TWHKKz9l00B9eYp2ic` ✅ CONFIGURED
   - Secret Key: `sk_test_51RWR5qQhzbuTbHPS7xl8olkihtkhCWBuEd5AvAOIcwvNDUwxSHK5hKOFH8spclHbcdAckUHii8uMK9LR9MU6lMXO00KEUo4b13` ✅ CONFIGURED

### **🔴 Missing API Keys (Need to Obtain)**

#### **3. OpenAI (CRITICAL - For FINN AI Assistant)**
- **Purpose**: Powers FINN AI financial assistant
- **Where to Get**: https://platform.openai.com/api-keys
- **Cost**: ~$20-50/month for typical usage
- **Required For**: 
  - FINN chat functionality
  - AI-powered financial insights
  - Smart transaction categorization
  - Financial advice and recommendations

#### **4. Mapbox (IMPORTANT - For Location Services)**
- **Purpose**: Location-based marketplace search, address geocoding
- **Where to Get**: https://account.mapbox.com/access-tokens/
- **Cost**: Free tier: 50,000 requests/month, then $0.50/1000 requests
- **Required For**:
  - Professional location search
  - Radius-based filtering
  - Address autocomplete
  - Distance calculations

#### **5. Google Maps API (ALTERNATIVE - Backup for Mapbox)**
- **Purpose**: Alternative location services
- **Where to Get**: https://console.cloud.google.com/apis/credentials
- **Cost**: $200 free credit monthly, then $2-7/1000 requests
- **Required For**:
  - Backup location services
  - Enhanced mapping features

### **🟡 Optional API Keys (Enhanced Features)**

#### **6. Stripe Connect (For Marketplace Payments)**
- **Purpose**: Marketplace commission processing
- **Where to Get**: Stripe Dashboard → Connect
- **Required For**: Marketplace payment processing (when marketplace is enabled)

#### **7. Twilio (For SMS Notifications)**
- **Purpose**: SMS notifications and 2FA
- **Where to Get**: https://console.twilio.com/
- **Required For**: Enhanced user notifications

#### **8. SendGrid (For Email Services)**
- **Purpose**: Transactional emails
- **Where to Get**: https://app.sendgrid.com/
- **Required For**: Enhanced email notifications

## 🚀 **Priority Setup Order**

### **IMMEDIATE (Day 1):**
1. **OpenAI API Key** - FINN won't work without this
2. **Mapbox Token** - Location search won't work without this

### **WEEK 1:**
3. **Google Maps API** - Backup location services
4. **Stripe Connect** - For marketplace payments

### **MONTH 1:**
5. **Twilio** - Enhanced notifications
6. **SendGrid** - Professional emails

## 📝 **How to Obtain Each API Key**

### **OpenAI API Key**
1. Go to https://platform.openai.com/
2. Sign up/login to your account
3. Navigate to "API Keys" in the left sidebar
4. Click "Create new secret key"
5. Copy the key (starts with `sk-...`)
6. **Cost**: Pay-per-use, typically $20-50/month

### **Mapbox Access Token**
1. Go to https://account.mapbox.com/
2. Sign up for free account
3. Go to "Access tokens" page
4. Copy your "Default public token" (starts with `pk.`)
5. **Cost**: Free tier covers most usage

### **Google Maps API Key**
1. Go to https://console.cloud.google.com/
2. Create new project or select existing
3. Enable "Maps JavaScript API" and "Geocoding API"
4. Go to "Credentials" → "Create Credentials" → "API Key"
5. Copy the API key
6. **Cost**: $200 free credit monthly

### **Stripe Connect Client ID**
1. In your Stripe Dashboard
2. Go to "Connect" → "Settings"
3. Copy your "Client ID" (starts with `ca_`)
4. **Cost**: No additional cost

## 🔧 **Integration Instructions**

### **Step 1: Update .env.local File**
```env
# CRITICAL - App won't work without these
OPENAI_API_KEY=sk-your_openai_key_here
NEXT_PUBLIC_MAPBOX_TOKEN=pk.your_mapbox_token_here

# IMPORTANT - For enhanced features
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=your_google_maps_key_here
STRIPE_CONNECT_CLIENT_ID=ca_your_stripe_connect_client_id

# OPTIONAL - For advanced features
TWILIO_ACCOUNT_SID=your_twilio_sid_here
TWILIO_AUTH_TOKEN=your_twilio_token_here
SENDGRID_API_KEY=your_sendgrid_key_here
```

### **Step 2: Test API Connections**
After adding keys, test each service:

```bash
# Test OpenAI connection
curl -X POST http://localhost:3000/api/finn/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Hello FINN"}'

# Test location services
curl "http://localhost:3000/api/marketplace/search/services?lat=40.7128&lng=-74.0060&radius=25"
```

### **Step 3: Verify Functionality**
1. **FINN Chat**: Ask FINN a financial question
2. **Location Search**: Search for professionals near you
3. **Marketplace**: Browse services with location filtering
4. **Payments**: Test Stripe payment processing

## 💰 **Cost Breakdown (Monthly)**

### **Essential APIs:**
- **OpenAI**: $20-50/month (based on FINN usage)
- **Mapbox**: $0-25/month (free tier covers most usage)
- **Total Essential**: $20-75/month

### **Enhanced APIs:**
- **Google Maps**: $0-50/month ($200 free credit)
- **Twilio**: $10-30/month
- **SendGrid**: $0-15/month (free tier available)
- **Total Enhanced**: $10-95/month

### **Total Monthly Cost**: $30-170/month for full functionality

## 🔒 **Security Best Practices**

### **Environment Variables:**
- Never commit API keys to Git
- Use different keys for development/production
- Rotate keys regularly
- Monitor API usage for anomalies

### **API Key Restrictions:**
- **Mapbox**: Restrict to your domain
- **Google Maps**: Restrict to your domain and IP
- **OpenAI**: Monitor usage limits
- **Stripe**: Use test keys in development

## 🚨 **Fallback Options**

### **If You Can't Get All Keys Immediately:**

#### **Without OpenAI:**
- FINN will show "AI assistant temporarily unavailable"
- Basic financial dashboard still works
- Manual transaction categorization

#### **Without Mapbox/Google Maps:**
- Location search disabled
- Marketplace works without location filtering
- Manual location entry only

#### **Without Stripe Connect:**
- Basic Stripe payments still work
- Marketplace commission processing disabled
- Direct payments between users

## 📋 **Setup Checklist**

### **Before GitHub Push:**
- [ ] OpenAI API key obtained and tested
- [ ] Mapbox token obtained and tested
- [ ] .env.local file updated with all keys
- [ ] API connections tested locally
- [ ] All features verified working
- [ ] Security restrictions applied to keys

### **After GitHub Push:**
- [ ] Set up production environment variables
- [ ] Configure webhook endpoints
- [ ] Set up monitoring and alerts
- [ ] Test production deployment

## 🎯 **Recommended Action Plan**

### **Today:**
1. Get OpenAI API key (CRITICAL)
2. Get Mapbox token (IMPORTANT)
3. Update .env.local file
4. Test FINN and location features

### **This Week:**
1. Get Google Maps API key (backup)
2. Set up Stripe Connect
3. Test marketplace functionality
4. Prepare for GitHub push

### **Next Week:**
1. Get optional APIs (Twilio, SendGrid)
2. Set up production environment
3. Configure monitoring
4. Launch to users

**Once you provide the OpenAI and Mapbox keys, your Accruance app will be 100% functional from day one!** 🚀

