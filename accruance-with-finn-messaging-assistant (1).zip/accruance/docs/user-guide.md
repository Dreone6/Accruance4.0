# Accruance User Guide

## Welcome to Accruance

Accruance is your AI-powered financial dashboard that simplifies accounting, automates bookkeeping, and provides intelligent insights to help your business thrive. This comprehensive guide will help you get the most out of your Accruance experience.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Smart Onboarding](#smart-onboarding)
3. [Dashboard Overview](#dashboard-overview)
4. [Transaction Management](#transaction-management)
5. [Receipt Management](#receipt-management)
6. [Invoicing & Payments](#invoicing--payments)
7. [FINN AI Assistant](#finn-ai-assistant)
8. [Reports & Analytics](#reports--analytics)
9. [Settings & Configuration](#settings--configuration)
10. [Troubleshooting](#troubleshooting)

## Getting Started

### Creating Your Account

1. **Visit Accruance**: Go to your Accruance URL
2. **Sign Up**: Click "Get Started" and choose your registration method:
   - Email and password
   - Google OAuth (recommended for faster setup)
3. **Verify Email**: Check your email and click the verification link
4. **Complete Profile**: Add your basic information

### System Requirements

- **Web Browser**: Chrome, Firefox, Safari, or Edge (latest versions)
- **Internet Connection**: Stable internet for real-time features
- **Mobile**: Responsive design works on all devices
- **File Uploads**: Support for JPEG, PNG, GIF, BMP, and PDF files

## Smart Onboarding

Accruance's Smart Onboarding gets you set up in under 5 minutes with AI-guided assistance.

### Step 1: Organization Setup

1. **Choose Your Path**:
   - **Create New Organization**: Start fresh with your business
   - **Join Existing Organization**: Use an invitation code

2. **Business Information**:
   - Organization name
   - Business type (LLC, Corporation, Partnership, Sole Proprietorship)
   - Industry selection (9 options available)
   - Business address and contact information

### Step 2: Industry-Specific Configuration

Based on your industry selection, Accruance automatically:
- Creates appropriate chart of accounts
- Sets up relevant expense categories
- Configures tax settings
- Establishes reporting templates

**Available Industries**:
- Retail & E-commerce
- Restaurant & Food Service
- Consulting & Professional Services
- Technology & Software
- Healthcare & Medical
- Real Estate & Property Management
- Manufacturing & Production
- Creative & Marketing Agencies
- General Business

### Step 3: Banking Integration

1. **Connect Your Bank**: Use Plaid integration to connect 12,000+ financial institutions
2. **Account Selection**: Choose which accounts to sync
3. **Historical Data**: Import up to 24 months of transaction history
4. **Security**: All connections use bank-level encryption

### Step 4: Document Upload

Upload essential business documents:
- Business license
- Tax identification documents
- Bank statements
- Previous financial records

**File Requirements**:
- Maximum size: 10MB per file
- Supported formats: PDF, JPEG, PNG
- Automatic organization and storage

## Dashboard Overview

Your dashboard provides a real-time view of your business finances with interactive charts and key metrics.

### Key Performance Indicators (KPIs)

**Revenue Metrics**:
- Total revenue with growth percentage
- Monthly recurring revenue (if applicable)
- Revenue by source/category

**Expense Tracking**:
- Total expenses with trend analysis
- Expense breakdown by category
- Budget vs. actual spending

**Profitability**:
- Net profit with margin calculations
- Gross profit analysis
- Year-over-year comparisons

**Cash Flow**:
- Current cash position
- Cash flow projections
- Outstanding receivables and payables

### Interactive Charts

**Financial Trends**:
- Revenue and expense trends over time
- Profit margin analysis
- Seasonal pattern recognition

**Category Breakdown**:
- Expense distribution pie charts
- Revenue source analysis
- Budget allocation visualization

**Real-Time Updates**:
- Data refreshes every 30 seconds
- Manual refresh option available
- Live transaction processing

## Transaction Management

Accruance's AI-powered transaction management automates categorization and provides intelligent insights.

### Adding Transactions

**Manual Entry**:
1. Click "Add Transaction" button
2. Fill in transaction details:
   - Description
   - Amount
   - Date
   - Transaction type (Income/Expense)
3. AI automatically suggests categories with confidence scores
4. Review and confirm or modify suggestions

**Bulk Import**:
1. Download CSV template
2. Fill in transaction data
3. Upload file for processing
4. Review AI categorizations
5. Approve or modify as needed

### AI Categorization

**How It Works**:
- 7 intelligent categorization rules
- 85-98% confidence scoring
- Pattern recognition and learning
- Merchant database matching

**Category Suggestions**:
- Office Supplies (95% confidence)
- Fuel & Gas (90% confidence)
- Meals & Entertainment (85% confidence)
- Software & Subscriptions (92% confidence)
- Rent & Lease (98% confidence)
- Marketing & Advertising (88% confidence)
- Sales Revenue (95% confidence)

**Manual Recategorization**:
1. Select transactions to recategorize
2. Choose new category from dropdown
3. AI learns from your corrections
4. Improved suggestions for future transactions

### Bulk Operations

**Available Actions**:
- Categorize multiple transactions
- Delete selected transactions
- Mark as reconciled
- Export to CSV/PDF
- Apply tags or notes

**Keyboard Shortcuts**:
- `Ctrl+N`: New transaction
- `Ctrl+S`: Save transaction
- `Ctrl+A`: Select all
- `Delete`: Delete selected
- `Ctrl+E`: Export selected

### Transaction Status

**Status Types**:
- **Pending**: Awaiting bank confirmation
- **Cleared**: Confirmed by bank
- **Reconciled**: Matched with bank statement

**Status Management**:
- Automatic status updates from bank feeds
- Manual status changes available
- Reconciliation workflow built-in

## Receipt Management

Transform receipt management with AI-powered OCR and automatic data extraction.

### Uploading Receipts

**Drag & Drop Interface**:
1. Drag receipt images to upload area
2. Multiple files supported (up to 10 at once)
3. Real-time progress tracking
4. Automatic OCR processing

**Mobile Camera Integration**:
1. Click camera icon on mobile devices
2. Position receipt within guides
3. Capture high-quality image
4. Instant processing and extraction

**File Requirements**:
- Supported formats: JPEG, PNG, GIF, BMP, PDF
- Maximum size: 10MB per file
- Recommended: Clear, well-lit images

### OCR Data Extraction

**Extracted Information**:
- Merchant name and address
- Transaction date and time
- Total amount and tax
- Individual line items
- Payment method
- Receipt number

**Accuracy Rates**:
- Merchant name: 90-95%
- Total amount: 95-98%
- Date: 85-90%
- Line items: 80-85%

**Data Validation**:
- Automatic reasonableness checks
- Confidence scoring for each field
- Manual correction capabilities
- Learning from user corrections

### Receipt-to-Transaction Matching

**Automatic Matching**:
- AI compares receipt data with existing transactions
- Multi-factor analysis (amount, date, merchant)
- Confidence scoring (60-95%)
- One-click confirmation

**Manual Matching**:
1. View suggested matches
2. Compare receipt and transaction details
3. Confirm or reject matches
4. Create new transaction if no match

### Duplicate Detection

**Detection Criteria**:
- Identical amounts and dates
- Similar merchant names
- File hash comparison
- Visual similarity analysis

**Resolution Options**:
- Keep first occurrence
- Keep highest quality image
- Manual review and selection
- Batch resolution for multiple duplicates

## Invoicing & Payments

Create professional invoices and get paid faster with integrated payment processing.

### Creating Invoices

**Invoice Builder**:
1. Click "Create Invoice"
2. Select or add client information
3. Add line items with descriptions and amounts
4. Set payment terms and due date
5. Customize with your branding

**Client Management**:
- Comprehensive client database
- Contact information and billing addresses
- Payment history and preferences
- Quick client selection and creation

**Line Items**:
- Unlimited line items per invoice
- Quantity, rate, and amount calculations
- Tax calculations (configurable rates)
- Discount applications

### Professional PDF Generation

**Features**:
- High-quality, branded invoices
- Print-ready format (A4 standard)
- Professional typography and layout
- Company logo and contact information
- Terms and conditions inclusion

**Customization Options**:
- Color scheme matching your brand
- Custom footer messages
- Payment instructions
- Late fee policies

### Payment Processing

**Stripe Integration**:
- Secure payment processing
- Multiple payment methods:
  - Credit and debit cards
  - Apple Pay and Google Pay
  - Bank transfers (ACH)
  - International payments

**Payment Features**:
- Real-time payment notifications
- Automatic invoice status updates
- Payment confirmation emails
- Refund processing capabilities

**Security**:
- PCI DSS compliant
- No card data stored locally
- Encrypted payment processing
- Fraud detection and prevention

### Invoice Management

**Status Tracking**:
- Draft: Being created or edited
- Sent: Delivered to client
- Paid: Payment received
- Overdue: Past due date
- Cancelled: Voided or cancelled

**Automated Follow-ups**:
- Payment reminder emails
- Overdue notifications
- Customizable reminder schedules
- Professional email templates

**Analytics**:
- Payment timing analysis
- Client payment patterns
- Revenue forecasting
- Outstanding balance tracking

## FINN AI Assistant

Meet FINN (Financial Intelligence Neural Network), your AI-powered CFO assistant that provides intelligent insights and answers financial questions in natural language.

### Chat Interface

**Natural Language Queries**:
Ask FINN questions like:
- "What's my cash flow looking like this month?"
- "How are my expenses trending?"
- "Should I be worried about taxes?"
- "What are my biggest expense categories?"
- "How is my profit margin compared to last month?"

**Conversation Features**:
- Real-time responses (1-3 seconds)
- Confidence scoring (70-98%)
- Conversation history
- Context-aware responses
- Suggested follow-up questions

### AI-Powered Insights

**Automatic Insights**:
FINN continuously monitors your finances and provides alerts for:

**Cash Flow Alerts** (High Priority):
- Low cash flow warnings
- Seasonal cash flow patterns
- Recommended actions for improvement

**Expense Trend Analysis** (Medium Priority):
- Unusual spending increases
- Category-specific trends
- Budget variance alerts

**Revenue Opportunities** (Medium Priority):
- Growth pattern recognition
- Seasonal opportunity identification
- Scaling recommendations

**Tax Reminders** (High Priority):
- Quarterly tax preparation alerts
- Estimated payment calculations
- Document preparation checklists

**Payment Reminders** (High Priority):
- Overdue invoice notifications
- Client payment pattern analysis
- Collection recommendations

### Monthly Summaries

**Comprehensive Reports**:
- Financial overview with key metrics
- AI-generated insights and observations
- Actionable recommendations
- Expense breakdown with trends
- Tax planning guidance

**Export Options**:
- PDF download for sharing
- Email delivery to stakeholders
- Text format for easy copying
- Integration with external tools

### FINN's Intelligence

**Learning Capabilities**:
- Learns from your business patterns
- Improves recommendations over time
- Adapts to your industry specifics
- Personalizes insights to your needs

**Data Analysis**:
- Pattern recognition in financial data
- Anomaly detection for unusual transactions
- Trend analysis and forecasting
- Comparative analysis with industry benchmarks

## Reports & Analytics

Generate comprehensive financial reports and gain deep insights into your business performance.

### Standard Reports

**Profit & Loss Statement**:
- Revenue breakdown by category
- Expense analysis by type
- Net income calculations
- Period-over-period comparisons

**Balance Sheet**:
- Assets, liabilities, and equity
- Current vs. non-current classifications
- Financial position analysis
- Liquidity ratios

**Cash Flow Statement**:
- Operating, investing, and financing activities
- Cash flow projections
- Working capital analysis
- Cash conversion cycle

**Expense Reports**:
- Category-wise expense breakdown
- Trend analysis over time
- Budget vs. actual comparisons
- Cost center analysis

### Custom Reports

**Report Builder**:
- Drag-and-drop interface
- Custom date ranges
- Filter by categories, clients, or projects
- Multiple visualization options

**Scheduled Reports**:
- Automatic report generation
- Email delivery to stakeholders
- Customizable frequency (daily, weekly, monthly)
- Multiple format options (PDF, Excel, CSV)

### Analytics Dashboard

**Key Metrics**:
- Revenue growth rates
- Expense ratios
- Profit margins
- Cash flow trends

**Visualizations**:
- Interactive charts and graphs
- Trend lines and projections
- Comparative analysis
- Drill-down capabilities

## Settings & Configuration

Customize Accruance to match your business needs and preferences.

### Organization Settings

**Business Information**:
- Company name and address
- Tax identification numbers
- Industry classification
- Fiscal year settings

**User Management**:
- Add team members
- Assign roles and permissions
- Manage access levels
- Audit user activity

**Roles Available**:
- **Owner**: Full access to all features
- **Admin**: Manage users and settings
- **Accountant**: Financial data access
- **Read-only**: View-only access

### Chart of Accounts

**Account Management**:
- Add, edit, or delete accounts
- Customize account codes
- Set account types and categories
- Import from existing systems

**Industry Templates**:
- Pre-configured account structures
- Best practice recommendations
- Compliance considerations
- Easy customization options

### Integration Settings

**Banking Connections**:
- Manage connected accounts
- Update connection credentials
- Set sync frequencies
- Review transaction imports

**Third-Party Integrations**:
- Payment processors
- E-commerce platforms
- CRM systems
- Payroll services

### Notification Preferences

**Email Notifications**:
- Transaction alerts
- Payment confirmations
- Report delivery
- System updates

**In-App Notifications**:
- Real-time alerts
- Task reminders
- System messages
- Feature announcements

## Troubleshooting

### Common Issues and Solutions

**Login Problems**:
- **Forgot Password**: Use password reset link
- **Account Locked**: Contact support after multiple failed attempts
- **Email Verification**: Check spam folder for verification email

**Transaction Issues**:
- **Missing Transactions**: Check bank connection status
- **Incorrect Categorization**: Use manual recategorization feature
- **Duplicate Transactions**: Use duplicate detection tool

**Receipt Processing**:
- **Poor OCR Results**: Ensure clear, well-lit images
- **Upload Failures**: Check file size and format requirements
- **Missing Data**: Manually edit extracted information

**Performance Issues**:
- **Slow Loading**: Check internet connection
- **Sync Problems**: Refresh bank connections
- **Browser Issues**: Clear cache and cookies

### Getting Help

**Support Channels**:
- In-app help center
- Email support: support@accruance.com
- Live chat (business hours)
- Community forum

**Documentation**:
- Video tutorials
- Step-by-step guides
- FAQ section
- Best practices

**Training Resources**:
- Webinar series
- One-on-one training sessions
- Implementation assistance
- Custom training programs

### System Status

**Monitoring**:
- Real-time system status
- Planned maintenance notifications
- Service disruption alerts
- Performance metrics

**Updates**:
- Regular feature updates
- Security patches
- Performance improvements
- New integration announcements

## Best Practices

### Data Management

**Regular Backups**:
- Automatic cloud backups
- Export important data regularly
- Maintain local copies of critical documents
- Test backup restoration procedures

**Data Quality**:
- Review AI categorizations regularly
- Maintain consistent naming conventions
- Keep client information updated
- Reconcile accounts monthly

### Security

**Account Security**:
- Use strong, unique passwords
- Enable two-factor authentication
- Regularly review user access
- Monitor login activity

**Data Protection**:
- Limit access to sensitive information
- Use secure networks for access
- Keep software updated
- Report suspicious activity

### Workflow Optimization

**Daily Tasks**:
- Review new transactions
- Process receipts promptly
- Check for payment notifications
- Monitor cash flow alerts

**Weekly Tasks**:
- Reconcile bank accounts
- Review expense categories
- Update client information
- Generate weekly reports

**Monthly Tasks**:
- Complete month-end closing
- Review financial statements
- Analyze performance metrics
- Plan for upcoming expenses

## Conclusion

Accruance is designed to simplify your financial management while providing powerful insights to help your business grow. This user guide covers the essential features and workflows, but don't hesitate to explore and experiment with the platform.

For additional support or advanced features, contact our support team or visit the help center. We're here to help you succeed with Accruance!

---

**Need Help?**
- Email: support@accruance.com
- Live Chat: Available in-app
- Documentation: help.accruance.com
- Community: community.accruance.com

