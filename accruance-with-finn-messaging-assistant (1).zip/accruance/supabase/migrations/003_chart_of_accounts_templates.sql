-- Default Chart of Accounts Templates by Industry

-- Function to create default accounts for an organization
CREATE OR REPLACE FUNCTION create_default_chart_of_accounts(
    org_id UUID,
    business_type_param business_type,
    industry_param VARCHAR(100) DEFAULT 'general'
)
RETURNS VOID AS $$
BEGIN
    -- Assets
    INSERT INTO accounts (organization_id, account_number, name, account_type, description) VALUES
    (org_id, '1000', 'Cash and Cash Equivalents', 'asset', 'Checking accounts, savings accounts, petty cash'),
    (org_id, '1100', 'Accounts Receivable', 'asset', 'Money owed by customers'),
    (org_id, '1200', 'Inventory', 'asset', 'Products held for sale'),
    (org_id, '1300', 'Prepaid Expenses', 'asset', 'Expenses paid in advance'),
    (org_id, '1400', 'Equipment', 'asset', 'Office equipment, computers, furniture'),
    (org_id, '1500', 'Accumulated Depreciation - Equipment', 'asset', 'Depreciation of equipment');

    -- Liabilities
    INSERT INTO accounts (organization_id, account_number, name, account_type, description) VALUES
    (org_id, '2000', 'Accounts Payable', 'liability', 'Money owed to suppliers'),
    (org_id, '2100', 'Credit Cards Payable', 'liability', 'Credit card balances'),
    (org_id, '2200', 'Accrued Expenses', 'liability', 'Expenses incurred but not yet paid'),
    (org_id, '2300', 'Payroll Liabilities', 'liability', 'Wages, taxes, and benefits payable'),
    (org_id, '2400', 'Sales Tax Payable', 'liability', 'Sales tax collected from customers'),
    (org_id, '2500', 'Income Tax Payable', 'liability', 'Income taxes owed');

    -- Equity
    INSERT INTO accounts (organization_id, account_number, name, account_type, description) VALUES
    (org_id, '3000', 'Owner''s Equity', 'equity', 'Owner''s investment in the business'),
    (org_id, '3100', 'Retained Earnings', 'equity', 'Accumulated profits retained in business'),
    (org_id, '3200', 'Owner''s Draw', 'equity', 'Money withdrawn by owner');

    -- Income
    INSERT INTO accounts (organization_id, account_number, name, account_type, description) VALUES
    (org_id, '4000', 'Sales Revenue', 'income', 'Revenue from primary business activities'),
    (org_id, '4100', 'Service Revenue', 'income', 'Revenue from services provided'),
    (org_id, '4200', 'Interest Income', 'income', 'Interest earned on investments'),
    (org_id, '4300', 'Other Income', 'income', 'Miscellaneous income');

    -- Expenses
    INSERT INTO accounts (organization_id, account_number, name, account_type, description) VALUES
    (org_id, '5000', 'Cost of Goods Sold', 'expense', 'Direct costs of producing goods'),
    (org_id, '6000', 'Advertising and Marketing', 'expense', 'Marketing and promotional expenses'),
    (org_id, '6100', 'Bank Fees', 'expense', 'Banking and financial service fees'),
    (org_id, '6200', 'Business Insurance', 'expense', 'Insurance premiums'),
    (org_id, '6300', 'Equipment Rental', 'expense', 'Rental of equipment and tools'),
    (org_id, '6400', 'Internet and Phone', 'expense', 'Communication expenses'),
    (org_id, '6500', 'Legal and Professional', 'expense', 'Attorney and consultant fees'),
    (org_id, '6600', 'Meals and Entertainment', 'expense', 'Business meals and entertainment'),
    (org_id, '6700', 'Office Supplies', 'expense', 'Office materials and supplies'),
    (org_id, '6800', 'Rent', 'expense', 'Office and facility rent'),
    (org_id, '6900', 'Software Subscriptions', 'expense', 'Software and SaaS subscriptions'),
    (org_id, '7000', 'Travel', 'expense', 'Business travel expenses'),
    (org_id, '7100', 'Utilities', 'expense', 'Electricity, gas, water'),
    (org_id, '7200', 'Vehicle Expenses', 'expense', 'Vehicle maintenance and fuel'),
    (org_id, '7300', 'Wages and Salaries', 'expense', 'Employee compensation'),
    (org_id, '7400', 'Payroll Taxes', 'expense', 'Employer payroll taxes'),
    (org_id, '7500', 'Employee Benefits', 'expense', 'Health insurance, retirement contributions'),
    (org_id, '7600', 'Depreciation Expense', 'expense', 'Depreciation of assets'),
    (org_id, '7700', 'Interest Expense', 'expense', 'Interest on loans and credit'),
    (org_id, '7800', 'Income Tax Expense', 'expense', 'Federal and state income taxes');

    -- Industry-specific accounts
    IF industry_param = 'retail' THEN
        INSERT INTO accounts (organization_id, account_number, name, account_type, description) VALUES
        (org_id, '1250', 'Merchandise Inventory', 'asset', 'Retail merchandise for sale'),
        (org_id, '6050', 'Inventory Shrinkage', 'expense', 'Lost or stolen inventory'),
        (org_id, '6150', 'Point of Sale Fees', 'expense', 'Credit card processing fees');
    END IF;

    IF industry_param = 'restaurant' THEN
        INSERT INTO accounts (organization_id, account_number, name, account_type, description) VALUES
        (org_id, '1260', 'Food Inventory', 'asset', 'Food and beverage inventory'),
        (org_id, '5050', 'Food Costs', 'expense', 'Cost of food and beverages'),
        (org_id, '6050', 'Kitchen Equipment', 'expense', 'Kitchen equipment and maintenance');
    END IF;

    IF industry_param = 'consulting' THEN
        INSERT INTO accounts (organization_id, account_number, name, account_type, description) VALUES
        (org_id, '1150', 'Unbilled Receivables', 'asset', 'Work completed but not yet billed'),
        (org_id, '2150', 'Deferred Revenue', 'liability', 'Payments received for future work'),
        (org_id, '6050', 'Subcontractor Costs', 'expense', 'Payments to subcontractors');
    END IF;

    IF industry_param = 'ecommerce' THEN
        INSERT INTO accounts (organization_id, account_number, name, account_type, description) VALUES
        (org_id, '6050', 'Payment Processing Fees', 'expense', 'Credit card and payment gateway fees'),
        (org_id, '6150', 'Shipping Costs', 'expense', 'Shipping and fulfillment expenses'),
        (org_id, '6250', 'Returns and Refunds', 'expense', 'Product returns and refunds');
    END IF;

END;
$$ LANGUAGE plpgsql;

-- Function to get industry-specific categories for AI
CREATE OR REPLACE FUNCTION get_industry_categories(industry_param VARCHAR(100))
RETURNS TABLE(category VARCHAR(100), subcategory VARCHAR(100)) AS $$
BEGIN
    -- Common categories for all industries
    RETURN QUERY VALUES
    ('Office Expenses', 'Office Supplies'),
    ('Office Expenses', 'Software'),
    ('Office Expenses', 'Equipment'),
    ('Travel', 'Airfare'),
    ('Travel', 'Hotels'),
    ('Travel', 'Meals'),
    ('Travel', 'Ground Transportation'),
    ('Marketing', 'Advertising'),
    ('Marketing', 'Website'),
    ('Marketing', 'Social Media'),
    ('Professional Services', 'Legal'),
    ('Professional Services', 'Accounting'),
    ('Professional Services', 'Consulting'),
    ('Utilities', 'Internet'),
    ('Utilities', 'Phone'),
    ('Utilities', 'Electricity'),
    ('Insurance', 'General Liability'),
    ('Insurance', 'Professional Liability'),
    ('Banking', 'Bank Fees'),
    ('Banking', 'Interest'),
    ('Payroll', 'Wages'),
    ('Payroll', 'Benefits'),
    ('Payroll', 'Taxes');

    -- Industry-specific categories
    IF industry_param = 'retail' THEN
        RETURN QUERY VALUES
        ('Inventory', 'Merchandise'),
        ('Point of Sale', 'Processing Fees'),
        ('Store Operations', 'Rent'),
        ('Store Operations', 'Security');
    END IF;

    IF industry_param = 'restaurant' THEN
        RETURN QUERY VALUES
        ('Food & Beverage', 'Food Costs'),
        ('Food & Beverage', 'Beverage Costs'),
        ('Kitchen', 'Equipment'),
        ('Kitchen', 'Supplies'),
        ('Restaurant Operations', 'Rent'),
        ('Restaurant Operations', 'Licenses');
    END IF;

    IF industry_param = 'consulting' THEN
        RETURN QUERY VALUES
        ('Project Expenses', 'Client Materials'),
        ('Project Expenses', 'Subcontractors'),
        ('Business Development', 'Networking'),
        ('Business Development', 'Proposals');
    END IF;

    IF industry_param = 'ecommerce' THEN
        RETURN QUERY VALUES
        ('Fulfillment', 'Shipping'),
        ('Fulfillment', 'Packaging'),
        ('Fulfillment', 'Warehouse'),
        ('Online Operations', 'Payment Processing'),
        ('Online Operations', 'Platform Fees'),
        ('Returns', 'Refunds'),
        ('Returns', 'Restocking');
    END IF;

END;
$$ LANGUAGE plpgsql;

