-- Migration: 015_adhoc_reporting_drill_through.sql
-- Description: Add tables for ad-hoc reporting, custom reports, and drill-through functionality

-- Report templates and custom reports
CREATE TABLE IF NOT EXISTS report_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100), -- 'financial', 'operational', 'custom', 'system'
    report_type VARCHAR(50) NOT NULL, -- 'table', 'chart', 'dashboard', 'pivot'
    
    -- Report configuration
    report_config JSONB NOT NULL, -- Complete report definition
    data_sources JSONB, -- Array of data source configurations
    filters JSONB, -- Default filters and parameters
    dimensions JSONB, -- Available dimensions for grouping
    measures JSONB, -- Available measures for calculation
    
    -- Template metadata
    is_system_template BOOLEAN DEFAULT false,
    is_public BOOLEAN DEFAULT false,
    is_favorite BOOLEAN DEFAULT false,
    usage_count INTEGER DEFAULT 0,
    
    -- Display settings
    thumbnail_url VARCHAR(500),
    tags JSONB, -- Array of tags for categorization
    sort_order INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Custom reports created by users
CREATE TABLE IF NOT EXISTS custom_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    template_id UUID REFERENCES report_templates(id),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Report definition
    report_config JSONB NOT NULL, -- Complete report configuration
    data_sources JSONB NOT NULL, -- Data source configurations
    filters JSONB, -- Applied filters and parameters
    grouping JSONB, -- Grouping and sorting configuration
    formatting JSONB, -- Display formatting options
    
    -- Execution settings
    auto_refresh BOOLEAN DEFAULT false,
    refresh_frequency INTEGER, -- Minutes
    last_executed TIMESTAMP WITH TIME ZONE,
    execution_time_ms INTEGER,
    
    -- Sharing and permissions
    is_shared BOOLEAN DEFAULT false,
    shared_with JSONB, -- Array of user IDs or roles
    access_level VARCHAR(20) DEFAULT 'view', -- 'view', 'edit', 'admin'
    
    -- Status and metadata
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'draft', 'archived'
    is_favorite BOOLEAN DEFAULT false,
    view_count INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Report execution history and caching
CREATE TABLE IF NOT EXISTS report_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    report_id UUID NOT NULL REFERENCES custom_reports(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id),
    
    -- Execution details
    execution_start TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    execution_end TIMESTAMP WITH TIME ZONE,
    execution_time_ms INTEGER,
    status VARCHAR(20) DEFAULT 'running', -- 'running', 'completed', 'failed', 'cancelled'
    
    -- Parameters and filters used
    parameters JSONB,
    filters_applied JSONB,
    
    -- Results metadata
    row_count INTEGER,
    column_count INTEGER,
    data_size_bytes INTEGER,
    
    -- Caching
    cache_key VARCHAR(255),
    cache_expires_at TIMESTAMP WITH TIME ZONE,
    
    -- Error handling
    error_message TEXT,
    error_details JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Drill-through definitions and configurations
CREATE TABLE IF NOT EXISTS drill_through_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    source_report_id UUID REFERENCES custom_reports(id),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Drill-through configuration
    source_field VARCHAR(255) NOT NULL, -- Field that triggers drill-through
    target_type VARCHAR(50) NOT NULL, -- 'report', 'transaction_list', 'custom_view'
    target_config JSONB NOT NULL, -- Target configuration
    
    -- Parameter mapping
    parameter_mapping JSONB, -- How to pass parameters to target
    filter_mapping JSONB, -- How to apply filters to target
    
    -- Display settings
    display_type VARCHAR(50) DEFAULT 'modal', -- 'modal', 'new_tab', 'inline'
    icon VARCHAR(50),
    tooltip TEXT,
    
    -- Permissions
    is_enabled BOOLEAN DEFAULT true,
    required_permissions JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Report data sources and connections
CREATE TABLE IF NOT EXISTS report_data_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Data source configuration
    source_type VARCHAR(50) NOT NULL, -- 'table', 'view', 'api', 'custom_query'
    connection_config JSONB NOT NULL, -- Connection details
    query_config JSONB, -- Query or API configuration
    
    -- Schema information
    available_fields JSONB, -- Array of available fields
    field_types JSONB, -- Data types for each field
    relationships JSONB, -- Relationships to other data sources
    
    -- Performance settings
    cache_enabled BOOLEAN DEFAULT true,
    cache_duration_minutes INTEGER DEFAULT 60,
    max_rows INTEGER DEFAULT 10000,
    
    -- Status and validation
    is_active BOOLEAN DEFAULT true,
    last_validated TIMESTAMP WITH TIME ZONE,
    validation_status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'valid', 'invalid'
    validation_errors JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Report dimensions for grouping and filtering
CREATE TABLE IF NOT EXISTS report_dimensions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    data_source_id UUID NOT NULL REFERENCES report_data_sources(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    display_name VARCHAR(255),
    description TEXT,
    
    -- Dimension configuration
    field_name VARCHAR(255) NOT NULL,
    data_type VARCHAR(50) NOT NULL, -- 'string', 'number', 'date', 'boolean'
    dimension_type VARCHAR(50), -- 'categorical', 'temporal', 'geographical', 'hierarchical'
    
    -- Hierarchy information
    parent_dimension_id UUID REFERENCES report_dimensions(id),
    hierarchy_level INTEGER DEFAULT 0,
    hierarchy_path VARCHAR(500),
    
    -- Display settings
    format_string VARCHAR(100),
    sort_order INTEGER DEFAULT 0,
    is_visible BOOLEAN DEFAULT true,
    is_filterable BOOLEAN DEFAULT true,
    is_groupable BOOLEAN DEFAULT true,
    
    -- Value constraints
    allowed_values JSONB, -- Array of allowed values for categorical dimensions
    min_value DECIMAL(15,4), -- Minimum value for numeric dimensions
    max_value DECIMAL(15,4), -- Maximum value for numeric dimensions
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Report measures for calculations and aggregations
CREATE TABLE IF NOT EXISTS report_measures (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    data_source_id UUID NOT NULL REFERENCES report_data_sources(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    display_name VARCHAR(255),
    description TEXT,
    
    -- Measure configuration
    field_name VARCHAR(255),
    calculation_type VARCHAR(50) NOT NULL, -- 'sum', 'count', 'avg', 'min', 'max', 'custom'
    calculation_formula TEXT, -- Custom calculation formula
    data_type VARCHAR(50) DEFAULT 'number',
    
    -- Aggregation settings
    aggregation_level VARCHAR(50) DEFAULT 'detail', -- 'detail', 'summary', 'total'
    is_additive BOOLEAN DEFAULT true,
    
    -- Display formatting
    format_type VARCHAR(50) DEFAULT 'number', -- 'number', 'currency', 'percentage', 'date'
    decimal_places INTEGER DEFAULT 2,
    currency_code VARCHAR(3) DEFAULT 'USD',
    
    -- Performance settings
    is_calculated BOOLEAN DEFAULT false,
    calculation_order INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Report filters and parameters
CREATE TABLE IF NOT EXISTS report_filters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    report_id UUID REFERENCES custom_reports(id) ON DELETE CASCADE,
    dimension_id UUID REFERENCES report_dimensions(id),
    name VARCHAR(255) NOT NULL,
    display_name VARCHAR(255),
    
    -- Filter configuration
    filter_type VARCHAR(50) NOT NULL, -- 'equals', 'contains', 'range', 'in', 'custom'
    filter_values JSONB, -- Array of filter values
    filter_expression TEXT, -- Custom filter expression
    
    -- UI settings
    control_type VARCHAR(50) DEFAULT 'dropdown', -- 'dropdown', 'multiselect', 'date_range', 'text'
    is_required BOOLEAN DEFAULT false,
    is_visible BOOLEAN DEFAULT true,
    default_value JSONB,
    
    -- Validation
    validation_rules JSONB,
    
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Report sharing and collaboration
CREATE TABLE IF NOT EXISTS report_shares (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    report_id UUID NOT NULL REFERENCES custom_reports(id) ON DELETE CASCADE,
    shared_by UUID NOT NULL REFERENCES auth.users(id),
    shared_with UUID REFERENCES auth.users(id),
    
    -- Sharing configuration
    access_level VARCHAR(20) NOT NULL DEFAULT 'view', -- 'view', 'edit', 'admin'
    share_type VARCHAR(20) NOT NULL DEFAULT 'user', -- 'user', 'role', 'public', 'link'
    
    -- Link sharing
    share_token VARCHAR(255), -- For public link sharing
    expires_at TIMESTAMP WITH TIME ZONE,
    password_protected BOOLEAN DEFAULT false,
    password_hash VARCHAR(255),
    
    -- Usage tracking
    view_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMP WITH TIME ZONE,
    
    -- Status
    is_active BOOLEAN DEFAULT true,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Report comments and annotations
CREATE TABLE IF NOT EXISTS report_comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    report_id UUID NOT NULL REFERENCES custom_reports(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id),
    parent_comment_id UUID REFERENCES report_comments(id),
    
    -- Comment content
    comment_text TEXT NOT NULL,
    comment_type VARCHAR(50) DEFAULT 'general', -- 'general', 'question', 'insight', 'issue'
    
    -- Context information
    context_data JSONB, -- Context about what the comment refers to
    highlighted_data JSONB, -- Data that was highlighted when commenting
    
    -- Status and metadata
    is_resolved BOOLEAN DEFAULT false,
    resolved_by UUID REFERENCES auth.users(id),
    resolved_at TIMESTAMP WITH TIME ZONE,
    
    -- Reactions and engagement
    reactions JSONB, -- Array of reactions (like, helpful, etc.)
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_report_templates_user_id ON report_templates(user_id);
CREATE INDEX IF NOT EXISTS idx_report_templates_category ON report_templates(category);
CREATE INDEX IF NOT EXISTS idx_report_templates_public ON report_templates(is_public);
CREATE INDEX IF NOT EXISTS idx_report_templates_system ON report_templates(is_system_template);

CREATE INDEX IF NOT EXISTS idx_custom_reports_user_id ON custom_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_custom_reports_template_id ON custom_reports(template_id);
CREATE INDEX IF NOT EXISTS idx_custom_reports_status ON custom_reports(status);
CREATE INDEX IF NOT EXISTS idx_custom_reports_shared ON custom_reports(is_shared);

CREATE INDEX IF NOT EXISTS idx_report_executions_report_id ON report_executions(report_id);
CREATE INDEX IF NOT EXISTS idx_report_executions_user_id ON report_executions(user_id);
CREATE INDEX IF NOT EXISTS idx_report_executions_status ON report_executions(status);
CREATE INDEX IF NOT EXISTS idx_report_executions_cache_key ON report_executions(cache_key);

CREATE INDEX IF NOT EXISTS idx_drill_through_configs_user_id ON drill_through_configs(user_id);
CREATE INDEX IF NOT EXISTS idx_drill_through_configs_source_report ON drill_through_configs(source_report_id);
CREATE INDEX IF NOT EXISTS idx_drill_through_configs_enabled ON drill_through_configs(is_enabled);

CREATE INDEX IF NOT EXISTS idx_report_data_sources_user_id ON report_data_sources(user_id);
CREATE INDEX IF NOT EXISTS idx_report_data_sources_type ON report_data_sources(source_type);
CREATE INDEX IF NOT EXISTS idx_report_data_sources_active ON report_data_sources(is_active);

CREATE INDEX IF NOT EXISTS idx_report_dimensions_data_source ON report_dimensions(data_source_id);
CREATE INDEX IF NOT EXISTS idx_report_dimensions_parent ON report_dimensions(parent_dimension_id);
CREATE INDEX IF NOT EXISTS idx_report_dimensions_visible ON report_dimensions(is_visible);

CREATE INDEX IF NOT EXISTS idx_report_measures_data_source ON report_measures(data_source_id);
CREATE INDEX IF NOT EXISTS idx_report_measures_calculation_type ON report_measures(calculation_type);

CREATE INDEX IF NOT EXISTS idx_report_filters_report_id ON report_filters(report_id);
CREATE INDEX IF NOT EXISTS idx_report_filters_dimension_id ON report_filters(dimension_id);

CREATE INDEX IF NOT EXISTS idx_report_shares_report_id ON report_shares(report_id);
CREATE INDEX IF NOT EXISTS idx_report_shares_shared_with ON report_shares(shared_with);
CREATE INDEX IF NOT EXISTS idx_report_shares_token ON report_shares(share_token);
CREATE INDEX IF NOT EXISTS idx_report_shares_active ON report_shares(is_active);

CREATE INDEX IF NOT EXISTS idx_report_comments_report_id ON report_comments(report_id);
CREATE INDEX IF NOT EXISTS idx_report_comments_user_id ON report_comments(user_id);
CREATE INDEX IF NOT EXISTS idx_report_comments_parent ON report_comments(parent_comment_id);

-- Row Level Security (RLS) policies
ALTER TABLE report_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE custom_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_executions ENABLE ROW LEVEL SECURITY;
ALTER TABLE drill_through_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_data_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_dimensions ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_measures ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_filters ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_shares ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_comments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for report_templates
CREATE POLICY "Users can view public and their own templates" ON report_templates
    FOR SELECT USING (is_public = true OR auth.uid() = user_id);

CREATE POLICY "Users can manage their own templates" ON report_templates
    FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for custom_reports
CREATE POLICY "Users can manage their own reports" ON custom_reports
    FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view shared reports" ON custom_reports
    FOR SELECT USING (
        auth.uid() = user_id OR 
        is_shared = true OR
        EXISTS (
            SELECT 1 FROM report_shares 
            WHERE report_shares.report_id = custom_reports.id 
            AND report_shares.shared_with = auth.uid()
            AND report_shares.is_active = true
        )
    );

-- RLS Policies for report_executions
CREATE POLICY "Users can view executions for accessible reports" ON report_executions
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM custom_reports 
            WHERE custom_reports.id = report_executions.report_id 
            AND (
                custom_reports.user_id = auth.uid() OR
                custom_reports.is_shared = true OR
                EXISTS (
                    SELECT 1 FROM report_shares 
                    WHERE report_shares.report_id = custom_reports.id 
                    AND report_shares.shared_with = auth.uid()
                    AND report_shares.is_active = true
                )
            )
        )
    );

-- RLS Policies for other tables follow similar patterns...

-- Functions for automatic timestamp updates
CREATE OR REPLACE FUNCTION update_report_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for automatic timestamp updates
CREATE TRIGGER update_report_templates_updated_at
    BEFORE UPDATE ON report_templates
    FOR EACH ROW
    EXECUTE FUNCTION update_report_updated_at();

CREATE TRIGGER update_custom_reports_updated_at
    BEFORE UPDATE ON custom_reports
    FOR EACH ROW
    EXECUTE FUNCTION update_report_updated_at();

CREATE TRIGGER update_drill_through_configs_updated_at
    BEFORE UPDATE ON drill_through_configs
    FOR EACH ROW
    EXECUTE FUNCTION update_report_updated_at();

CREATE TRIGGER update_report_data_sources_updated_at
    BEFORE UPDATE ON report_data_sources
    FOR EACH ROW
    EXECUTE FUNCTION update_report_updated_at();

CREATE TRIGGER update_report_dimensions_updated_at
    BEFORE UPDATE ON report_dimensions
    FOR EACH ROW
    EXECUTE FUNCTION update_report_updated_at();

CREATE TRIGGER update_report_measures_updated_at
    BEFORE UPDATE ON report_measures
    FOR EACH ROW
    EXECUTE FUNCTION update_report_updated_at();

CREATE TRIGGER update_report_filters_updated_at
    BEFORE UPDATE ON report_filters
    FOR EACH ROW
    EXECUTE FUNCTION update_report_updated_at();

CREATE TRIGGER update_report_shares_updated_at
    BEFORE UPDATE ON report_shares
    FOR EACH ROW
    EXECUTE FUNCTION update_report_updated_at();

CREATE TRIGGER update_report_comments_updated_at
    BEFORE UPDATE ON report_comments
    FOR EACH ROW
    EXECUTE FUNCTION update_report_updated_at();

-- Function to execute a custom report
CREATE OR REPLACE FUNCTION execute_custom_report(
    report_id UUID,
    user_id UUID,
    parameters JSONB DEFAULT '{}'::JSONB
)
RETURNS JSONB AS $$
DECLARE
    report_record RECORD;
    execution_id UUID;
    result JSONB;
    start_time TIMESTAMP WITH TIME ZONE;
    end_time TIMESTAMP WITH TIME ZONE;
    row_count INTEGER := 0;
BEGIN
    start_time := NOW();
    
    -- Get report configuration
    SELECT * INTO report_record 
    FROM custom_reports 
    WHERE id = report_id;
    
    IF NOT FOUND THEN
        RETURN jsonb_build_object('error', 'Report not found');
    END IF;
    
    -- Create execution record
    INSERT INTO report_executions (
        report_id, user_id, execution_start, parameters, status
    ) VALUES (
        report_id, user_id, start_time, parameters, 'running'
    ) RETURNING id INTO execution_id;
    
    -- Execute report logic would go here
    -- This is a simplified version that returns sample data
    result := jsonb_build_object(
        'execution_id', execution_id,
        'report_id', report_id,
        'data', '[]'::JSONB,
        'columns', '[]'::JSONB,
        'row_count', row_count,
        'execution_time_ms', EXTRACT(EPOCH FROM (NOW() - start_time)) * 1000
    );
    
    end_time := NOW();
    
    -- Update execution record
    UPDATE report_executions 
    SET 
        execution_end = end_time,
        execution_time_ms = EXTRACT(EPOCH FROM (end_time - start_time)) * 1000,
        status = 'completed',
        row_count = row_count
    WHERE id = execution_id;
    
    RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get drill-through data
CREATE OR REPLACE FUNCTION get_drill_through_data(
    source_report_id UUID,
    source_field VARCHAR(255),
    source_value TEXT,
    user_id UUID
)
RETURNS JSONB AS $$
DECLARE
    drill_config RECORD;
    result JSONB;
BEGIN
    -- Get drill-through configuration
    SELECT * INTO drill_config
    FROM drill_through_configs
    WHERE source_report_id = get_drill_through_data.source_report_id
    AND source_field = get_drill_through_data.source_field
    AND is_enabled = true
    LIMIT 1;
    
    IF NOT FOUND THEN
        RETURN jsonb_build_object('error', 'No drill-through configuration found');
    END IF;
    
    -- Execute drill-through logic based on target_type
    CASE drill_config.target_type
        WHEN 'transaction_list' THEN
            -- Return transaction list filtered by source value
            SELECT jsonb_build_object(
                'type', 'transaction_list',
                'data', jsonb_agg(
                    jsonb_build_object(
                        'id', t.id,
                        'date', t.date,
                        'description', t.description,
                        'amount', t.amount,
                        'account', a.name
                    )
                )
            ) INTO result
            FROM transactions t
            JOIN accounts a ON a.id = t.account_id
            WHERE t.user_id = get_drill_through_data.user_id
            AND t.description ILIKE '%' || source_value || '%'
            LIMIT 100;
            
        WHEN 'report' THEN
            -- Execute target report with filtered parameters
            result := jsonb_build_object(
                'type', 'report',
                'target_report_id', (drill_config.target_config->>'report_id'),
                'parameters', drill_config.parameter_mapping
            );
            
        ELSE
            result := jsonb_build_object('error', 'Unsupported drill-through type');
    END CASE;
    
    RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create system report templates
CREATE OR REPLACE FUNCTION create_system_report_templates()
RETURNS INTEGER AS $$
DECLARE
    template_count INTEGER := 0;
BEGIN
    -- Financial Statement Template
    INSERT INTO report_templates (
        user_id, name, description, category, report_type, 
        report_config, is_system_template, is_public
    ) VALUES (
        '00000000-0000-0000-0000-000000000000', -- System user
        'Income Statement',
        'Standard income statement with revenue, expenses, and net income',
        'financial',
        'table',
        jsonb_build_object(
            'layout', 'vertical',
            'grouping', jsonb_build_array('account_type', 'account_category'),
            'measures', jsonb_build_array('amount'),
            'formatting', jsonb_build_object('currency', true)
        ),
        true,
        true
    );
    
    -- Balance Sheet Template
    INSERT INTO report_templates (
        user_id, name, description, category, report_type, 
        report_config, is_system_template, is_public
    ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        'Balance Sheet',
        'Standard balance sheet with assets, liabilities, and equity',
        'financial',
        'table',
        jsonb_build_object(
            'layout', 'vertical',
            'grouping', jsonb_build_array('account_type', 'account_category'),
            'measures', jsonb_build_array('balance'),
            'formatting', jsonb_build_object('currency', true)
        ),
        true,
        true
    );
    
    -- Cash Flow Template
    INSERT INTO report_templates (
        user_id, name, description, category, report_type, 
        report_config, is_system_template, is_public
    ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        'Cash Flow Statement',
        'Cash flow from operating, investing, and financing activities',
        'financial',
        'table',
        jsonb_build_object(
            'layout', 'vertical',
            'grouping', jsonb_build_array('cash_flow_category'),
            'measures', jsonb_build_array('cash_flow_amount'),
            'formatting', jsonb_build_object('currency', true)
        ),
        true,
        true
    );
    
    -- Transaction Detail Template
    INSERT INTO report_templates (
        user_id, name, description, category, report_type, 
        report_config, is_system_template, is_public
    ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        'Transaction Detail',
        'Detailed transaction listing with drill-through capabilities',
        'operational',
        'table',
        jsonb_build_object(
            'layout', 'horizontal',
            'columns', jsonb_build_array('date', 'description', 'account', 'amount'),
            'sorting', jsonb_build_object('field', 'date', 'direction', 'desc'),
            'formatting', jsonb_build_object('currency', true)
        ),
        true,
        true
    );
    
    GET DIAGNOSTICS template_count = ROW_COUNT;
    
    RETURN template_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add comments for documentation
COMMENT ON TABLE report_templates IS 'Report templates for ad-hoc reporting';
COMMENT ON TABLE custom_reports IS 'Custom reports created by users';
COMMENT ON TABLE report_executions IS 'Report execution history and caching';
COMMENT ON TABLE drill_through_configs IS 'Drill-through configurations';
COMMENT ON TABLE report_data_sources IS 'Data sources for reports';
COMMENT ON TABLE report_dimensions IS 'Report dimensions for grouping';
COMMENT ON TABLE report_measures IS 'Report measures for calculations';
COMMENT ON TABLE report_filters IS 'Report filters and parameters';
COMMENT ON TABLE report_shares IS 'Report sharing and collaboration';
COMMENT ON TABLE report_comments IS 'Report comments and annotations';

COMMENT ON FUNCTION execute_custom_report IS 'Execute a custom report with parameters';
COMMENT ON FUNCTION get_drill_through_data IS 'Get drill-through data for a report field';
COMMENT ON FUNCTION create_system_report_templates IS 'Create default system report templates';

