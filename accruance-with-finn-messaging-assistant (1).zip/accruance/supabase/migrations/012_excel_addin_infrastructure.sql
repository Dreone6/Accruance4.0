-- Migration: 012_excel_addin_infrastructure.sql
-- Description: Add tables for Excel Add-in functionality

-- User API keys for Excel authentication
CREATE TABLE IF NOT EXISTS user_api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    api_key_hash TEXT NOT NULL UNIQUE,
    permissions JSONB DEFAULT '["read", "write"]'::jsonb,
    is_active BOOLEAN DEFAULT true,
    last_used_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Excel activity logs for monitoring and debugging
CREATE TABLE IF NOT EXISTS excel_activity_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    activity VARCHAR(100) NOT NULL, -- 'authentication', 'data_pull', 'push_adjustments'
    metadata JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Excel adjustments for tracking changes that don't map to specific records
CREATE TABLE IF NOT EXISTS excel_adjustments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    change_type VARCHAR(100) NOT NULL,
    original_value TEXT,
    new_value TEXT,
    cell_address VARCHAR(50),
    row_index INTEGER,
    col_index INTEGER,
    metadata JSONB,
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'applied', 'rejected'
    applied_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Excel audit trail for comprehensive change tracking
CREATE TABLE IF NOT EXISTS excel_audit_trail (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    action VARCHAR(100) NOT NULL,
    changes_count INTEGER DEFAULT 0,
    processed_count INTEGER DEFAULT 0,
    created_count INTEGER DEFAULT 0,
    updated_count INTEGER DEFAULT 0,
    failed_count INTEGER DEFAULT 0,
    changes_data JSONB,
    result_data JSONB,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Excel sync sessions for tracking ongoing sync operations
CREATE TABLE IF NOT EXISTS excel_sync_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    session_type VARCHAR(50) NOT NULL, -- 'pull', 'push', 'bidirectional'
    data_type VARCHAR(50), -- 'transactions', 'accounts', 'budget', 'forecast'
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'completed', 'failed', 'cancelled'
    range_address VARCHAR(100),
    record_count INTEGER DEFAULT 0,
    last_activity_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    error_message TEXT,
    metadata JSONB
);

-- Excel formula preservation for maintaining Excel formulas during data refresh
CREATE TABLE IF NOT EXISTS excel_formula_preservation (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    session_id UUID REFERENCES excel_sync_sessions(id) ON DELETE CASCADE,
    cell_address VARCHAR(50) NOT NULL,
    formula TEXT NOT NULL,
    cell_value TEXT,
    dependencies JSONB, -- Array of cell addresses this formula depends on
    is_preserved BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Excel data mappings for linking Excel cells to Accruance records
CREATE TABLE IF NOT EXISTS excel_data_mappings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    session_id UUID REFERENCES excel_sync_sessions(id) ON DELETE CASCADE,
    cell_address VARCHAR(50) NOT NULL,
    row_index INTEGER NOT NULL,
    col_index INTEGER NOT NULL,
    record_type VARCHAR(50) NOT NULL, -- 'transaction', 'account', 'budget_item'
    record_id UUID NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    data_type VARCHAR(50), -- 'string', 'number', 'date', 'boolean'
    is_editable BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_user_api_keys_user_id ON user_api_keys(user_id);
CREATE INDEX IF NOT EXISTS idx_user_api_keys_hash ON user_api_keys(api_key_hash);
CREATE INDEX IF NOT EXISTS idx_user_api_keys_active ON user_api_keys(is_active);

CREATE INDEX IF NOT EXISTS idx_excel_activity_logs_user_id ON excel_activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_excel_activity_logs_activity ON excel_activity_logs(activity);
CREATE INDEX IF NOT EXISTS idx_excel_activity_logs_created_at ON excel_activity_logs(created_at);

CREATE INDEX IF NOT EXISTS idx_excel_adjustments_user_id ON excel_adjustments(user_id);
CREATE INDEX IF NOT EXISTS idx_excel_adjustments_status ON excel_adjustments(status);
CREATE INDEX IF NOT EXISTS idx_excel_adjustments_created_at ON excel_adjustments(created_at);

CREATE INDEX IF NOT EXISTS idx_excel_audit_trail_user_id ON excel_audit_trail(user_id);
CREATE INDEX IF NOT EXISTS idx_excel_audit_trail_action ON excel_audit_trail(action);
CREATE INDEX IF NOT EXISTS idx_excel_audit_trail_created_at ON excel_audit_trail(created_at);

CREATE INDEX IF NOT EXISTS idx_excel_sync_sessions_user_id ON excel_sync_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_excel_sync_sessions_status ON excel_sync_sessions(status);
CREATE INDEX IF NOT EXISTS idx_excel_sync_sessions_started_at ON excel_sync_sessions(started_at);

CREATE INDEX IF NOT EXISTS idx_excel_formula_preservation_user_id ON excel_formula_preservation(user_id);
CREATE INDEX IF NOT EXISTS idx_excel_formula_preservation_session_id ON excel_formula_preservation(session_id);
CREATE INDEX IF NOT EXISTS idx_excel_formula_preservation_cell_address ON excel_formula_preservation(cell_address);

CREATE INDEX IF NOT EXISTS idx_excel_data_mappings_user_id ON excel_data_mappings(user_id);
CREATE INDEX IF NOT EXISTS idx_excel_data_mappings_session_id ON excel_data_mappings(session_id);
CREATE INDEX IF NOT EXISTS idx_excel_data_mappings_record ON excel_data_mappings(record_type, record_id);

-- Row Level Security (RLS) policies
ALTER TABLE user_api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE excel_activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE excel_adjustments ENABLE ROW LEVEL SECURITY;
ALTER TABLE excel_audit_trail ENABLE ROW LEVEL SECURITY;
ALTER TABLE excel_sync_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE excel_formula_preservation ENABLE ROW LEVEL SECURITY;
ALTER TABLE excel_data_mappings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_api_keys
CREATE POLICY "Users can manage their own API keys" ON user_api_keys
    FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for excel_activity_logs
CREATE POLICY "Users can view their own Excel activity logs" ON excel_activity_logs
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "System can insert Excel activity logs" ON excel_activity_logs
    FOR INSERT WITH CHECK (true);

-- RLS Policies for excel_adjustments
CREATE POLICY "Users can manage their own Excel adjustments" ON excel_adjustments
    FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for excel_audit_trail
CREATE POLICY "Users can view their own Excel audit trail" ON excel_audit_trail
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "System can insert Excel audit trail" ON excel_audit_trail
    FOR INSERT WITH CHECK (true);

-- RLS Policies for excel_sync_sessions
CREATE POLICY "Users can manage their own Excel sync sessions" ON excel_sync_sessions
    FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for excel_formula_preservation
CREATE POLICY "Users can manage their own Excel formula preservation" ON excel_formula_preservation
    FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for excel_data_mappings
CREATE POLICY "Users can manage their own Excel data mappings" ON excel_data_mappings
    FOR ALL USING (auth.uid() = user_id);

-- Functions for automatic timestamp updates
CREATE OR REPLACE FUNCTION update_excel_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for automatic timestamp updates
CREATE TRIGGER update_user_api_keys_updated_at
    BEFORE UPDATE ON user_api_keys
    FOR EACH ROW
    EXECUTE FUNCTION update_excel_updated_at();

CREATE TRIGGER update_excel_adjustments_updated_at
    BEFORE UPDATE ON excel_adjustments
    FOR EACH ROW
    EXECUTE FUNCTION update_excel_updated_at();

CREATE TRIGGER update_excel_data_mappings_updated_at
    BEFORE UPDATE ON excel_data_mappings
    FOR EACH ROW
    EXECUTE FUNCTION update_excel_updated_at();

-- Function to process Excel changes in a transaction
CREATE OR REPLACE FUNCTION process_excel_changes(
    user_id UUID,
    changes_data JSONB,
    metadata_data JSONB
)
RETURNS JSONB AS $$
DECLARE
    session_id UUID;
    result JSONB;
BEGIN
    -- Create a new sync session
    INSERT INTO excel_sync_sessions (user_id, session_type, status, metadata)
    VALUES (user_id, 'push', 'active', metadata_data)
    RETURNING id INTO session_id;
    
    -- Process changes would be implemented here
    -- For now, return success
    result := jsonb_build_object(
        'success', true,
        'session_id', session_id,
        'processed', jsonb_array_length(changes_data)
    );
    
    -- Update session status
    UPDATE excel_sync_sessions 
    SET status = 'completed', completed_at = NOW()
    WHERE id = session_id;
    
    RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to clean up old Excel data
CREATE OR REPLACE FUNCTION cleanup_excel_data(days_to_keep INTEGER DEFAULT 90)
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER := 0;
    cutoff_date TIMESTAMP WITH TIME ZONE;
BEGIN
    cutoff_date := NOW() - (days_to_keep || ' days')::INTERVAL;
    
    -- Clean up old activity logs
    DELETE FROM excel_activity_logs WHERE created_at < cutoff_date;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    -- Clean up old completed sync sessions
    DELETE FROM excel_sync_sessions 
    WHERE status = 'completed' AND completed_at < cutoff_date;
    
    -- Clean up old applied adjustments
    DELETE FROM excel_adjustments 
    WHERE status = 'applied' AND applied_at < cutoff_date;
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get Excel usage statistics
CREATE OR REPLACE FUNCTION get_excel_usage_stats(user_id UUID)
RETURNS JSONB AS $$
DECLARE
    stats JSONB;
BEGIN
    SELECT jsonb_build_object(
        'total_sessions', COUNT(*),
        'active_sessions', COUNT(*) FILTER (WHERE status = 'active'),
        'completed_sessions', COUNT(*) FILTER (WHERE status = 'completed'),
        'failed_sessions', COUNT(*) FILTER (WHERE status = 'failed'),
        'last_activity', MAX(last_activity_at),
        'total_records_synced', COALESCE(SUM(record_count), 0)
    )
    INTO stats
    FROM excel_sync_sessions
    WHERE excel_sync_sessions.user_id = get_excel_usage_stats.user_id;
    
    RETURN stats;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Insert default API key permissions
INSERT INTO user_api_keys (user_id, name, api_key_hash, permissions, is_active)
SELECT 
    id,
    'Default Excel API Key',
    'placeholder_hash_' || id::text,
    '["read", "write", "excel"]'::jsonb,
    false
FROM auth.users
WHERE NOT EXISTS (
    SELECT 1 FROM user_api_keys 
    WHERE user_api_keys.user_id = auth.users.id
)
LIMIT 0; -- Don't actually insert, just show the pattern

-- Add comments for documentation
COMMENT ON TABLE user_api_keys IS 'API keys for Excel add-in authentication';
COMMENT ON TABLE excel_activity_logs IS 'Logs of all Excel add-in activities for monitoring';
COMMENT ON TABLE excel_adjustments IS 'Tracks Excel changes that don''t map to specific records';
COMMENT ON TABLE excel_audit_trail IS 'Comprehensive audit trail for Excel operations';
COMMENT ON TABLE excel_sync_sessions IS 'Tracks ongoing Excel sync operations';
COMMENT ON TABLE excel_formula_preservation IS 'Preserves Excel formulas during data refresh';
COMMENT ON TABLE excel_data_mappings IS 'Maps Excel cells to Accruance records for two-way sync';

COMMENT ON FUNCTION process_excel_changes IS 'Processes Excel changes in a transaction';
COMMENT ON FUNCTION cleanup_excel_data IS 'Cleans up old Excel data to maintain performance';
COMMENT ON FUNCTION get_excel_usage_stats IS 'Returns Excel usage statistics for a user';

