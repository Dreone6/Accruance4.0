-- Migration: 017_finn_messaging_assistant
-- Description: Add database schema for FINN messaging assistant features
-- Created: 2025-06-23

-- Table to track FINN messaging assistant usage
CREATE TABLE finn_messaging_usage (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  action_type VARCHAR(50) NOT NULL, -- analyze_message, suggest_improvements, rewrite_message, etc.
  message_length INTEGER,
  recipient_context JSONB,
  conversation_context JSONB,
  tone_preference VARCHAR(50),
  processing_time_ms INTEGER,
  tokens_used INTEGER,
  success BOOLEAN DEFAULT true,
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table to store user's FINN messaging preferences
CREATE TABLE finn_messaging_preferences (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  default_tone VARCHAR(50) DEFAULT 'professional', -- professional, friendly, formal, casual
  auto_suggestions BOOLEAN DEFAULT true,
  grammar_check_enabled BOOLEAN DEFAULT true,
  tone_analysis_enabled BOOLEAN DEFAULT true,
  response_suggestions_enabled BOOLEAN DEFAULT true,
  professional_polish_enabled BOOLEAN DEFAULT true,
  preferred_communication_style VARCHAR(50) DEFAULT 'balanced', -- concise, detailed, balanced
  industry_context VARCHAR(100),
  role_context VARCHAR(100), -- CEO, CFO, Manager, etc.
  custom_instructions TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, organization_id)
);

-- Table to store conversation context for better FINN suggestions
CREATE TABLE finn_conversation_context (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  conversation_id UUID NOT NULL, -- References messages.conversation_id
  recipient_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  relationship_type VARCHAR(50), -- client, vendor, colleague, professional, etc.
  communication_history JSONB, -- Summary of past communication patterns
  preferred_tone_with_recipient VARCHAR(50),
  context_summary TEXT,
  last_interaction_at TIMESTAMP WITH TIME ZONE,
  interaction_count INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, conversation_id)
);

-- Table to store FINN's message improvement suggestions and user feedback
CREATE TABLE finn_message_improvements (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  usage_id UUID REFERENCES finn_messaging_usage(id) ON DELETE CASCADE,
  original_message TEXT NOT NULL,
  improved_message TEXT,
  improvement_type VARCHAR(50), -- tone, clarity, professionalism, grammar, etc.
  suggestions JSONB, -- Array of specific suggestions
  user_accepted BOOLEAN,
  user_modified BOOLEAN,
  final_message TEXT, -- What the user actually sent
  effectiveness_score INTEGER, -- 1-10 rating
  user_feedback TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table to store FINN messaging templates based on successful patterns
CREATE TABLE finn_messaging_templates (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE, -- NULL for system templates
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  template_name VARCHAR(100) NOT NULL,
  template_category VARCHAR(50), -- greeting, follow_up, proposal, meeting_request, etc.
  template_content TEXT NOT NULL,
  tone VARCHAR(50),
  use_case_description TEXT,
  industry_specific BOOLEAN DEFAULT false,
  role_specific BOOLEAN DEFAULT false,
  usage_count INTEGER DEFAULT 0,
  effectiveness_rating DECIMAL(3,2), -- Average user rating
  is_system_template BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table to track FINN messaging analytics and insights
CREATE TABLE finn_messaging_analytics (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  total_assists INTEGER DEFAULT 0,
  messages_analyzed INTEGER DEFAULT 0,
  messages_improved INTEGER DEFAULT 0,
  messages_rewritten INTEGER DEFAULT 0,
  grammar_checks INTEGER DEFAULT 0,
  tone_analyses INTEGER DEFAULT 0,
  response_suggestions INTEGER DEFAULT 0,
  professional_polishes INTEGER DEFAULT 0,
  average_improvement_score DECIMAL(3,2),
  most_common_tone VARCHAR(50),
  most_improved_area VARCHAR(50), -- tone, clarity, grammar, etc.
  time_saved_minutes INTEGER, -- Estimated time saved
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, organization_id, date)
);

-- Create indexes for performance
CREATE INDEX idx_finn_messaging_usage_user_date ON finn_messaging_usage(user_id, created_at DESC);
CREATE INDEX idx_finn_messaging_usage_organization ON finn_messaging_usage(organization_id);
CREATE INDEX idx_finn_messaging_usage_action_type ON finn_messaging_usage(action_type);

CREATE INDEX idx_finn_conversation_context_user ON finn_conversation_context(user_id);
CREATE INDEX idx_finn_conversation_context_conversation ON finn_conversation_context(conversation_id);
CREATE INDEX idx_finn_conversation_context_recipient ON finn_conversation_context(recipient_user_id);

CREATE INDEX idx_finn_message_improvements_user ON finn_message_improvements(user_id);
CREATE INDEX idx_finn_message_improvements_usage ON finn_message_improvements(usage_id);
CREATE INDEX idx_finn_message_improvements_type ON finn_message_improvements(improvement_type);

CREATE INDEX idx_finn_messaging_templates_user ON finn_messaging_templates(user_id);
CREATE INDEX idx_finn_messaging_templates_category ON finn_messaging_templates(template_category);
CREATE INDEX idx_finn_messaging_templates_system ON finn_messaging_templates(is_system_template) WHERE is_system_template = true;

CREATE INDEX idx_finn_messaging_analytics_user_date ON finn_messaging_analytics(user_id, date DESC);
CREATE INDEX idx_finn_messaging_analytics_organization ON finn_messaging_analytics(organization_id);

-- Enable Row Level Security
ALTER TABLE finn_messaging_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE finn_messaging_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE finn_conversation_context ENABLE ROW LEVEL SECURITY;
ALTER TABLE finn_message_improvements ENABLE ROW LEVEL SECURITY;
ALTER TABLE finn_messaging_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE finn_messaging_analytics ENABLE ROW LEVEL SECURITY;

-- RLS Policies for finn_messaging_usage
CREATE POLICY "Users can view their own FINN messaging usage" ON finn_messaging_usage
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own FINN messaging usage" ON finn_messaging_usage
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own FINN messaging usage" ON finn_messaging_usage
  FOR UPDATE USING (auth.uid() = user_id);

-- RLS Policies for finn_messaging_preferences
CREATE POLICY "Users can manage their own FINN messaging preferences" ON finn_messaging_preferences
  FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for finn_conversation_context
CREATE POLICY "Users can manage their own conversation context" ON finn_conversation_context
  FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for finn_message_improvements
CREATE POLICY "Users can view their own message improvements" ON finn_message_improvements
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own message improvements" ON finn_message_improvements
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own message improvements" ON finn_message_improvements
  FOR UPDATE USING (auth.uid() = user_id);

-- RLS Policies for finn_messaging_templates
CREATE POLICY "Users can view system templates and their own templates" ON finn_messaging_templates
  FOR SELECT USING (is_system_template = true OR auth.uid() = user_id);

CREATE POLICY "Users can manage their own templates" ON finn_messaging_templates
  FOR ALL USING (auth.uid() = user_id AND is_system_template = false);

-- RLS Policies for finn_messaging_analytics
CREATE POLICY "Users can view their own messaging analytics" ON finn_messaging_analytics
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own messaging analytics" ON finn_messaging_analytics
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own messaging analytics" ON finn_messaging_analytics
  FOR UPDATE USING (auth.uid() = user_id);

-- Function to update FINN messaging analytics
CREATE OR REPLACE FUNCTION update_finn_messaging_analytics()
RETURNS TRIGGER AS $$
BEGIN
  -- Update daily analytics when new usage is recorded
  INSERT INTO finn_messaging_analytics (
    user_id,
    organization_id,
    date,
    total_assists,
    messages_analyzed,
    messages_improved,
    messages_rewritten,
    grammar_checks,
    tone_analyses,
    response_suggestions,
    professional_polishes
  )
  VALUES (
    NEW.user_id,
    NEW.organization_id,
    CURRENT_DATE,
    1,
    CASE WHEN NEW.action_type = 'analyze_message' THEN 1 ELSE 0 END,
    CASE WHEN NEW.action_type = 'suggest_improvements' THEN 1 ELSE 0 END,
    CASE WHEN NEW.action_type = 'rewrite_message' THEN 1 ELSE 0 END,
    CASE WHEN NEW.action_type = 'grammar_check' THEN 1 ELSE 0 END,
    CASE WHEN NEW.action_type = 'check_tone' THEN 1 ELSE 0 END,
    CASE WHEN NEW.action_type = 'suggest_responses' THEN 1 ELSE 0 END,
    CASE WHEN NEW.action_type = 'professional_polish' THEN 1 ELSE 0 END
  )
  ON CONFLICT (user_id, organization_id, date)
  DO UPDATE SET
    total_assists = finn_messaging_analytics.total_assists + 1,
    messages_analyzed = finn_messaging_analytics.messages_analyzed + 
      CASE WHEN NEW.action_type = 'analyze_message' THEN 1 ELSE 0 END,
    messages_improved = finn_messaging_analytics.messages_improved + 
      CASE WHEN NEW.action_type = 'suggest_improvements' THEN 1 ELSE 0 END,
    messages_rewritten = finn_messaging_analytics.messages_rewritten + 
      CASE WHEN NEW.action_type = 'rewrite_message' THEN 1 ELSE 0 END,
    grammar_checks = finn_messaging_analytics.grammar_checks + 
      CASE WHEN NEW.action_type = 'grammar_check' THEN 1 ELSE 0 END,
    tone_analyses = finn_messaging_analytics.tone_analyses + 
      CASE WHEN NEW.action_type = 'check_tone' THEN 1 ELSE 0 END,
    response_suggestions = finn_messaging_analytics.response_suggestions + 
      CASE WHEN NEW.action_type = 'suggest_responses' THEN 1 ELSE 0 END,
    professional_polishes = finn_messaging_analytics.professional_polishes + 
      CASE WHEN NEW.action_type = 'professional_polish' THEN 1 ELSE 0 END,
    updated_at = NOW();

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for analytics updates
CREATE TRIGGER trigger_update_finn_messaging_analytics
  AFTER INSERT ON finn_messaging_usage
  FOR EACH ROW
  EXECUTE FUNCTION update_finn_messaging_analytics();

-- Function to get user's FINN messaging usage limits
CREATE OR REPLACE FUNCTION get_finn_messaging_limits(user_uuid UUID)
RETURNS TABLE (
  plan VARCHAR(50),
  monthly_limit INTEGER,
  current_usage INTEGER,
  remaining_usage INTEGER,
  usage_percentage DECIMAL(5,2)
) AS $$
DECLARE
  user_plan VARCHAR(50);
  plan_limit INTEGER;
  current_month_usage INTEGER;
BEGIN
  -- Get user's subscription plan
  SELECT subscription_plan INTO user_plan
  FROM user_profiles
  WHERE user_id = user_uuid;

  -- Set limits based on plan
  plan_limit := CASE user_plan
    WHEN 'free' THEN 0
    WHEN 'essentials' THEN 50
    WHEN 'professional' THEN 200
    WHEN 'enterprise' THEN 1000
    ELSE 0
  END;

  -- Get current month usage
  SELECT COUNT(*) INTO current_month_usage
  FROM finn_messaging_usage
  WHERE user_id = user_uuid
    AND created_at >= DATE_TRUNC('month', CURRENT_DATE)
    AND success = true;

  -- Return results
  RETURN QUERY SELECT
    user_plan,
    plan_limit,
    current_month_usage,
    GREATEST(0, plan_limit - current_month_usage),
    CASE WHEN plan_limit > 0 THEN 
      ROUND((current_month_usage::DECIMAL / plan_limit::DECIMAL) * 100, 2)
    ELSE 0 END;
END;
$$ LANGUAGE plpgsql;

-- Function to create default FINN messaging preferences for new users
CREATE OR REPLACE FUNCTION create_default_finn_messaging_preferences(user_uuid UUID, org_uuid UUID DEFAULT NULL)
RETURNS VOID AS $$
BEGIN
  INSERT INTO finn_messaging_preferences (
    user_id,
    organization_id,
    default_tone,
    auto_suggestions,
    grammar_check_enabled,
    tone_analysis_enabled,
    response_suggestions_enabled,
    professional_polish_enabled,
    preferred_communication_style
  )
  VALUES (
    user_uuid,
    org_uuid,
    'professional',
    true,
    true,
    true,
    true,
    true,
    'balanced'
  )
  ON CONFLICT (user_id, organization_id) DO NOTHING;
END;
$$ LANGUAGE plpgsql;

-- Insert system messaging templates
INSERT INTO finn_messaging_templates (
  template_name,
  template_category,
  template_content,
  tone,
  use_case_description,
  is_system_template,
  effectiveness_rating
) VALUES
(
  'Professional Introduction',
  'greeting',
  'Hello [Name], I hope this message finds you well. I''m reaching out regarding [topic/project]. I''d appreciate the opportunity to discuss this further at your convenience.',
  'professional',
  'Initial contact with new business contacts or potential clients',
  true,
  4.5
),
(
  'Meeting Request',
  'meeting_request',
  'Hi [Name], I''d like to schedule a meeting to discuss [topic]. Would you be available for a [duration] call sometime [timeframe]? I''m flexible with timing and can work around your schedule.',
  'friendly',
  'Requesting meetings with colleagues or clients',
  true,
  4.7
),
(
  'Follow-up After Meeting',
  'follow_up',
  'Thank you for taking the time to meet with me today. As discussed, I''ll [action items]. Please let me know if you have any questions or if there''s anything else I can help with.',
  'professional',
  'Following up after business meetings or calls',
  true,
  4.6
),
(
  'Project Update',
  'update',
  'Hi [Name], I wanted to provide you with a quick update on [project]. We''ve completed [milestone] and are on track for [next milestone] by [date]. I''ll keep you posted on our progress.',
  'professional',
  'Updating stakeholders on project progress',
  true,
  4.4
),
(
  'Request for Information',
  'request',
  'Hello [Name], I hope you''re doing well. I''m working on [project/task] and would appreciate your input on [specific question]. When you have a moment, could you please [specific request]?',
  'friendly',
  'Requesting information or assistance from colleagues',
  true,
  4.3
);

-- Add updated_at trigger for all tables
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_finn_messaging_usage_updated_at
  BEFORE UPDATE ON finn_messaging_usage
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_finn_messaging_preferences_updated_at
  BEFORE UPDATE ON finn_messaging_preferences
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_finn_conversation_context_updated_at
  BEFORE UPDATE ON finn_conversation_context
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_finn_message_improvements_updated_at
  BEFORE UPDATE ON finn_message_improvements
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_finn_messaging_templates_updated_at
  BEFORE UPDATE ON finn_messaging_templates
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_finn_messaging_analytics_updated_at
  BEFORE UPDATE ON finn_messaging_analytics
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

