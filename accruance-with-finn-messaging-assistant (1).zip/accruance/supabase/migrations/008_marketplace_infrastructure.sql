-- Marketplace Infrastructure (Dormant)
-- This schema supports the future marketplace but remains inactive until enabled

-- Service categories for marketplace
CREATE TABLE IF NOT EXISTS service_categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  icon VARCHAR(50),
  is_active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Professional services offered in marketplace
CREATE TABLE IF NOT EXISTS services (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id UUID REFERENCES service_categories(id) ON DELETE SET NULL,
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  service_type VARCHAR(20) CHECK (service_type IN ('hourly', 'fixed', 'package', 'retainer')) DEFAULT 'hourly',
  price DECIMAL(10,2) NOT NULL,
  duration_estimate INTEGER, -- in hours
  requirements TEXT, -- What client needs to provide
  deliverables TEXT, -- What professional will deliver
  is_active BOOLEAN DEFAULT true,
  is_featured BOOLEAN DEFAULT false,
  featured_until TIMESTAMP WITH TIME ZONE,
  tags TEXT[],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Service bookings/orders
CREATE TABLE IF NOT EXISTS service_bookings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  service_id UUID REFERENCES services(id) ON DELETE CASCADE,
  client_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  professional_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  status VARCHAR(20) CHECK (status IN ('pending', 'confirmed', 'in_progress', 'completed', 'cancelled', 'disputed')) DEFAULT 'pending',
  scheduled_date TIMESTAMP WITH TIME ZONE,
  completion_date TIMESTAMP WITH TIME ZONE,
  total_amount DECIMAL(10,2) NOT NULL,
  platform_fee DECIMAL(10,2) NOT NULL,
  professional_amount DECIMAL(10,2) NOT NULL,
  payment_status VARCHAR(20) CHECK (payment_status IN ('pending', 'paid', 'held', 'released', 'refunded')) DEFAULT 'pending',
  stripe_payment_intent_id VARCHAR(255),
  client_notes TEXT,
  professional_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Service reviews and ratings
CREATE TABLE IF NOT EXISTS service_reviews (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  booking_id UUID REFERENCES service_bookings(id) ON DELETE CASCADE,
  service_id UUID REFERENCES services(id) ON DELETE CASCADE,
  client_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  professional_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  overall_rating INTEGER CHECK (overall_rating >= 1 AND overall_rating <= 5) NOT NULL,
  communication_rating INTEGER CHECK (communication_rating >= 1 AND communication_rating <= 5),
  quality_rating INTEGER CHECK (quality_rating >= 1 AND quality_rating <= 5),
  timeliness_rating INTEGER CHECK (timeliness_rating >= 1 AND timeliness_rating <= 5),
  review_text TEXT,
  response_text TEXT, -- Professional response
  is_verified BOOLEAN DEFAULT true,
  is_featured BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(booking_id) -- One review per booking
);

-- Marketplace configuration and feature flags
CREATE TABLE IF NOT EXISTS marketplace_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  setting_key VARCHAR(100) UNIQUE NOT NULL,
  setting_value TEXT NOT NULL,
  data_type VARCHAR(20) CHECK (data_type IN ('boolean', 'string', 'number', 'json')) DEFAULT 'string',
  description TEXT,
  is_public BOOLEAN DEFAULT false, -- Whether setting is visible to users
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Professional marketplace profiles (extended)
CREATE TABLE IF NOT EXISTS professional_marketplace_profiles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  is_marketplace_active BOOLEAN DEFAULT false,
  marketplace_tier VARCHAR(20) CHECK (marketplace_tier IN ('basic', 'standard', 'premium', 'enterprise')) DEFAULT 'basic',
  response_time_hours INTEGER DEFAULT 24,
  completion_rate DECIMAL(5,2) DEFAULT 0, -- Percentage
  total_earnings DECIMAL(12,2) DEFAULT 0,
  total_bookings INTEGER DEFAULT 0,
  average_rating DECIMAL(3,2) DEFAULT 0,
  portfolio_items JSONB DEFAULT '[]',
  availability_calendar JSONB DEFAULT '{}',
  auto_accept_bookings BOOLEAN DEFAULT false,
  stripe_connect_account_id VARCHAR(255),
  is_stripe_connected BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Service packages (bundled services)
CREATE TABLE IF NOT EXISTS service_packages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  package_type VARCHAR(20) CHECK (package_type IN ('starter', 'growth', 'enterprise', 'custom')) DEFAULT 'starter',
  total_price DECIMAL(10,2) NOT NULL,
  duration_months INTEGER DEFAULT 1,
  services_included JSONB NOT NULL, -- Array of service IDs and quantities
  features_included TEXT[],
  is_active BOOLEAN DEFAULT true,
  is_popular BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Marketplace disputes
CREATE TABLE IF NOT EXISTS marketplace_disputes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  booking_id UUID REFERENCES service_bookings(id) ON DELETE CASCADE,
  client_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  professional_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  dispute_type VARCHAR(50) CHECK (dispute_type IN ('quality', 'communication', 'payment', 'scope', 'other')) NOT NULL,
  status VARCHAR(20) CHECK (status IN ('open', 'investigating', 'resolved', 'closed')) DEFAULT 'open',
  client_description TEXT NOT NULL,
  professional_response TEXT,
  admin_notes TEXT,
  resolution_notes TEXT,
  refund_amount DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  resolved_at TIMESTAMP WITH TIME ZONE
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_services_professional_id ON services(professional_id);
CREATE INDEX IF NOT EXISTS idx_services_category_id ON services(category_id);
CREATE INDEX IF NOT EXISTS idx_services_is_active ON services(is_active);
CREATE INDEX IF NOT EXISTS idx_services_is_featured ON services(is_featured);
CREATE INDEX IF NOT EXISTS idx_services_price ON services(price);

CREATE INDEX IF NOT EXISTS idx_service_bookings_client_id ON service_bookings(client_id);
CREATE INDEX IF NOT EXISTS idx_service_bookings_professional_id ON service_bookings(professional_id);
CREATE INDEX IF NOT EXISTS idx_service_bookings_status ON service_bookings(status);
CREATE INDEX IF NOT EXISTS idx_service_bookings_scheduled_date ON service_bookings(scheduled_date);

CREATE INDEX IF NOT EXISTS idx_service_reviews_professional_id ON service_reviews(professional_id);
CREATE INDEX IF NOT EXISTS idx_service_reviews_overall_rating ON service_reviews(overall_rating);
CREATE INDEX IF NOT EXISTS idx_service_reviews_is_verified ON service_reviews(is_verified);

CREATE INDEX IF NOT EXISTS idx_marketplace_settings_key ON marketplace_settings(setting_key);

-- Enable RLS on all marketplace tables
ALTER TABLE service_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketplace_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE professional_marketplace_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketplace_disputes ENABLE ROW LEVEL SECURITY;

-- RLS Policies for marketplace tables

-- Service categories (public read)
CREATE POLICY "Anyone can view active service categories" ON service_categories
  FOR SELECT USING (is_active = true);

-- Services (public read for active, professionals can manage their own)
CREATE POLICY "Anyone can view active services" ON services
  FOR SELECT USING (is_active = true);

CREATE POLICY "Professionals can manage their own services" ON services
  FOR ALL USING (auth.uid() = professional_id);

-- Service bookings (participants can view/manage)
CREATE POLICY "Participants can view their bookings" ON service_bookings
  FOR SELECT USING (auth.uid() = client_id OR auth.uid() = professional_id);

CREATE POLICY "Clients can create bookings" ON service_bookings
  FOR INSERT WITH CHECK (auth.uid() = client_id);

CREATE POLICY "Participants can update their bookings" ON service_bookings
  FOR UPDATE USING (auth.uid() = client_id OR auth.uid() = professional_id);

-- Service reviews (public read, participants can create/update)
CREATE POLICY "Anyone can view verified reviews" ON service_reviews
  FOR SELECT USING (is_verified = true);

CREATE POLICY "Clients can create reviews for their bookings" ON service_reviews
  FOR INSERT WITH CHECK (auth.uid() = client_id);

CREATE POLICY "Professionals can respond to their reviews" ON service_reviews
  FOR UPDATE USING (auth.uid() = professional_id);

-- Marketplace settings (public read for public settings)
CREATE POLICY "Anyone can view public marketplace settings" ON marketplace_settings
  FOR SELECT USING (is_public = true);

-- Professional marketplace profiles (public read, professionals manage own)
CREATE POLICY "Anyone can view active marketplace profiles" ON professional_marketplace_profiles
  FOR SELECT USING (is_marketplace_active = true);

CREATE POLICY "Professionals can manage their marketplace profile" ON professional_marketplace_profiles
  FOR ALL USING (auth.uid() = professional_id);

-- Service packages (public read for active, professionals manage own)
CREATE POLICY "Anyone can view active service packages" ON service_packages
  FOR SELECT USING (is_active = true);

CREATE POLICY "Professionals can manage their service packages" ON service_packages
  FOR ALL USING (auth.uid() = professional_id);

-- Marketplace disputes (participants only)
CREATE POLICY "Participants can view their disputes" ON marketplace_disputes
  FOR SELECT USING (auth.uid() = client_id OR auth.uid() = professional_id);

CREATE POLICY "Participants can create disputes" ON marketplace_disputes
  FOR INSERT WITH CHECK (auth.uid() = client_id OR auth.uid() = professional_id);

-- Insert default marketplace settings (disabled by default)
INSERT INTO marketplace_settings (setting_key, setting_value, data_type, description, is_public) VALUES
('marketplace_enabled', 'false', 'boolean', 'Enable/disable marketplace functionality', true),
('marketplace_bookings_enabled', 'false', 'boolean', 'Enable/disable service bookings', true),
('marketplace_payments_enabled', 'false', 'boolean', 'Enable/disable marketplace payments', false),
('commission_rate', '0.08', 'number', 'Platform commission rate (8%)', false),
('minimum_service_price', '50', 'number', 'Minimum service price in USD', true),
('featured_listing_price', '99', 'number', 'Monthly price for featured listings', false),
('auto_approval_enabled', 'false', 'boolean', 'Auto-approve new services', false),
('dispute_resolution_days', '7', 'number', 'Days to resolve disputes', true)
ON CONFLICT (setting_key) DO NOTHING;

-- Insert default service categories
INSERT INTO service_categories (name, description, icon, sort_order) VALUES
('Tax Preparation', 'Individual and business tax filing services', 'calculator', 1),
('Bookkeeping & Accounting', 'Monthly bookkeeping and financial statement preparation', 'book-open', 2),
('Financial Planning', 'Personal and business financial planning services', 'trending-up', 3),
('Business Consulting', 'Strategic business and financial consulting', 'briefcase', 4),
('Audit & Compliance', 'Financial audits and regulatory compliance', 'shield-check', 5),
('Payroll Services', 'Payroll processing and management', 'users', 6),
('CFO Services', 'Part-time and fractional CFO services', 'user-tie', 7),
('Business Formation', 'Entity formation and business setup', 'building', 8)
ON CONFLICT DO NOTHING;

-- Functions for marketplace operations

-- Function to calculate professional ratings
CREATE OR REPLACE FUNCTION update_professional_marketplace_rating()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE professional_marketplace_profiles 
  SET 
    average_rating = (
      SELECT AVG(overall_rating)::DECIMAL(3,2) 
      FROM service_reviews 
      WHERE professional_id = COALESCE(NEW.professional_id, OLD.professional_id)
      AND is_verified = true
    ),
    updated_at = NOW()
  WHERE professional_id = COALESCE(NEW.professional_id, OLD.professional_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to update professional rating when reviews change
DROP TRIGGER IF EXISTS update_marketplace_rating_on_review_change ON service_reviews;
CREATE TRIGGER update_marketplace_rating_on_review_change
  AFTER INSERT OR UPDATE OR DELETE ON service_reviews
  FOR EACH ROW EXECUTE FUNCTION update_professional_marketplace_rating();

-- Function to update booking completion rate
CREATE OR REPLACE FUNCTION update_professional_completion_rate()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE professional_marketplace_profiles 
  SET 
    completion_rate = (
      SELECT 
        CASE 
          WHEN COUNT(*) = 0 THEN 0
          ELSE (COUNT(*) FILTER (WHERE status = 'completed')::DECIMAL / COUNT(*) * 100)::DECIMAL(5,2)
        END
      FROM service_bookings 
      WHERE professional_id = COALESCE(NEW.professional_id, OLD.professional_id)
    ),
    total_bookings = (
      SELECT COUNT(*) 
      FROM service_bookings 
      WHERE professional_id = COALESCE(NEW.professional_id, OLD.professional_id)
    ),
    updated_at = NOW()
  WHERE professional_id = COALESCE(NEW.professional_id, OLD.professional_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to update completion rate when bookings change
DROP TRIGGER IF EXISTS update_completion_rate_on_booking_change ON service_bookings;
CREATE TRIGGER update_completion_rate_on_booking_change
  AFTER INSERT OR UPDATE OR DELETE ON service_bookings
  FOR EACH ROW EXECUTE FUNCTION update_professional_completion_rate();

-- Function to get marketplace settings
CREATE OR REPLACE FUNCTION get_marketplace_setting(setting_name TEXT)
RETURNS TEXT AS $$
DECLARE
  setting_val TEXT;
BEGIN
  SELECT setting_value INTO setting_val
  FROM marketplace_settings
  WHERE setting_key = setting_name;
  
  RETURN setting_val;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check if marketplace is enabled
CREATE OR REPLACE FUNCTION is_marketplace_enabled()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN get_marketplace_setting('marketplace_enabled')::BOOLEAN;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

