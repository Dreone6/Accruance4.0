-- Migration: 013_driver_based_budgeting_forecasting.sql
-- Description: Add tables for driver-based budgeting and forecasting system

-- Budget templates for different business models
CREATE TABLE IF NOT EXISTS budget_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    business_type VARCHAR(100), -- 'saas', 'retail', 'manufacturing', 'services', 'general'
    template_data JSONB NOT NULL, -- Template structure and default drivers
    is_public BOOLEAN DEFAULT false,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Budget scenarios for different planning scenarios
CREATE TABLE IF NOT EXISTS budget_scenarios (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    scenario_type VARCHAR(50) DEFAULT 'budget', -- 'budget', 'forecast', 'what_if'
    base_scenario_id UUID REFERENCES budget_scenarios(id),
    template_id UUID REFERENCES budget_templates(id),
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    frequency VARCHAR(20) DEFAULT 'monthly', -- 'monthly', 'quarterly', 'annually'
    status VARCHAR(20) DEFAULT 'draft', -- 'draft', 'active', 'archived'
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Revenue and expense drivers
CREATE TABLE IF NOT EXISTS budget_drivers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scenario_id UUID NOT NULL REFERENCES budget_scenarios(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    driver_type VARCHAR(50) NOT NULL, -- 'revenue', 'expense', 'operational'
    category VARCHAR(100), -- 'customers', 'pricing', 'headcount', 'marketing', etc.
    unit_type VARCHAR(50), -- 'count', 'percentage', 'currency', 'hours', 'units'
    calculation_method VARCHAR(50) DEFAULT 'direct', -- 'direct', 'formula', 'lookup'
    formula TEXT, -- For calculated drivers
    is_active BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Driver values by period
CREATE TABLE IF NOT EXISTS budget_driver_values (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    driver_id UUID NOT NULL REFERENCES budget_drivers(id) ON DELETE CASCADE,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    value DECIMAL(15,4),
    growth_rate DECIMAL(8,4), -- Period-over-period growth rate
    confidence_level INTEGER DEFAULT 80, -- 0-100 confidence percentage
    notes TEXT,
    is_actual BOOLEAN DEFAULT false, -- true for actual values, false for planned
    source VARCHAR(50) DEFAULT 'manual', -- 'manual', 'imported', 'calculated'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(driver_id, period_start, period_end, is_actual)
);

-- Budget line items calculated from drivers
CREATE TABLE IF NOT EXISTS budget_line_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scenario_id UUID NOT NULL REFERENCES budget_scenarios(id) ON DELETE CASCADE,
    account_id UUID REFERENCES accounts(id),
    line_item_name VARCHAR(255) NOT NULL,
    line_item_type VARCHAR(50) NOT NULL, -- 'revenue', 'cogs', 'opex', 'capex'
    category VARCHAR(100),
    calculation_formula TEXT, -- Formula using driver references
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    budgeted_amount DECIMAL(15,2),
    actual_amount DECIMAL(15,2),
    variance DECIMAL(15,2),
    variance_percentage DECIMAL(8,4),
    is_calculated BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Driver relationships and dependencies
CREATE TABLE IF NOT EXISTS budget_driver_relationships (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    parent_driver_id UUID NOT NULL REFERENCES budget_drivers(id) ON DELETE CASCADE,
    child_driver_id UUID NOT NULL REFERENCES budget_drivers(id) ON DELETE CASCADE,
    relationship_type VARCHAR(50) NOT NULL, -- 'multiplier', 'percentage', 'sum', 'formula'
    coefficient DECIMAL(10,4) DEFAULT 1.0,
    formula TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(parent_driver_id, child_driver_id)
);

-- Forecasting models and algorithms
CREATE TABLE IF NOT EXISTS forecast_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    model_type VARCHAR(50) NOT NULL, -- 'linear', 'exponential', 'seasonal', 'arima', 'ml'
    target_driver_id UUID REFERENCES budget_drivers(id),
    input_drivers JSONB, -- Array of driver IDs used as inputs
    model_parameters JSONB, -- Model-specific parameters
    accuracy_metrics JSONB, -- R-squared, MAPE, etc.
    last_trained_at TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Forecast results and predictions
CREATE TABLE IF NOT EXISTS forecast_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_id UUID NOT NULL REFERENCES forecast_models(id) ON DELETE CASCADE,
    scenario_id UUID NOT NULL REFERENCES budget_scenarios(id) ON DELETE CASCADE,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    predicted_value DECIMAL(15,4),
    confidence_interval_lower DECIMAL(15,4),
    confidence_interval_upper DECIMAL(15,4),
    prediction_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    model_version INTEGER DEFAULT 1,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Budget worksheets for guided input
CREATE TABLE IF NOT EXISTS budget_worksheets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scenario_id UUID NOT NULL REFERENCES budget_scenarios(id) ON DELETE CASCADE,
    worksheet_type VARCHAR(50) NOT NULL, -- 'revenue', 'headcount', 'marketing', 'operations'
    name VARCHAR(255) NOT NULL,
    description TEXT,
    worksheet_data JSONB NOT NULL, -- Worksheet structure and data
    completion_status VARCHAR(20) DEFAULT 'not_started', -- 'not_started', 'in_progress', 'completed'
    completion_percentage INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Budget approval workflow
CREATE TABLE IF NOT EXISTS budget_approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scenario_id UUID NOT NULL REFERENCES budget_scenarios(id) ON DELETE CASCADE,
    approver_id UUID NOT NULL REFERENCES auth.users(id),
    approval_level INTEGER NOT NULL, -- 1, 2, 3 for different approval levels
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
    comments TEXT,
    approved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_budget_templates_business_type ON budget_templates(business_type);
CREATE INDEX IF NOT EXISTS idx_budget_templates_public ON budget_templates(is_public);

CREATE INDEX IF NOT EXISTS idx_budget_scenarios_user_id ON budget_scenarios(user_id);
CREATE INDEX IF NOT EXISTS idx_budget_scenarios_type ON budget_scenarios(scenario_type);
CREATE INDEX IF NOT EXISTS idx_budget_scenarios_status ON budget_scenarios(status);
CREATE INDEX IF NOT EXISTS idx_budget_scenarios_period ON budget_scenarios(period_start, period_end);

CREATE INDEX IF NOT EXISTS idx_budget_drivers_scenario_id ON budget_drivers(scenario_id);
CREATE INDEX IF NOT EXISTS idx_budget_drivers_type ON budget_drivers(driver_type);
CREATE INDEX IF NOT EXISTS idx_budget_drivers_category ON budget_drivers(category);

CREATE INDEX IF NOT EXISTS idx_budget_driver_values_driver_id ON budget_driver_values(driver_id);
CREATE INDEX IF NOT EXISTS idx_budget_driver_values_period ON budget_driver_values(period_start, period_end);
CREATE INDEX IF NOT EXISTS idx_budget_driver_values_actual ON budget_driver_values(is_actual);

CREATE INDEX IF NOT EXISTS idx_budget_line_items_scenario_id ON budget_line_items(scenario_id);
CREATE INDEX IF NOT EXISTS idx_budget_line_items_account_id ON budget_line_items(account_id);
CREATE INDEX IF NOT EXISTS idx_budget_line_items_type ON budget_line_items(line_item_type);
CREATE INDEX IF NOT EXISTS idx_budget_line_items_period ON budget_line_items(period_start, period_end);

CREATE INDEX IF NOT EXISTS idx_forecast_models_user_id ON forecast_models(user_id);
CREATE INDEX IF NOT EXISTS idx_forecast_models_type ON forecast_models(model_type);
CREATE INDEX IF NOT EXISTS idx_forecast_models_active ON forecast_models(is_active);

CREATE INDEX IF NOT EXISTS idx_forecast_results_model_id ON forecast_results(model_id);
CREATE INDEX IF NOT EXISTS idx_forecast_results_scenario_id ON forecast_results(scenario_id);
CREATE INDEX IF NOT EXISTS idx_forecast_results_period ON forecast_results(period_start, period_end);

CREATE INDEX IF NOT EXISTS idx_budget_worksheets_scenario_id ON budget_worksheets(scenario_id);
CREATE INDEX IF NOT EXISTS idx_budget_worksheets_type ON budget_worksheets(worksheet_type);

CREATE INDEX IF NOT EXISTS idx_budget_approvals_scenario_id ON budget_approvals(scenario_id);
CREATE INDEX IF NOT EXISTS idx_budget_approvals_approver_id ON budget_approvals(approver_id);
CREATE INDEX IF NOT EXISTS idx_budget_approvals_status ON budget_approvals(status);

-- Row Level Security (RLS) policies
ALTER TABLE budget_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE budget_scenarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE budget_drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE budget_driver_values ENABLE ROW LEVEL SECURITY;
ALTER TABLE budget_line_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE budget_driver_relationships ENABLE ROW LEVEL SECURITY;
ALTER TABLE forecast_models ENABLE ROW LEVEL SECURITY;
ALTER TABLE forecast_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE budget_worksheets ENABLE ROW LEVEL SECURITY;
ALTER TABLE budget_approvals ENABLE ROW LEVEL SECURITY;

-- RLS Policies for budget_templates
CREATE POLICY "Public templates are viewable by all" ON budget_templates
    FOR SELECT USING (is_public = true);

CREATE POLICY "Users can view their own templates" ON budget_templates
    FOR SELECT USING (auth.uid() = created_by);

CREATE POLICY "Users can create templates" ON budget_templates
    FOR INSERT WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update their own templates" ON budget_templates
    FOR UPDATE USING (auth.uid() = created_by);

-- RLS Policies for budget_scenarios
CREATE POLICY "Users can manage their own budget scenarios" ON budget_scenarios
    FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for budget_drivers
CREATE POLICY "Users can manage drivers for their scenarios" ON budget_drivers
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM budget_scenarios 
            WHERE budget_scenarios.id = budget_drivers.scenario_id 
            AND budget_scenarios.user_id = auth.uid()
        )
    );

-- RLS Policies for budget_driver_values
CREATE POLICY "Users can manage driver values for their scenarios" ON budget_driver_values
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM budget_drivers 
            JOIN budget_scenarios ON budget_scenarios.id = budget_drivers.scenario_id
            WHERE budget_drivers.id = budget_driver_values.driver_id 
            AND budget_scenarios.user_id = auth.uid()
        )
    );

-- RLS Policies for budget_line_items
CREATE POLICY "Users can manage line items for their scenarios" ON budget_line_items
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM budget_scenarios 
            WHERE budget_scenarios.id = budget_line_items.scenario_id 
            AND budget_scenarios.user_id = auth.uid()
        )
    );

-- RLS Policies for budget_driver_relationships
CREATE POLICY "Users can manage driver relationships for their scenarios" ON budget_driver_relationships
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM budget_drivers 
            JOIN budget_scenarios ON budget_scenarios.id = budget_drivers.scenario_id
            WHERE budget_drivers.id = budget_driver_relationships.parent_driver_id 
            AND budget_scenarios.user_id = auth.uid()
        )
    );

-- RLS Policies for forecast_models
CREATE POLICY "Users can manage their own forecast models" ON forecast_models
    FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for forecast_results
CREATE POLICY "Users can view forecast results for their models" ON forecast_results
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM forecast_models 
            WHERE forecast_models.id = forecast_results.model_id 
            AND forecast_models.user_id = auth.uid()
        )
    );

-- RLS Policies for budget_worksheets
CREATE POLICY "Users can manage worksheets for their scenarios" ON budget_worksheets
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM budget_scenarios 
            WHERE budget_scenarios.id = budget_worksheets.scenario_id 
            AND budget_scenarios.user_id = auth.uid()
        )
    );

-- RLS Policies for budget_approvals
CREATE POLICY "Users can view approvals for their scenarios" ON budget_approvals
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM budget_scenarios 
            WHERE budget_scenarios.id = budget_approvals.scenario_id 
            AND budget_scenarios.user_id = auth.uid()
        )
    );

CREATE POLICY "Approvers can manage their approvals" ON budget_approvals
    FOR ALL USING (auth.uid() = approver_id);

-- Functions for automatic timestamp updates
CREATE OR REPLACE FUNCTION update_budget_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for automatic timestamp updates
CREATE TRIGGER update_budget_templates_updated_at
    BEFORE UPDATE ON budget_templates
    FOR EACH ROW
    EXECUTE FUNCTION update_budget_updated_at();

CREATE TRIGGER update_budget_scenarios_updated_at
    BEFORE UPDATE ON budget_scenarios
    FOR EACH ROW
    EXECUTE FUNCTION update_budget_updated_at();

CREATE TRIGGER update_budget_drivers_updated_at
    BEFORE UPDATE ON budget_drivers
    FOR EACH ROW
    EXECUTE FUNCTION update_budget_updated_at();

CREATE TRIGGER update_budget_driver_values_updated_at
    BEFORE UPDATE ON budget_driver_values
    FOR EACH ROW
    EXECUTE FUNCTION update_budget_updated_at();

CREATE TRIGGER update_budget_line_items_updated_at
    BEFORE UPDATE ON budget_line_items
    FOR EACH ROW
    EXECUTE FUNCTION update_budget_updated_at();

CREATE TRIGGER update_forecast_models_updated_at
    BEFORE UPDATE ON forecast_models
    FOR EACH ROW
    EXECUTE FUNCTION update_budget_updated_at();

CREATE TRIGGER update_budget_worksheets_updated_at
    BEFORE UPDATE ON budget_worksheets
    FOR EACH ROW
    EXECUTE FUNCTION update_budget_updated_at();

-- Function to calculate budget line items from drivers
CREATE OR REPLACE FUNCTION calculate_budget_line_items(scenario_id UUID, period_start DATE, period_end DATE)
RETURNS INTEGER AS $$
DECLARE
    line_item RECORD;
    calculated_amount DECIMAL(15,2);
    updated_count INTEGER := 0;
BEGIN
    -- Loop through all line items for the scenario and period
    FOR line_item IN 
        SELECT * FROM budget_line_items 
        WHERE budget_line_items.scenario_id = calculate_budget_line_items.scenario_id
        AND budget_line_items.period_start = calculate_budget_line_items.period_start
        AND budget_line_items.period_end = calculate_budget_line_items.period_end
        AND is_calculated = true
    LOOP
        -- Calculate the amount based on the formula
        -- This is a simplified version - real implementation would parse and evaluate formulas
        calculated_amount := 0;
        
        -- Update the line item with calculated amount
        UPDATE budget_line_items 
        SET budgeted_amount = calculated_amount,
            updated_at = NOW()
        WHERE id = line_item.id;
        
        updated_count := updated_count + 1;
    END LOOP;
    
    RETURN updated_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to generate rolling forecast
CREATE OR REPLACE FUNCTION generate_rolling_forecast(
    scenario_id UUID, 
    periods_ahead INTEGER DEFAULT 12
)
RETURNS JSONB AS $$
DECLARE
    forecast_data JSONB;
    current_period DATE;
    end_period DATE;
BEGIN
    current_period := DATE_TRUNC('month', CURRENT_DATE);
    end_period := current_period + (periods_ahead || ' months')::INTERVAL;
    
    -- Generate forecast data for each period
    -- This is a simplified version - real implementation would use ML models
    SELECT jsonb_agg(
        jsonb_build_object(
            'period', period_month,
            'revenue_forecast', 100000 + (EXTRACT(MONTH FROM period_month) * 5000),
            'expense_forecast', 80000 + (EXTRACT(MONTH FROM period_month) * 3000),
            'confidence', 85
        )
    )
    INTO forecast_data
    FROM generate_series(current_period, end_period, '1 month'::INTERVAL) AS period_month;
    
    RETURN forecast_data;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Insert default budget templates
INSERT INTO budget_templates (name, description, business_type, template_data, is_public) VALUES
('SaaS Startup Template', 'Template for SaaS businesses with subscription revenue model', 'saas', 
 '{"drivers": [
    {"name": "Monthly Recurring Revenue", "type": "revenue", "unit": "currency"},
    {"name": "Customer Acquisition Cost", "type": "expense", "unit": "currency"},
    {"name": "Churn Rate", "type": "operational", "unit": "percentage"},
    {"name": "Headcount", "type": "operational", "unit": "count"}
  ], "worksheets": ["Revenue Planning", "Headcount Planning", "Marketing Budget"]}', true),

('Retail Business Template', 'Template for retail businesses with product sales', 'retail',
 '{"drivers": [
    {"name": "Units Sold", "type": "revenue", "unit": "count"},
    {"name": "Average Selling Price", "type": "revenue", "unit": "currency"},
    {"name": "Cost of Goods Sold", "type": "expense", "unit": "percentage"},
    {"name": "Store Count", "type": "operational", "unit": "count"}
  ], "worksheets": ["Sales Planning", "Inventory Planning", "Store Operations"]}', true),

('Professional Services Template', 'Template for consulting and professional services', 'services',
 '{"drivers": [
    {"name": "Billable Hours", "type": "revenue", "unit": "hours"},
    {"name": "Hourly Rate", "type": "revenue", "unit": "currency"},
    {"name": "Utilization Rate", "type": "operational", "unit": "percentage"},
    {"name": "Consultant Count", "type": "operational", "unit": "count"}
  ], "worksheets": ["Revenue Planning", "Resource Planning", "Project Budget"]}', true);

-- Add comments for documentation
COMMENT ON TABLE budget_templates IS 'Predefined budget templates for different business types';
COMMENT ON TABLE budget_scenarios IS 'Budget and forecast scenarios for planning';
COMMENT ON TABLE budget_drivers IS 'Revenue and expense drivers that drive budget calculations';
COMMENT ON TABLE budget_driver_values IS 'Values for drivers by time period';
COMMENT ON TABLE budget_line_items IS 'Budget line items calculated from drivers';
COMMENT ON TABLE budget_driver_relationships IS 'Relationships and dependencies between drivers';
COMMENT ON TABLE forecast_models IS 'Forecasting models and algorithms';
COMMENT ON TABLE forecast_results IS 'Results from forecast model predictions';
COMMENT ON TABLE budget_worksheets IS 'Guided worksheets for budget input';
COMMENT ON TABLE budget_approvals IS 'Budget approval workflow tracking';

