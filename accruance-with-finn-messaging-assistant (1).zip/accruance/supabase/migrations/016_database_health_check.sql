-- Migration: 016_database_health_check
-- Description: Database health check functions and comprehensive validation

-- Function to check database health
CREATE OR REPLACE FUNCTION check_database_health()
RETURNS TABLE (
  check_name TEXT,
  status TEXT,
  details TEXT
) AS $$
BEGIN
  -- Check if all required tables exist
  RETURN QUERY
  SELECT 
    'table_existence'::TEXT,
    CASE WHEN COUNT(*) = 35 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    'Expected 35 tables, found ' || COUNT(*)::TEXT
  FROM information_schema.tables 
  WHERE table_schema = 'public' 
    AND table_type = 'BASE TABLE';

  -- Check if RLS is enabled on critical tables
  RETURN QUERY
  SELECT 
    'rls_enabled'::TEXT,
    CASE WHEN COUNT(*) >= 10 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    'RLS enabled on ' || COUNT(*)::TEXT || ' critical tables'
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname = 'public' 
    AND c.relkind = 'r'
    AND c.relrowsecurity = true
    AND c.relname IN ('users', 'organizations', 'accounts', 'transactions', 'invoices');

  -- Check if authentication functions exist
  RETURN QUERY
  SELECT 
    'auth_functions'::TEXT,
    CASE WHEN COUNT(*) >= 2 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    'Found ' || COUNT(*)::TEXT || ' auth functions'
  FROM information_schema.routines 
  WHERE routine_schema = 'auth' 
    AND routine_name IN ('uid', 'jwt');

  -- Check if critical indexes exist
  RETURN QUERY
  SELECT 
    'critical_indexes'::TEXT,
    CASE WHEN COUNT(*) >= 20 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    'Found ' || COUNT(*)::TEXT || ' indexes'
  FROM pg_indexes 
  WHERE schemaname = 'public';

  -- Check if foreign key constraints exist
  RETURN QUERY
  SELECT 
    'foreign_keys'::TEXT,
    CASE WHEN COUNT(*) >= 15 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    'Found ' || COUNT(*)::TEXT || ' foreign key constraints'
  FROM information_schema.table_constraints 
  WHERE constraint_schema = 'public' 
    AND constraint_type = 'FOREIGN KEY';

  -- Check if triggers exist for updated_at
  RETURN QUERY
  SELECT 
    'updated_at_triggers'::TEXT,
    CASE WHEN COUNT(*) >= 10 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    'Found ' || COUNT(*)::TEXT || ' updated_at triggers'
  FROM information_schema.triggers 
  WHERE trigger_schema = 'public' 
    AND trigger_name LIKE '%updated_at%';

END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to validate user permissions
CREATE OR REPLACE FUNCTION validate_user_permissions(user_id UUID)
RETURNS TABLE (
  permission_check TEXT,
  has_access BOOLEAN,
  details TEXT
) AS $$
BEGIN
  -- Check if user exists
  RETURN QUERY
  SELECT 
    'user_exists'::TEXT,
    EXISTS(SELECT 1 FROM auth.users WHERE id = user_id),
    'User ' || user_id::TEXT || ' existence check'::TEXT;

  -- Check if user has profile
  RETURN QUERY
  SELECT 
    'user_profile'::TEXT,
    EXISTS(SELECT 1 FROM user_profiles WHERE user_id = validate_user_permissions.user_id),
    'User profile existence check'::TEXT;

  -- Check organization access
  RETURN QUERY
  SELECT 
    'organization_access'::TEXT,
    EXISTS(
      SELECT 1 FROM user_profiles up 
      JOIN organizations o ON o.id = up.company_id 
      WHERE up.user_id = validate_user_permissions.user_id
    ),
    'Organization access check'::TEXT;

END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check data integrity
CREATE OR REPLACE FUNCTION check_data_integrity()
RETURNS TABLE (
  integrity_check TEXT,
  status TEXT,
  count_found INTEGER,
  details TEXT
) AS $$
BEGIN
  -- Check for orphaned transactions
  RETURN QUERY
  SELECT 
    'orphaned_transactions'::TEXT,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    COUNT(*)::INTEGER,
    'Transactions without valid accounts'::TEXT
  FROM transactions t
  LEFT JOIN accounts a ON a.id = t.account_id
  WHERE a.id IS NULL;

  -- Check for invalid journal entries (debits != credits)
  RETURN QUERY
  SELECT 
    'unbalanced_journal_entries'::TEXT,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    COUNT(*)::INTEGER,
    'Journal entries where debits != credits'::TEXT
  FROM (
    SELECT 
      je.id,
      SUM(jel.debit_amount) as total_debits,
      SUM(jel.credit_amount) as total_credits
    FROM journal_entries je
    JOIN journal_entry_lines jel ON jel.journal_entry_id = je.id
    GROUP BY je.id
    HAVING ABS(SUM(jel.debit_amount) - SUM(jel.credit_amount)) > 0.01
  ) unbalanced;

  -- Check for invoices without line items
  RETURN QUERY
  SELECT 
    'invoices_without_items'::TEXT,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    COUNT(*)::INTEGER,
    'Invoices without line items'::TEXT
  FROM invoices i
  LEFT JOIN invoice_line_items ili ON ili.invoice_id = i.id
  WHERE ili.id IS NULL AND i.status != 'draft';

  -- Check for duplicate account numbers within organizations
  RETURN QUERY
  SELECT 
    'duplicate_account_numbers'::TEXT,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END::TEXT,
    COUNT(*)::INTEGER,
    'Duplicate account numbers within organizations'::TEXT
  FROM (
    SELECT organization_id, account_number, COUNT(*)
    FROM accounts
    GROUP BY organization_id, account_number
    HAVING COUNT(*) > 1
  ) duplicates;

END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check performance metrics
CREATE OR REPLACE FUNCTION check_performance_metrics()
RETURNS TABLE (
  metric_name TEXT,
  metric_value NUMERIC,
  status TEXT,
  recommendation TEXT
) AS $$
BEGIN
  -- Check table sizes
  RETURN QUERY
  SELECT 
    'largest_table_mb'::TEXT,
    ROUND((pg_total_relation_size(schemaname||'.'||tablename))::NUMERIC / 1024 / 1024, 2),
    CASE WHEN pg_total_relation_size(schemaname||'.'||tablename) > 100 * 1024 * 1024 
         THEN 'WARNING' ELSE 'OK' END::TEXT,
    'Consider partitioning if > 100MB'::TEXT
  FROM pg_tables 
  WHERE schemaname = 'public'
  ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC
  LIMIT 1;

  -- Check index usage
  RETURN QUERY
  SELECT 
    'unused_indexes'::TEXT,
    COUNT(*)::NUMERIC,
    CASE WHEN COUNT(*) > 5 THEN 'WARNING' ELSE 'OK' END::TEXT,
    'Consider dropping unused indexes'::TEXT
  FROM pg_stat_user_indexes 
  WHERE idx_scan = 0 AND schemaname = 'public';

  -- Check connection count
  RETURN QUERY
  SELECT 
    'active_connections'::TEXT,
    COUNT(*)::NUMERIC,
    CASE WHEN COUNT(*) > 80 THEN 'WARNING' ELSE 'OK' END::TEXT,
    'Monitor connection pooling'::TEXT
  FROM pg_stat_activity 
  WHERE state = 'active';

END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a comprehensive health check view
CREATE OR REPLACE VIEW database_health_summary AS
SELECT 
  'Database Health Check' as report_type,
  NOW() as check_time,
  (SELECT COUNT(*) FROM check_database_health() WHERE status = 'PASS') as passed_checks,
  (SELECT COUNT(*) FROM check_database_health() WHERE status = 'FAIL') as failed_checks,
  (SELECT COUNT(*) FROM check_data_integrity() WHERE status = 'PASS') as integrity_passed,
  (SELECT COUNT(*) FROM check_data_integrity() WHERE status = 'FAIL') as integrity_failed;

-- Grant permissions for health check functions
GRANT EXECUTE ON FUNCTION check_database_health() TO authenticated;
GRANT EXECUTE ON FUNCTION validate_user_permissions(UUID) TO authenticated;
GRANT EXECUTE ON FUNCTION check_data_integrity() TO authenticated;
GRANT EXECUTE ON FUNCTION check_performance_metrics() TO authenticated;
GRANT SELECT ON database_health_summary TO authenticated;

-- Create indexes for performance if they don't exist
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_transactions_user_id_date ON transactions(user_id, date);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_invoices_organization_status ON invoices(organization_id, status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_accounts_organization_type ON accounts(organization_id, type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_audit_logs_user_action ON audit_logs(user_id, action);

-- Create function to automatically update updated_at columns
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Ensure updated_at triggers exist on all tables that need them
DO $$
DECLARE
    table_name TEXT;
    tables_with_updated_at TEXT[] := ARRAY[
        'organizations', 'user_profiles', 'accounts', 'transactions', 
        'invoices', 'receipts', 'journal_entries', 'budget_scenarios',
        'variance_analysis_periods', 'custom_reports', 'integration_connections'
    ];
BEGIN
    FOREACH table_name IN ARRAY tables_with_updated_at
    LOOP
        -- Check if trigger exists, if not create it
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.triggers 
            WHERE trigger_name = 'update_' || table_name || '_updated_at'
        ) THEN
            EXECUTE format('
                CREATE TRIGGER update_%I_updated_at
                    BEFORE UPDATE ON %I
                    FOR EACH ROW
                    EXECUTE FUNCTION update_updated_at_column()
            ', table_name, table_name);
        END IF;
    END LOOP;
END $$;

-- Add comments for documentation
COMMENT ON FUNCTION check_database_health() IS 'Comprehensive database health check including tables, RLS, indexes, and constraints';
COMMENT ON FUNCTION validate_user_permissions(UUID) IS 'Validates user permissions and access rights';
COMMENT ON FUNCTION check_data_integrity() IS 'Checks for data integrity issues like orphaned records and unbalanced entries';
COMMENT ON FUNCTION check_performance_metrics() IS 'Monitors database performance metrics and provides recommendations';
COMMENT ON VIEW database_health_summary IS 'Summary view of overall database health status';

