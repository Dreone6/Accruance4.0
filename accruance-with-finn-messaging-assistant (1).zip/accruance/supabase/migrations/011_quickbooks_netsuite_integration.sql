-- Migration: 011_quickbooks_netsuite_integration.sql
-- Description: Add tables for QuickBooks and NetSuite integration

-- Integration connections table
CREATE TABLE IF NOT EXISTS integrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    provider VARCHAR(50) NOT NULL, -- 'quickbooks', 'netsuite'
    company_id VARCHAR(255), -- QB company ID or NetSuite account ID
    access_token TEXT,
    refresh_token TEXT,
    token_expires_at TIMESTAMP WITH TIME ZONE,
    scope TEXT,
    realm_id VARCHAR(255), -- QuickBooks realm ID
    base_url TEXT, -- NetSuite base URL
    is_active BOOLEAN DEFAULT true,
    last_sync_at TIMESTAMP WITH TIME ZONE,
    sync_frequency VARCHAR(20) DEFAULT 'daily', -- 'hourly', 'daily', 'weekly'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, provider, company_id)
);

-- Field mappings for data sync
CREATE TABLE IF NOT EXISTS integration_field_mappings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
    entity_type VARCHAR(50) NOT NULL, -- 'account', 'transaction', 'customer', 'vendor'
    source_field VARCHAR(255) NOT NULL, -- QB/NetSuite field name
    target_field VARCHAR(255) NOT NULL, -- Accruance field name
    transformation_rule JSONB, -- Optional transformation logic
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Sync logs for tracking and debugging
CREATE TABLE IF NOT EXISTS integration_sync_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
    sync_type VARCHAR(50) NOT NULL, -- 'full', 'incremental', 'manual'
    entity_type VARCHAR(50), -- 'accounts', 'transactions', 'customers'
    status VARCHAR(20) NOT NULL, -- 'pending', 'running', 'completed', 'failed'
    records_processed INTEGER DEFAULT 0,
    records_created INTEGER DEFAULT 0,
    records_updated INTEGER DEFAULT 0,
    records_failed INTEGER DEFAULT 0,
    error_message TEXT,
    error_details JSONB,
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Sync queue for managing sync operations
CREATE TABLE IF NOT EXISTS integration_sync_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
    entity_type VARCHAR(50) NOT NULL,
    sync_type VARCHAR(50) NOT NULL,
    priority INTEGER DEFAULT 5, -- 1 (highest) to 10 (lowest)
    scheduled_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    attempts INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 3,
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed'
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- External entity mappings (QB/NetSuite ID to Accruance ID)
CREATE TABLE IF NOT EXISTS integration_entity_mappings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
    entity_type VARCHAR(50) NOT NULL, -- 'account', 'transaction', 'customer'
    external_id VARCHAR(255) NOT NULL, -- QB/NetSuite entity ID
    internal_id UUID NOT NULL, -- Accruance entity ID
    external_data JSONB, -- Store original external entity data
    last_synced_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(integration_id, entity_type, external_id)
);

-- Integration settings and configuration
CREATE TABLE IF NOT EXISTS integration_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
    setting_key VARCHAR(100) NOT NULL,
    setting_value TEXT,
    setting_type VARCHAR(20) DEFAULT 'string', -- 'string', 'number', 'boolean', 'json'
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(integration_id, setting_key)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_integrations_user_provider ON integrations(user_id, provider);
CREATE INDEX IF NOT EXISTS idx_integrations_active ON integrations(is_active);
CREATE INDEX IF NOT EXISTS idx_integration_sync_logs_integration_id ON integration_sync_logs(integration_id);
CREATE INDEX IF NOT EXISTS idx_integration_sync_logs_status ON integration_sync_logs(status);
CREATE INDEX IF NOT EXISTS idx_integration_sync_queue_status ON integration_sync_queue(status);
CREATE INDEX IF NOT EXISTS idx_integration_sync_queue_scheduled ON integration_sync_queue(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_integration_entity_mappings_external ON integration_entity_mappings(integration_id, entity_type, external_id);

-- Row Level Security (RLS) policies
ALTER TABLE integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE integration_field_mappings ENABLE ROW LEVEL SECURITY;
ALTER TABLE integration_sync_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE integration_sync_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE integration_entity_mappings ENABLE ROW LEVEL SECURITY;
ALTER TABLE integration_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for integrations
CREATE POLICY "Users can view their own integrations" ON integrations
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own integrations" ON integrations
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own integrations" ON integrations
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own integrations" ON integrations
    FOR DELETE USING (auth.uid() = user_id);

-- RLS Policies for field mappings
CREATE POLICY "Users can manage their integration field mappings" ON integration_field_mappings
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM integrations 
            WHERE integrations.id = integration_field_mappings.integration_id 
            AND integrations.user_id = auth.uid()
        )
    );

-- RLS Policies for sync logs
CREATE POLICY "Users can view their integration sync logs" ON integration_sync_logs
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM integrations 
            WHERE integrations.id = integration_sync_logs.integration_id 
            AND integrations.user_id = auth.uid()
        )
    );

-- RLS Policies for sync queue
CREATE POLICY "Users can manage their integration sync queue" ON integration_sync_queue
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM integrations 
            WHERE integrations.id = integration_sync_queue.integration_id 
            AND integrations.user_id = auth.uid()
        )
    );

-- RLS Policies for entity mappings
CREATE POLICY "Users can manage their integration entity mappings" ON integration_entity_mappings
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM integrations 
            WHERE integrations.id = integration_entity_mappings.integration_id 
            AND integrations.user_id = auth.uid()
        )
    );

-- RLS Policies for settings
CREATE POLICY "Users can manage their integration settings" ON integration_settings
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM integrations 
            WHERE integrations.id = integration_settings.integration_id 
            AND integrations.user_id = auth.uid()
        )
    );

-- Functions for automatic timestamp updates
CREATE OR REPLACE FUNCTION update_integration_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for automatic timestamp updates
CREATE TRIGGER update_integrations_updated_at
    BEFORE UPDATE ON integrations
    FOR EACH ROW
    EXECUTE FUNCTION update_integration_updated_at();

CREATE TRIGGER update_integration_field_mappings_updated_at
    BEFORE UPDATE ON integration_field_mappings
    FOR EACH ROW
    EXECUTE FUNCTION update_integration_updated_at();

CREATE TRIGGER update_integration_sync_queue_updated_at
    BEFORE UPDATE ON integration_sync_queue
    FOR EACH ROW
    EXECUTE FUNCTION update_integration_updated_at();

CREATE TRIGGER update_integration_entity_mappings_updated_at
    BEFORE UPDATE ON integration_entity_mappings
    FOR EACH ROW
    EXECUTE FUNCTION update_integration_updated_at();

CREATE TRIGGER update_integration_settings_updated_at
    BEFORE UPDATE ON integration_settings
    FOR EACH ROW
    EXECUTE FUNCTION update_integration_updated_at();

-- Insert default field mappings for QuickBooks
INSERT INTO integration_field_mappings (integration_id, entity_type, source_field, target_field, transformation_rule, is_active)
SELECT 
    '00000000-0000-0000-0000-000000000000'::uuid, -- Placeholder, will be updated per integration
    'account',
    'Name',
    'name',
    '{"type": "direct"}'::jsonb,
    true
WHERE NOT EXISTS (
    SELECT 1 FROM integration_field_mappings 
    WHERE entity_type = 'account' AND source_field = 'Name'
);

-- Add comment for migration tracking
COMMENT ON TABLE integrations IS 'Stores OAuth connections to external accounting systems like QuickBooks and NetSuite';
COMMENT ON TABLE integration_field_mappings IS 'Maps fields between external systems and Accruance';
COMMENT ON TABLE integration_sync_logs IS 'Tracks sync operations for debugging and monitoring';
COMMENT ON TABLE integration_sync_queue IS 'Manages queued sync operations';
COMMENT ON TABLE integration_entity_mappings IS 'Maps external entity IDs to internal Accruance IDs';
COMMENT ON TABLE integration_settings IS 'Stores configuration settings for each integration';

