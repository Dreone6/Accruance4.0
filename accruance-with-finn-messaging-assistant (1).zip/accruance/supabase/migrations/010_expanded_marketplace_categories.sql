-- Expanded Marketplace Categories and Executive Services
-- Adds comprehensive business marketplace categories and C-suite professional services

-- Update equipment categories with expanded options
UPDATE marketplace_settings 
SET setting_value = '[
  "computer_hardware",
  "software_licenses", 
  "office_furniture",
  "financial_tools",
  "business_assets",
  "technology_equipment",
  "vehicles_fleet",
  "machinery_equipment",
  "real_estate_offices",
  "networking_equipment",
  "security_systems",
  "communication_tools",
  "manufacturing_equipment",
  "retail_equipment",
  "medical_equipment",
  "construction_equipment"
]'
WHERE setting_key = 'equipment_categories';

-- Add real estate specific table for office spaces
CREATE TABLE IF NOT EXISTS real_estate_offices (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  listing_id UUID REFERENCES equipment_listings(id) ON DELETE CASCADE,
  
  -- Property details
  property_type VARCHAR(50) CHECK (property_type IN ('office_space', 'coworking', 'executive_suite', 'warehouse', 'retail_space', 'mixed_use')) NOT NULL,
  square_footage INTEGER,
  number_of_rooms INTEGER,
  number_of_bathrooms INTEGER,
  parking_spaces INTEGER,
  floor_number INTEGER,
  total_floors INTEGER,
  
  -- Building amenities
  amenities TEXT[], -- ['elevator', 'parking', 'security', 'conference_rooms', 'kitchen', 'reception']
  utilities_included TEXT[], -- ['electricity', 'water', 'internet', 'hvac', 'cleaning']
  
  -- Lease terms
  lease_type VARCHAR(20) CHECK (lease_type IN ('full_service', 'triple_net', 'modified_gross', 'percentage')) DEFAULT 'full_service',
  min_lease_term INTEGER, -- months
  max_lease_term INTEGER, -- months
  security_deposit_months DECIMAL(3,1),
  
  -- Availability
  available_date DATE,
  move_in_ready BOOLEAN DEFAULT true,
  furnished BOOLEAN DEFAULT false,
  
  -- Building information
  building_name VARCHAR(200),
  building_year_built INTEGER,
  building_class VARCHAR(10), -- 'A', 'B', 'C'
  zoning VARCHAR(100),
  
  -- Financial details
  monthly_rent DECIMAL(10,2),
  price_per_sqft DECIMAL(8,2),
  operating_expenses DECIMAL(10,2),
  property_taxes DECIMAL(10,2),
  insurance_cost DECIMAL(10,2),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add software licenses table
CREATE TABLE IF NOT EXISTS software_licenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  listing_id UUID REFERENCES equipment_listings(id) ON DELETE CASCADE,
  
  -- Software details
  software_name VARCHAR(200) NOT NULL,
  software_category VARCHAR(100), -- 'accounting', 'crm', 'project_management', 'design', 'development'
  version VARCHAR(50),
  license_type VARCHAR(50) CHECK (license_type IN ('perpetual', 'subscription', 'volume', 'educational', 'trial')) NOT NULL,
  
  -- License terms
  number_of_licenses INTEGER DEFAULT 1,
  concurrent_users INTEGER,
  license_duration_months INTEGER, -- for subscription licenses
  renewal_date DATE,
  
  -- Compatibility
  operating_systems TEXT[], -- ['windows', 'mac', 'linux', 'web_based']
  system_requirements JSONB DEFAULT '{}',
  
  -- Support and maintenance
  support_included BOOLEAN DEFAULT false,
  support_level VARCHAR(50), -- 'basic', 'standard', 'premium', 'enterprise'
  updates_included BOOLEAN DEFAULT false,
  
  -- Transfer details
  transferable BOOLEAN DEFAULT true,
  transfer_fee DECIMAL(8,2),
  original_purchase_date DATE,
  original_purchase_price DECIMAL(10,2),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Expand service categories to include executive and professional services
INSERT INTO service_categories (id, name, description, icon, parent_category_id, is_active) VALUES
-- Executive Services
('fractional-ceo', 'Fractional CEO', 'Part-time chief executive officer services', 'user-tie', NULL, true),
('fractional-cfo', 'Fractional CFO', 'Part-time chief financial officer services', 'calculator', NULL, true),
('fractional-cto', 'Fractional CTO', 'Part-time chief technology officer services', 'cpu', NULL, true),
('fractional-coo', 'Fractional COO', 'Part-time chief operating officer services', 'settings', NULL, true),
('fractional-cmo', 'Fractional CMO', 'Part-time chief marketing officer services', 'megaphone', NULL, true),
('fractional-chro', 'Fractional CHRO', 'Part-time chief human resources officer services', 'users', NULL, true),

-- Management Services
('project-management', 'Project Management', 'Professional project management services', 'clipboard-list', NULL, true),
('program-management', 'Program Management', 'Large-scale program management services', 'layers', NULL, true),
('change-management', 'Change Management', 'Organizational change management consulting', 'refresh-cw', NULL, true),
('interim-management', 'Interim Management', 'Temporary executive management services', 'clock', NULL, true),

-- Specialized Professional Services
('business-strategy', 'Business Strategy', 'Strategic planning and business development', 'target', NULL, true),
('operations-consulting', 'Operations Consulting', 'Operational efficiency and process improvement', 'trending-up', NULL, true),
('digital-transformation', 'Digital Transformation', 'Technology and digital strategy consulting', 'smartphone', NULL, true),
('mergers-acquisitions', 'M&A Advisory', 'Mergers and acquisitions advisory services', 'git-merge', NULL, true),
('fundraising-advisory', 'Fundraising Advisory', 'Capital raising and investor relations', 'dollar-sign', NULL, true),
('board-advisory', 'Board Advisory', 'Board of directors and governance advisory', 'shield', NULL, true),

-- Technical Services
('software-development', 'Software Development', 'Custom software and application development', 'code', NULL, true),
('data-analytics', 'Data Analytics', 'Business intelligence and data analysis services', 'bar-chart', NULL, true),
('cybersecurity', 'Cybersecurity', 'Information security and risk management', 'lock', NULL, true),
('cloud-consulting', 'Cloud Consulting', 'Cloud migration and infrastructure consulting', 'cloud', NULL, true),

-- Marketing & Sales Services
('marketing-strategy', 'Marketing Strategy', 'Marketing planning and strategy development', 'bullhorn', NULL, true),
('sales-consulting', 'Sales Consulting', 'Sales process optimization and training', 'trending-up', NULL, true),
('brand-consulting', 'Brand Consulting', 'Brand strategy and identity development', 'award', NULL, true),
('digital-marketing', 'Digital Marketing', 'Online marketing and social media services', 'monitor', NULL, true),

-- Legal & Compliance Services
('corporate-law', 'Corporate Law', 'Business legal services and corporate law', 'scale', NULL, true),
('compliance-consulting', 'Compliance Consulting', 'Regulatory compliance and risk management', 'check-circle', NULL, true),
('intellectual-property', 'Intellectual Property', 'Patent, trademark, and IP services', 'lightbulb', NULL, true),
('contract-management', 'Contract Management', 'Contract review and negotiation services', 'file-text', NULL, true),

-- HR & Organizational Services
('hr-consulting', 'HR Consulting', 'Human resources strategy and operations', 'users', NULL, true),
('talent-acquisition', 'Talent Acquisition', 'Executive search and recruitment services', 'search', NULL, true),
('organizational-development', 'Organizational Development', 'Team building and organizational design', 'users', NULL, true),
('compensation-consulting', 'Compensation Consulting', 'Salary benchmarking and compensation design', 'dollar-sign', NULL, true)

ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  icon = EXCLUDED.icon,
  is_active = EXCLUDED.is_active;

-- Add executive service specializations
CREATE TABLE IF NOT EXISTS executive_service_profiles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  professional_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  
  -- Executive role details
  executive_role VARCHAR(50) CHECK (executive_role IN ('ceo', 'cfo', 'cto', 'coo', 'cmo', 'chro', 'general_manager', 'project_manager')) NOT NULL,
  seniority_level VARCHAR(20) CHECK (seniority_level IN ('senior', 'executive', 'c_suite', 'board_level')) DEFAULT 'senior',
  
  -- Experience and expertise
  years_experience INTEGER NOT NULL,
  industries TEXT[], -- ['technology', 'healthcare', 'finance', 'manufacturing', 'retail']
  company_sizes TEXT[], -- ['startup', 'small_business', 'mid_market', 'enterprise', 'fortune_500']
  functional_expertise TEXT[], -- ['strategy', 'operations', 'finance', 'marketing', 'technology']
  
  -- Engagement preferences
  engagement_types TEXT[], -- ['fractional', 'interim', 'project_based', 'advisory', 'board_member']
  min_engagement_duration INTEGER, -- months
  max_engagement_duration INTEGER, -- months
  availability_hours_per_week INTEGER,
  
  -- Geographic preferences
  travel_willingness VARCHAR(20) CHECK (travel_willingness IN ('none', 'local', 'regional', 'national', 'international')) DEFAULT 'regional',
  remote_work_preference VARCHAR(20) CHECK (remote_work_preference IN ('remote_only', 'hybrid', 'on_site', 'flexible')) DEFAULT 'flexible',
  
  -- Compensation
  hourly_rate DECIMAL(8,2),
  daily_rate DECIMAL(10,2),
  monthly_retainer DECIMAL(10,2),
  equity_consideration BOOLEAN DEFAULT false,
  
  -- Credentials and achievements
  education_background TEXT,
  certifications TEXT[],
  notable_achievements TEXT[],
  previous_companies TEXT[],
  
  -- Portfolio and case studies
  case_studies JSONB DEFAULT '[]',
  portfolio_url VARCHAR(500),
  linkedin_url VARCHAR(500),
  
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(professional_id, executive_role)
);

-- Add computer hardware specifications table
CREATE TABLE IF NOT EXISTS computer_hardware_specs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  listing_id UUID REFERENCES equipment_listings(id) ON DELETE CASCADE,
  
  -- Hardware type
  hardware_type VARCHAR(50) CHECK (hardware_type IN ('desktop', 'laptop', 'server', 'workstation', 'tablet', 'monitor', 'printer', 'networking', 'storage', 'components')) NOT NULL,
  
  -- Computer specifications
  processor VARCHAR(200),
  ram_gb INTEGER,
  storage_type VARCHAR(20), -- 'hdd', 'ssd', 'hybrid'
  storage_capacity_gb INTEGER,
  graphics_card VARCHAR(200),
  operating_system VARCHAR(100),
  
  -- Monitor specifications
  screen_size_inches DECIMAL(4,1),
  resolution VARCHAR(20), -- '1920x1080', '2560x1440', '3840x2160'
  panel_type VARCHAR(20), -- 'ips', 'tn', 'va', 'oled'
  refresh_rate_hz INTEGER,
  
  -- Networking specifications
  network_type VARCHAR(50), -- 'router', 'switch', 'access_point', 'firewall'
  port_count INTEGER,
  max_speed_mbps INTEGER,
  wireless_standards TEXT[], -- ['wifi6', 'wifi5', 'bluetooth5']
  
  -- General specifications
  power_consumption_watts INTEGER,
  dimensions_inches VARCHAR(50), -- 'L x W x H'
  weight_pounds DECIMAL(5,2),
  
  -- Performance benchmarks
  benchmark_scores JSONB DEFAULT '{}',
  performance_rating INTEGER CHECK (performance_rating >= 1 AND performance_rating <= 10),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add furniture specifications table
CREATE TABLE IF NOT EXISTS furniture_specs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  listing_id UUID REFERENCES equipment_listings(id) ON DELETE CASCADE,
  
  -- Furniture details
  furniture_type VARCHAR(50) CHECK (furniture_type IN ('desk', 'chair', 'table', 'cabinet', 'bookshelf', 'sofa', 'reception_desk', 'conference_table', 'storage', 'lighting')) NOT NULL,
  furniture_style VARCHAR(50), -- 'modern', 'traditional', 'industrial', 'minimalist', 'executive'
  
  -- Physical specifications
  dimensions_inches VARCHAR(50), -- 'L x W x H'
  weight_pounds DECIMAL(6,2),
  material VARCHAR(100), -- 'wood', 'metal', 'plastic', 'fabric', 'leather', 'glass'
  color VARCHAR(50),
  
  -- Condition and features
  assembly_required BOOLEAN DEFAULT false,
  adjustable BOOLEAN DEFAULT false,
  ergonomic BOOLEAN DEFAULT false,
  
  -- Office furniture specific
  seating_capacity INTEGER, -- for conference tables, sofas
  storage_capacity VARCHAR(100), -- for cabinets, desks with drawers
  
  -- Set information
  is_part_of_set BOOLEAN DEFAULT false,
  set_name VARCHAR(200),
  pieces_in_set INTEGER,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Update marketplace settings with expanded categories
INSERT INTO marketplace_settings (setting_key, setting_value, data_type, description, is_public) VALUES
('computer_hardware_types', '["desktop", "laptop", "server", "workstation", "tablet", "monitor", "printer", "networking", "storage", "components"]', 'json', 'Computer hardware categories', true),
('software_categories', '["accounting", "crm", "project_management", "design", "development", "productivity", "security", "analytics", "communication", "industry_specific"]', 'json', 'Software license categories', true),
('furniture_types', '["desk", "chair", "table", "cabinet", "bookshelf", "sofa", "reception_desk", "conference_table", "storage", "lighting"]', 'json', 'Office furniture categories', true),
('real_estate_property_types', '["office_space", "coworking", "executive_suite", "warehouse", "retail_space", "mixed_use"]', 'json', 'Real estate property types', true),
('executive_roles', '["ceo", "cfo", "cto", "coo", "cmo", "chro", "general_manager", "project_manager"]', 'json', 'Available executive roles', true),
('engagement_types', '["fractional", "interim", "project_based", "advisory", "board_member"]', 'json', 'Executive engagement types', true),
('industries', '["technology", "healthcare", "finance", "manufacturing", "retail", "real_estate", "education", "non_profit", "government", "consulting"]', 'json', 'Industry categories', true),
('company_sizes', '["startup", "small_business", "mid_market", "enterprise", "fortune_500"]', 'json', 'Company size categories', true)
ON CONFLICT (setting_key) DO UPDATE SET
  setting_value = EXCLUDED.setting_value,
  description = EXCLUDED.description;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_real_estate_offices_property_type ON real_estate_offices(property_type);
CREATE INDEX IF NOT EXISTS idx_real_estate_offices_square_footage ON real_estate_offices(square_footage);
CREATE INDEX IF NOT EXISTS idx_real_estate_offices_monthly_rent ON real_estate_offices(monthly_rent);
CREATE INDEX IF NOT EXISTS idx_real_estate_offices_available_date ON real_estate_offices(available_date);

CREATE INDEX IF NOT EXISTS idx_software_licenses_software_category ON software_licenses(software_category);
CREATE INDEX IF NOT EXISTS idx_software_licenses_license_type ON software_licenses(license_type);
CREATE INDEX IF NOT EXISTS idx_software_licenses_number_of_licenses ON software_licenses(number_of_licenses);

CREATE INDEX IF NOT EXISTS idx_executive_service_profiles_executive_role ON executive_service_profiles(executive_role);
CREATE INDEX IF NOT EXISTS idx_executive_service_profiles_seniority_level ON executive_service_profiles(seniority_level);
CREATE INDEX IF NOT EXISTS idx_executive_service_profiles_years_experience ON executive_service_profiles(years_experience);
CREATE INDEX IF NOT EXISTS idx_executive_service_profiles_hourly_rate ON executive_service_profiles(hourly_rate);

CREATE INDEX IF NOT EXISTS idx_computer_hardware_specs_hardware_type ON computer_hardware_specs(hardware_type);
CREATE INDEX IF NOT EXISTS idx_computer_hardware_specs_ram_gb ON computer_hardware_specs(ram_gb);
CREATE INDEX IF NOT EXISTS idx_computer_hardware_specs_storage_capacity_gb ON computer_hardware_specs(storage_capacity_gb);

CREATE INDEX IF NOT EXISTS idx_furniture_specs_furniture_type ON furniture_specs(furniture_type);
CREATE INDEX IF NOT EXISTS idx_furniture_specs_furniture_style ON furniture_specs(furniture_style);

-- Enable RLS on new tables
ALTER TABLE real_estate_offices ENABLE ROW LEVEL SECURITY;
ALTER TABLE software_licenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE executive_service_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE computer_hardware_specs ENABLE ROW LEVEL SECURITY;
ALTER TABLE furniture_specs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for new tables
CREATE POLICY "Anyone can view real estate office details" ON real_estate_offices
  FOR SELECT USING (true);

CREATE POLICY "Anyone can view software license details" ON software_licenses
  FOR SELECT USING (true);

CREATE POLICY "Anyone can view executive service profiles" ON executive_service_profiles
  FOR SELECT USING (is_active = true);

CREATE POLICY "Professionals can manage their executive profiles" ON executive_service_profiles
  FOR ALL USING (auth.uid() = professional_id);

CREATE POLICY "Anyone can view computer hardware specs" ON computer_hardware_specs
  FOR SELECT USING (true);

CREATE POLICY "Anyone can view furniture specs" ON furniture_specs
  FOR SELECT USING (true);

-- Function to search executive services with filters
CREATE OR REPLACE FUNCTION search_executive_services(
  search_lat DECIMAL DEFAULT NULL,
  search_lon DECIMAL DEFAULT NULL,
  radius_miles INTEGER DEFAULT 50,
  executive_role_filter VARCHAR DEFAULT NULL,
  seniority_filter VARCHAR DEFAULT NULL,
  min_experience INTEGER DEFAULT NULL,
  max_hourly_rate DECIMAL DEFAULT NULL,
  industry_filter VARCHAR DEFAULT NULL,
  company_size_filter VARCHAR DEFAULT NULL,
  engagement_type_filter VARCHAR DEFAULT NULL,
  remote_preference VARCHAR DEFAULT NULL,
  sort_by VARCHAR DEFAULT 'relevance',
  limit_count INTEGER DEFAULT 20,
  offset_count INTEGER DEFAULT 0
) RETURNS TABLE (
  professional_id UUID,
  full_name VARCHAR,
  executive_role VARCHAR,
  years_experience INTEGER,
  hourly_rate DECIMAL,
  industries TEXT[],
  engagement_types TEXT[],
  remote_work_preference VARCHAR,
  average_rating DECIMAL,
  distance_miles DECIMAL,
  city VARCHAR,
  state_province VARCHAR
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    esp.professional_id,
    up.full_name,
    esp.executive_role,
    esp.years_experience,
    esp.hourly_rate,
    esp.industries,
    esp.engagement_types,
    esp.remote_work_preference,
    pmp.average_rating,
    CASE 
      WHEN search_lat IS NOT NULL AND search_lon IS NOT NULL AND up.latitude IS NOT NULL AND up.longitude IS NOT NULL
      THEN calculate_distance(search_lat, search_lon, up.latitude, up.longitude)
      ELSE NULL
    END as distance,
    up.city,
    up.state_province
  FROM executive_service_profiles esp
  JOIN user_profiles up ON esp.professional_id = up.id
  LEFT JOIN professional_marketplace_profiles pmp ON esp.professional_id = pmp.professional_id
  WHERE esp.is_active = true
    AND (executive_role_filter IS NULL OR esp.executive_role = executive_role_filter)
    AND (seniority_filter IS NULL OR esp.seniority_level = seniority_filter)
    AND (min_experience IS NULL OR esp.years_experience >= min_experience)
    AND (max_hourly_rate IS NULL OR esp.hourly_rate <= max_hourly_rate)
    AND (industry_filter IS NULL OR industry_filter = ANY(esp.industries))
    AND (company_size_filter IS NULL OR company_size_filter = ANY(esp.company_sizes))
    AND (engagement_type_filter IS NULL OR engagement_type_filter = ANY(esp.engagement_types))
    AND (remote_preference IS NULL OR esp.remote_work_preference = remote_preference)
    AND (
      search_lat IS NULL OR search_lon IS NULL OR esp.remote_work_preference = 'remote_only' OR
      (up.latitude IS NOT NULL AND up.longitude IS NOT NULL AND 
       calculate_distance(search_lat, search_lon, up.latitude, up.longitude) <= radius_miles)
    )
  ORDER BY 
    CASE 
      WHEN sort_by = 'hourly_rate_low' THEN esp.hourly_rate
      ELSE NULL
    END ASC,
    CASE 
      WHEN sort_by = 'hourly_rate_high' THEN esp.hourly_rate
      ELSE NULL
    END DESC,
    CASE 
      WHEN sort_by = 'experience' THEN esp.years_experience
      ELSE NULL
    END DESC,
    CASE 
      WHEN sort_by = 'distance' AND search_lat IS NOT NULL AND search_lon IS NOT NULL 
      THEN calculate_distance(search_lat, search_lon, up.latitude, up.longitude)
      ELSE NULL
    END ASC,
    CASE 
      WHEN sort_by = 'rating' THEN pmp.average_rating
      ELSE NULL
    END DESC,
    esp.created_at DESC
  LIMIT limit_count OFFSET offset_count;
END;
$$ LANGUAGE plpgsql;

