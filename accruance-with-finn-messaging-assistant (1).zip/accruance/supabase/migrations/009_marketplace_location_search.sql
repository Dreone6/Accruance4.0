-- Enhanced Marketplace with Location and Advanced Search
-- Extends the marketplace infrastructure with location-based search and filtering

-- Add location data to user profiles
ALTER TABLE user_profiles 
ADD COLUMN IF NOT EXISTS address_line1 VARCHAR(255),
ADD COLUMN IF NOT EXISTS address_line2 VARCHAR(255),
ADD COLUMN IF NOT EXISTS city VARCHAR(100),
ADD COLUMN IF NOT EXISTS state_province VARCHAR(100),
ADD COLUMN IF NOT EXISTS postal_code VARCHAR(20),
ADD COLUMN IF NOT EXISTS country VARCHAR(100) DEFAULT 'United States',
ADD COLUMN IF NOT EXISTS latitude DECIMAL(10, 8),
ADD COLUMN IF NOT EXISTS longitude DECIMAL(11, 8),
ADD COLUMN IF NOT EXISTS location_verified BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS service_radius INTEGER DEFAULT 50, -- miles
ADD COLUMN IF NOT EXISTS remote_services BOOLEAN DEFAULT true;

-- Add location data to services
ALTER TABLE services
ADD COLUMN IF NOT EXISTS service_location VARCHAR(20) CHECK (service_location IN ('remote', 'on_site', 'hybrid', 'client_location')) DEFAULT 'remote',
ADD COLUMN IF NOT EXISTS service_radius INTEGER DEFAULT 50, -- miles for on-site services
ADD COLUMN IF NOT EXISTS address_line1 VARCHAR(255),
ADD COLUMN IF NOT EXISTS address_line2 VARCHAR(255),
ADD COLUMN IF NOT EXISTS city VARCHAR(100),
ADD COLUMN IF NOT EXISTS state_province VARCHAR(100),
ADD COLUMN IF NOT EXISTS postal_code VARCHAR(20),
ADD COLUMN IF NOT EXISTS country VARCHAR(100) DEFAULT 'United States',
ADD COLUMN IF NOT EXISTS latitude DECIMAL(10, 8),
ADD COLUMN IF NOT EXISTS longitude DECIMAL(11, 8);

-- Equipment marketplace table
CREATE TABLE IF NOT EXISTS equipment_listings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  seller_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(100) NOT NULL, -- 'office_equipment', 'financial_tools', 'business_assets', 'software'
  subcategory VARCHAR(100),
  condition VARCHAR(50) CHECK (condition IN ('new', 'like_new', 'good', 'fair', 'poor')) DEFAULT 'good',
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  currency VARCHAR(3) DEFAULT 'USD',
  listing_type VARCHAR(20) CHECK (listing_type IN ('sale', 'lease', 'rent', 'wanted')) DEFAULT 'sale',
  availability VARCHAR(20) CHECK (availability IN ('available', 'pending', 'sold', 'expired')) DEFAULT 'available',
  
  -- Location data
  pickup_location VARCHAR(20) CHECK (pickup_location IN ('pickup_only', 'delivery_available', 'shipping_available', 'digital_delivery')) DEFAULT 'pickup_only',
  address_line1 VARCHAR(255),
  address_line2 VARCHAR(255),
  city VARCHAR(100),
  state_province VARCHAR(100),
  postal_code VARCHAR(20),
  country VARCHAR(100) DEFAULT 'United States',
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  delivery_radius INTEGER DEFAULT 25, -- miles
  shipping_cost DECIMAL(8,2),
  
  -- Equipment details
  brand VARCHAR(100),
  model VARCHAR(100),
  year_manufactured INTEGER,
  serial_number VARCHAR(100),
  warranty_remaining VARCHAR(100),
  specifications JSONB DEFAULT '{}',
  images TEXT[], -- Array of image URLs
  
  -- Listing metadata
  views_count INTEGER DEFAULT 0,
  favorites_count INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT false,
  featured_until TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Wanted ads table
CREATE TABLE IF NOT EXISTS wanted_ads (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  poster_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(100) NOT NULL, -- 'services', 'equipment', 'partnerships'
  subcategory VARCHAR(100),
  ad_type VARCHAR(20) CHECK (ad_type IN ('service_wanted', 'equipment_wanted', 'partnership', 'collaboration')) DEFAULT 'service_wanted',
  budget_min DECIMAL(10,2),
  budget_max DECIMAL(10,2),
  currency VARCHAR(3) DEFAULT 'USD',
  urgency VARCHAR(20) CHECK (urgency IN ('low', 'medium', 'high', 'urgent')) DEFAULT 'medium',
  
  -- Location preferences
  location_preference VARCHAR(20) CHECK (location_preference IN ('remote', 'local', 'regional', 'national', 'international')) DEFAULT 'local',
  preferred_radius INTEGER DEFAULT 50, -- miles
  address_line1 VARCHAR(255),
  address_line2 VARCHAR(255),
  city VARCHAR(100),
  state_province VARCHAR(100),
  postal_code VARCHAR(20),
  country VARCHAR(100) DEFAULT 'United States',
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  
  -- Timeline
  needed_by TIMESTAMP WITH TIME ZONE,
  project_duration VARCHAR(100),
  
  -- Requirements
  requirements JSONB DEFAULT '{}',
  preferred_qualifications TEXT[],
  
  -- Responses
  responses_count INTEGER DEFAULT 0,
  status VARCHAR(20) CHECK (status IN ('active', 'in_progress', 'completed', 'cancelled', 'expired')) DEFAULT 'active',
  
  -- Metadata
  views_count INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT false,
  featured_until TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '30 days'),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Wanted ad responses table
CREATE TABLE IF NOT EXISTS wanted_ad_responses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  wanted_ad_id UUID REFERENCES wanted_ads(id) ON DELETE CASCADE,
  responder_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  proposed_price DECIMAL(10,2),
  proposed_timeline VARCHAR(100),
  attachments TEXT[], -- Array of file URLs
  status VARCHAR(20) CHECK (status IN ('pending', 'accepted', 'declined', 'withdrawn')) DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(wanted_ad_id, responder_id)
);

-- Marketplace search filters table (for saved searches)
CREATE TABLE IF NOT EXISTS marketplace_saved_searches (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  search_name VARCHAR(100) NOT NULL,
  search_type VARCHAR(20) CHECK (search_type IN ('services', 'equipment', 'wanted_ads')) NOT NULL,
  filters JSONB NOT NULL, -- Stores all filter criteria
  notification_enabled BOOLEAN DEFAULT true,
  last_notified TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Marketplace favorites table
CREATE TABLE IF NOT EXISTS marketplace_favorites (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  item_type VARCHAR(20) CHECK (item_type IN ('service', 'equipment', 'wanted_ad')) NOT NULL,
  item_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, item_type, item_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_location ON user_profiles(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_user_profiles_city_state ON user_profiles(city, state_province);
CREATE INDEX IF NOT EXISTS idx_user_profiles_postal_code ON user_profiles(postal_code);

CREATE INDEX IF NOT EXISTS idx_services_location ON services(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_services_service_location ON services(service_location);
CREATE INDEX IF NOT EXISTS idx_services_service_radius ON services(service_radius);
CREATE INDEX IF NOT EXISTS idx_services_city_state ON services(city, state_province);

CREATE INDEX IF NOT EXISTS idx_equipment_listings_category ON equipment_listings(category);
CREATE INDEX IF NOT EXISTS idx_equipment_listings_subcategory ON equipment_listings(subcategory);
CREATE INDEX IF NOT EXISTS idx_equipment_listings_condition ON equipment_listings(condition);
CREATE INDEX IF NOT EXISTS idx_equipment_listings_price ON equipment_listings(price);
CREATE INDEX IF NOT EXISTS idx_equipment_listings_listing_type ON equipment_listings(listing_type);
CREATE INDEX IF NOT EXISTS idx_equipment_listings_availability ON equipment_listings(availability);
CREATE INDEX IF NOT EXISTS idx_equipment_listings_location ON equipment_listings(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_equipment_listings_city_state ON equipment_listings(city, state_province);
CREATE INDEX IF NOT EXISTS idx_equipment_listings_pickup_location ON equipment_listings(pickup_location);

CREATE INDEX IF NOT EXISTS idx_wanted_ads_category ON wanted_ads(category);
CREATE INDEX IF NOT EXISTS idx_wanted_ads_subcategory ON wanted_ads(subcategory);
CREATE INDEX IF NOT EXISTS idx_wanted_ads_ad_type ON wanted_ads(ad_type);
CREATE INDEX IF NOT EXISTS idx_wanted_ads_urgency ON wanted_ads(urgency);
CREATE INDEX IF NOT EXISTS idx_wanted_ads_status ON wanted_ads(status);
CREATE INDEX IF NOT EXISTS idx_wanted_ads_location ON wanted_ads(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_wanted_ads_location_preference ON wanted_ads(location_preference);
CREATE INDEX IF NOT EXISTS idx_wanted_ads_needed_by ON wanted_ads(needed_by);

CREATE INDEX IF NOT EXISTS idx_wanted_ad_responses_ad_id ON wanted_ad_responses(wanted_ad_id);
CREATE INDEX IF NOT EXISTS idx_wanted_ad_responses_responder_id ON wanted_ad_responses(responder_id);
CREATE INDEX IF NOT EXISTS idx_wanted_ad_responses_status ON wanted_ad_responses(status);

CREATE INDEX IF NOT EXISTS idx_marketplace_saved_searches_user_id ON marketplace_saved_searches(user_id);
CREATE INDEX IF NOT EXISTS idx_marketplace_saved_searches_type ON marketplace_saved_searches(search_type);

CREATE INDEX IF NOT EXISTS idx_marketplace_favorites_user_id ON marketplace_favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_marketplace_favorites_item_type ON marketplace_favorites(item_type);

-- Enable RLS on new tables
ALTER TABLE equipment_listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE wanted_ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE wanted_ad_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketplace_saved_searches ENABLE ROW LEVEL SECURITY;
ALTER TABLE marketplace_favorites ENABLE ROW LEVEL SECURITY;

-- RLS Policies for equipment listings
CREATE POLICY "Anyone can view available equipment listings" ON equipment_listings
  FOR SELECT USING (availability = 'available');

CREATE POLICY "Users can manage their own equipment listings" ON equipment_listings
  FOR ALL USING (auth.uid() = seller_id);

-- RLS Policies for wanted ads
CREATE POLICY "Anyone can view active wanted ads" ON wanted_ads
  FOR SELECT USING (status = 'active');

CREATE POLICY "Users can manage their own wanted ads" ON wanted_ads
  FOR ALL USING (auth.uid() = poster_id);

-- RLS Policies for wanted ad responses
CREATE POLICY "Ad posters and responders can view responses" ON wanted_ad_responses
  FOR SELECT USING (
    auth.uid() = responder_id OR 
    auth.uid() IN (SELECT poster_id FROM wanted_ads WHERE id = wanted_ad_id)
  );

CREATE POLICY "Users can create responses to wanted ads" ON wanted_ad_responses
  FOR INSERT WITH CHECK (auth.uid() = responder_id);

CREATE POLICY "Responders can update their own responses" ON wanted_ad_responses
  FOR UPDATE USING (auth.uid() = responder_id);

-- RLS Policies for saved searches
CREATE POLICY "Users can manage their own saved searches" ON marketplace_saved_searches
  FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for favorites
CREATE POLICY "Users can manage their own favorites" ON marketplace_favorites
  FOR ALL USING (auth.uid() = user_id);

-- Function to calculate distance between two points (Haversine formula)
CREATE OR REPLACE FUNCTION calculate_distance(
  lat1 DECIMAL, lon1 DECIMAL, 
  lat2 DECIMAL, lon2 DECIMAL
) RETURNS DECIMAL AS $$
DECLARE
  R DECIMAL := 3959; -- Earth's radius in miles
  dLat DECIMAL;
  dLon DECIMAL;
  a DECIMAL;
  c DECIMAL;
BEGIN
  IF lat1 IS NULL OR lon1 IS NULL OR lat2 IS NULL OR lon2 IS NULL THEN
    RETURN NULL;
  END IF;
  
  dLat := RADIANS(lat2 - lat1);
  dLon := RADIANS(lon2 - lon1);
  
  a := SIN(dLat/2) * SIN(dLat/2) + 
       COS(RADIANS(lat1)) * COS(RADIANS(lat2)) * 
       SIN(dLon/2) * SIN(dLon/2);
  c := 2 * ATAN2(SQRT(a), SQRT(1-a));
  
  RETURN R * c;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Function to search services with location filtering
CREATE OR REPLACE FUNCTION search_services_with_location(
  search_lat DECIMAL DEFAULT NULL,
  search_lon DECIMAL DEFAULT NULL,
  radius_miles INTEGER DEFAULT 50,
  category_filter VARCHAR DEFAULT NULL,
  service_type_filter VARCHAR DEFAULT NULL,
  min_price DECIMAL DEFAULT NULL,
  max_price DECIMAL DEFAULT NULL,
  location_type VARCHAR DEFAULT NULL, -- 'remote', 'on_site', 'hybrid'
  sort_by VARCHAR DEFAULT 'relevance', -- 'relevance', 'price_low', 'price_high', 'distance', 'rating', 'newest'
  limit_count INTEGER DEFAULT 20,
  offset_count INTEGER DEFAULT 0
) RETURNS TABLE (
  service_id UUID,
  title VARCHAR,
  description TEXT,
  price DECIMAL,
  service_type VARCHAR,
  service_location VARCHAR,
  professional_name VARCHAR,
  professional_rating DECIMAL,
  distance_miles DECIMAL,
  city VARCHAR,
  state_province VARCHAR
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    s.id,
    s.title,
    s.description,
    s.price,
    s.service_type,
    s.service_location,
    up.full_name,
    pmp.average_rating,
    CASE 
      WHEN search_lat IS NOT NULL AND search_lon IS NOT NULL AND s.latitude IS NOT NULL AND s.longitude IS NOT NULL
      THEN calculate_distance(search_lat, search_lon, s.latitude, s.longitude)
      ELSE NULL
    END as distance,
    s.city,
    s.state_province
  FROM services s
  JOIN user_profiles up ON s.professional_id = up.id
  LEFT JOIN professional_marketplace_profiles pmp ON s.professional_id = pmp.professional_id
  WHERE s.is_active = true
    AND (category_filter IS NULL OR s.category_id::VARCHAR = category_filter)
    AND (service_type_filter IS NULL OR s.service_type = service_type_filter)
    AND (min_price IS NULL OR s.price >= min_price)
    AND (max_price IS NULL OR s.price <= max_price)
    AND (location_type IS NULL OR s.service_location = location_type)
    AND (
      search_lat IS NULL OR search_lon IS NULL OR s.service_location = 'remote' OR
      (s.latitude IS NOT NULL AND s.longitude IS NOT NULL AND 
       calculate_distance(search_lat, search_lon, s.latitude, s.longitude) <= radius_miles)
    )
  ORDER BY 
    CASE 
      WHEN sort_by = 'price_low' THEN s.price
      ELSE NULL
    END ASC,
    CASE 
      WHEN sort_by = 'price_high' THEN s.price
      ELSE NULL
    END DESC,
    CASE 
      WHEN sort_by = 'distance' AND search_lat IS NOT NULL AND search_lon IS NOT NULL 
      THEN calculate_distance(search_lat, search_lon, s.latitude, s.longitude)
      ELSE NULL
    END ASC,
    CASE 
      WHEN sort_by = 'rating' THEN pmp.average_rating
      ELSE NULL
    END DESC,
    CASE 
      WHEN sort_by = 'newest' THEN s.created_at
      ELSE NULL
    END DESC,
    s.is_featured DESC,
    s.created_at DESC
  LIMIT limit_count OFFSET offset_count;
END;
$$ LANGUAGE plpgsql;

-- Function to search equipment with location filtering
CREATE OR REPLACE FUNCTION search_equipment_with_location(
  search_lat DECIMAL DEFAULT NULL,
  search_lon DECIMAL DEFAULT NULL,
  radius_miles INTEGER DEFAULT 50,
  category_filter VARCHAR DEFAULT NULL,
  condition_filter VARCHAR DEFAULT NULL,
  min_price DECIMAL DEFAULT NULL,
  max_price DECIMAL DEFAULT NULL,
  listing_type_filter VARCHAR DEFAULT NULL,
  sort_by VARCHAR DEFAULT 'relevance',
  limit_count INTEGER DEFAULT 20,
  offset_count INTEGER DEFAULT 0
) RETURNS TABLE (
  equipment_id UUID,
  title VARCHAR,
  description TEXT,
  price DECIMAL,
  condition VARCHAR,
  listing_type VARCHAR,
  seller_name VARCHAR,
  distance_miles DECIMAL,
  city VARCHAR,
  state_province VARCHAR,
  pickup_location VARCHAR
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    e.id,
    e.title,
    e.description,
    e.price,
    e.condition,
    e.listing_type,
    up.full_name,
    CASE 
      WHEN search_lat IS NOT NULL AND search_lon IS NOT NULL AND e.latitude IS NOT NULL AND e.longitude IS NOT NULL
      THEN calculate_distance(search_lat, search_lon, e.latitude, e.longitude)
      ELSE NULL
    END as distance,
    e.city,
    e.state_province,
    e.pickup_location
  FROM equipment_listings e
  JOIN user_profiles up ON e.seller_id = up.id
  WHERE e.availability = 'available'
    AND (category_filter IS NULL OR e.category = category_filter)
    AND (condition_filter IS NULL OR e.condition = condition_filter)
    AND (min_price IS NULL OR e.price >= min_price)
    AND (max_price IS NULL OR e.price <= max_price)
    AND (listing_type_filter IS NULL OR e.listing_type = listing_type_filter)
    AND (
      search_lat IS NULL OR search_lon IS NULL OR e.pickup_location = 'shipping_available' OR
      (e.latitude IS NOT NULL AND e.longitude IS NOT NULL AND 
       calculate_distance(search_lat, search_lon, e.latitude, e.longitude) <= radius_miles)
    )
  ORDER BY 
    CASE 
      WHEN sort_by = 'price_low' THEN e.price
      ELSE NULL
    END ASC,
    CASE 
      WHEN sort_by = 'price_high' THEN e.price
      ELSE NULL
    END DESC,
    CASE 
      WHEN sort_by = 'distance' AND search_lat IS NOT NULL AND search_lon IS NOT NULL 
      THEN calculate_distance(search_lat, search_lon, e.latitude, e.longitude)
      ELSE NULL
    END ASC,
    CASE 
      WHEN sort_by = 'newest' THEN e.created_at
      ELSE NULL
    END DESC,
    e.is_featured DESC,
    e.created_at DESC
  LIMIT limit_count OFFSET offset_count;
END;
$$ LANGUAGE plpgsql;

-- Insert equipment categories
INSERT INTO marketplace_settings (setting_key, setting_value, data_type, description, is_public) VALUES
('equipment_categories', '["office_equipment", "financial_tools", "business_assets", "software", "furniture", "technology", "vehicles", "machinery"]', 'json', 'Available equipment categories', true),
('service_location_types', '["remote", "on_site", "hybrid", "client_location"]', 'json', 'Available service location types', true),
('equipment_conditions', '["new", "like_new", "good", "fair", "poor"]', 'json', 'Available equipment conditions', true),
('default_search_radius', '50', 'number', 'Default search radius in miles', true),
('max_search_radius', '500', 'number', 'Maximum search radius in miles', true)
ON CONFLICT (setting_key) DO NOTHING;

