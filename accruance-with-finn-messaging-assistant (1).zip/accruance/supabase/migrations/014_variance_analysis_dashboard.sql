-- Migration: 014_variance_analysis_dashboard.sql
-- Description: Add tables for variance analysis and business intelligence dashboard

-- Variance analysis periods for tracking performance
CREATE TABLE IF NOT EXISTS variance_analysis_periods (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    period_type VARCHAR(50) NOT NULL, -- 'monthly', 'quarterly', 'annually', 'custom'
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    budget_scenario_id UUID REFERENCES budget_scenarios(id),
    forecast_scenario_id UUID REFERENCES budget_scenarios(id),
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'closed', 'archived'
    is_current_period BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Variance analysis line items with actual vs budget vs forecast
CREATE TABLE IF NOT EXISTS variance_analysis_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id UUID NOT NULL REFERENCES variance_analysis_periods(id) ON DELETE CASCADE,
    account_id UUID REFERENCES accounts(id),
    line_item_name VARCHAR(255) NOT NULL,
    line_item_type VARCHAR(50) NOT NULL, -- 'revenue', 'cogs', 'opex', 'capex', 'other'
    category VARCHAR(100),
    subcategory VARCHAR(100),
    
    -- Financial amounts
    actual_amount DECIMAL(15,2) DEFAULT 0,
    budget_amount DECIMAL(15,2) DEFAULT 0,
    forecast_amount DECIMAL(15,2) DEFAULT 0,
    prior_year_amount DECIMAL(15,2) DEFAULT 0,
    
    -- Variance calculations
    budget_variance DECIMAL(15,2) DEFAULT 0, -- actual - budget
    budget_variance_percentage DECIMAL(8,4) DEFAULT 0,
    forecast_variance DECIMAL(15,2) DEFAULT 0, -- actual - forecast
    forecast_variance_percentage DECIMAL(8,4) DEFAULT 0,
    prior_year_variance DECIMAL(15,2) DEFAULT 0, -- actual - prior year
    prior_year_variance_percentage DECIMAL(8,4) DEFAULT 0,
    
    -- Analysis metadata
    variance_threshold_amount DECIMAL(15,2) DEFAULT 1000, -- Threshold for flagging variances
    variance_threshold_percentage DECIMAL(8,4) DEFAULT 0.05, -- 5% threshold
    is_favorable BOOLEAN, -- true if variance is favorable, false if unfavorable
    significance_level VARCHAR(20) DEFAULT 'normal', -- 'low', 'normal', 'high', 'critical'
    
    -- Commentary and explanations
    variance_explanation TEXT,
    action_required TEXT,
    responsible_person VARCHAR(255),
    
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Variance analysis KPIs and metrics
CREATE TABLE IF NOT EXISTS variance_analysis_kpis (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id UUID NOT NULL REFERENCES variance_analysis_periods(id) ON DELETE CASCADE,
    kpi_name VARCHAR(255) NOT NULL,
    kpi_category VARCHAR(100), -- 'financial', 'operational', 'customer', 'growth'
    kpi_type VARCHAR(50), -- 'ratio', 'percentage', 'count', 'currency', 'days'
    
    -- KPI values
    actual_value DECIMAL(15,4),
    budget_value DECIMAL(15,4),
    forecast_value DECIMAL(15,4),
    target_value DECIMAL(15,4),
    prior_period_value DECIMAL(15,4),
    
    -- Variance calculations
    budget_variance DECIMAL(15,4),
    budget_variance_percentage DECIMAL(8,4),
    target_variance DECIMAL(15,4),
    target_variance_percentage DECIMAL(8,4),
    
    -- Performance indicators
    performance_status VARCHAR(20), -- 'excellent', 'good', 'warning', 'critical'
    trend_direction VARCHAR(20), -- 'improving', 'stable', 'declining'
    
    -- Display settings
    display_format VARCHAR(50) DEFAULT 'number', -- 'number', 'currency', 'percentage'
    decimal_places INTEGER DEFAULT 2,
    is_visible BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Variance analysis comments and explanations
CREATE TABLE IF NOT EXISTS variance_analysis_comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_id UUID NOT NULL REFERENCES variance_analysis_periods(id) ON DELETE CASCADE,
    item_id UUID REFERENCES variance_analysis_items(id) ON DELETE CASCADE,
    kpi_id UUID REFERENCES variance_analysis_kpis(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id),
    
    comment_type VARCHAR(50) NOT NULL, -- 'explanation', 'action_plan', 'note', 'alert'
    comment_text TEXT NOT NULL,
    is_public BOOLEAN DEFAULT true,
    is_resolved BOOLEAN DEFAULT false,
    
    -- Tagging and categorization
    tags JSONB, -- Array of tags for categorization
    priority VARCHAR(20) DEFAULT 'normal', -- 'low', 'normal', 'high', 'urgent'
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Variance analysis alerts and notifications
CREATE TABLE IF NOT EXISTS variance_analysis_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    period_id UUID NOT NULL REFERENCES variance_analysis_periods(id) ON DELETE CASCADE,
    item_id UUID REFERENCES variance_analysis_items(id) ON DELETE CASCADE,
    kpi_id UUID REFERENCES variance_analysis_kpis(id) ON DELETE CASCADE,
    
    alert_type VARCHAR(50) NOT NULL, -- 'variance_threshold', 'kpi_target', 'trend_change', 'manual'
    alert_level VARCHAR(20) NOT NULL, -- 'info', 'warning', 'error', 'critical'
    alert_title VARCHAR(255) NOT NULL,
    alert_message TEXT NOT NULL,
    
    -- Alert conditions
    threshold_amount DECIMAL(15,2),
    threshold_percentage DECIMAL(8,4),
    condition_met BOOLEAN DEFAULT true,
    
    -- Alert status
    is_active BOOLEAN DEFAULT true,
    is_acknowledged BOOLEAN DEFAULT false,
    acknowledged_by UUID REFERENCES auth.users(id),
    acknowledged_at TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Variance analysis drill-through data
CREATE TABLE IF NOT EXISTS variance_analysis_drill_through (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_id UUID NOT NULL REFERENCES variance_analysis_items(id) ON DELETE CASCADE,
    transaction_id UUID REFERENCES transactions(id),
    invoice_id UUID REFERENCES invoices(id),
    
    -- Drill-through metadata
    drill_level INTEGER DEFAULT 1, -- 1=summary, 2=detail, 3=transaction
    parent_drill_id UUID REFERENCES variance_analysis_drill_through(id),
    
    -- Financial data
    amount DECIMAL(15,2),
    date DATE,
    description TEXT,
    reference VARCHAR(255),
    
    -- Categorization
    category VARCHAR(100),
    subcategory VARCHAR(100),
    tags JSONB,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Variance analysis dashboard configurations
CREATE TABLE IF NOT EXISTS variance_analysis_dashboards (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Dashboard configuration
    dashboard_config JSONB NOT NULL, -- Layout, widgets, filters, etc.
    default_period_id UUID REFERENCES variance_analysis_periods(id),
    
    -- Display settings
    is_default BOOLEAN DEFAULT false,
    is_public BOOLEAN DEFAULT false,
    refresh_frequency INTEGER DEFAULT 60, -- Minutes
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_variance_analysis_periods_user_id ON variance_analysis_periods(user_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_periods_dates ON variance_analysis_periods(period_start, period_end);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_periods_current ON variance_analysis_periods(is_current_period);

CREATE INDEX IF NOT EXISTS idx_variance_analysis_items_period_id ON variance_analysis_items(period_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_items_account_id ON variance_analysis_items(account_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_items_type ON variance_analysis_items(line_item_type);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_items_significance ON variance_analysis_items(significance_level);

CREATE INDEX IF NOT EXISTS idx_variance_analysis_kpis_period_id ON variance_analysis_kpis(period_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_kpis_category ON variance_analysis_kpis(kpi_category);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_kpis_status ON variance_analysis_kpis(performance_status);

CREATE INDEX IF NOT EXISTS idx_variance_analysis_comments_period_id ON variance_analysis_comments(period_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_comments_item_id ON variance_analysis_comments(item_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_comments_user_id ON variance_analysis_comments(user_id);

CREATE INDEX IF NOT EXISTS idx_variance_analysis_alerts_user_id ON variance_analysis_alerts(user_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_alerts_period_id ON variance_analysis_alerts(period_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_alerts_active ON variance_analysis_alerts(is_active);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_alerts_level ON variance_analysis_alerts(alert_level);

CREATE INDEX IF NOT EXISTS idx_variance_analysis_drill_through_item_id ON variance_analysis_drill_through(item_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_drill_through_transaction_id ON variance_analysis_drill_through(transaction_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_drill_through_level ON variance_analysis_drill_through(drill_level);

CREATE INDEX IF NOT EXISTS idx_variance_analysis_dashboards_user_id ON variance_analysis_dashboards(user_id);
CREATE INDEX IF NOT EXISTS idx_variance_analysis_dashboards_default ON variance_analysis_dashboards(is_default);

-- Row Level Security (RLS) policies
ALTER TABLE variance_analysis_periods ENABLE ROW LEVEL SECURITY;
ALTER TABLE variance_analysis_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE variance_analysis_kpis ENABLE ROW LEVEL SECURITY;
ALTER TABLE variance_analysis_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE variance_analysis_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE variance_analysis_drill_through ENABLE ROW LEVEL SECURITY;
ALTER TABLE variance_analysis_dashboards ENABLE ROW LEVEL SECURITY;

-- RLS Policies for variance_analysis_periods
CREATE POLICY "Users can manage their own variance analysis periods" ON variance_analysis_periods
    FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for variance_analysis_items
CREATE POLICY "Users can manage variance items for their periods" ON variance_analysis_items
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM variance_analysis_periods 
            WHERE variance_analysis_periods.id = variance_analysis_items.period_id 
            AND variance_analysis_periods.user_id = auth.uid()
        )
    );

-- RLS Policies for variance_analysis_kpis
CREATE POLICY "Users can manage KPIs for their periods" ON variance_analysis_kpis
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM variance_analysis_periods 
            WHERE variance_analysis_periods.id = variance_analysis_kpis.period_id 
            AND variance_analysis_periods.user_id = auth.uid()
        )
    );

-- RLS Policies for variance_analysis_comments
CREATE POLICY "Users can manage comments for their periods" ON variance_analysis_comments
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM variance_analysis_periods 
            WHERE variance_analysis_periods.id = variance_analysis_comments.period_id 
            AND variance_analysis_periods.user_id = auth.uid()
        )
    );

-- RLS Policies for variance_analysis_alerts
CREATE POLICY "Users can manage their own variance alerts" ON variance_analysis_alerts
    FOR ALL USING (auth.uid() = user_id);

-- RLS Policies for variance_analysis_drill_through
CREATE POLICY "Users can view drill-through data for their items" ON variance_analysis_drill_through
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM variance_analysis_items 
            JOIN variance_analysis_periods ON variance_analysis_periods.id = variance_analysis_items.period_id
            WHERE variance_analysis_items.id = variance_analysis_drill_through.item_id 
            AND variance_analysis_periods.user_id = auth.uid()
        )
    );

-- RLS Policies for variance_analysis_dashboards
CREATE POLICY "Users can manage their own variance dashboards" ON variance_analysis_dashboards
    FOR ALL USING (auth.uid() = user_id);

-- Functions for automatic timestamp updates
CREATE OR REPLACE FUNCTION update_variance_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for automatic timestamp updates
CREATE TRIGGER update_variance_analysis_periods_updated_at
    BEFORE UPDATE ON variance_analysis_periods
    FOR EACH ROW
    EXECUTE FUNCTION update_variance_updated_at();

CREATE TRIGGER update_variance_analysis_items_updated_at
    BEFORE UPDATE ON variance_analysis_items
    FOR EACH ROW
    EXECUTE FUNCTION update_variance_updated_at();

CREATE TRIGGER update_variance_analysis_kpis_updated_at
    BEFORE UPDATE ON variance_analysis_kpis
    FOR EACH ROW
    EXECUTE FUNCTION update_variance_updated_at();

CREATE TRIGGER update_variance_analysis_comments_updated_at
    BEFORE UPDATE ON variance_analysis_comments
    FOR EACH ROW
    EXECUTE FUNCTION update_variance_updated_at();

CREATE TRIGGER update_variance_analysis_alerts_updated_at
    BEFORE UPDATE ON variance_analysis_alerts
    FOR EACH ROW
    EXECUTE FUNCTION update_variance_updated_at();

CREATE TRIGGER update_variance_analysis_dashboards_updated_at
    BEFORE UPDATE ON variance_analysis_dashboards
    FOR EACH ROW
    EXECUTE FUNCTION update_variance_updated_at();

-- Function to calculate variance analysis for a period
CREATE OR REPLACE FUNCTION calculate_variance_analysis(period_id UUID)
RETURNS JSONB AS $$
DECLARE
    period_record RECORD;
    result JSONB;
    total_items INTEGER := 0;
    significant_variances INTEGER := 0;
    favorable_variances INTEGER := 0;
    unfavorable_variances INTEGER := 0;
BEGIN
    -- Get period details
    SELECT * INTO period_record FROM variance_analysis_periods WHERE id = period_id;
    
    IF NOT FOUND THEN
        RETURN jsonb_build_object('error', 'Period not found');
    END IF;
    
    -- Calculate variances for all items in the period
    UPDATE variance_analysis_items 
    SET 
        budget_variance = actual_amount - budget_amount,
        budget_variance_percentage = CASE 
            WHEN budget_amount != 0 THEN (actual_amount - budget_amount) / budget_amount 
            ELSE 0 
        END,
        forecast_variance = actual_amount - forecast_amount,
        forecast_variance_percentage = CASE 
            WHEN forecast_amount != 0 THEN (actual_amount - forecast_amount) / forecast_amount 
            ELSE 0 
        END,
        prior_year_variance = actual_amount - prior_year_amount,
        prior_year_variance_percentage = CASE 
            WHEN prior_year_amount != 0 THEN (actual_amount - prior_year_amount) / prior_year_amount 
            ELSE 0 
        END,
        is_favorable = CASE 
            WHEN line_item_type = 'revenue' THEN (actual_amount - budget_amount) > 0
            ELSE (actual_amount - budget_amount) < 0
        END,
        significance_level = CASE 
            WHEN ABS(actual_amount - budget_amount) > variance_threshold_amount 
                OR ABS((actual_amount - budget_amount) / NULLIF(budget_amount, 0)) > variance_threshold_percentage 
            THEN 'high'
            WHEN ABS(actual_amount - budget_amount) > (variance_threshold_amount * 0.5) 
                OR ABS((actual_amount - budget_amount) / NULLIF(budget_amount, 0)) > (variance_threshold_percentage * 0.5) 
            THEN 'normal'
            ELSE 'low'
        END,
        updated_at = NOW()
    WHERE variance_analysis_items.period_id = calculate_variance_analysis.period_id;
    
    -- Get summary statistics
    SELECT 
        COUNT(*),
        COUNT(*) FILTER (WHERE significance_level IN ('high', 'critical')),
        COUNT(*) FILTER (WHERE is_favorable = true),
        COUNT(*) FILTER (WHERE is_favorable = false)
    INTO total_items, significant_variances, favorable_variances, unfavorable_variances
    FROM variance_analysis_items 
    WHERE variance_analysis_items.period_id = calculate_variance_analysis.period_id;
    
    -- Build result
    result := jsonb_build_object(
        'period_id', period_id,
        'total_items', total_items,
        'significant_variances', significant_variances,
        'favorable_variances', favorable_variances,
        'unfavorable_variances', unfavorable_variances,
        'calculation_date', NOW()
    );
    
    RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to generate variance analysis alerts
CREATE OR REPLACE FUNCTION generate_variance_alerts(period_id UUID)
RETURNS INTEGER AS $$
DECLARE
    item_record RECORD;
    kpi_record RECORD;
    alert_count INTEGER := 0;
    period_user_id UUID;
BEGIN
    -- Get the user ID for the period
    SELECT user_id INTO period_user_id FROM variance_analysis_periods WHERE id = period_id;
    
    IF NOT FOUND THEN
        RETURN 0;
    END IF;
    
    -- Generate alerts for significant variances
    FOR item_record IN 
        SELECT * FROM variance_analysis_items 
        WHERE variance_analysis_items.period_id = generate_variance_alerts.period_id
        AND significance_level IN ('high', 'critical')
    LOOP
        INSERT INTO variance_analysis_alerts (
            user_id, period_id, item_id, alert_type, alert_level, 
            alert_title, alert_message, threshold_amount, threshold_percentage
        ) VALUES (
            period_user_id, period_id, item_record.id, 'variance_threshold',
            CASE WHEN item_record.significance_level = 'critical' THEN 'error' ELSE 'warning' END,
            'Significant Variance: ' || item_record.line_item_name,
            'Variance of ' || item_record.budget_variance || ' (' || 
            ROUND(item_record.budget_variance_percentage * 100, 2) || '%) detected',
            item_record.variance_threshold_amount,
            item_record.variance_threshold_percentage
        );
        
        alert_count := alert_count + 1;
    END LOOP;
    
    -- Generate alerts for KPI targets
    FOR kpi_record IN 
        SELECT * FROM variance_analysis_kpis 
        WHERE variance_analysis_kpis.period_id = generate_variance_alerts.period_id
        AND performance_status IN ('warning', 'critical')
    LOOP
        INSERT INTO variance_analysis_alerts (
            user_id, period_id, kpi_id, alert_type, alert_level, 
            alert_title, alert_message
        ) VALUES (
            period_user_id, period_id, kpi_record.id, 'kpi_target',
            CASE WHEN kpi_record.performance_status = 'critical' THEN 'error' ELSE 'warning' END,
            'KPI Alert: ' || kpi_record.kpi_name,
            'KPI performance is ' || kpi_record.performance_status || 
            ' with variance of ' || ROUND(kpi_record.target_variance_percentage * 100, 2) || '%'
        );
        
        alert_count := alert_count + 1;
    END LOOP;
    
    RETURN alert_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get variance analysis summary
CREATE OR REPLACE FUNCTION get_variance_analysis_summary(user_id UUID, period_id UUID DEFAULT NULL)
RETURNS JSONB AS $$
DECLARE
    summary JSONB;
    current_period_id UUID;
BEGIN
    -- Use current period if none specified
    IF period_id IS NULL THEN
        SELECT id INTO current_period_id 
        FROM variance_analysis_periods 
        WHERE variance_analysis_periods.user_id = get_variance_analysis_summary.user_id 
        AND is_current_period = true 
        LIMIT 1;
    ELSE
        current_period_id := period_id;
    END IF;
    
    -- Build summary
    SELECT jsonb_build_object(
        'period_id', current_period_id,
        'total_revenue_actual', COALESCE(SUM(actual_amount) FILTER (WHERE line_item_type = 'revenue'), 0),
        'total_revenue_budget', COALESCE(SUM(budget_amount) FILTER (WHERE line_item_type = 'revenue'), 0),
        'total_expenses_actual', COALESCE(SUM(actual_amount) FILTER (WHERE line_item_type IN ('cogs', 'opex')), 0),
        'total_expenses_budget', COALESCE(SUM(budget_amount) FILTER (WHERE line_item_type IN ('cogs', 'opex')), 0),
        'significant_variances', COUNT(*) FILTER (WHERE significance_level IN ('high', 'critical')),
        'favorable_variances', COUNT(*) FILTER (WHERE is_favorable = true),
        'unfavorable_variances', COUNT(*) FILTER (WHERE is_favorable = false),
        'total_items', COUNT(*)
    )
    INTO summary
    FROM variance_analysis_items vai
    JOIN variance_analysis_periods vap ON vap.id = vai.period_id
    WHERE vap.user_id = get_variance_analysis_summary.user_id
    AND vai.period_id = current_period_id;
    
    RETURN summary;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Insert default KPIs for new periods
CREATE OR REPLACE FUNCTION create_default_kpis_for_period(period_id UUID)
RETURNS INTEGER AS $$
DECLARE
    kpi_count INTEGER := 0;
BEGIN
    -- Insert default financial KPIs
    INSERT INTO variance_analysis_kpis (
        period_id, kpi_name, kpi_category, kpi_type, display_format, sort_order
    ) VALUES 
    (period_id, 'Revenue Growth Rate', 'financial', 'percentage', 'percentage', 1),
    (period_id, 'Gross Margin %', 'financial', 'percentage', 'percentage', 2),
    (period_id, 'Operating Margin %', 'financial', 'percentage', 'percentage', 3),
    (period_id, 'EBITDA', 'financial', 'currency', 'currency', 4),
    (period_id, 'Cash Flow', 'financial', 'currency', 'currency', 5),
    (period_id, 'Customer Acquisition Cost', 'customer', 'currency', 'currency', 6),
    (period_id, 'Customer Lifetime Value', 'customer', 'currency', 'currency', 7),
    (period_id, 'Monthly Recurring Revenue', 'growth', 'currency', 'currency', 8),
    (period_id, 'Churn Rate', 'customer', 'percentage', 'percentage', 9),
    (period_id, 'Employee Productivity', 'operational', 'ratio', 'number', 10);
    
    GET DIAGNOSTICS kpi_count = ROW_COUNT;
    
    RETURN kpi_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add comments for documentation
COMMENT ON TABLE variance_analysis_periods IS 'Time periods for variance analysis tracking';
COMMENT ON TABLE variance_analysis_items IS 'Line items with actual vs budget vs forecast comparisons';
COMMENT ON TABLE variance_analysis_kpis IS 'Key performance indicators with variance tracking';
COMMENT ON TABLE variance_analysis_comments IS 'Comments and explanations for variances';
COMMENT ON TABLE variance_analysis_alerts IS 'Automated alerts for significant variances';
COMMENT ON TABLE variance_analysis_drill_through IS 'Drill-through data for detailed analysis';
COMMENT ON TABLE variance_analysis_dashboards IS 'Custom dashboard configurations';

COMMENT ON FUNCTION calculate_variance_analysis IS 'Calculate all variances for a given period';
COMMENT ON FUNCTION generate_variance_alerts IS 'Generate alerts for significant variances and KPI misses';
COMMENT ON FUNCTION get_variance_analysis_summary IS 'Get summary statistics for variance analysis';
COMMENT ON FUNCTION create_default_kpis_for_period IS 'Create default KPIs when a new period is created';

