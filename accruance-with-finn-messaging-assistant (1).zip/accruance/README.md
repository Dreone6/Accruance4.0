# Accruance - AI-Powered Financial Dashboard

A comprehensive financial management platform with AI assistant, professional marketplace, and advanced business tools.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Supabase account
- Required API keys (see below)

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/Dreone6/Accruance.git
cd Accruance
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
cp .env.example .env.local
```

4. **Add your API keys to .env.local** (see API Keys section below)

5. **Run the development server**
```bash
npm run dev
```

6. **Open your browser**
Navigate to [http://localhost:3000](http://localhost:3000)

## 🔑 Required API Keys

### CRITICAL (App won't work without these):

#### OpenAI API Key
- **Get it**: https://platform.openai.com/api-keys
- **Cost**: ~$20-50/month
- **Purpose**: Powers FINN AI assistant
- **Add to .env.local**: `OPENAI_API_KEY=sk-...`

#### Mapbox Access Token  
- **Get it**: https://account.mapbox.com/access-tokens/
- **Cost**: Free tier (50k requests/month)
- **Purpose**: Location-based marketplace search
- **Add to .env.local**: `NEXT_PUBLIC_MAPBOX_TOKEN=pk....`

### OPTIONAL (Enhanced features):

#### Google Maps API Key
- **Get it**: https://console.cloud.google.com/apis/credentials
- **Purpose**: Backup location services
- **Add to .env.local**: `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=...`

## ✨ Features

### 🤖 FINN AI Assistant
- Comprehensive financial expertise
- Tax strategy and compliance advice
- Business structuring recommendations
- SaaS metrics and analysis
- International tax considerations

### 💼 Professional Marketplace
- **Services**: Financial professionals, C-suite executives
- **Equipment**: Computer hardware, software licenses, office furniture
- **Real Estate**: Office spaces, coworking, executive suites
- **Location-based search** with radius filtering
- **Advanced filtering** and sorting options

### 📊 Financial Dashboard
- Real-time financial metrics
- Transaction management
- Invoice processing
- Receipt OCR and management
- Advanced reporting

### 🔐 Enterprise Security
- Row-level security (RLS)
- User authentication
- Protected routes
- Audit trails

## 🏗️ Architecture

### Tech Stack
- **Frontend**: Next.js 14, React, TypeScript, Tailwind CSS
- **Backend**: Next.js API routes, Supabase
- **Database**: PostgreSQL (Supabase)
- **Authentication**: Supabase Auth
- **Payments**: Stripe
- **AI**: OpenAI GPT-4
- **Maps**: Mapbox/Google Maps

### Database
- 10 comprehensive migration files
- Location-based search functions
- Advanced filtering capabilities
- Performance-optimized indexes

## 📁 Project Structure

```
src/
├── app/                    # Next.js app router
│   ├── api/               # API endpoints
│   ├── auth/              # Authentication pages
│   ├── dashboard/         # Dashboard pages
│   ├── marketplace/       # Marketplace pages
│   └── ...
├── components/            # React components
│   ├── ui/               # Base UI components
│   ├── dashboard/        # Dashboard components
│   ├── marketplace/      # Marketplace components
│   └── ...
├── lib/                  # Utility libraries
│   ├── supabase/        # Supabase configuration
│   ├── auth-context.tsx # Authentication context
│   └── ...
└── middleware.ts         # Route protection
```

## 🚀 Deployment

### Vercel (Recommended)
1. Connect your GitHub repository to Vercel
2. Add environment variables in Vercel dashboard
3. Deploy automatically on push

### Environment Variables for Production
```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
OPENAI_API_KEY=your_openai_key
NEXT_PUBLIC_MAPBOX_TOKEN=your_mapbox_token
STRIPE_SECRET_KEY=your_stripe_secret_key
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_publishable_key
```

## 📈 Scaling Plan

### Phase 1: Foundation (0-1000 users)
- Core financial dashboard
- Basic user authentication
- FINN AI assistant

### Phase 2: Basic Marketplace (1000+ users)
- Services marketplace
- Professional networking
- Location-based search

### Phase 3: Complete Marketplace (5000+ users)
- Equipment marketplace
- Real estate listings
- Executive services
- Advanced features

## 🧪 Testing

```bash
# Run tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm run test:coverage
```

## 📚 Documentation

- [API Keys Integration Guide](./docs/api-keys-integration-guide.md)
- [GitHub Setup Guide](./docs/github-setup-guide.md)
- [Marketplace Scaling Plan](./docs/comprehensive-marketplace-scaling-plan.md)
- [Security Audit Report](./docs/security-audit-report.md)
- [Deployment Guide](./docs/deployment-guide.md)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support, email support@accruance.com or join our Discord community.

## 🎯 Roadmap

- [ ] Mobile app (React Native)
- [ ] Advanced AI features
- [ ] International expansion
- [ ] Enterprise features
- [ ] API marketplace

---

**Built with ❤️ by the Accruance team**

